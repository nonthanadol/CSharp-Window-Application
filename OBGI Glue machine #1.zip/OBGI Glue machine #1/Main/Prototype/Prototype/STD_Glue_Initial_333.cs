﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using Communication.EtherCAT;
using Communication.IO_Commu;
using Equipment_Control;
using Equipment_Control.IO_Control;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.Interface;
using Equipment_Control.Camera;

namespace Prototype
{
    public class STD_Glue_Initial_333
    {
        IVariableShare Common;
        XYZ_Motion Servo_XYZ;
        DMV_VGR_Camera Camera_IP;

        [DllImport("kernel32.dll")]
        public static extern uint GetTickCount();

        ulong _startTime;
        uint _spanTime;
        public bool IsUsing { get; private set; }

        int X_Position;
        int Y_Position;
        int Z_Position;
        int RZ_Position;

        static STD_Glue_Error_333 P_Error;

        bool bChk_X1_MoveDone;
        bool bChk_Y1_MoveDone;
        bool bChk_Y2_MoveDone;
        bool bChk_Z1_MoveDone;
        bool bChk_RZ_MoveDone;
        bool bChk_YSyc_MoveDone;
        bool bChk_XYMulti_MoveDone;
        bool bChk_XYZ_MotionBuffer_MoveDone;

        int iSPD_Movement_Fast = 100000;
        int iSPD_LineMove_Normal = 15000;
        int iSPD_LineMove_Slow = 1000;
        int iSPD_RZ_Move = 200;

        String sql;
        String CallPosition;

        SqlConnection Conn;

        public STD_Glue_Initial_333(IVariableShare common, XYZ_Motion ServoXYZ, DMV_VGR_Camera CameraIP)
        {
            Common = common;
            Servo_XYZ = ServoXYZ;
            Camera_IP = CameraIP;

            P_Error = new STD_Glue_Error_333(Common, Servo_XYZ, Camera_IP);
        }

        public void Machine_Initial()
        {
            while (true)
            {
                //Initial Flow
                if (Common.bChkInitialButtonPush)
                {
                    if (!Common.bFlgInitial_Finished && Common.bChkAuto_Manual && !Common.bChkAlarm)
                    {
                        Common.bChkInitialButtonPush = false;
                        Common.bFlgInitial_onWork = true;
                        while (Common.bFlgInitial_onWork && !Common.bChkAlarm)
                        {
                            switch (Common.iInitialFlow_Step)
                            {
                                case 0:
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;
                                        P_Error.MachineResetError();

                                        if (Common.IOTable.DI[3, 4].State && Common.IOTable.DI[3, 9].State) { Common.IOTable.DO[3, 10].Reset(); Common.IOTable.DO[3, 11].Set(); Common.bToolsClamp = false; } // if all tools are in position -> un clamp
                                        else { Common.IOTable.DO[3, 10].Set(); Common.IOTable.DO[3, 11].Reset(); Common.bToolsClamp = true; }
                                        Thread.Sleep(1000);

                                        Common.iInitialFlow_Step = 10;
                                    }
                                    break;
                                case 10:
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;

                                        //////////////////////////////////////////////////////////////////////// Need Test ////////////////////////////////////////////////////////////////////////

                                        if (Common.bChkFirstInitial)
                                        {
                                            //Check Position if Z < Z safety = move Y out from component
                                            if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                            {
                                                Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Slow, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                                Thread.Sleep(300); CallCheckFinishMove();
                                                while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }

                                            }
                                        }

                                        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                                        //Z Home
                                        Servo_XYZ.Z1_AXIS.HomeMove();
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }

                                        Common.iInitialFlow_Step = 20;
                                    }
                                    break;
                                case 20:
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;

                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                        //Y Duo Home
                                        Servo_XYZ.Y_Sync_Axis.Enable_Follow_Enableushort(); //Set enable Synchro Y in Gentry command (after home finish need to diable Synchro Y in Gentry command)
                                        Servo_XYZ.Y_Sync_Axis.Set_Home_Config(); //Set Home config in Gentry command
                                        Servo_XYZ.Y_Sync_Axis.Home_Edge_Trigger_Level(); //Set Home edge in Gentry command
                                        Servo_XYZ.Y_Sync_Axis.Gantry_Home_Move(); //Start Y Duo home move in Gentry command

                                        //RZ Home
                                        Servo_XYZ.RZ_AXIS.HomeMove();
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }

                                        CallPosition = "H1";//Target to Home position
                                        CallPositionXYZ();//Call Home position (Referance from "H1")

                                        Thread.Sleep(1000);
                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                        Servo_XYZ.RZ_AXIS.PosMoveAbs(RZ_Position, iSPD_RZ_Move);//Move RZ to home

                                        //X Home
                                        Servo_XYZ.X1_AXIS.HomeMove();

                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }


                                        Common.iInitialFlow_Step = 30;
                                    }
                                    break;
                                case 30:
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;

                                        CallPosition = "H1";//Target to Home position
                                        CallPositionXYZ();//Call Home position (Referance from "H1")
                                        Common.iMem_X_Home_Pos = X_Position;//For save X Home position to variable
                                        Common.iMem_Y_Home_Pos = Y_Position;//For save Y Home position to variable
                                        Common.iMem_Z_Home_Pos = Z_Position;//For save Z Home position to variable
                                        Common.iMem_RZ_Home_Pos = RZ_Position;//For save RZ Home position to variable

                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                                        Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Movement_Fast);//Move Z up to home
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                                        Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, Common.iMem_X_Home_Pos, Common.iMem_Y_Home_Pos);//Move XY to home
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone /*|| !bChk_Y2_MoveDone*/ || !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                        Common.iInitialFlow_Step = 40;
                                    }
                                    break;
                                case 40:
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; /*bChk_Y2_MoveDone = false;*/ bChk_Z1_MoveDone = false;

                                        Common.iInitialFlow_Step = 1000;

                                    }
                                    break;
                                case 1000:
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone /*&& bChk_Y2_MoveDone*/ && bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; /*bChk_Y2_MoveDone = false;*/ bChk_Z1_MoveDone = false;


                                        Common.IOTable.DO[1, 0].Set();//Upper Stopper ON
                                        Common.IOTable.DO[1, 7].Set();//Under Stopper ON
                                        Common.IOTable.DO[1, 14].Reset();//Un-Clamp
                                        Common.IOTable.DO[2, 0].Reset();//RFID L IN
                                        Common.IOTable.DO[2, 2].Reset();//RFID R IN
                                        Common.iInitialFlow_Step = 9000;
                                    }
                                    break;
                                case 9000:
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; /*bChk_Y2_MoveDone = false;*/ bChk_Z1_MoveDone = false;


                                        Common.iToolsPick = 0; //Reset tools pick status(Haven't tool on robot)
                                        Common.iInitialFlow_Step = 0; //Reset Initial Flow Step
                                        Common.bFlgInitial_Finished = true; //Set Flag Initial Finished
                                        Common.bFlgInitial_onWork = false; //For break "while (!Common.bFlgInitial_onWork)"
                                        Common.bFlgAlreadyApplyGlue = false;
                                    }
                                    break;
                            }
                        }
                    }
                    else { Common.bChkInitialButtonPush = false; }
                }

                //Calibration tools
                if (Common.bFlgInitial_Finished && Common.bCalibrationToolsTrig)
                {
                    Common.bCalibrationToolsTrig = false;
                    Common.bCalibration_onwork = true;
                    while (Common.bCalibration_onwork && !Common.bChkAlarm)
                    {
                        switch (Common.bCalibration_FlowStep)
                        {
                            case 0:
                                Thread.Sleep(300); CallCheckFinishMove();
                                if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                {
                                    bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;

                                    if (Common.iNozzle_Cal_Select == 1)
                                    {
                                        CallPosition = "CT1_1";
                                        CallPositionXYZ();//Call position (Referance from "CT1_1")
                                    }
                                    else
                                    {
                                        CallPosition = "CT2_1";
                                        CallPositionXYZ();//Call position (Referance from "CT2_1")
                                    }

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                                    Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Movement_Fast);//Move Z up to home
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                    Servo_XYZ.RZ_AXIS.PosMoveAbs(Common.iMem_RZ_Home_Pos, iSPD_Movement_Fast);//Move RZ to home
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                                    Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_LineMove_Normal);//Move Z
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (Common.IOTable.DI[2, 4].State || Common.IOTable.DI[2, 5].State || Common.IOTable.DI[2, 6].State) { Servo_XYZ.Z1_AXIS.EStop(); break; } }

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                                    Servo_XYZ.Z1_AXIS.PosMoveRel(-6000, iSPD_LineMove_Slow);//Move Z -6,000
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (Common.IOTable.DI[2, 4].State || Common.IOTable.DI[2, 5].State) { Thread.Sleep(300); Servo_XYZ.Z1_AXIS.EStop(); break; } }

                                    //IF Sensor all OFF -> Alarm
                                    //if (!Common.IOTable.DI[2, 4].State && !Common.IOTable.DI[2, 5].State && !Common.IOTable.DI[2, 6].State)
                                    //{
                                    //    Common.bCalibrationAlarm = true; //Error can't find X sensor position
                                    //}

                                    //Check Z sensor cal on for stop move Z.
                                    //if (Common.IOTable.DI[2, 6].State) { Servo_XYZ.Z1_AXIS.EStop(); }


                                    Common.bCalibration_FlowStep = 10;
                                }
                                break;
                            case 10:
                                Thread.Sleep(300); CallCheckFinishMove();
                                if (bChk_X1_MoveDone && bChk_Y1_MoveDone && bChk_Y2_MoveDone && bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                {
                                    bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;

                                    //Check X and find position.

                                    if (!Common.IOTable.DI[2, 5].State)
                                    {
                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                        //Check X sensor cal on for stop move X.
                                        //Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Slow, X_Position + 5500, Y_Position);//Move XY
                                        Servo_XYZ.X1_AXIS.PosMoveAbs(X_Position + 5500, iSPD_LineMove_Slow);
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || !bChk_Y2_MoveDone || !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (Common.IOTable.DI[2, 5].State) { Servo_XYZ.X1_AXIS.EStop(); break; } }

                                        if (!Common.IOTable.DI[2, 5].State)
                                        {
                                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                            //Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Slow, X_Position - 5500, Y_Position);//Move XY
                                            Servo_XYZ.X1_AXIS.PosMoveAbs(X_Position - 5500, iSPD_LineMove_Slow);
                                            Thread.Sleep(300); CallCheckFinishMove();
                                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || !bChk_Y2_MoveDone || !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (Common.IOTable.DI[2, 5].State) { Servo_XYZ.X1_AXIS.EStop(); break; } }
                                        }
                                    }

                                    if (Common.IOTable.DI[2, 5].State)
                                    {
                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                        //Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Slow, X_Position + 5500, Y_Position);//Move XY
                                        Servo_XYZ.X1_AXIS.PosMoveAbs(X_Position + 5500, iSPD_LineMove_Slow);
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || !bChk_Y2_MoveDone || !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (!Common.IOTable.DI[2, 5].State) { Servo_XYZ.X1_AXIS.EStop(); break; } }

                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                        //Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Slow, X_Position - 5500, Y_Position);//Move XY
                                        Servo_XYZ.X1_AXIS.PosMoveAbs(X_Position - 5500, iSPD_LineMove_Slow);
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || !bChk_Y2_MoveDone || !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (Common.IOTable.DI[2, 5].State) { Servo_XYZ.X1_AXIS.EStop(); break; } }

                                    }
                                    else { Common.bCalibrationAlarm = true; } //Error can't find X sensor position

                                    Common.bCalibration_FlowStep = 20;
                                }
                                break;
                            case 20:
                                Thread.Sleep(300); CallCheckFinishMove();
                                if (bChk_X1_MoveDone && bChk_Y1_MoveDone && bChk_Y2_MoveDone && bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                {
                                    bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;

                                    //Check Y and find position.

                                    if (!Common.IOTable.DI[2, 4].State)
                                    {
                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                        //Check Y sensor cal on for stop move Y.
                                        //Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Slow, X_Position, Y_Position + 5500);//Move XY

                                        Servo_XYZ.Y_Sync_Axis.Servo_YAxis_Sync_Start_Set();
                                        Servo_XYZ.Y1_AXIS.PosMoveAbs(Y_Position + 5500, iSPD_LineMove_Slow);
                                        Servo_XYZ.Y1_AXIS.Cancel_isMoveing();
                                        Servo_XYZ.Y2_AXIS.PosMoveAbs(Y_Position + 5500, iSPD_LineMove_Slow);
                                        Servo_XYZ.Y_Sync_Axis.Servo_Axis_Sync_Start();

                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || !bChk_Y2_MoveDone || !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (Common.IOTable.DI[2, 4].State) { Servo_XYZ.Y1_AXIS.EStop(); Servo_XYZ.Y2_AXIS.EStop(); break; } }

                                        if (!Common.IOTable.DI[2, 4].State)
                                        {
                                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                                                                                                                                                                                                    //Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Slow, X_Position, Y_Position - 5500);//Move XY

                                            Servo_XYZ.Y_Sync_Axis.Servo_YAxis_Sync_Start_Set();
                                            Servo_XYZ.Y1_AXIS.PosMoveAbs(Y_Position - 5500, iSPD_LineMove_Slow);
                                            Servo_XYZ.Y1_AXIS.Cancel_isMoveing();
                                            Servo_XYZ.Y2_AXIS.PosMoveAbs(Y_Position - 5500, iSPD_LineMove_Slow);
                                            Servo_XYZ.Y_Sync_Axis.Servo_Axis_Sync_Start();

                                            Thread.Sleep(300); CallCheckFinishMove();
                                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || !bChk_Y2_MoveDone || !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (Common.IOTable.DI[2, 4].State) { Servo_XYZ.Y1_AXIS.EStop(); Servo_XYZ.Y2_AXIS.EStop(); break; } }
                                        }
                                    }

                                    if (Common.IOTable.DI[2, 4].State)
                                    {
                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                                                                                                                                                                                                //Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Slow, X_Position, Y_Position + 5500);//Move XY

                                        Servo_XYZ.Y_Sync_Axis.Servo_YAxis_Sync_Start_Set();
                                        Servo_XYZ.Y1_AXIS.PosMoveAbs(Y_Position + 5500, iSPD_LineMove_Slow);
                                        Servo_XYZ.Y1_AXIS.Cancel_isMoveing();
                                        Servo_XYZ.Y2_AXIS.PosMoveAbs(Y_Position + 5500, iSPD_LineMove_Slow);
                                        Servo_XYZ.Y_Sync_Axis.Servo_Axis_Sync_Start();

                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || !bChk_Y2_MoveDone || !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (!Common.IOTable.DI[2, 4].State) { Servo_XYZ.Y1_AXIS.EStop(); Servo_XYZ.Y2_AXIS.EStop(); break; } }

                                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                                                                                                                                                                                                //Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Slow, X_Position, Y_Position - 5500);//Move XY

                                        Servo_XYZ.Y_Sync_Axis.Servo_YAxis_Sync_Start_Set();
                                        Servo_XYZ.Y1_AXIS.PosMoveAbs(Y_Position - 5500, iSPD_LineMove_Slow);
                                        Servo_XYZ.Y1_AXIS.Cancel_isMoveing();
                                        Servo_XYZ.Y2_AXIS.PosMoveAbs(Y_Position - 5500, iSPD_LineMove_Slow);
                                        Servo_XYZ.Y_Sync_Axis.Servo_Axis_Sync_Start();

                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || !bChk_Y2_MoveDone || !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (Common.IOTable.DI[2, 4].State) { Servo_XYZ.Y1_AXIS.EStop(); Servo_XYZ.Y2_AXIS.EStop(); break; } }

                                    }
                                    else { Common.bCalibrationAlarm = true; } //Error can't find Y sensor position

                                    Common.bCalibration_FlowStep = 30;
                                }
                                break;
                            case 30:
                                Thread.Sleep(300); CallCheckFinishMove();
                                if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                {
                                    bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                                    //Check Z and find position.
                                    //Check Z sensor cal off for stop move Z.
                                    Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_LineMove_Slow);//Move Z up to home
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); if (!Common.IOTable.DI[2, 6].State) { Servo_XYZ.Z1_AXIS.EStop(); break; } }


                                    Common.bCalibration_FlowStep = 40;
                                }
                                break;
                            case 40:
                                Thread.Sleep(300); CallCheckFinishMove();
                                if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                {
                                    bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;


                                    //Spare


                                    Common.bCalibration_FlowStep = 50;
                                }
                                break;
                            case 50:
                                Thread.Sleep(300); CallCheckFinishMove();
                                if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                {
                                    bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;


                                    //Spare


                                    Common.bCalibration_FlowStep = 9000;
                                }
                                break;
                            case 9000:
                                Thread.Sleep(300); CallCheckFinishMove();
                                if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                {
                                    bChk_X1_MoveDone = false; bChk_Y1_MoveDone = false; bChk_Y2_MoveDone = false; bChk_Z1_MoveDone = false;




                                    Common.bCalibration_onwork = false;
                                    Common.bCalibration_FlowStep = 0;
                                }
                                break;
                        }
                    }
                }


                Thread.Sleep(200);
            }
        }

        public void CallPositionXYZ()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            if (Common.iModelSelect == 1) { sql = "SELECT * FROM dbo.XYZ_Position_View WHERE STEP = '" + CallPosition + "';"; }
            else if (Common.iModelSelect == 2) { sql = "SELECT * FROM dbo.XYZ_Position_M2_View WHERE STEP = '" + CallPosition + "';"; }

            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    X_Position = SQLRead.GetInt32(3);
                    Y_Position = SQLRead.GetInt32(4);
                    Z_Position = SQLRead.GetInt32(5);
                    RZ_Position = SQLRead.GetInt32(6);
                }
            }

            if (CallPosition != "TC1_1" && CallPosition != "TC1_2" && CallPosition != "TC1_3" && CallPosition != "TC2_1" && CallPosition != "TC2_2" && CallPosition != "TC2_3" &&
                CallPosition != "CT1_1" && CallPosition != "CT2_1" && CallPosition != "GCT1_1" && CallPosition != "GCT1_2" && CallPosition != "GCT2_1" && CallPosition != "GCT2_2" &&
                CallPosition != "GP1" && CallPosition != "GP2" & CallPosition != "C1" && CallPosition != "C2" && CallPosition != "H1")
            {
                X_Position = X_Position - Convert.ToInt32(Common.dbNozzle_X_Diff);
                Y_Position = Y_Position - Convert.ToInt32(Common.dbNozzle_Y_Diff);
                Z_Position = Z_Position - Convert.ToInt32(Common.dbNozzle_Z_Diff);
            }

        }

        public void CallCheckFinishMove()
        {
            if (Servo_XYZ.X1_AXIS.CheckMoveDone()) { bChk_X1_MoveDone = true; } else { bChk_X1_MoveDone = false; }
            if (Servo_XYZ.Y1_AXIS.CheckMoveDone()) { bChk_Y1_MoveDone = true; } else { bChk_Y1_MoveDone = false; }
            if (Servo_XYZ.Y2_AXIS.CheckMoveDone()) { bChk_Y2_MoveDone = true; } else { bChk_Y2_MoveDone = false; }
            if (Servo_XYZ.Z1_AXIS.CheckMoveDone()) { bChk_Z1_MoveDone = true; } else { bChk_Z1_MoveDone = false; }
            if (Servo_XYZ.RZ_AXIS.CheckMoveDone()) { bChk_RZ_MoveDone = true; } else { bChk_RZ_MoveDone = false; }
            if (Servo_XYZ.Y_Sync_Axis.CheckMoveDone()) { bChk_YSyc_MoveDone = true; } else { bChk_YSyc_MoveDone = false; }
            if (Servo_XYZ.XY_Multi.CheckMoveDone()) { bChk_XYMulti_MoveDone = true; } else { bChk_XYMulti_MoveDone = false; }
            if (Servo_XYZ.XYZ_MotionBuffer.CheckMoveDone()) { bChk_XYZ_MotionBuffer_MoveDone = true; } else { bChk_XYZ_MotionBuffer_MoveDone = false; }
        }

        public bool TimeOut_Start(uint time)
        {
            _startTime = GetTickCount();
            _spanTime = time;
            IsUsing = true;
            return true;
        }
        public bool TimeOut_Respond()
        {
            if (IsUsing)
            {
                uint a = GetTickCount();
                if (a - _startTime > _spanTime)
                {
                    //IsUsing = false;
                    return true;
                }
                else
                    return false;

            }
            else
            {
                return false;
            }
        }

    }
}
