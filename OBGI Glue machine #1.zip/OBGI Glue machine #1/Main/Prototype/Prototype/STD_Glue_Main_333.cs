﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
///////////////////////////////////////////////
using EasyModbus;
///////////////////////////////////////////////
using UI_Common;
using Communication.EtherCAT;
using Communication.IO_Commu;
using Equipment_Control;
using Equipment_Control.IO_Control;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.Interface;
using Equipment_Control.Camera;
using Equipment_Control.RFID;


namespace Prototype
{
    static class Prototype_Main
    {
        static SystemCommon Common;
        static XYZ_Motion Servo_XYZ;
        static DMV_VGR_Camera CameraIP;
        static RFID_Control Sygole_RFID;
        static STD_Glue_Initial_333 P_Initial;
        static STD_Glue_Auto_333 P_AutoRun;
        static STD_Glue_Error_333 P_Error;
        static EtherCAT_16input input;
        static EtherCAT_16output output;
        static bool isInitialSuccess = false;

        [STAThread]
        static void Main()
        {
            if (Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).Length > 1)
            {
                MessageBox.Show("Application already run");
                return;
            }

            Common = new SystemCommon();
            Servo_XYZ = new XYZ_Motion(Common);
            CameraIP = new DMV_VGR_Camera(Common);
            Sygole_RFID = new RFID_Control(Common);
            P_Initial = new STD_Glue_Initial_333(Common, Servo_XYZ, CameraIP);
            P_AutoRun = new STD_Glue_Auto_333(Common, Servo_XYZ, CameraIP, Sygole_RFID);
            P_Error = new STD_Glue_Error_333(Common, Servo_XYZ, CameraIP);
            Task threadInitial = new Task(Initial);
            Thread AutoControlFlow = new Thread(Auto_control_Flow);

            #region First set
            Common.iInitialFlow_Step = 0;
            Common.iAutoRunFlow_Step = 0;
            Common.bChkAlarm = false;

            Common.Connection_String = @"Data Source=DESKTOP-4AGMG63\SQLEXPRESS;Initial Catalog=GlueMC;integrated security=true;";

            #endregion

            threadInitial.Start();
            threadInitial.Wait();
            if (isInitialSuccess)
            {
                AutoControlFlow.Start();

                Common.iModelSelect = 1;
                Common.IOTable.DO[0, 10].Reset();//Reset red light
                Common.IOTable.DO[0, 11].Set();//Set Yellow light
                Common.IOTable.DO[0, 12].Reset();//Reset Green light

            }

            #region Ex use IO
            //bool bAAA = Common.IOTable.DI[0, 0].State;
            //Common.IOTable.DO[1, 0].Set();
            //Common.IOTable.DO[1, 0].Reset();
            #endregion
            #region Ex use Servo
            //Servo_XYZ.X1_AXIS.PosMoveRel(5, 5);
            //Servo_XYZ.Y1_AXIS.PosMoveAbs(100, 5);
            #endregion
            #region Ex read write value to .ini
            //Common.iComponent_1_Warning = Common.Config.ReadValue(Section, "Component_1_warning").ToInt();
            //Common.Config.WriteValue("Auto_Purge", "Purge_Time", " 10");
            //Common.Para.WriteValue("Auto_Purge", "Purge_Time", " 10");
            #endregion

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainGUI(Common, Servo_XYZ, Sygole_RFID));
        }
        static void Initial()
        {
            isInitialSuccess = MotionInitial();
        }
        static bool MotionInitial()
        {
            string Section = "";
            if (Common.Config.FileExists())
            {
                try
                {
                    Common.card.CardNo = Common.Config.ReadValue("Card", "CardNo").ToUshort();

                    #region DIO read config
                    ////DI
                    Section = "Input";
                    int iLengh = Common.Config.ReadValue(Section, "Lengh").ToInt();
                    ushort uStartNo = Common.Config.ReadValue(Section, "SlaveNo").ToUshort();
                    string DiType = Common.Config.ReadValue(Section, "HwType").ToString();
                    for (int i = 0; i < iLengh; i++)
                    {
                        switch (DiType)
                        {
                            case "R1_EC6002":
                                input = new R1_EC6002();
                                break;
                            case "R1_EC6022":
                                input = new R1_EC6022();
                                break;
                            default:
                                input = new R1_EC6002();
                                break;
                        }
                        input.ParentCard = Common.card;
                        input.SlaveNo = (ushort)(uStartNo + i);
                        Common.IOTable.DI.Add(input);
                    }
                    ////DO
                    Section = "Output";
                    iLengh = Common.Config.ReadValue(Section, "Lengh").ToInt();
                    uStartNo = Common.Config.ReadValue(Section, "SlaveNo").ToUshort();
                    string DoType = Common.Config.ReadValue(Section, "HwType").ToString();
                    for (int i = 0; i < iLengh; i++)
                    {
                        switch (DoType)
                        {
                            case "R1_EC7062D0":
                                output = new R1_EC7062D0();
                                break;
                            case "R1_EC70E2D0":
                                output = new R1_EC70E2D0();
                                break;
                            default:
                                output = new R1_EC7062D0();
                                break;
                        }
                        output.ParentCard = Common.card;
                        output.SlaveNo = (ushort)(uStartNo + i);
                        output.isErrorHandle = true;
                        Common.IOTable.DO.Add(output);
                    }
                    #endregion

                    #region Servo read config
                    ////Servo XYZ AXIS
                    Section = "X1_AXIS";
                    Common.X1_AXIS.ParentCard = Common.card;
                    Common.X1_AXIS.SlaveNo = Common.Config.ReadValue(Section, "SlaveNo").ToUshort();
                    Common.X1_AXIS.curveMode = EcurveMode.S_curve;

                    Section = "Y1_AXIS";
                    Common.Y1_AXIS.ParentCard = Common.card;
                    Common.Y1_AXIS.SlaveNo = Common.Config.ReadValue(Section, "SlaveNo").ToUshort();
                    Common.Y1_AXIS.curveMode = EcurveMode.S_curve;

                    Section = "Y2_AXIS";
                    Common.Y2_AXIS.ParentCard = Common.card;
                    Common.Y2_AXIS.SlaveNo = Common.Config.ReadValue(Section, "SlaveNo").ToUshort();
                    Common.Y2_AXIS.curveMode = EcurveMode.S_curve;

                    Section = "Z1_AXIS";
                    Common.Z1_AXIS.ParentCard = Common.card;
                    Common.Z1_AXIS.SlaveNo = Common.Config.ReadValue(Section, "SlaveNo").ToUshort();
                    Common.Z1_AXIS.curveMode = EcurveMode.S_curve;

                    Section = "RZ_AXIS";
                    Common.RZ_AXIS.ParentCard = Common.card;
                    Common.RZ_AXIS.SlaveNo = Common.Config.ReadValue(Section, "SlaveNo").ToUshort();
                    Common.RZ_AXIS.curveMode = EcurveMode.S_curve;
                    #endregion

                    #region Auto purge read config
                    //Glue Auto Purge
                    Section = "Auto_Purge";
                    Common.dbSetPurgeTime = Common.Config.ReadValue(Section, "Purge_Time").ToDouble();
                    Common.iTimetoAutoPurge = Common.Config.ReadValue(Section, "Time_to_Auto_Purge").ToInt();
                    #endregion

                    #region LifeTime read config
                    //LifeTime
                    Section = "LifeTime";
                    Common.iComponent_1_Warning = Common.Config.ReadValue(Section, "Component_1_warning ").ToInt();
                    Common.iComponent_1_Limit = Common.Config.ReadValue(Section, "Component_1_Limit ").ToInt();
                    Common.iComponent_1_Usage = Common.Config.ReadValue(Section, "Component_1_Usage ").ToInt();
                    Common.iComponent_2_Warning = Common.Config.ReadValue(Section, "Component_2_warning ").ToInt();
                    Common.iComponent_2_Limit = Common.Config.ReadValue(Section, "Component_2_Limit ").ToInt();
                    Common.iComponent_2_Usage = Common.Config.ReadValue(Section, "Component_2_Usage ").ToInt();
                    Common.iComponent_3_Warning = Common.Config.ReadValue(Section, "Component_3_warning ").ToInt();
                    Common.iComponent_3_Limit = Common.Config.ReadValue(Section, "Component_3_Limit ").ToInt();
                    Common.iComponent_3_Usage = Common.Config.ReadValue(Section, "Component_3_Usage ").ToInt();
                    Common.iComponent_4_Warning = Common.Config.ReadValue(Section, "Component_4_warning ").ToInt();
                    Common.iComponent_4_Limit = Common.Config.ReadValue(Section, "Component_4_Limit ").ToInt();
                    Common.iComponent_4_Usage = Common.Config.ReadValue(Section, "Component_4_Usage ").ToInt();
                    Common.iComponent_5_Warning = Common.Config.ReadValue(Section, "Component_5_warning ").ToInt();
                    Common.iComponent_5_Limit = Common.Config.ReadValue(Section, "Component_5_Limit ").ToInt();
                    Common.iComponent_5_Usage = Common.Config.ReadValue(Section, "Component_5_Usage ").ToInt();
                    Common.iComponent_6_Warning = Common.Config.ReadValue(Section, "Component_6_warning ").ToInt();
                    Common.iComponent_6_Limit = Common.Config.ReadValue(Section, "Component_6_Limit ").ToInt();
                    Common.iComponent_6_Usage = Common.Config.ReadValue(Section, "Component_6_Usage ").ToInt();
                    Common.iComponent_7_Warning = Common.Config.ReadValue(Section, "Component_7_warning ").ToInt();
                    Common.iComponent_7_Limit = Common.Config.ReadValue(Section, "Component_7_Limit ").ToInt();
                    Common.iComponent_7_Usage = Common.Config.ReadValue(Section, "Component_7_Usage ").ToInt();
                    Common.iComponent_8_Warning = Common.Config.ReadValue(Section, "Component_8_warning ").ToInt();
                    Common.iComponent_8_Limit = Common.Config.ReadValue(Section, "Component_8_Limit ").ToInt();
                    Common.iComponent_8_Usage = Common.Config.ReadValue(Section, "Component_8_Usage ").ToInt();
                    Common.iComponent_9_Warning = Common.Config.ReadValue(Section, "Component_9_warning ").ToInt();
                    Common.iComponent_9_Limit = Common.Config.ReadValue(Section, "Component_9_Limit ").ToInt();
                    Common.iComponent_9_Usage = Common.Config.ReadValue(Section, "Component_9_Usage ").ToInt();
                    Common.iComponent_10_Warning = Common.Config.ReadValue(Section, "Component_10_warning ").ToInt();
                    Common.iComponent_10_Limit = Common.Config.ReadValue(Section, "Component_10_Limit ").ToInt();
                    Common.iComponent_10_Usage = Common.Config.ReadValue(Section, "Component_10_Usage ").ToInt();
                    Common.iComponent_11_Warning = Common.Config.ReadValue(Section, "Component_11_warning ").ToInt();
                    Common.iComponent_11_Limit = Common.Config.ReadValue(Section, "Component_11_Limit ").ToInt();
                    Common.iComponent_11_Usage = Common.Config.ReadValue(Section, "Component_11_Usage ").ToInt();
                    Common.iComponent_12_Warning = Common.Config.ReadValue(Section, "Component_12_warning ").ToInt();
                    Common.iComponent_12_Limit = Common.Config.ReadValue(Section, "Component_12_Limit ").ToInt();
                    Common.iComponent_12_Usage = Common.Config.ReadValue(Section, "Component_12_Usage ").ToInt();
                    Common.iComponent_13_Warning = Common.Config.ReadValue(Section, "Component_13_warning ").ToInt();
                    Common.iComponent_13_Limit = Common.Config.ReadValue(Section, "Component_13_Limit ").ToInt();
                    Common.iComponent_13_Usage = Common.Config.ReadValue(Section, "Component_13_Usage ").ToInt();
                    Common.iComponent_14_Warning = Common.Config.ReadValue(Section, "Component_14_warning ").ToInt();
                    Common.iComponent_14_Limit = Common.Config.ReadValue(Section, "Component_14_Limit ").ToInt();
                    Common.iComponent_14_Usage = Common.Config.ReadValue(Section, "Component_14_Usage ").ToInt();
                    Common.iComponent_15_Warning = Common.Config.ReadValue(Section, "Component_15_warning ").ToInt();
                    Common.iComponent_15_Limit = Common.Config.ReadValue(Section, "Component_15_Limit ").ToInt();
                    Common.iComponent_15_Usage = Common.Config.ReadValue(Section, "Component_15_Usage ").ToInt();
                    #endregion


                    Common.card.Open();

                    Common.X1_AXIS.Open();
                    Common.Y1_AXIS.Open();
                    Common.Y2_AXIS.Open();
                    Common.Z1_AXIS.Open();
                    Common.RZ_AXIS.Open();
                    Servo_XYZ.ServoParaLoad();

                    Common.IOTable.DI.Open();
                    Common.IOTable.DO.Open();


                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("System Error");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Can't find the config.ini", "System Error");
                return false;
            }
        }
        public static void Auto_control_Flow() 
        {
            Thread DIOThread = new Thread(UpdateDIO);
            Thread ServoPosThread = new Thread(UpdateServoPos);
            Thread MachineInitial = new Thread(P_Initial.Machine_Initial);
            Thread MachineAutoRun = new Thread(P_AutoRun.Machine_AutoRun);
            Thread ApplyGlueTrig = new Thread(P_AutoRun.Check_Trig_Apply_Glue);
            Thread MoveStepbyStep = new Thread(P_AutoRun.Check_Trig_Move_Step);
            Thread ToolsChange = new Thread(P_AutoRun.ToolsChange_Select);
            Thread MachineError = new Thread(P_Error.Machine_Error);
            Thread CheckTrigStart = new Thread(CheckTrigAutoStart);
            Thread LampBuzzer = new Thread(CheckLampBuzzer);
            Thread ConveyerCommu = new Thread(CoveyerSigcommu);
            Thread WaitManual = new Thread(AlarmWaitManual);

            ApplyGlueTrig.Priority = ThreadPriority.AboveNormal;
            DIOThread.Priority = ThreadPriority.AboveNormal;
            ServoPosThread.Priority = ThreadPriority.AboveNormal;

            DIOThread.Start(); //MultiThread for Always update DIO signal.
            ServoPosThread.Start();  //MultiThread for Always update Servo Position.
            MachineInitial.Start(); //MultiThread for Always check machine Initial.
            MachineAutoRun.Start(); //MultiThread for Always check Machine Auto run.
            ApplyGlueTrig.Start(); //MultiThread for Always check Trig for apply glue.
            MoveStepbyStep.Start(); //Multithread for Alwats check Trig Move Step by Step.
            ToolsChange.Start(); //Multithread for Alwats check Trig Pick/Place Tools
            MachineError.Start(); //Multithread for Always check Machine Error.
            CheckTrigStart.Start(); //Multithread for Always check Trig Start signal.
            LampBuzzer.Start(); //Multithread for Always check Lamp and Buzzer status.
            ConveyerCommu.Start(); //Multithread for Always check Signal between machine.
            WaitManual.Start(); //Multithread for Always check Signal for buzzer alarm.
        }
        public static void UpdateDIO()
        {
            while (true)
            {
                for (int iRoundd1 = 0; iRoundd1 < Common.IOTable.DI.InputModelCount; iRoundd1++)
                {
                    Common.IOTable.DI.GetInputModel(iRoundd1).update();
                }
                for (int iRoundd2 = 0; iRoundd2 < Common.IOTable.DO.OutputModelCount; iRoundd2++)
                {
                    Common.IOTable.DO.GetOutputModel(iRoundd2).update();
                }
                Thread.Sleep(200);
            }
        }
        public static void UpdateServoPos()
        {
            while (true)
            {
                Servo_XYZ.X1_AXIS.update();
                Servo_XYZ.Y1_AXIS.update();
                Servo_XYZ.Y2_AXIS.update();
                Servo_XYZ.Z1_AXIS.update();
                Servo_XYZ.RZ_AXIS.update();
                Thread.Sleep(200);
            }
        }
        public static void CheckTrigAutoStart()
        {
            while (true) 
            {
                if (Common.bChkMC_RUN_STOP && !Common.bFlgAutoRun_onWork && !Common.bFlgInitial_onWork && !Common.bFlgAlreadyApplyGlue && Common.bFlgInitial_Finished && !Common.bChkAlarm)
                {
                    if (Common.IOTable.DI[1, 5].State && !Common.IOTable.DI[1, 4].State && !Common.IOTable.DI[1, 6].State && !Common.bFlgWorkFinished && !Common.bUpperSendNext)
                    {
                        Thread.Sleep(1000);
                        Common.bFlgTrigStart = true;
                    }
                }
                Thread.Sleep(200);
            }
        }
        public static void CheckLampBuzzer()
        {
            while (true)
            {
                if (Common.bChkAlarm)
                {
                    Common.IOTable.DO[0, 10].Set();//Set red light
                    Common.IOTable.DO[0, 11].Reset();//Reset Yellow light
                    Common.IOTable.DO[0, 12].Reset();//Reset Green light

                    if (!Common.bChkMuteButtonPush)
                    {
                        //Buzzer on and off for alarm
                        Common.IOTable.DO[0, 13].Set();
                        Thread.Sleep(200);
                        Common.IOTable.DO[0, 13].Reset();
                    }
                }
                Thread.Sleep(200);
            }            
        }
        public static void AlarmWaitManual()
        {
            while (true)
            {
                if (Common.bChkWaitManual)
                {
                    //Buzzer on and off for alarm
                    Common.IOTable.DO[0, 13].Set();
                    Thread.Sleep(500);
                    Common.IOTable.DO[0, 13].Reset();
                    Thread.Sleep(500);
                    Common.IOTable.DO[0, 13].Set();
                    Thread.Sleep(500);
                    Common.IOTable.DO[0, 13].Reset();

                    Common.bChkWaitManual = false;
                }
                Thread.Sleep(200);
            }
        }
        public static void CoveyerSigcommu()
        {
            bool bUnderStatus = false;
            bool bUnserReceiveStatus = false;

            while (true) //Remain Solenoid control
            {
                #region L=>R
                //if (Common.bFlgInitial_Finished && Common.bChkMC_RUN_STOP && !Common.bChkAlarm)
                //{
                //    #region Upper receive
                //    if (!Common.IOTable.DI[1, 5].State && !Common.IOTable.DI[1, 4].State && !Common.IOTable.DI[1, 6].State && !Common.bFlgWorkFinished) //For Upper conveyer
                //    {
                //        Common.IOTable.DO[1, 0].Set();//Upper Stopper ON
                //        Common.IOTable.DO[2, 8].Set();//ON Upper receive in from before
                //    }
                //    else if (!Common.IOTable.DI[1, 5].State && Common.IOTable.DI[1, 4].State && Common.IOTable.DO[2, 8].State)
                //    {
                //        Common.IOTable.DO[1, 5].Set();//Conveyer Upper CW ON
                //    }
                //    else if (Common.IOTable.DI[1, 5].State && !Common.bFlgWorkFinished)
                //    {
                //        Thread.Sleep(1000);
                //        Common.IOTable.DO[2, 8].Reset();//OFF Upper receive in from before
                //        Common.IOTable.DO[1, 5].Reset();//Conveyer Upper CW OFF
                //    }
                //    #endregion

                //    #region Upper Send next
                //    if (Common.IOTable.DI[1, 5].State && !Common.IOTable.DI[1, 6].State && Common.IOTable.DI[2, 12].State && Common.bFlgWorkFinished)
                //    {
                //        Common.IOTable.DO[2, 8].Reset();//OFF Upper receive in from before
                //        Common.IOTable.DO[1, 0].Reset();//Upper Stopper OFF
                //        Common.IOTable.DO[1, 5].Set();//Conveyer Upper CW ON                    
                //    }
                //    else if (!Common.IOTable.DI[1, 5].State && !Common.IOTable.DI[1, 6].State && !Common.IOTable.DO[2, 8].State && !Common.IOTable.DI[2, 12].State && Common.bFlgWorkFinished)
                //    {
                //        Common.IOTable.DO[1, 0].Set();//Upper Stopper ON
                //        Common.IOTable.DO[1, 5].Reset();//Conveyer Upper CW OFF
                //        Common.bFlgTrigStart = false;
                //        Common.bFlgWorkFinished = false;
                //        Common.bUpperSendNext = false;
                //    }
                //    #endregion

                //}

                //if (Common.bFlgInitial_Finished && Common.bChkMC_RUN_STOP && !Common.bChkAlarm)
                //{
                //    #region Under Receive
                //    if (!Common.IOTable.DI[1, 12].State && !Common.IOTable.DI[1, 11].State && !Common.IOTable.DI[1, 13].State && !bUnderStatus) //For Under conveyer
                //    {
                //        Common.IOTable.DO[1, 7].Set();//Under Stopper ON
                //        Common.IOTable.DO[2, 12].Set();//ON Under receive in from before
                //    }
                //    else if (Common.IOTable.DI[1, 11].State && Common.IOTable.DO[2, 12].State && !bUnderStatus)
                //    {
                //        Common.IOTable.DO[1, 12].Set();//CConveyer Under CCW ON
                //    }
                //    else if (Common.IOTable.DI[1, 12].State && !Common.IOTable.DI[2, 8].State && !bUnderStatus)
                //    {
                //        Thread.Sleep(1000);
                //        Common.IOTable.DO[2, 12].Reset();//OFF Under receive in from before
                //        Common.IOTable.DO[1, 12].Reset();//CConveyer Under CCW OFF
                //    }
                //    #endregion

                //    #region Under Send next
                //    if (Common.IOTable.DI[1, 12].State && !Common.IOTable.DI[1, 13].State && Common.IOTable.DI[2, 8].State)
                //    {
                //        bUnderStatus = true;
                //        Common.IOTable.DO[2, 12].Reset();//OFF Under receive in from before
                //        Common.IOTable.DO[1, 7].Reset();//Under Stopper OFF
                //        Common.IOTable.DO[1, 12].Set();//CConveyer Under CCW ON
                //    }
                //    else if (!Common.IOTable.DI[2, 8].State && !Common.IOTable.DI[1, 12].State && !Common.IOTable.DI[1, 13].State)
                //    {
                //        Thread.Sleep(1000);
                //        Common.IOTable.DO[1, 7].Set();//Under Stopper ON
                //        Common.IOTable.DO[1, 12].Reset();//CConveyer Under CCW OFF
                //        bUnderStatus = false;
                //    }
                //    #endregion

                //}
                //Thread.Sleep(200);
                #endregion

                #region L<=R
                if (Common.bFlgInitial_Finished && Common.bChkMC_RUN_STOP && !Common.bChkAlarm)
                {
                    #region Upper receive
                    if (!Common.IOTable.DI[1, 5].State && !Common.IOTable.DI[1, 4].State && !Common.IOTable.DI[1, 6].State && !Common.bFlgWorkFinished) //For Upper conveyer
                    {
                        Common.IOTable.DO[1, 0].Set();//Upper Stopper ON
                        Common.IOTable.DO[2, 8].Set();//ON Upper receive in from before
                    }
                    else if (!Common.IOTable.DI[1, 5].State && Common.IOTable.DI[1, 4].State && Common.IOTable.DO[2, 8].State)
                    {
                        Common.IOTable.DO[1, 4].Set();//Conveyer Upper CW ON
                    }
                    else if (Common.IOTable.DI[1, 5].State && !Common.bFlgWorkFinished)
                    {
                        Thread.Sleep(1000);
                        Common.IOTable.DO[2, 8].Reset();//OFF Upper receive in from before
                        Common.IOTable.DO[1, 4].Reset();//Conveyer Upper CW OFF
                    }
                    #endregion

                    #region Upper Send next
                    if (Common.IOTable.DI[1, 5].State && !Common.IOTable.DI[1, 6].State && Common.IOTable.DI[2, 12].State && Common.bFlgWorkFinished)
                    {
                        Common.IOTable.DO[2, 8].Reset();//OFF Upper receive in from before
                        Common.IOTable.DO[1, 0].Reset();//Upper Stopper OFF
                        Common.IOTable.DO[1, 4].Set();//Conveyer Upper CW ON                    
                    }
                    else if (!Common.IOTable.DI[1, 5].State && !Common.IOTable.DI[1, 6].State && !Common.IOTable.DO[2, 8].State && !Common.IOTable.DI[2, 12].State && Common.bFlgWorkFinished)
                    {
                        Common.IOTable.DO[1, 0].Set();//Upper Stopper ON
                        Common.IOTable.DO[1, 4].Reset();//Conveyer Upper CW OFF
                        Common.bFlgTrigStart = false;
                        Common.bFlgWorkFinished = false;
                        Common.bUpperSendNext = false;
                    }
                    #endregion

                }

                if (Common.bFlgInitial_Finished && Common.bChkMC_RUN_STOP && !Common.bChkAlarm)
                {
                    #region Under Receive
                    if (!Common.IOTable.DI[1, 12].State && !Common.IOTable.DI[1, 11].State && !Common.IOTable.DI[1, 13].State && !bUnderStatus) //For Under conveyer
                    {
                        Common.IOTable.DO[1, 7].Set();//Under Stopper ON
                        Common.IOTable.DO[2, 12].Set();//ON Under receive in from before
                    }
                    else if (Common.IOTable.DI[1, 11].State && Common.IOTable.DO[2, 12].State && !bUnderStatus)
                    {
                        bUnserReceiveStatus = true;
                        Common.IOTable.DO[1, 12].Set();//CConveyer Under CCW ON
                    }
                    else if (Common.IOTable.DI[1, 12].State && /*!Common.IOTable.DI[2, 8].State &&*/ !bUnderStatus)
                    {
                        Thread.Sleep(1000);
                        Common.IOTable.DO[2, 12].Reset();//OFF Under receive in from before
                        Common.IOTable.DO[1, 12].Reset();//CConveyer Under CCW OFF
                        bUnserReceiveStatus = false;
                    }
                    #endregion

                    #region Under Send next
                    if (Common.IOTable.DI[1, 12].State && !Common.IOTable.DI[1, 13].State && Common.IOTable.DI[2, 8].State && !bUnserReceiveStatus)
                    {
                        bUnderStatus = true;
                        Common.IOTable.DO[2, 12].Reset();//OFF Under receive in from before
                        Common.IOTable.DO[1, 7].Reset();//Under Stopper OFF
                        Common.IOTable.DO[1, 12].Set();//CConveyer Under CCW ON
                    }
                    else if (!Common.IOTable.DI[2, 8].State && !Common.IOTable.DI[1, 12].State && !Common.IOTable.DI[1, 13].State && !bUnserReceiveStatus)
                    {
                        Thread.Sleep(1000);
                        Common.IOTable.DO[1, 7].Set();//Under Stopper ON
                        Common.IOTable.DO[1, 12].Reset();//CConveyer Under CCW OFF
                        bUnderStatus = false;
                    }
                    #endregion

                }
                Thread.Sleep(200);
                #endregion
            }
        }
    }
}
