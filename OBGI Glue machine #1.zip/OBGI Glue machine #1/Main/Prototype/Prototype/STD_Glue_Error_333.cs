﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Data.SqlClient;
using Communication.EtherCAT;
using Communication.IO_Commu;
using Equipment_Control;
using Equipment_Control.IO_Control;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.Interface;
using Equipment_Control.Camera;

namespace Prototype
{
    public class STD_Glue_Error_333
    {
        IVariableShare Common;
        XYZ_Motion Servo_XYZ;
        DMV_VGR_Camera Camera_IP;

        string strDateTime = "";
        string strStatusError;
        String dd, mm;
        Int32 yy;


        String sql;

        bool bChkDo_1_Time = false;


        SqlConnection Conn;

        public STD_Glue_Error_333(IVariableShare common, XYZ_Motion ServoXYZ, DMV_VGR_Camera CameraIP)
        {
            Common = common;
            Servo_XYZ = ServoXYZ;
            Camera_IP = CameraIP;
        }

        public void Machine_Error()
        {
            while (true)
            {
                if (Common.bChkErrorResetButtonPush)//Push Reset Button for clear error
                {
                    Common.bChkErrorResetButtonPush = false;

                    if (Common.bChkAlarm)
                    {
                        MachineResetError();
                    }
                }

                if (Common.bChkAlarm || (!Common.bChkMC_RUN_STOP && Common.bFlgAutoRun_onWork))
                {
                    if (!bChkDo_1_Time)
                    {
                        CallPQM_Data();
                        PQM_Save_Error_Count();
                        if (Common.bFlgAutoRun_onWork) { PQM_Save_FailQty(); }
                        bChkDo_1_Time = true;
                    }
                    

                    #region Set/Reset IO,Servo,Parameter for stop machine and wait clear error.
                    Servo_XYZ.X1_AXIS.Machine_Error_ClearBitStatus();
                    Servo_XYZ.Y1_AXIS.Machine_Error_ClearBitStatus();
                    Servo_XYZ.Y2_AXIS.Machine_Error_ClearBitStatus();
                    Servo_XYZ.Z1_AXIS.Machine_Error_ClearBitStatus();
                    Servo_XYZ.RZ_AXIS.Machine_Error_ClearBitStatus();
                    Servo_XYZ.Y_Sync_Axis.Machine_Error_ClearBitStatus();
                    Servo_XYZ.XY_Multi.Machine_Error_ClearBitStatus();
                    Servo_XYZ.XYZ_MotionBuffer.Machine_Error_ClearBitStatus();
                    Servo_XYZ.X1_AXIS.EStop();
                    Servo_XYZ.Y1_AXIS.EStop();
                    Servo_XYZ.Y2_AXIS.EStop();
                    Servo_XYZ.Z1_AXIS.EStop();
                    Servo_XYZ.RZ_AXIS.EStop();
                    Common.IOTable.DO[0, 4].Reset(); //Reset Glue purge wait edit
                    Common.IOTable.DO[0, 14].Reset();//Start switch light off
                    Common.IOTable.DO[2, 6].Reset(); //Light source off
                    Common.bFlgInitial_Finished = false;
                    Common.bFlgInitial_onWork = false;
                    Common.iInitialFlow_Step = 0;
                    Common.bFlgAutoRun_onWork = false;
                    Common.iAutoRunFlow_Step = 0;
                    Common.iAutoPurgeFlow_Step = 0;
                    Common.bFlgTrigApplyGlue = false;
                    Common.bFlgAutoFlowTrigApplyGlue = false;
                    Common.iTrigPositionApplyGlue = 0;
                    Common.bSkipApplyGlue = false;
                    Common.bApplyGluePointFinished = false;
                    Common.bManualPickPlaceOnWork = false;
                    Common.bCalibrationAlarm = false;
                    Common.RFID_MANUAL = false;
                    Common.IOTable.DO[1, 4].Reset();
                    Common.IOTable.DO[1, 5].Reset();
                    Common.IOTable.DO[1, 11].Reset();
                    Common.IOTable.DO[1, 12].Reset();

                    #endregion
                }
                else
                {
                    if (Common.bEmerOnScreen || !Common.IOTable.DI[0, 10].State)
                    {
                        Common.bChkAlarm = true;
                        Common.strErrorCode = "ERR_001";
                        SaveErrorlog();
                    }

                    #region Area Sensor
                    //if (Common.bChkAreaSensor && (Common.bFlgAutoRun_onWork || Common.bFlgInitial_onWork))
                    //{
                    //    if (Common.iAutoRunFlow_Step != 120 && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))
                    //    {
                    //        Common.bChkAlarm = true;
                    //        Common.strErrorCode = "ERR_002";
                    //        SaveErrorlog();
                    //    }
                    //}
                    #endregion

                    #region Door Sensor

                    //Haven't in this machine
                    //Common.strErrorCode = "ERR_003";

                    #endregion

                    #region Air Pressure
                    if (!Common.IOTable.DI[0, 13].State)
                    {
                        Common.bChkAlarm = true;
                        Common.strErrorCode = "ERR_004";
                        SaveErrorlog();
                    }
                    #endregion

                    #region Servo Error
                    if (!Common.bFlgInitial_onWork)
                    {
                        if (Servo_XYZ.X1_AXIS.ErrorCode != 0)
                        {
                            Common.bChkAlarm = true;
                            Common.strErrorCode = "ERR_005";
                            SaveErrorlog();
                        }

                        if (Servo_XYZ.Y1_AXIS.ErrorCode != 0)
                        {
                            Common.bChkAlarm = true;
                            Common.strErrorCode = "ERR_005";
                            SaveErrorlog();
                        }
                        if (Servo_XYZ.Y2_AXIS.ErrorCode != 0)
                        {
                            Common.bChkAlarm = true;
                            Common.strErrorCode = "ERR_005";
                            SaveErrorlog();
                        }

                        if (Servo_XYZ.Z1_AXIS.ErrorCode != 0)
                        {
                            Common.bChkAlarm = true;
                            Common.strErrorCode = "ERR_005";
                            SaveErrorlog();
                        }

                        if (Servo_XYZ.Y_Sync_Axis.ErrorCode != 0)
                        {
                            Common.bChkAlarm = true;
                            Common.strErrorCode = "ERR_005";
                            SaveErrorlog();
                        }

                        if (Servo_XYZ.XY_Multi.ErrorCode != 0)
                        {
                            Common.bChkAlarm = true;
                            Common.strErrorCode = "ERR_005";
                            SaveErrorlog();
                        }

                        if (Servo_XYZ.XYZ_MotionBuffer.ErrorCode != 0)
                        {
                            Common.bChkAlarm = true;
                            Common.strErrorCode = "ERR_005";
                            SaveErrorlog();
                        }
                    }
                    #endregion

                    #region Tools Change
                    if (Common.bTrigToolsChangeAlarm)
                    {
                        Common.bChkAlarm = true;
                        Common.strErrorCode = "ERR_006";
                        SaveErrorlog();
                    }
                    #endregion

                    #region Solenoid TimeOut
                    if (Common.bSolenoidTimeOutAlarm)
                    {
                        Common.bChkAlarm = true;
                        Common.strErrorCode = "ERR_007";
                        SaveErrorlog();
                    }
                    #endregion

                    #region Calibration Fail
                    if (Common.bCalibrationAlarm)
                    {
                        Common.bChkAlarm = true;
                        Common.strErrorCode = "ERR_008";
                        SaveErrorlog();
                    }
                    #endregion

                    #region RFID Read Fail
                    if (Common.bRFIDCommandFail)
                    {
                        Common.bChkAlarm = true;
                        Common.strErrorCode = "ERR_009";
                        SaveErrorlog();
                    }
                    #endregion

                    #region MES Fail
                    if (Common.bMESFail)
                    {
                        Common.bChkAlarm = true;
                        Common.strErrorCode = "ERR_010";
                        SaveErrorlog();
                    }
                    #endregion

                    #region Camera Fail
                    if (Common.bCameraFail)
                    {
                        Common.bChkAlarm = true;
                        Common.strErrorCode = "ERR_011";
                        SaveErrorlog();
                    }
                    #endregion

                    #region EtherCAT Fail
                    if (Common.bEtherCatCommandFail)
                    {
                        Common.bChkAlarm = true;
                        Common.strErrorCode = "ERR_012";
                        SaveErrorlog();
                    }
                    #endregion

                }

                Thread.Sleep(200);
            }
        }

        public void SaveErrorlog()
        {
            DateTime dt = DateTime.Now;

            dd = dt.Day.ToString();
            mm = dt.Month.ToString();
            yy = Convert.ToInt32(dt.Year);

            strStatusError = "Found_ERROR";

            strDateTime = mm + "-" + dd + "-" + yy.ToString() + " " + dt.Hour + ":" + dt.Minute + ":" + dt.Second;

            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            sql = "INSERT INTO[dbo].[ERROR_CODE] ([ERROR_CODE],[DATE_TIME],[STATUS])" + "VALUES('" + Common.strErrorCode + "','" + strDateTime + "','" + strStatusError + "')"; //wait fix
            using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
        }

        public void MachineResetError()
        {
            Servo_XYZ.X1_AXIS.ClearAlarm();
            Servo_XYZ.Y1_AXIS.ClearAlarm();
            Servo_XYZ.Y2_AXIS.ClearAlarm();
            Servo_XYZ.Z1_AXIS.ClearAlarm();
            Servo_XYZ.RZ_AXIS.ClearAlarm();

            DateTime dt = DateTime.Now;

            dd = dt.Day.ToString();
            mm = dt.Month.ToString();
            yy = Convert.ToInt32(dt.Year);

            strStatusError = "Cleared_ERROR";

            strDateTime = mm + "-" + dd + "-" + yy.ToString() + " " + dt.Hour + ":" + dt.Minute + ":" + dt.Second;

            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            String sql = "INSERT INTO[dbo].[ERROR_CODE] ([ERROR_CODE],[DATE_TIME],[STATUS])" + "VALUES('" + Common.strErrorCode + "','" + strDateTime + "','" + strStatusError + "')"; //wait fix
            using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }

            Common.strErrorCode = "";
                        
            Common.bEmerOnScreen = false;
            Common.bTrigToolsChangeAlarm = false;
            Common.bSolenoidTimeOutAlarm = false;
            Common.bRFIDCommandFail = false;
            Common.bMESFail = false;
            Common.bPQMFail = false;
            Common.bCameraFail = false;
            Common.bEtherCatCommandFail = false;
            Common.bChkAlarm = false;
            bChkDo_1_Time = false;
        }

        public void CallPQM_Data()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            sql = "SELECT * FROM dbo.PQM_Data_View WHERE ID = '" + "1" + "';";

            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    Common.iPQM_PassQty = SQLRead.GetInt32(1);
                    Common.iPQM_FailQty = SQLRead.GetInt32(2);
                    Common.iPQM_Error_Count = SQLRead.GetInt32(3);
                    Common.iPQM_InputQty = SQLRead.GetInt32(5);
                }
            }
        }

        public void PQM_Save_FailQty()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();

            Common.iPQM_FailQty = Common.iPQM_FailQty + 1;

            sql = "UPDATE dbo.PQM_Data SET Fail_Qty = " + Common.iPQM_FailQty + " WHERE ID = '" + "1" + "';";
            using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
        }

        public void PQM_Save_Error_Count()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();

            Common.iPQM_Error_Count = Common.iPQM_Error_Count + 1;

            sql = "UPDATE dbo.PQM_Data SET Error_Count = " + Common.iPQM_Error_Count + " WHERE ID = '" + "1" + "';";
            using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
        }


    }
}
