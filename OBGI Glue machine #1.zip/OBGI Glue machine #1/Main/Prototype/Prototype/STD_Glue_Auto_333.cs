﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using Communication.EtherCAT;
using Communication.IO_Commu;
using Equipment_Control;
using Equipment_Control.IO_Control;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.Interface;
using Equipment_Control.Camera;
using Equipment_Control.RFID;
using Equipment_Control.Database;

namespace Prototype
{
    public class STD_Glue_Auto_333
    {
        IVariableShare Common;
        XYZ_Motion Servo_XYZ;
        DMV_VGR_Camera Camera_IP;
        RFID_Control _RFID;

        [DllImport("kernel32.dll")]
        public static extern uint GetTickCount();

        ulong _startTime;
        uint _spanTime;
        public bool IsUsing { get; private set; }

        int X_Position;
        int Y_Position;
        int Z_Position;
        int RZ_Position;
        int Z_Safety_Pos;

        ushort Motion_Status;

        bool bChk_X1_MoveDone;
        bool bChk_Y1_MoveDone;
        bool bChk_Y2_MoveDone;
        bool bChk_Z1_MoveDone;
        bool bChk_RZ_MoveDone;
        bool bChk_YSyc_MoveDone;
        bool bChk_XYMulti_MoveDone;
        bool bChk_XYZ_MotionBuffer_MoveDone;

        int iApplyGlueStep = 0;

        int iSPD_RZ_Move = 200;

        int iSPD_CutGlue = 100000;
        int iSPD_Movement_Fast = 300000;
        int iSPD_Movement_Fast_EndZero = 400000;
        int iSPD_Z_Movement_Fast = 300000;
        int iSPD_Z_Safety_Movement_Fast = 500000;
        int iSPD_LineMove_Normal = 100000;

        int iSPD_LineMove_M1_P1 = 36000;
        int iSPD_LineMove_M1_P2 = 35000;
        int iSPD_LineMove_M1_P3 = 35000;
        int iSPD_LineMove_M1_P4 = 35000;
        int iSPD_LineMove_M1_P5 = 35000;
        int iSPD_LineMove_M1_P6 = 35000;
        int iSPD_LineMove_M1_P7 = 35000;
        int iSPD_LineMove_M1_P8 = 35000;
        int iSPD_LineMove_M1_P9 = 35000;
        int iSPD_LineMove_M1_P10 = 35000;

        int ISPD_ArcMove_Normal = 17300;
        int ISPD_ArcMove_High = 50000;

        string pTest_data;
        string pLog_data;
        string MES_Factory;
        string MES_MO_Num;
        string MES_Model;
        string MES_LineName;
        string MES_Secion;
        string MES_Group;
        string MES_Station;

        bool MES_Reject_Chk;
        string RFID_Data_trim;

        string MO_Read;
        string Model_Read;
        string LineName_Read;

        ResMsg MESChkResult = new ResMsg();

        String sql;
        String CallPosition;

        SqlConnection Conn;

        public STD_Glue_Auto_333(IVariableShare common, XYZ_Motion ServoXYZ, DMV_VGR_Camera CameraIP, RFID_Control Sygole_RFID)
        {
            Common = common;
            Servo_XYZ = ServoXYZ;
            Camera_IP = CameraIP;
            _RFID = Sygole_RFID;
        }

        public void Machine_AutoRun()
        {
            while (true)
            {
                //Auto Purge check
                if (Common.bChkAuto_Manual && Common.bFlgInitial_Finished && Common.bChkMC_RUN_STOP && !Common.bChkPauseButtonPush && !Common.bChkAlarm && Common.bChkAutoPurge && !Common.bFlgAutoRun_onWork)
                {
                    if (Common.iPurgeTimeCount == Common.iTimetoAutoPurge)
                    {
                        Common.bFlgAutoPurge_onWork = true;

                        while (Common.bFlgAutoPurge_onWork)
                        {
                            switch (Common.iAutoPurgeFlow_Step)
                            {
                                case 0:

                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        CallPosition = "GCT1_1";//Target to Glue cut tool 1 position.
                                        CallPositionXYZ();//Call Home position (Referance from "GCT1")

                                        Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Movement_Fast);//Move Z up to home
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                        Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                        Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }


                                        Common.iAutoPurgeFlow_Step = 10;
                                    }
                                    break;
                                case 10:

                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {

                                        Common.IOTable.DO[0, 4].Set(); //On glue purge signal
                                        Thread.Sleep(Convert.ToInt32(Common.dbSetPurgeTime * 1000));
                                        Common.IOTable.DO[0, 4].Reset(); //Off glue purge signal

                                        Common.iAutoPurgeFlow_Step = 20;
                                    }
                                    break;
                                case 20:

                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        CallPosition = "GCT1_2";//Target to Glue cut tool 1 position.
                                        CallPositionXYZ();//Call Home position (Referance from "GCT1")

                                        Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                        Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Movement_Fast);//Move Z up to home
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                        Common.iAutoPurgeFlow_Step = 30;
                                    }
                                    break;
                                case 30:

                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {
                                        Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, Common.iMem_X_Home_Pos, Common.iMem_Y_Home_Pos);//Move XY to home
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                        Common.iAutoPurgeFlow_Step = 40;
                                    }
                                    break;
                                case 40:

                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {

                                        //Spare
                                        Common.iAutoPurgeFlow_Step = 100;

                                    }
                                    break;
                                case 100:

                                    Thread.Sleep(300); CallCheckFinishMove();
                                    if (bChk_X1_MoveDone && bChk_Y1_MoveDone && /*bChk_Y2_MoveDone*/ bChk_Z1_MoveDone && bChk_YSyc_MoveDone && bChk_XYMulti_MoveDone && bChk_XYZ_MotionBuffer_MoveDone)
                                    {

                                        Common.iAutoPurgeFlow_Step = 0; //Reset Auto Purge Flow Step
                                        Common.iPurgeTimeCount = 0;
                                        Common.bFlgAutoPurge_onWork = false; //For break "while
                                    }
                                    break;
                            }
                        }
                    }
                }
                //Auto Run check
                if (Common.bChkAuto_Manual && Common.bFlgInitial_Finished && Common.bChkMC_RUN_STOP && !Common.bChkPauseButtonPush && !Common.bFlgAlreadyApplyGlue && !Common.bFlgAutoRun_onWork && !Common.bFlgAutoPurge_onWork && !Common.bChkAlarm && !Common.bUpperSendNext && (Common.bFlgTrigStart || Common.bTempStartTrig))
                {
                    if (!Common.bChkMC_Bypass)
                    {
                        MES_Reject_Chk = false;
                        Common.bFlgTrigStart = false;
                        Common.bTempStartTrig = false; //Temporary close for marathon run test.
                        Common.bFlgWorkFinished = false;
                        Common.bFlgAutoRun_onWork = true;

                        Common.iPQM_Cycle_Time = 0;

                        while (Common.bFlgAutoRun_onWork)
                        {
                            switch (Common.iAutoRunFlow_Step)
                            {
                                case 0:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    CallPQM_Data();
                                    PQM_Save_InputQty();

                                    Common.iAutoRunFlow_Step = 10;

                                    break;
                                case 10:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bChkFirstAuto)
                                    {
                                        //Check Position if Z < Z safety = move Y out from component
                                        if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                        {
                                            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                            Thread.Sleep(300); CallCheckFinishMove();
                                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                        }

                                        Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                        Servo_XYZ.RZ_AXIS.PosMoveAbs(Common.iMem_RZ_Home_Pos, iSPD_RZ_Move);//Move RZ up to home
                                        Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, Common.iMem_X_Home_Pos, Common.iMem_Y_Home_Pos);//Move XY to home
                                        Thread.Sleep(300); CallCheckFinishMove();
                                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                                    }

                                    Common.iAutoRunFlow_Step = 20;

                                    break;
                                case 20:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.IOTable.DI[1, 5].State) { Common.IOTable.DO[1, 14].Set(); }//Clamp
                                    TimeOut_Start(5000);
                                    while (Common.IOTable.DI[1, 14].State || !Common.IOTable.DI[1, 15].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

                                    Common.iAutoRunFlow_Step = 30;

                                    break;
                                case 30:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bChkRFID_BYPASS)
                                    {
                                        //Common.IOTable.DO[2, 0].Set();//RFID L OUT
                                        Common.IOTable.DO[2, 2].Set();//RFID R OUT
                                        TimeOut_Start(5000);
                                        while (!Common.IOTable.DI[2, 1].State || Common.IOTable.DI[2, 0].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }
                                    }

                                    Common.iAutoRunFlow_Step = 40;

                                    break;
                                case 40:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bChkRFID_BYPASS)
                                    {
                                        RFID_Read();

                                        if (!Common.bChkMES_BYPASS) { MES_Send_Check(); }

                                        Common.IOTable.DO[2, 0].Reset();//RFID IN
                                        TimeOut_Start(5000);
                                        while (Common.IOTable.DI[2, 1].State || !Common.IOTable.DI[2, 0].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

                                    }

                                    Call_Z_Safety();

                                    if (MES_Reject_Chk) { Common.iAutoRunFlow_Step = 8000; }
                                    else { Common.iAutoRunFlow_Step = 100; }

                                    break;
                                case 100: //Model 1 Start
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    CalTakePicture();

                                    Common.iAutoRunFlow_Step = 110;

                                    break;
                                case 110: //M1_P1
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 1; //Set apply glue position to P1
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.

                                    Common.iAutoRunFlow_Step = 120;

                                    break;
                                case 120:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 130;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }

                                    break;
                                case 130: //M1_P2
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 2; //Set apply glue position to P2
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.


                                    Common.iAutoRunFlow_Step = 140;

                                    break;
                                case 140:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 150;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }

                                    break;
                                case 150: //M1_P3
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 3; //Set apply glue position to P3
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.


                                    Common.iAutoRunFlow_Step = 160;

                                    break;
                                case 160:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 170;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }

                                    break;
                                case 170: //M1_P4
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 4; //Set apply glue position to P4
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.


                                    Common.iAutoRunFlow_Step = 180;

                                    break;
                                case 180:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 190;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }

                                    break;
                                case 190: //M1_P5
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 5; //Set apply glue position to P5
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.


                                    Common.iAutoRunFlow_Step = 200;

                                    break;
                                case 200:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 210;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }

                                    break;
                                case 210: //M1_P6
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 6; //Set apply glue position to P6
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.


                                    Common.iAutoRunFlow_Step = 220;

                                    break;
                                case 220:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 230;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }

                                    break;
                                case 230: //M1_P7
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 7; //Set apply glue position to P7
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.


                                    Common.iAutoRunFlow_Step = 240;

                                    break;
                                case 240:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 250;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }

                                    break;
                                case 250: //M1_P8
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 8; //Set apply glue position to P8
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.


                                    Common.iAutoRunFlow_Step = 260;

                                    break;
                                case 260:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 270;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }

                                    break;
                                case 270: //M1_P9
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 9; //Set apply glue position to P9
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.


                                    Common.iAutoRunFlow_Step = 280;

                                    break;
                                case 280:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 290;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }

                                    break;
                                case 290: //M1_P10
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    Common.iTrigPositionApplyGlue = 10; //Set apply glue position to P10
                                    Common.bFlgAutoFlowTrigApplyGlue = true; //Set Flag for trig start apply glue
                                    Common.bFlgAlreadyApplyGlue = true; //Set Flg this part already apply glue.


                                    Common.iAutoRunFlow_Step = 300;

                                    break;
                                case 300:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (Common.bApplyGluePointFinished) //Wait Apply glue complete.
                                    {
                                        Common.iAutoRunFlow_Step = 8000;
                                        Common.bApplyGluePointFinished = false; //Reset bit --------- Example
                                    }
                                    break;
                                case 8000:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    Common.IOTable.DO[1, 14].Reset();//Un-Clamp
                                    Common.bFlgWorkFinished = true; //Trig work finish for send out
                                    Common.bUpperSendNext = true;

                                    #region Move to camera position
                                    //CallPosition = "C1";
                                    //CallPositionXYZ();

                                    //Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Z_Movement_Fast);//Move Z
                                    //Thread.Sleep(300); CallCheckFinishMove();
                                    //while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                    //Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
                                    //Thread.Sleep(300); CallCheckFinishMove();
                                    //while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                                    #endregion

                                    #region Move to Home position
                                    Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

                                    Servo_XYZ.RZ_AXIS.PosMoveAbs(Common.iMem_RZ_Home_Pos, iSPD_RZ_Move);//Move RZ up to home
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, Common.iMem_X_Home_Pos, Common.iMem_Y_Home_Pos);//Move XY to home
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                                    #endregion

                                    Common.iAutoRunFlow_Step = 9000;

                                    break;
                                case 9000:
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    CallPQM_Data();
                                    PQM_Save_PassQty();
                                    if (!Common.bChkMES_BYPASS && !MES_Reject_Chk) { MES_Send_Update(); } //MES send update OK

                                    //Common.IOTable.DO[1, 14].Reset();//Un-Clamp
                                    Common.iAutoRunFlow_Step = 0; //Reset Auto Run Flow Step
                                    Common.iPurgeTimeCount = 0; //Reset Auto purge time count
                                    Common.bFlgAlreadyApplyGlue = false; //Reset Flg this part already apply glue.
                                    //Common.bFlgWorkFinished = true; //Trig work finish for send out
                                    //Common.bUpperSendNext = true;
                                    Common.bFlgAutoRun_onWork = false; //For break while
                                    MES_Reject_Chk = false;
                                    Common.bChkFirstAuto = true;

                                    break;
                            }
                        }
                    }
                    else { Common.bFlgWorkFinished = true; Common.bUpperSendNext = true; }
                }
                else { Common.bTempStartTrig = false; }


                Thread.Sleep(200);
            }
        }

        public void RFID_Read()
        {
            if (!Common.bChkRFID_BYPASS)
            {
                int iRFIDTryagain = 0;

            RFID_READ_FLG:

                Common.bRFID_select_Fail = false;

                try
                {
                    iRFIDTryagain++;
                    if (iRFIDTryagain <= 5)
                    {
                        Common.RFID_Read_Data = "";
                        RFID_Data_trim = "";

                        _RFID.RFIDConnect();
                        byte[] RFID_DATA = _RFID.ReadUserdata(0, 0, 18);

                        if (Common.bRFID_select_Fail) { goto RFID_READ_FLG; }

                        string RFID_1st_Char = Char.ConvertFromUtf32(RFID_DATA[0]);
                        string RFID_2nd_Char = Char.ConvertFromUtf32(RFID_DATA[1]);
                        string RFID_3rd_Char = Char.ConvertFromUtf32(RFID_DATA[2]);
                        string RFID_4th_Char = Char.ConvertFromUtf32(RFID_DATA[3]);
                        string RFID_5th_Char = Char.ConvertFromUtf32(RFID_DATA[4]);
                        string RFID_6th_Char = Char.ConvertFromUtf32(RFID_DATA[5]);
                        string RFID_7th_Char = Char.ConvertFromUtf32(RFID_DATA[6]);
                        string RFID_8th_Char = Char.ConvertFromUtf32(RFID_DATA[7]);
                        string RFID_9th_Char = Char.ConvertFromUtf32(RFID_DATA[8]);
                        string RFID_10th_Char = Char.ConvertFromUtf32(RFID_DATA[9]);
                        string RFID_11th_Char = Char.ConvertFromUtf32(RFID_DATA[10]);
                        string RFID_12th_Char = Char.ConvertFromUtf32(RFID_DATA[11]);
                        string RFID_13th_Char = Char.ConvertFromUtf32(RFID_DATA[12]);
                        string RFID_14th_Char = Char.ConvertFromUtf32(RFID_DATA[13]);
                        string RFID_15th_Char = Char.ConvertFromUtf32(RFID_DATA[14]);
                        string RFID_16th_Char = Char.ConvertFromUtf32(RFID_DATA[15]);
                        string RFID_17th_Char = Char.ConvertFromUtf32(RFID_DATA[16]);
                        string RFID_18th_Char = Char.ConvertFromUtf32(RFID_DATA[17]);

                        Common.RFID_Read_Data = RFID_2nd_Char + RFID_1st_Char + RFID_4th_Char + RFID_3rd_Char + RFID_6th_Char + RFID_5th_Char
                    + RFID_8th_Char + RFID_7th_Char + RFID_10th_Char + RFID_9th_Char + RFID_12th_Char + RFID_11th_Char + RFID_14th_Char
                    + RFID_13th_Char + RFID_16th_Char + RFID_15th_Char + RFID_18th_Char + RFID_17th_Char;

                        RFID_Data_trim = Common.RFID_Read_Data.Trim('\0');

                        if (RFID_Data_trim == "") { goto RFID_READ_FLG; }
                    }
                    else
                    {
                        //Buzzer on and off for alarm
                        Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                        Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                        Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                        Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);

                        DialogResult re = MessageBox.Show("RFID Check Fail\n | Abort = Alarm RFID Fail\n | Retry = Try again\n | Ignore = Skip Read RFID", "RFID Read Fail", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Question);
                        if (re == DialogResult.Abort) { Common.bRFIDCommandFail = true; }
                        else if (re == DialogResult.Retry) { iRFIDTryagain = 0; goto RFID_READ_FLG; }
                        else { /*Nothing to do*/ }
                    }

                }
                catch
                {
                    Thread.Sleep(500); goto RFID_READ_FLG;
                }
            }
        }

        public void CallPositionXYZ()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            if (Common.iModelSelect == 1) { sql = "SELECT * FROM dbo.XYZ_Position_View WHERE STEP = '" + CallPosition + "';"; }
            else if (Common.iModelSelect == 2) { sql = "SELECT * FROM dbo.XYZ_Position_M2_View WHERE STEP = '" + CallPosition + "';"; }

            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    X_Position = SQLRead.GetInt32(3);
                    Y_Position = SQLRead.GetInt32(4);
                    Z_Position = SQLRead.GetInt32(5);
                    RZ_Position = SQLRead.GetInt32(6);
                }
            }

            if (CallPosition != "TC1_1" && CallPosition != "TC1_2" && CallPosition != "TC1_3" && CallPosition != "TC2_1" && CallPosition != "TC2_2" && CallPosition != "TC2_3" &&
                CallPosition != "CT1_1" && CallPosition != "CT2_1" && CallPosition != "GCT1_1" && CallPosition != "GCT1_2" && CallPosition != "GCT2_1" && CallPosition != "GCT2_2" &&
                CallPosition != "GP1" && CallPosition != "GP2" & CallPosition != "C1" && CallPosition != "C2" && CallPosition != "H1" && !Common.bFlgTrigMoveStepByStep)
            {
                if (Common.iToolsPick == 1)
                {
                    X_Position = X_Position - Convert.ToInt32(Common.dbNozzle_X_Diff);
                    Y_Position = Y_Position - Convert.ToInt32(Common.dbNozzle_Y_Diff);
                    Z_Position = Z_Position - Convert.ToInt32(Common.dbNozzle_Z_Diff);
                }
                if (Common.iToolsPick == 2)
                {
                    X_Position = X_Position - Convert.ToInt32(Common.dbNozzle_2_X_Diff);
                    Y_Position = Y_Position - Convert.ToInt32(Common.dbNozzle_2_Y_Diff);
                    Z_Position = Z_Position - Convert.ToInt32(Common.dbNozzle_2_Z_Diff);
                }
            }

        }

        public void Call_Z_Safety()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            if (Common.iModelSelect == 1)
            {
                sql = "SELECT * FROM dbo.XYZ_Position_View WHERE STEP = '" + "ZS1_1" + "';";
            }
            else
            {
                sql = "SELECT * FROM dbo.XYZ_Position_M2_View WHERE STEP = '" + "ZS1_1" + "';";
            }
            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    Z_Position = SQLRead.GetInt32(5);
                }
            }

            if (CallPosition != "TC1_1" && CallPosition != "TC1_2" && CallPosition != "TC1_3" && CallPosition != "TC2_1" && CallPosition != "TC2_2" && CallPosition != "TC2_3" &&
                CallPosition != "CT1_1" && CallPosition != "CT2_1" && CallPosition != "GCT1_1" && CallPosition != "GCT1_2" && CallPosition != "GCT2_1" && CallPosition != "GCT2_2" &&
                CallPosition != "GP1" && CallPosition != "GP2" & CallPosition != "C1" && CallPosition != "C2" && CallPosition != "H1" && !Common.bFlgTrigMoveStepByStep)
            {
                Z_Position = Z_Position - Convert.ToInt32(Common.dbNozzle_Z_Diff);
                Z_Safety_Pos = Z_Position;
            }
        }

        public void CalTakePicture()
        {
            if (Common.bChkCemeraOffset)
            {
                CallPosition = "C1";
                CallPositionXYZ();

                Common.dbX_Center_ref = X_Position;
                Common.dbY_Center_ref = Y_Position;

                Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
                Thread.Sleep(300); CallCheckFinishMove();
                while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                if (Common.bChkAlarm) { return; }

                Common.IOTable.DO[2, 6].Set(); //Light source on

                Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Z_Movement_Fast);//Move Z
                Thread.Sleep(300); CallCheckFinishMove();
                while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                if (Common.bChkAlarm) { return; }
                try
                {
                    Camera_IP.Write_Single_registor(4096, 1); //Address 0x1000(Hex) to 4096(Dec) write data for trig run camera flow.
                    Camera_IP.Read_Holding_Registers();
                }
                catch
                {
                    Common.bCameraFail = true;
                    MessageBox.Show("Camera connect Fail!! - Please open DMV-VGR");
                }

                Common.IOTable.DO[2, 6].Reset(); //Light source off

                if (Common.iToolsPick == 1) { CallPosition = "ZS1_1"; }
                else if (Common.iToolsPick == 2) { CallPosition = "ZS2_1"; }
                else { CallPosition = "ZS1_1"; }

                //CallPositionXYZ();
                //Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Z_Movement_Fast);//Move Z up

                //Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Movement_Fast);//Move Z up to home

                Thread.Sleep(300); CallCheckFinishMove();
                while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                if (Common.bChkAlarm) { return; }

            }
        }

        public void CalOffsetPosition()
        {
            if (Common.bChkCemeraOffset)
            {
                Camera_IP.Cal_offset_position(X_Position, Y_Position);
                X_Position = Convert.ToInt32(Common.dbX_offset_position);
                Y_Position = Convert.ToInt32(Common.dbY_offset_position);
            }
        }

        public void CallPQM_Data()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            sql = "SELECT * FROM dbo.PQM_Data_View WHERE ID = '" + "1" + "';";

            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    Common.iPQM_PassQty = SQLRead.GetInt32(1);
                    Common.iPQM_FailQty = SQLRead.GetInt32(2);
                    Common.iPQM_Error_Count = SQLRead.GetInt32(3);
                    Common.iPQM_InputQty = SQLRead.GetInt32(5);
                }
            }
        }

        public void PQM_Save_InputQty()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();

            Common.iPQM_InputQty = Common.iPQM_InputQty + 1;

            sql = "UPDATE dbo.PQM_Data SET Input_Qty = " + Common.iPQM_InputQty + " WHERE ID = '" + "1" + "';";
            using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
        }

        public void PQM_Save_PassQty()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();

            Common.iPQM_PassQty = Common.iPQM_PassQty + 1;

            sql = "UPDATE dbo.PQM_Data SET Pass_Qty = " + Common.iPQM_PassQty + " WHERE ID = '" + "1" + "';";
            using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
        }

        public void CallCheckFinishMove()
        {
            if (Servo_XYZ.X1_AXIS.CheckMoveDone()) { bChk_X1_MoveDone = true; } else { bChk_X1_MoveDone = false; }
            if (Servo_XYZ.Y1_AXIS.CheckMoveDone()) { bChk_Y1_MoveDone = true; } else { bChk_Y1_MoveDone = false; }
            if (Servo_XYZ.Y2_AXIS.CheckMoveDone()) { bChk_Y2_MoveDone = true; } else { bChk_Y2_MoveDone = false; }
            if (Servo_XYZ.Z1_AXIS.CheckMoveDone()) { bChk_Z1_MoveDone = true; } else { bChk_Z1_MoveDone = false; }
            if (Servo_XYZ.RZ_AXIS.CheckMoveDone()) { bChk_RZ_MoveDone = true; } else { bChk_RZ_MoveDone = false; }
            if (Servo_XYZ.Y_Sync_Axis.CheckMoveDone()) { bChk_YSyc_MoveDone = true; } else { bChk_YSyc_MoveDone = false; }
            if (Servo_XYZ.XY_Multi.CheckMoveDone()) { bChk_XYMulti_MoveDone = true; } else { bChk_XYMulti_MoveDone = false; }
            if (Servo_XYZ.XYZ_MotionBuffer.CheckMoveDone()) { bChk_XYZ_MotionBuffer_MoveDone = true; } else { bChk_XYZ_MotionBuffer_MoveDone = false; }
        }

        public void Check_Trig_Move_Step()
        {
            while (true)
            {
            EndMoveStepbyStep: //Label for goto function
                if (Common.bFlgTrigMoveStepByStep)
                {
                    CallPosition = Common.strTrigPotitionMove + Common.iTrigStepMove;
                    CallPositionXYZ();

                    //Check Position if Z < Z safety = move Y out from component
                    if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                    {
                        Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                        Thread.Sleep(300); CallCheckFinishMove();
                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                    }

                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                    Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Movement_Fast);//Move Z up to home
                    Thread.Sleep(300); CallCheckFinishMove();

                    Servo_XYZ.RZ_AXIS.PosMoveAbs(RZ_Position, iSPD_RZ_Move);//Move RZ
                    Thread.Sleep(300); CallCheckFinishMove();
                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                    if (Common.bChkAlarm) { goto EndMoveStepbyStep; }

                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                    if (Common.bChkAlarm) { goto EndMoveStepbyStep; }

                    if(Common.strTrigPotitionMove == "P1_" || Common.strTrigPotitionMove == "P2_" || Common.strTrigPotitionMove == "P3_" || Common.strTrigPotitionMove == "P7_" || Common.strTrigPotitionMove == "P8_" || Common.strTrigPotitionMove == "P9_" || Common.strTrigPotitionMove == "P10_")
                    {
                        Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                        Move_XY_Linear_Dodge_ZSafety(iSPD_Movement_Fast);//Move Z to safety area in Dodge position
                        Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                        Move_XY_Linear(iSPD_LineMove_M1_P1);
                        Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                        Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                        while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                        while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                        Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();
                        Common.bFlgTrigMoveStepByStep = false;
                    }
                    else //no need move to dodge position
                    {
                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                        Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
                        Thread.Sleep(300); CallCheckFinishMove();
                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                        if (Common.bChkAlarm) { goto EndMoveStepbyStep; }


                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                        Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
                        Thread.Sleep(300); CallCheckFinishMove();
                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                        if (Common.bChkAlarm) { goto EndMoveStepbyStep; }
                        Common.bFlgTrigMoveStepByStep = false;
                    }
                }
            }
        }

        public void Check_Trig_Apply_Glue()
        {
            while (true)
            {
            EndTrigApplyGlue: //Label for goto function

                if ((Common.bFlgTrigApplyGlue || Common.bFlgAutoFlowTrigApplyGlue) && Common.bFlgInitial_Finished)
                {
                    if (Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue) { CalTakePicture(); }

                    Read_Spd_Time();
                    Call_Z_Safety();

                    //Model 1
                    if (Common.iModelSelect == 1)
                    {
                        //For Point1_Step1-20
                        //P1 - Line Base Component
                        if (Common.iTrigPositionApplyGlue == 1)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Move_XY_Linear_Dodge_ZSafety_EndZero(iSPD_Movement_Fast_EndZero);//Move Z to safety area in Dodge position
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear(iSPD_LineMove_Normal);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal
                                    
                                    Move_XY_Linear(iSPD_LineMove_M1_P1);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear_Dodge_ZSafety(iSPD_Movement_Fast);//Move Z up to safety area in Dodge position

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                        //P2 - 1 Line Base Component
                        else if (Common.iTrigPositionApplyGlue == 2)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Move_XY_Linear_Dodge_ZSafety_EndZero(iSPD_Movement_Fast_EndZero);//Move Z to safety area in Dodge position
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear(iSPD_LineMove_Normal);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                    
                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal

                                    Move_XY_Linear(iSPD_LineMove_M1_P2);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear_Dodge_ZSafety(iSPD_Movement_Fast);//Move Z up to safety area in Dodge position

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move
                                    
                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                        //P3 - 1 Line Base Component
                        else if (Common.iTrigPositionApplyGlue == 3)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Move_XY_Linear_Dodge_ZSafety_EndZero(iSPD_Movement_Fast_EndZero);//Move Z to safety area in Dodge position
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear(iSPD_LineMove_Normal);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal

                                    Move_XY_Linear(iSPD_LineMove_M1_P3);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear_Dodge_ZSafety(iSPD_Movement_Fast);//Move Z up to safety area in Dodge position

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                        //P4 - 1 Line Top Component
                        else if (Common.iTrigPositionApplyGlue == 4)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Z_Move_Up_Safety();//Move Z to safety area
                                    Move_XY_Linear_EndZero(iSPD_Movement_Fast_EndZero);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal

                                    Move_XY_Linear(iSPD_LineMove_M1_P4);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Z_Move_Up_Safety();//Move Z to safety area

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                        //P5 - 1 Line Top Component
                        else if (Common.iTrigPositionApplyGlue == 5)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Z_Move_Up_Safety();//Move Z to safety area
                                    Move_XY_Linear_EndZero(iSPD_Movement_Fast_EndZero);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal

                                    Move_XY_Linear(iSPD_LineMove_M1_P5);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Z_Move_Up_Safety();//Move Z to safety area

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                        //P6 - 1 Line Top Component
                        else if (Common.iTrigPositionApplyGlue == 6)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Z_Move_Up_Safety();//Move Z to safety area
                                    Move_XY_Linear_EndZero(iSPD_Movement_Fast_EndZero);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal

                                    Move_XY_Linear(iSPD_LineMove_M1_P6);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Z_Move_Up_Safety();//Move Z to safety area

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                        //P7 - 1 Line Base Component
                        else if (Common.iTrigPositionApplyGlue == 7)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Move_XY_Linear_Dodge_ZSafety_EndZero(iSPD_Movement_Fast_EndZero);//Move Z to safety area in Dodge position
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear(iSPD_LineMove_Normal);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal

                                    Move_XY_Linear(iSPD_LineMove_M1_P7);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear_Dodge_ZSafety(iSPD_Movement_Fast);//Move Z up to safety area in Dodge position

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                        //P8 - 1 Line Base Component
                        else if (Common.iTrigPositionApplyGlue == 8)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Move_XY_Linear_Dodge_ZSafety_EndZero(iSPD_Movement_Fast_EndZero);//Move Z to safety area in Dodge position
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear(iSPD_LineMove_Normal);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal

                                    Move_XY_Linear(iSPD_LineMove_M1_P8);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear_Dodge_ZSafety(iSPD_Movement_Fast);//Move Z up to safety area in Dodge position

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                        //P9 - 1 Line Base Component
                        else if (Common.iTrigPositionApplyGlue == 9)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Move_XY_Linear_Dodge_ZSafety_EndZero(iSPD_Movement_Fast_EndZero);//Move Z to safety area in Dodge position
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear(iSPD_LineMove_Normal);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal

                                    Move_XY_Linear(iSPD_LineMove_M1_P9);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear_Dodge_ZSafety(iSPD_Movement_Fast);//Move Z up to safety area in Dodge position

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                        //P10 - 1 Line Base Component
                        else if (Common.iTrigPositionApplyGlue == 10)
                        {
                            if (Common.bFlgTrigApplyGlue)
                            {
                                //Check Position if Z < Z safety = move Y out from component
                                if (Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_Safety_Pos && Servo_XYZ.Z1_AXIS.Position < Common.iMem_Z_PCBBase_Pos + 10000)
                                {
                                    Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, Convert.ToInt32(Servo_XYZ.X1_AXIS.Position), Convert.ToInt32(Servo_XYZ.Y1_AXIS.Position) - 3000);//Move XY
                                    Thread.Sleep(300); CallCheckFinishMove();
                                    while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(510); CallCheckFinishMove(); }
                                }

                                while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                                Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
                                Thread.Sleep(300); CallCheckFinishMove();
                            }

                            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                            for (iApplyGlueStep = 1; iApplyGlueStep <= 2; iApplyGlueStep++) //Can edit Step value*******************************
                            {
                                CallPosition = "P" + Common.iTrigPositionApplyGlue + "_" + iApplyGlueStep;
                                CallPositionXYZ();
                                CalOffsetPosition();

                                if (iApplyGlueStep == 1)
                                {
                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Set_card_parameter();//Before move MotionBuffer need tp set card parameter first

                                    Move_XY_Linear_Dodge_ZSafety_EndZero(iSPD_Movement_Fast_EndZero);//Move Z to safety area in Dodge position
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear(iSPD_LineMove_Normal);

                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                }
                                else if (iApplyGlueStep == 2)
                                {
                                    while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                                    if (!Common.bSkipApplyGlue) { Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Set(11, 4); Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_DelayyTime(0.05); } //On Glue signal

                                    Move_XY_Linear(iSPD_LineMove_M1_P10);
                                    //Motion buffet for off glue when move finished.
                                    Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_IOControl_Reset(11, 4);
                                    Cut_Glue_X_Move_Left();//Cut Glue before move up
                                    Move_XY_Linear_Dodge(iSPD_LineMove_Normal);//Move to Dodge position
                                    Move_XY_Linear_Dodge_ZSafety(iSPD_Movement_Fast);//Move Z up to safety area in Dodge position

                                    Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Start();//For trig start MotionBuffer move

                                }
                            }

                            Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status();
                            while (Motion_Status == 0 || Motion_Status == 2) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            while (Motion_Status == 1) { if (Common.bChkAlarm) { break; } Motion_Status = Servo_XYZ.XYZ_MotionBuffer.MotionBuffer_Get_Status(); }
                            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Stop();

                            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause

                            Common.bSkipApplyGlue = false;
                            Common.bFlgAutoFlowTrigApplyGlue = false;
                            Common.bApplyGluePointFinished = true; //Apply Glue Finished.
                        }
                    }
                    //Model 2
                    else if (Common.iModelSelect == 2)
                    {
                        //For Point1_Step1-20
                        //P1 - 
                        if (Common.iTrigPositionApplyGlue == 1) { }
                        //P2 - 
                        else if (Common.iTrigPositionApplyGlue == 2) { }
                        //P3 - 
                        else if (Common.iTrigPositionApplyGlue == 3) { }
                        //P4 - 
                        else if (Common.iTrigPositionApplyGlue == 4) { }
                        //P5 - 
                        else if (Common.iTrigPositionApplyGlue == 5) { }
                        //P6 - 
                        else if (Common.iTrigPositionApplyGlue == 6) { }
                        //P7 - 
                        else if (Common.iTrigPositionApplyGlue == 7) { }
                        //P8 - 
                        else if (Common.iTrigPositionApplyGlue == 8) { }
                        //P9 - 
                        else if (Common.iTrigPositionApplyGlue == 9) { }
                        //P10 - 
                        else if (Common.iTrigPositionApplyGlue == 10) { }
                        //P11 - 
                        else if (Common.iTrigPositionApplyGlue == 11) { }
                        //P12 - 
                        else if (Common.iTrigPositionApplyGlue == 12) { }
                        //P13 - 
                        else if (Common.iTrigPositionApplyGlue == 13) { }
                        //P14 - 
                        else if (Common.iTrigPositionApplyGlue == 14) { }
                        //P15 - 
                        else if (Common.iTrigPositionApplyGlue == 15) { }
                        //P16 - 
                        else if (Common.iTrigPositionApplyGlue == 16) { }
                        //P17 - 
                        else if (Common.iTrigPositionApplyGlue == 17) { }
                        //P18 - 
                        else if (Common.iTrigPositionApplyGlue == 18) { }
                        //P19 - 
                        else if (Common.iTrigPositionApplyGlue == 19) { }
                        //P20 - 
                        else if (Common.iTrigPositionApplyGlue == 20) { }
                    }
                    //Model 3
                    else if (Common.iModelSelect == 3)
                    {
                        //For Point1_Step1-20
                        //P1 - 
                        if (Common.iTrigPositionApplyGlue == 1) { }
                        //P2 - 
                        else if (Common.iTrigPositionApplyGlue == 2) { }
                        //P3 - 
                        else if (Common.iTrigPositionApplyGlue == 3) { }
                        //P4 - 
                        else if (Common.iTrigPositionApplyGlue == 4) { }
                        //P5 - 
                        else if (Common.iTrigPositionApplyGlue == 5) { }
                        //P6 - 
                        else if (Common.iTrigPositionApplyGlue == 6) { }
                        //P7 - 
                        else if (Common.iTrigPositionApplyGlue == 7) { }
                        //P8 - 
                        else if (Common.iTrigPositionApplyGlue == 8) { }
                        //P9 - 
                        else if (Common.iTrigPositionApplyGlue == 9) { }
                        //P10 - 
                        else if (Common.iTrigPositionApplyGlue == 10) { }
                        //P11 - 
                        else if (Common.iTrigPositionApplyGlue == 11) { }
                        //P12 - 
                        else if (Common.iTrigPositionApplyGlue == 12) { }
                        //P13 - 
                        else if (Common.iTrigPositionApplyGlue == 13) { }
                        //P14 - 
                        else if (Common.iTrigPositionApplyGlue == 14) { }
                        //P15 - 
                        else if (Common.iTrigPositionApplyGlue == 15) { }
                        //P16 - 
                        else if (Common.iTrigPositionApplyGlue == 16) { }
                        //P17 - 
                        else if (Common.iTrigPositionApplyGlue == 17) { }
                        //P18 - 
                        else if (Common.iTrigPositionApplyGlue == 18) { }
                        //P19 - 
                        else if (Common.iTrigPositionApplyGlue == 19) { }
                        //P20 - 
                        else if (Common.iTrigPositionApplyGlue == 20) { }
                    }
                    //Model 4
                    else if (Common.iModelSelect == 4)
                    {
                        //For Point1_Step1-20
                        //P1 - 
                        if (Common.iTrigPositionApplyGlue == 1) { }
                        //P2 - 
                        else if (Common.iTrigPositionApplyGlue == 2) { }
                        //P3 - 
                        else if (Common.iTrigPositionApplyGlue == 3) { }
                        //P4 - 
                        else if (Common.iTrigPositionApplyGlue == 4) { }
                        //P5 - 
                        else if (Common.iTrigPositionApplyGlue == 5) { }
                        //P6 - 
                        else if (Common.iTrigPositionApplyGlue == 6) { }
                        //P7 - 
                        else if (Common.iTrigPositionApplyGlue == 7) { }
                        //P8 - 
                        else if (Common.iTrigPositionApplyGlue == 8) { }
                        //P9 - 
                        else if (Common.iTrigPositionApplyGlue == 9) { }
                        //P10 - 
                        else if (Common.iTrigPositionApplyGlue == 10) { }
                        //P11 - 
                        else if (Common.iTrigPositionApplyGlue == 11) { }
                        //P12 - 
                        else if (Common.iTrigPositionApplyGlue == 12) { }
                        //P13 - 
                        else if (Common.iTrigPositionApplyGlue == 13) { }
                        //P14 - 
                        else if (Common.iTrigPositionApplyGlue == 14) { }
                        //P15 - 
                        else if (Common.iTrigPositionApplyGlue == 15) { }
                        //P16 - 
                        else if (Common.iTrigPositionApplyGlue == 16) { }
                        //P17 - 
                        else if (Common.iTrigPositionApplyGlue == 17) { }
                        //P18 - 
                        else if (Common.iTrigPositionApplyGlue == 18) { }
                        //P19 - 
                        else if (Common.iTrigPositionApplyGlue == 19) { }
                        //P20 - 
                        else if (Common.iTrigPositionApplyGlue == 20) { }
                    }

                    #region If trig from manual move need to move back to home and reset signal.
                    if (Common.bFlgTrigApplyGlue)
                    {
                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                        Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Movement_Fast);//Move Z up to home
                        Thread.Sleep(300); CallCheckFinishMove();
                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                        if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                        while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
                        Servo_XYZ.RZ_AXIS.PosMoveAbs(Common.iMem_RZ_Home_Pos, iSPD_RZ_Move);//Move RZ up to home
                        Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, Common.iMem_X_Home_Pos, Common.iMem_Y_Home_Pos);//Move XY to home
                        Thread.Sleep(300); CallCheckFinishMove();
                        while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
                        if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { goto EndTrigApplyGlue; }

                        Common.bApplyGluePointFinished = false; //Apply Glue Finished.
                        Common.bFlgTrigApplyGlue = false;
                    }
                    #endregion


                }
            }
        }

        public void ToolsChange_Select()
        {
            while (true)
            {
                if (Common.bTool_1_Pick_Trig)
                {
                    Common.bTool_1_Pick_Trig = false;
                    Common.bManualPickPlaceOnWork = true;
                    Tool_1_Pick_up();
                }
                if (Common.bTool_1_Place_Trig)
                {
                    Common.bTool_1_Place_Trig = false;
                    Common.bManualPickPlaceOnWork = true;
                    Tool_1_Place();
                }
                if (Common.bTool_2_Pick_Trig)
                {
                    Common.bTool_2_Pick_Trig = false;
                    Common.bManualPickPlaceOnWork = true;
                    Tool_2_Pick_up();
                }
                if (Common.bTool_2_Place_Trig)
                {
                    Common.bTool_2_Place_Trig = false;
                    Common.bManualPickPlaceOnWork = true;
                    Tool_2_Place();
                }
            }
        }

        public void Move_XY_Linear(int iSpeed)
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi(iSpeed, X_Position, Y_Position, Z_Position, RZ_Position);//XY move - Linear
        }
        public void Move_XY_Linear_EndZero(int iSpeed)
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi_EndZero(iSpeed, X_Position, Y_Position, Z_Position, RZ_Position);//XY move - Linear
        }
        public void Move_XY_Linear_Dodge(int iSpeed)
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi(iSpeed, X_Position, Y_Position - 3000, Z_Position, RZ_Position);//XY move - Linear
        }
        public void Move_XY_Linear_ZSafety(int iSpeed)
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi(iSpeed, X_Position, Y_Position, Z_Safety_Pos, RZ_Position);//XY move - Linear
        }
        public void Move_XY_Linear_ZSafety_EndZero(int iSpeed)
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi_EndZero(iSpeed, X_Position, Y_Position, Z_Safety_Pos, RZ_Position);//XY move - Linear
        }
        public void Move_XY_Linear_Dodge_ZSafety(int iSpeed)
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi(iSpeed, X_Position, Y_Position - 3000, Z_Safety_Pos, RZ_Position);//XY move - Linear
        }
        public void Move_XY_Linear_Dodge_ZSafety_EndZero(int iSpeed)
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi_EndZero(iSpeed, X_Position, Y_Position - 3000, Z_Safety_Pos, RZ_Position);//XY move - Linear
        }

        public void Move_XY_Curve_90_CW()
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Arc_90_Follow_CW(ISPD_ArcMove_Normal, X_Position, Y_Position);//XY move - Curve
        }
        public void Move_XY_Curve_180_CW()
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Arc_180_Follow_CW(ISPD_ArcMove_High, X_Position, Y_Position);//XY move - Curve
        }
        public void Move_XY_Curve_180_CCW()
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Arc_180_Follow_CCW(ISPD_ArcMove_High, X_Position, Y_Position);//XY move - Curve
        }

        public void Cut_Glue_X_Move_Left()
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi(iSPD_LineMove_Normal, X_Position - 5000, Y_Position, Z_Position, RZ_Position);//XY move - Linear
        }
        public void Cut_Glue_X_Move_Right()
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi(iSPD_LineMove_Normal, X_Position + 5000, Y_Position, Z_Position, RZ_Position);//XY move - Linear
        }
        public void Cut_Glue_Y_Move_Up()
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi(iSPD_LineMove_Normal, X_Position, Y_Position - 5000, Z_Position, RZ_Position);//XY move - Linear
        }
        public void Cut_Glue_Y_Move_Down()
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi(iSPD_LineMove_Normal, X_Position, Y_Position + 5000, Z_Position, RZ_Position);//XY move - Linear
        }
        public void Z_Move_Up_Safety()
        {
            Servo_XYZ.XYZ_MotionBuffer.Start_MotionBuffer_Line_Multi(iSPD_Z_Safety_Movement_Fast, X_Position, Y_Position, Z_Safety_Pos, RZ_Position);
        }

        public void Cut_Glue_X_Move_Left_Normal()
        {
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_CutGlue, X_Position - 5000, Y_Position);//XY move - Line
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { /********************************/ }

        }
        public void Cut_Glue_X_Move_Right_Normal()
        {
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_CutGlue, X_Position + 5000, Y_Position);//XY move - Line
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { /********************************/ }

        }
        public void Cut_Glue_Y_Move_Up_Normal()
        {
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_CutGlue, X_Position, Y_Position - 5000);//XY move - Line
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { /********************************/ }
        }
        public void Cut_Glue_Y_Move_Down_Normal()
        {
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if ( Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_CutGlue, X_Position, Y_Position + 5000);//XY move - Line
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm || (!Common.bFlgTrigApplyGlue && !Common.bFlgAutoFlowTrigApplyGlue)) { /********************************/ }
        }


        public void Tool_1_Place()
        {
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, Common.iMem_X_Home_Pos, Common.iMem_Y_Home_Pos);//Move XY to home
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

            Common.IOTable.DO[3, 0].Set();//Tools change move Out

            Common.IOTable.DO[3, 2].Set();//Tool-1 un-lock
            TimeOut_Start(5000);
            while (Common.IOTable.DI[3, 2].State || !Common.IOTable.DI[3, 3].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            CallPosition = "TC1_1";
            CallPositionXYZ();//Call position (Referance from "TC1_1")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            TimeOut_Start(5000);
            while (Common.IOTable.DI[3, 0].State || !Common.IOTable.DI[3, 1].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            CallPosition = "TC1_2";
            CallPositionXYZ();//Call position (Referance from "TC1_2")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            CallPosition = "TC1_3";
            CallPositionXYZ();//Call position (Referance from "TC1_3")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_LineMove_Normal);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            Common.IOTable.DO[3, 10].Reset();
            Common.IOTable.DO[3, 11].Set();

            Common.IOTable.DO[3, 2].Reset();//Tool-1 Lock
            TimeOut_Start(5000);
            while (!Common.IOTable.DI[3, 2].State || Common.IOTable.DI[3, 3].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            TimeOut_Start(5000);
            while (!Common.IOTable.DI[3, 4].State) { if (TimeOut_Respond()) { Common.bTrigToolsChangeAlarm = true; break; } } //Tools change abnormal
            Common.iToolsPick = 0;

            CallPosition = "TC1_2";
            CallPositionXYZ();//Call position (Referance from "TC1_2")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            CallPosition = "TC1_1";
            CallPositionXYZ();//Call position (Referance from "TC1_1")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            Common.IOTable.DO[3, 0].Reset();//Tools change move In
                                            //TimeOut_Start(5000);
                                            //while (!Common.IOTable.DI[3, 0].State || Common.IOTable.DI[3, 1].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

        END_Function: { }

            Common.bManualPickPlaceOnWork = false;

        }
        public void Tool_1_Pick_up()
        {
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, Common.iMem_X_Home_Pos, Common.iMem_Y_Home_Pos);//Move XY to home
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

            Common.IOTable.DO[3, 0].Set();//Tools change move Out

            CallPosition = "TC1_1";
            CallPositionXYZ();//Call position (Referance from "TC1_1")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            TimeOut_Start(5000);
            while (Common.IOTable.DI[3, 0].State || !Common.IOTable.DI[3, 1].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            CallPosition = "TC1_2";
            CallPositionXYZ();//Call position (Referance from "TC1_2")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            CallPosition = "TC1_3";
            CallPositionXYZ();//Call position (Referance from "TC1_3")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_LineMove_Normal);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            Common.IOTable.DO[3, 2].Set();//Tool-1 un-lock
            TimeOut_Start(5000);
            while (Common.IOTable.DI[3, 2].State || !Common.IOTable.DI[3, 3].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            if (Common.IOTable.DI[3, 4].State) { Common.IOTable.DO[3, 10].Set(); Common.IOTable.DO[3, 11].Reset(); Common.iToolsPick = 1; Thread.Sleep(500); }
            else { Common.bTrigToolsChangeAlarm = true; } //Tools change abnormal


            CallPosition = "TC1_2";
            CallPositionXYZ();//Call position (Referance from "TC1_2")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            if (!Common.IOTable.DI[3, 4].State) { Thread.Sleep(500); } //Check sensor after pickup
            else { Common.iToolsPick = 0; Common.bTrigToolsChangeAlarm = true; }//Tools change abnormal


            CallPosition = "TC1_1";
            CallPositionXYZ();//Call position (Referance from "TC1_1")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            Common.IOTable.DO[3, 0].Reset();//Tools change move In
                                            //TimeOut_Start(5000);
                                            //while (!Common.IOTable.DI[3, 0].State || Common.IOTable.DI[3, 1].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

        END_Function: { }

            Common.bManualPickPlaceOnWork = false;

        }
        public void Tool_2_Place()
        {
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, Common.iMem_X_Home_Pos, Common.iMem_Y_Home_Pos);//Move XY to home
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

            Common.IOTable.DO[3, 5].Set();//Tools change move Out

            Common.IOTable.DO[3, 7].Set();//Tool-2 un-lock
            TimeOut_Start(5000);
            while (Common.IOTable.DI[3, 7].State || !Common.IOTable.DI[3, 8].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            CallPosition = "TC2_1";
            CallPositionXYZ();//Call position (Referance from "TC2_1")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            TimeOut_Start(5000);
            while (Common.IOTable.DI[3, 5].State || !Common.IOTable.DI[3, 6].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            CallPosition = "TC2_2";
            CallPositionXYZ();//Call position (Referance from "TC2_2")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            CallPosition = "TC2_3";
            CallPositionXYZ();//Call position (Referance from "TC2_3")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_LineMove_Normal);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            Common.IOTable.DO[3, 10].Reset();
            Common.IOTable.DO[3, 11].Set();

            Common.IOTable.DO[3, 7].Reset();//Tool-2 Lock
            TimeOut_Start(5000);
            while (!Common.IOTable.DI[3, 7].State || Common.IOTable.DI[3, 8].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            TimeOut_Start(5000);
            while (!Common.IOTable.DI[3, 9].State) { if (TimeOut_Respond()) { Common.bTrigToolsChangeAlarm = true; break; } } //Tools change abnormal
            Common.iToolsPick = 0;

            CallPosition = "TC2_2";
            CallPositionXYZ();//Call position (Referance from "TC2_2")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            CallPosition = "TC2_1";
            CallPositionXYZ();//Call position (Referance from "TC2_1")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            Common.IOTable.DO[3, 5].Reset();//Tools change move In
                                            //TimeOut_Start(5000);
                                            //while (!Common.IOTable.DI[3, 5].State || Common.IOTable.DI[3, 6].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

        END_Function: { }

            Common.bManualPickPlaceOnWork = false;

        }
        public void Tool_2_Pick_up()
        {
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Common.iMem_Z_Home_Pos, iSPD_Z_Movement_Fast);//Move Z up to home
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, Common.iMem_X_Home_Pos, Common.iMem_Y_Home_Pos);//Move XY to home
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }

            Common.IOTable.DO[3, 5].Set();//Tools change move Out

            CallPosition = "TC2_1";
            CallPositionXYZ();//Call position (Referance from "TC2_1")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            TimeOut_Start(5000);
            while (Common.IOTable.DI[3, 5].State || !Common.IOTable.DI[3, 6].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            CallPosition = "TC2_2";
            CallPositionXYZ();//Call position (Referance from "TC2_2")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            CallPosition = "TC2_3";
            CallPositionXYZ();//Call position (Referance from "TC2_3")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_LineMove_Normal, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_LineMove_Normal);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            Common.IOTable.DO[3, 7].Set();//Tool-2 un-lock
            TimeOut_Start(5000);
            while (Common.IOTable.DI[3, 7].State || !Common.IOTable.DI[3, 8].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

            if (Common.IOTable.DI[3, 9].State) { Common.IOTable.DO[3, 10].Set(); Common.IOTable.DO[3, 11].Reset(); Common.iToolsPick = 2; Thread.Sleep(500); }
            else { Common.bTrigToolsChangeAlarm = true; } //Tools change abnormal


            CallPosition = "TC2_2";
            CallPositionXYZ();//Call position (Referance from "TC2_2")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }


            if (!Common.IOTable.DI[3, 9].State) { Thread.Sleep(500); } //Check sensor after pickup
            else { Common.iToolsPick = 0; Common.bTrigToolsChangeAlarm = true; } //Tools change abnormal


            CallPosition = "TC2_1";
            CallPositionXYZ();//Call position (Referance from "TC2_1")
            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.XY_Multi.MultiXY_Move_Abs(iSPD_Movement_Fast, X_Position, Y_Position);//Move XY
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            while (Common.bChkPauseButtonPush || (Common.bChkAreaSensor && (!Common.IOTable.DI[0, 0].State || !Common.IOTable.DI[0, 3].State))) { if (Common.bChkAlarm) { break; } }//while Pause
            Servo_XYZ.Z1_AXIS.PosMoveAbs(Z_Position, iSPD_Movement_Fast);//Move Z
            Thread.Sleep(300); CallCheckFinishMove();
            while (!bChk_X1_MoveDone || !bChk_Y1_MoveDone || /*!bChk_Y2_MoveDone ||*/ !bChk_Z1_MoveDone || !bChk_RZ_MoveDone || !bChk_YSyc_MoveDone || !bChk_XYMulti_MoveDone || !bChk_XYZ_MotionBuffer_MoveDone) { if (Common.bChkAlarm) { break; } Thread.Sleep(300); CallCheckFinishMove(); }
            if (Common.bChkAlarm) { goto END_Function; }

            Common.IOTable.DO[3, 5].Reset();//Tools change move In
                                            //TimeOut_Start(5000);
                                            //while (!Common.IOTable.DI[3, 5].State || Common.IOTable.DI[3, 6].State) { if (TimeOut_Respond()) { Common.bSolenoidTimeOutAlarm = true; break; } }

        END_Function: { }

            Common.bManualPickPlaceOnWork = false;

        }

        public bool TimeOut_Start(uint time)
        {
            _startTime = GetTickCount();
            _spanTime = time;
            IsUsing = true;
            return true;
        }
        public bool TimeOut_Respond()
        {
            if (IsUsing)
            {
                uint a = GetTickCount();
                if (a - _startTime > _spanTime)
                {
                    //IsUsing = false;
                    return true;
                }
                else
                    return false;

            }
            else
            {
                return false;
            }
        }

        public void Read_Spd_Time()
        {
            iSPD_LineMove_M1_P1 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P1_Speed").ToInt();
            iSPD_LineMove_M1_P2 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P2_Speed").ToInt();
            iSPD_LineMove_M1_P3 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P3_Speed").ToInt();
            iSPD_LineMove_M1_P4 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P4_Speed").ToInt();
            iSPD_LineMove_M1_P5 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P5_Speed").ToInt();
            iSPD_LineMove_M1_P6 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P6_Speed").ToInt();
            iSPD_LineMove_M1_P7 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P7_Speed").ToInt();
            iSPD_LineMove_M1_P8 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P8_Speed").ToInt();
            iSPD_LineMove_M1_P9 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P9_Speed").ToInt();
            iSPD_LineMove_M1_P10 = Common.Config.ReadValue("Model_1_Speed_GlueTime", "P10_Speed").ToInt();
        }

        public void MES_Send_Check()
        {
            if (RFID_Data_trim == "")
            {
                //Buzzer on and off for alarm
                Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);

                DialogResult re = MessageBox.Show("Yes = Skip send data to MES\n No = RFID alarm and error", "Haven't RFID Data", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                if (re == DialogResult.Yes) { return; }
                else { Common.bMESFail = true; }
            }

            if (!Common.bChkMES_BYPASS && !Common.bMESFail)
            {
                MES_Factory = Common.Para.ReadValue("MES", "Factory").ToString();
                //MES_MO_Num = Common.Para.ReadValue("MES", "MO_Num").ToString();
                //MES_Model = Common.Para.ReadValue("MES", "Model").ToString();
                //MES_LineName = Common.Para.ReadValue("MES", "LineName").ToString();
                MES_Secion = Common.Para.ReadValue("MES", "Section").ToString();
                MES_Group = Common.Para.ReadValue("MES", "Group").ToString();
                MES_Station = Common.Para.ReadValue("MES", "Station").ToString();

                ResMsg_1 ReceiveSNInfo = new ResMsg_1();

                pTest_data = Common.RFID_Read_Data.Trim('\0') + "}";
                pLog_data = "";

                try
                {
                    ReceiveSNInfo = Common.MES.GET_SN_INFO(MES_Factory, pTest_data, pLog_data);

                    MO_Read = ReceiveSNInfo.description.MO;
                    Model_Read = ReceiveSNInfo.description.Model;
                    LineName_Read = ReceiveSNInfo.description.WipLine;

                    Common.Para.WriteValue("MES", "MO_Num", MO_Read);
                    Common.Para.WriteValue("MES", "Model", Model_Read);
                    Common.Para.WriteValue("MES", "LineName", LineName_Read);
                }
                catch
                {
                    //Buzzer on and off for alarm
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);

                    DialogResult re = MessageBox.Show("Yes = Skip Get SN info\n No = MES alarm and error", "Can't Get SN info", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                    if (re == DialogResult.Yes) { }
                    else { Common.bMESFail = true; }
                }


                pTest_data = Common.RFID_Read_Data.Trim('\0') + "}" + MO_Read + "}" + Model_Read + "}" + LineName_Read + "}" + MES_Secion + "}" + MES_Group + "}" + MES_Station + "}";

                pLog_data = "";

            MES_SEND_AGAIN:

                MESChkResult = Common.MES.ROUTING_Check(MES_Factory, pTest_data, pLog_data);

                if (MESChkResult.Result == "FAIL")
                {
                    //Buzzer on and off for alarm
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);

                    DialogResult re = MessageBox.Show("MES Check Fail\n | Abort = Reject and send to next\n | Retry = try again\n | Ignore = Skip Check Routing MES", "MES Check Routing Fail", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Question);
                    if (re == DialogResult.Abort) { MES_Reject_Chk = true; }
                    else if (re == DialogResult.Retry) { goto MES_SEND_AGAIN; }
                    else { /*Nothing to do*/ }

                }
            }
        }
        public void MES_Send_Update()
        {
            if (!Common.bChkMES_BYPASS)
            {
                MES_Factory = Common.Para.ReadValue("MES", "Factory").ToString();
                MES_MO_Num = Common.Para.ReadValue("MES", "MO_Num").ToString();
                MES_Model = Common.Para.ReadValue("MES", "Model").ToString();
                MES_LineName = Common.Para.ReadValue("MES", "LineName").ToString();
                MES_Secion = Common.Para.ReadValue("MES", "Section").ToString();
                MES_Group = Common.Para.ReadValue("MES", "Group").ToString();
                MES_Station = Common.Para.ReadValue("MES", "Station").ToString();

                pTest_data = Common.RFID_Read_Data.Trim('\0') + "}" + MES_MO_Num + "}" + MES_Model + "}" + MES_LineName + "}" + MES_Secion + "}" + MES_Group + "}" + MES_Station
                    + "}0}PASS}User}H022111607}1}none}";

                pLog_data = ""; //input data if have data need to send -> "data}data}" <- wait test.

            MES_SEND_AGAIN:

                MESChkResult = Common.MES.ROUTING_Update(MES_Factory, pTest_data, pLog_data);

                if (MESChkResult.Result == "Fail")
                {
                    //Buzzer on and off for alarm
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);
                    Common.IOTable.DO[0, 13].Set(); Thread.Sleep(250); Common.IOTable.DO[0, 13].Reset(); Thread.Sleep(250);

                    DialogResult re = MessageBox.Show("MES Update Fail\n | Abort = MES Fail\n | Retry = try again\n | Ignore = Skip Update MES and send to next", "MES Update Fail", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Question);
                    if (re == DialogResult.Abort) { Common.bMESFail = true; }
                    else if (re == DialogResult.Retry) { goto MES_SEND_AGAIN; }
                    else { /*Nothing to do*/ }

                }
            }
        }

    }
}
