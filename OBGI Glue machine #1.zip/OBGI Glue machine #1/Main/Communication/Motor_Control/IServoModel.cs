﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Communication.EtherCAT;

namespace Communication.Motor_Control
{
    public interface IServoModel
    {
        void EStop();
        /// <param name="Tdec"></param>
        void Stop(double Tdec);

        void ClearError();

        bool Alarm { get; }

        bool TargetDone { get; }

        ushort MotionDone { get; }

        ushort MotionBufferStatus { get; }

        ushort GantryHomeStatus { get; }

        int MDBlockNum { get; }

        EcurveMode curveMode { get; set; }

        int ErrorCode { get; }

        bool isOpen { get; }

        IControlCard ParentCard { get; set; }

        ushort SlaveNo { get; set; }

        int Command { get; }

        int Position { get; }

        short Torque { get; }

        int Speed { get; }

        bool ServoOn { get; set; }

        bool N_limit { get; }

        bool P_limit { get; }

        bool H_limit { get; }

        void Close();

        void Open();

        void update();

        void DriverUpdate();

        void Reset();

        /// <param name="StrVel"></param>
        /// <param name="MaxVel"></param>
        /// <param name="Dist"></param>
        /// <param name="Tacc"></param>
        /// <param name="Tdec"></param>
        void Pos_Move_Rel(int StrVel, int MaxVel, int Dist, double Tacc, double Tdec);

        /// <param name="StrVel"></param>
        /// <param name="MaxVel"></param>
        /// <param name="Dist"></param>
        /// <param name="Tacc"></param>
        /// <param name="Tdec"></param>
        void Pos_Move_Abs(int StrVel, int MaxVel, int Dist, double Tacc, double Tdec);





        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        void Write_Sever_Config_P1_44(ushort XSlaveNo);
        void Write_Sever_Config_P1_44_B3(ushort XSlaveNo);
        void MultiXY_Pos_Move_Abs(ushort XSlaveNo, ushort Y1SlaveNo, ushort Y2SlaveNo, int StrVel, int MaxVel, int EndVel, int DistX, int DistY, double Tacc, double Tdec);
        void MultiXY_Pos_Move_Rel(ushort XSlaveNo, ushort Y1SlaveNo, ushort Y2SlaveNo, int StrVel, int MaxVel, int EndVel, int DistX, int DistY, double Tacc, double Tdec);

        void YAxis_Sync_Config(ushort Y1_SlaveNo, ushort Y2_SlaveNo);
        void XYAxis_Sync_Config(ushort X1_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo);
        void Axis_Sync_Move();



        void CSP_Follow_Enable(ushort Y1_SlaveNo, ushort Y2_SlaveNo, ushort status);
        void Gantry_Set_Home_Config(ushort FirstVel, ushort SecondVel, double Acc);
        void Gantry_Home_Move();
        void Gantry_Disable_Home_Move();
        void Set_Home_Edge_Trigger_Level();



        void MotionBuffer_Set_card_parameter(ushort X1_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, ushort Z1_SlaveNo, ushort RZ_SlaveNo);
        void MotionBuffer_Arc_90_Follow(ushort X_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, int DistX, int DistY, int TargetVel, int EndVel, ushort CircleDir);
        void MotionBuffer_Arc_180_Follow(ushort X_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, int DistX, int DistY, int TargetVel, int EndVel, ushort CircleDir);
        void MotionBuffer_Line_Multi(int DistX, int DistY, int DistZ, int DistRZ, int TargetVel);
        void MotionBuffer_Line_Multi_EndVelZero(int DistX, int DistY, int DistZ, int DistRZ, int TargetVel);
        void MotionBuffer_Start();
        void MotionBuffer_Stop();
        void MotionBuffer_IO_Control(ushort SlaveNo, ushort BitNo, ushort Value);
        void MotionBuffer_Delay(double DelayTime);
        ushort MotionBuffer_Motion_Status();

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





        /// <param name="StrVel"></param>
        /// <param name="MaxVel"></param>
        /// <param name="Tacc"></param>
        /// <param name="Direction"></param>
        void Speed_Move(int StrVel, int MaxVel, double Tacc, EDirection Direction);

        void Torque_Move(short Torque, ushort VelocityLimit, uint Slope);

        /// <param name="VelocityLimit"></param>
        void AdjustVelocityLimit(ushort VelocityLimit);

        /// <param name="Mode"></param>
        /// <param name="offset"></param>
        /// <param name="lowSpeed"></param>
        /// <param name="highSpeed"></param>
        /// <param name="acc"></param>
        void Home_Move(ushort Mode, int offset, uint lowSpeed, uint highSpeed, double acc);

        event HlogEventHandler onLogWriting;

        event HlogEventHandler onErrorLogWriting;
    }
}
