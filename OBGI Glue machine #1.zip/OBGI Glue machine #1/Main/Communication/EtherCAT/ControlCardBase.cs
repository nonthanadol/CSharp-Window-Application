﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Communication.EtherCAT
{
    public abstract class ControlCardBase : IControlCard
    {
        
        public abstract string CardName { get; }
        
        public ushort CardNo { get; set; }
        
        public abstract EControlCard BrandType { get; }
        
        public bool isOpen { get; protected set; }
        
        public abstract event HlogEventHandler onLogWriting;

        public abstract void Close();
        
        public abstract void Open();
    }
}
