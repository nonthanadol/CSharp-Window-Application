﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Communication.EtherCAT
{
    public class OutputBase : IOutputBase
    {
        private bool m_OutputState;
        public OutputBase()
        {
            m_OutputState = false;
        }
        public bool State
        {
            get { return m_OutputState; }
            protected internal set { m_OutputState = value; }
        }
        public void Reset()
        {
            m_OutputState = false;
        }
        public void Set()
        {
            m_OutputState = true;
        }
    }

    public interface IOutputBase
    {
        bool State { get; }
        void Set();
        void Reset();
    }

    public interface IOutputModel
    {

        /// <param name="index"></param>
        /// <returns></returns>
        IOutputBase this[int index] { get; }

        int OutputCount { get; }

        bool isOpen { get; }

        IControlCard ParentCard { get; set; }

        ushort SlaveNo { get; set; }

        void Close();

        void Open();

        void update();


        event HlogEventHandler onLogWriting;


        event HlogEventHandler onErrorLogWriting;
    }

    public abstract class EtherCAT_16output : IOutputModel
    {
        private OutputBase[] m_outputList;
        protected ushort _uhOutValue0To15Buffer = 0;
        ushort _i, _uhOutValue, _uhOutValueTemp;
        ushort _uhRC = 0;

        /// <param name="SlaveType"></param>
        public EtherCAT_16output(EEtherCAT_Slave_Type SlaveType)
        {
            this.SlaveType = SlaveType;
            m_outputList = new OutputBase[16];
            for (int i = 0; i < m_outputList.Length; i++)
            {
                m_outputList[i] = new OutputBase();
            }
        }

        public bool isErrorHandle { get; set; }

        public EEtherCAT_Slave_Type SlaveType { get; protected set; }

        /// <param name="index"></param>
        /// <returns></returns>
        public IOutputBase this[int index] { get { return m_outputList[index]; } }
        protected internal ushort _NodeID { get; set; }

        public uint visionNo { get; protected internal set; }

        public bool isOpen { get; protected set; }

        public int OutputCount { get { return m_outputList.Length; } }

        public IControlCard ParentCard { get; set; }

        public ushort SlaveNo { get; set; }

        public event HlogEventHandler onErrorLogWriting;

        public event HlogEventHandler onLogWriting;

        public virtual void Close()
        {
            isOpen = false;
        }

        public virtual void Open()
        {
            ushort uhRC = 0, uhNodeID = 0, uhOutValue = 0;
            uint uiVenderID = 0, uiProductCode = 0, uiRevisionNo = 0, uiDCTime = 0;

            if (ParentCard == null) { MessageBox.Show("ParentCard is null"); }
            if (ParentCard.BrandType != EControlCard.DELTA_EtherCAT) { MessageBox.Show("This parentcard interface type is not DELTA_EtherCAT"); }
            if (!ParentCard.isOpen) { MessageBox.Show("ParentCard is not Open"); }
            else
            {
                EtherCAT_DLL.CS_ECAT_Master_Get_Slave_Info(ParentCard.CardNo, SlaveNo, ref uhNodeID, ref uiVenderID, ref uiProductCode, ref uiRevisionNo, ref uiDCTime);
                if (uiVenderID != 0x1A05 && uiVenderID != 0x1DD) { MessageBox.Show("This is not Delta vender"); }
                if (uiProductCode != (uint)SlaveType) { MessageBox.Show("This is not the decive"); }
                _NodeID = uhNodeID;
                visionNo = uiRevisionNo;
                Invoke_onIOlog("Open success,NodeID:" + _NodeID + ",vision:" + visionNo);
                if (isErrorHandle)
                {
                    //uhRC = EtherCAT_DLL.CS_ECAT_Slave_R1_EC70E2_Set_Output_Enable(ParentCard.CardNo, SlaveNo, _NodeID, 1);
                    //if (uhRC != 0)
                    //    throw new Exception("CS_ECAT_Slave_R1_EC70E2_Set_Output_Enable error ,uhRC : " + uhRC);
                    _NodeID = 0;
                    uhRC = EtherCAT_DLL.CS_ECAT_Slave_DIO_Set_Output_Value(ParentCard.CardNo, SlaveNo, _NodeID, uhOutValue);
                    if (uhRC != 0)
                        for (int i = 0; i < m_outputList.Length; i++)
                        {
                            if ((uhOutValue & 1) == 1)
                                m_outputList[i].Set();
                            else
                                m_outputList[i].Reset();
                            uhOutValue >>= 1;
                        }
                    _uhOutValue0To15Buffer = uhOutValue;
                    Invoke_onIOlog("This ErrorHandle is true,Value : " + uhOutValue);
                }
                else
                {
                    //uhRC = EtherCAT_DLL.CS_ECAT_Slave_R1_EC70E2_Set_Output_Enable(ParentCard.CardNo, SlaveNo, _NodeID, 0);
                    //if (uhRC != 0)
                    //    throw new Exception("CS_ECAT_Slave_R1_EC70E2_Set_Output_Enable error ,uhRC : " + uhRC);
                    uhRC = EtherCAT_DLL.CS_ECAT_Slave_DIO_Set_Output_Value(ParentCard.CardNo, SlaveNo, _NodeID, uhOutValue);
                    if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_DIO_Set_Output_Value error,uhRC : " + uhRC); }
                    for (int i = 0; i < m_outputList.Length; i++)
                    {
                        m_outputList[i].Reset();
                    }
                    _uhOutValue0To15Buffer = uhOutValue;
                    Invoke_onIOlog("This is not ErrorHandle");
                }
                isOpen = true;
            }
        }

        public virtual void update()
        {
            if (ParentCard.isOpen)
            {
                if (isOpen)
                {
                    for (_i = 0, _uhOutValue = 0, _uhOutValueTemp = 1; _i < 16; _i++)
                    {
                        if (m_outputList[_i].State)
                            _uhOutValue = (ushort)(_uhOutValue | _uhOutValueTemp);
                        _uhOutValueTemp <<= 1;
                    }
                    if (_uhOutValue0To15Buffer != _uhOutValue)
                    {
                        _uhRC = EtherCAT_DLL.CS_ECAT_Slave_DIO_Set_Output_Value(ParentCard.CardNo, SlaveNo, _NodeID, _uhOutValue);
                        _uhOutValue0To15Buffer = _uhOutValue;
                        if (_uhRC != 0)
                            Invoke_onIOErrorlog("update function \"_ECAT_Slave_DIO_Set_Output_Value \" fail decive return error code : " + _uhRC);
                    }

                }
            }
        }
        protected virtual void Invoke_onIOlog(string msg)
        {
            if (onLogWriting != null)
                onLogWriting(this, msg);
        }
        protected virtual void Invoke_onIOErrorlog(string msg)
        {
            if (onErrorLogWriting != null)
                onErrorLogWriting(this, msg);
        }
        public override string ToString()
        {
            return "Card : " + ParentCard.CardName + " No:" + ParentCard.CardNo + " slave type " + SlaveType.ToString() + " No:" + SlaveNo.ToString();
        }
    }

}
