﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Communication.EtherCAT
{
    public class PCI_L221_P1D0 : DeltaEtherCAT
    {
        public override string CardName
        {
            get
            {
                return "PCI_L221_P1D0";
            }
        }
    }
}
