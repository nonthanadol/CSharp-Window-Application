﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Communication.EtherCAT
{
    #region Enum

    public enum EControlCard
    {
        DMC_NET,
        DELTA_EtherCAT
    }
    public enum EEtherCAT_Slave_Type
    {
        ASDA_A2_E = 0x10305070,
        ASDA_A3_E = 0x00006010,
        ASDA_B3_E = 0x00006080,
        R1_EC5621D0 = 0x5621,       //one axis pulse
        R1_EC6002 = 0x6002,         //16input
        R1_EC6022 = 0x6022,         //16input
        R1_EC7062D0 = 0x7062,       //16output
        R1_EC70A2D0 = 0x70A2,       //16output
        R1_EC70E2D0 = 0x70E2,       //16output
        R1_EC70F2D0 = 0x70F2,       //16output
        R1_EC8124D0 = 0x8124,       //AD
        R1_EC9144D0 = 0x9144,       //DA

        KaifullY2SS3 = 533
    }
    public enum EcurveMode
    {
        T_curve = 1,
        S_curve = 2
    }
    public enum EDirection
    {
        Positive = 0,
        Negative = 1
    }
    public enum EpulserMode : ushort
    {
        ABphase = 0,
        CWCCW = 1,
        Pulse_Direction = 2
    }
    #endregion

    public delegate void HRisFullingedgeEventHandler();
    public delegate void HlogEventHandler(object sender, string msg);

    public interface IControlCard
    {
        
        event HlogEventHandler onLogWriting;
       
        string CardName { get; }
        
        ushort CardNo { get; set; }
        
        bool isOpen { get; }
        
        EControlCard BrandType { get; }
        
        void Open();
        
        void Close();
    }
}
