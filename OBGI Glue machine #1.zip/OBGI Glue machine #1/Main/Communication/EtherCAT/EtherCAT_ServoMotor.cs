﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Communication.Motor_Control;

namespace Communication.EtherCAT
{
    public abstract class EtherCAT_ServoMotor : IServoModel
    {
        public EtherCAT_ServoMotor(EEtherCAT_Slave_Type SlaveType)
        {
            this.SlaveType = SlaveType;
        }
        public EEtherCAT_Slave_Type SlaveType { get; private set; }
        protected internal ushort _NodeID { get; set; }
        public bool Alarm { get; protected set; }
        public int Command { get; protected set; }
        public EcurveMode curveMode { get; set; }
        public int ErrorCode { get; protected set; }
        public bool H_limit { get; protected set; }
        public bool isOpen { get; protected set; }
        public ushort MotionDone { get; protected set; }
        public ushort MotionBufferStatus { get; protected set; }
        public ushort GantryHomeStatus { get; protected set; }
        public int MDBlockNum { get; protected set; }
        public bool N_limit { get; protected set; }
        public IControlCard ParentCard { get; set; }
        public int Position { get; protected set; }

        public short Torque { get; protected set; }
        public bool P_limit { get; protected set; }
        public abstract bool ServoOn { get; set; }
        public ushort SlaveNo { get; set; }
        public int Speed { get; protected set; }
        public bool TargetDone { get; protected set; }
        public uint visionNo { get; protected set; }
        public event HlogEventHandler onLogWriting;
        public event HlogEventHandler onErrorLogWriting;


        public abstract void ClearError();
        public abstract void Close();
        public abstract void EStop();
        public abstract void Home_Move(ushort Mode, int offset, uint lowSpeed, uint highSpeed, double acc);
        public virtual void Open()
        {
            ushort uhNodeID = 0;
            uint uiVenderID = 0;
            uint uiProductCode = 0;
            uint uiRevisionNo = 0;
            uint uiDCTime = 0;
            if (ParentCard == null) { MessageBox.Show("Not setting ParentCard"); }
            if (ParentCard.BrandType != EControlCard.DELTA_EtherCAT) { MessageBox.Show("This parentcard interface type is not DELTA_EtherCAT"); }
            if (!ParentCard.isOpen) { MessageBox.Show("Card :" + ParentCard.CardName + " No " + ParentCard.CardNo + " is not Open"); }
            else
            {
                EtherCAT_DLL.CS_ECAT_Master_Get_Slave_Info(ParentCard.CardNo, SlaveNo, ref uhNodeID, ref uiVenderID, ref uiProductCode, ref uiRevisionNo, ref uiDCTime);

                if (uiVenderID != 0x1A05 && uiVenderID != 0x1DD) { MessageBox.Show(this.ToString() + " is not Delta vender"); }
                if (uiProductCode != (uint)SlaveType) { MessageBox.Show(this.ToString() + " is not the decive"); }
                _NodeID = 0;
                visionNo = uiRevisionNo;
            }
        }
        public abstract void Pos_Move_Abs(int StrVel, int MaxVel, int Dist, double Tacc, double Tdec);
        
        /// <param name="VelocityLimit"></param>
        public abstract void AdjustVelocityLimit(ushort VelocityLimit);
        public abstract void Torque_Move(short Torque, ushort VelocityLimit, uint Slope);

        public abstract void Pos_Move_Rel(int StrVel, int MaxVel, int Dist, double Tacc, double Tdec);




        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public abstract void Write_Sever_Config_P1_44(ushort XSlaveNo);
        public abstract void Write_Sever_Config_P1_44_B3(ushort XSlaveNo);
        public abstract void MultiXY_Pos_Move_Abs(ushort XSlaveNo, ushort Y1SlaveNo, ushort Y2SlaveNo, int StrVel, int MaxVel, int EndVel, int DistX, int DistY, double Tacc, double Tdec);
        public abstract void MultiXY_Pos_Move_Rel(ushort XSlaveNo, ushort Y1SlaveNo, ushort Y2SlaveNo, int StrVel, int MaxVel, int EndVel, int DistX, int DistY, double Tacc, double Tdec);

        public abstract void YAxis_Sync_Config(ushort Y1_SlaveNo, ushort Y2_SlaveNo);
        public abstract void XYAxis_Sync_Config(ushort X1_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo);
        public abstract void Axis_Sync_Move();




        public abstract void CSP_Follow_Enable(ushort Y1_SlaveNo, ushort Y2_SlaveNo, ushort status);
        public abstract void Gantry_Set_Home_Config(ushort FirstVel, ushort SecondVel, double Acc);
        public abstract void Gantry_Home_Move();
        public abstract void Gantry_Disable_Home_Move();
        public abstract void Set_Home_Edge_Trigger_Level();



        public abstract void MotionBuffer_Set_card_parameter(ushort X1_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, ushort Z1_SlaveNo, ushort RZ_SlaveNo);
        public abstract void MotionBuffer_Arc_90_Follow(ushort X_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, int DistX, int DistY, int TargetVel, int EndVel, ushort CircleDir);
        public abstract void MotionBuffer_Arc_180_Follow(ushort X_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, int DistX, int DistY, int TargetVel, int EndVel, ushort CircleDir);
        public abstract void MotionBuffer_Line_Multi(int DistX, int DistY, int DistZ, int DistRZ, int TargetVel);
        public abstract void MotionBuffer_Line_Multi_EndVelZero(int DistX, int DistY, int DistZ, int DistRZ, int TargetVel);
        public abstract void MotionBuffer_Start();
        public abstract void MotionBuffer_Stop();
        public abstract void MotionBuffer_IO_Control(ushort SlaveNo, ushort BitNo, ushort Value);
        public abstract void MotionBuffer_Delay(double DelayTime);
        public abstract ushort MotionBuffer_Motion_Status();

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




        public abstract void Reset();
        public abstract void Speed_Move(int StrVel, int MaxVel, double Tacc, EDirection Direction);
        public abstract void Stop(double Tdec);
        public abstract void update();
        public abstract void DriverUpdate();
        protected void m_checkParentCardisOpen()
        {
            if (!ParentCard.isOpen) { MessageBox.Show("Card :" + ParentCard.CardName + " No " + ParentCard.CardNo + " is not open"); }
            if (!this.isOpen) { MessageBox.Show(this.ToString() + " is not open"); }
        }
        protected virtual void Invoke_onIOlog(string msg)
        {
            if (onLogWriting != null)
                onLogWriting(this, msg);
        }
        protected virtual void Invoke_onIOErrorlog(string msg)
        {
            if (onErrorLogWriting != null)
                onErrorLogWriting(this, msg);
        }
    }
}
