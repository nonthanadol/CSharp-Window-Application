﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Communication.EtherCAT
{
    public class DeltaEtherCAT : ControlCardBase
    {
        public DeltaEtherCAT()
        {
            isOpen = false;
            CardNo = 0;
        }
        public override string CardName { get { return "DeltaEtherCAT"; } }
        public override EControlCard BrandType { get { return EControlCard.DELTA_EtherCAT; } }
        public override event HlogEventHandler onLogWriting;

        public override void Close()
        {
            ushort uhRC;
            if (isOpen)
            {
                uhRC = EtherCAT_DLL.CS_ECAT_Master_Reset(CardNo);
                EtherCAT_DLL.CS_ECAT_Master_Close();
                isOpen = false;
            }
        }
        public override void Open()
        {
            ushort uhRC;
            if (!isOpen)
            {
                ushort uhCardNumTemp = 0;
                ushort uhSlaveNum = 0;
                ushort uInitialDone = 0;
                uhRC = EtherCAT_DLL.CS_ECAT_Master_Open(ref uhCardNumTemp);
                if (uhCardNumTemp <= 0) { MessageBox.Show("CardNo: " + CardNo + " can not find the card"); }
                else
                {
                    uhRC = EtherCAT_DLL.CS_ECAT_Master_Initial(this.CardNo);
                    if (uhRC != 0) { MessageBox.Show("CardNo: " + CardNo + "can't boot EtherCAT Master Card! decive return error code : " + uhRC); }
                    else
                    {
                        uhRC = EtherCAT_DLL.CS_ECAT_Master_Get_SlaveNum(this.CardNo, ref uhSlaveNum);
                        if (uhRC != 0) { MessageBox.Show("CardNo: " + CardNo + "can't find any slave! decive return error code : " + uhRC); }
                        else
                        {
                            for (int i = 0; i < (uhSlaveNum * 10); i++)
                            {
                                uhRC = EtherCAT_DLL.CS_ECAT_Master_Check_Initial_Done(CardNo, ref uInitialDone);
                                if (uhRC != 0) { MessageBox.Show("CardNo: " + CardNo + "can't find any slave! decive return error code : " + uhRC); }
                                else
                                {
                                    if (uInitialDone == 0)
                                    {
                                        base.isOpen = true;
                                        break;
                                    }
                                    else if (uInitialDone == 1)
                                    {

                                    }
                                    else if (uInitialDone == 99)
                                    {

                                    }
                                }
                                System.Threading.Thread.Sleep(200);
                            }
                            if (!isOpen) { MessageBox.Show("CardNo: " + CardNo + "initial fail time out"); }
                            else
                                Invoke_onControlCard_log(this, "cardNo " + CardNo + " open success");
                        }
                    }
                }
            }
        }
        /// <param name="sender">Executor</param>
        /// <param name="msg">Content</param>
        protected void Invoke_onControlCard_log(object sender, string msg)
        {
            if (onLogWriting != null)
                onLogWriting(sender, msg);
        }
    }
}
