﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Communication.EtherCAT
{
    public class InputBase : IInputBase
    {
        private bool m_InputState;
        public InputBase()
        {
            m_InputState = false;
        }
        public bool State
        {
            get
            {
                return m_InputState;
            }
            protected internal set
            {
                if (value != m_InputState)
                {
                    if (value)
                    {
                        if (onRisingedge != null)
                            onRisingedge();
                    }
                    else
                    {
                        if (onFullingdege != null)
                            onFullingdege();
                    }
                    m_InputState = value;
                }
            }
        }

        public event HRisFullingedgeEventHandler BeginRisingedge;
        public event HRisFullingedgeEventHandler BeginFullingedge;
        public event HRisFullingedgeEventHandler onRisingedge;
        public event HRisFullingedgeEventHandler onFullingdege;

        protected void m_BegineRising_edge()
        {
            if (BeginRisingedge != null)
                BeginRisingedge.BeginInvoke(new AsyncCallback(Rising), this);
        }
        protected void Rising(IAsyncResult ar)
        {
            BeginRisingedge.EndInvoke(ar);
        }
        protected void m_BeginFulling_edge()
        {
            if (onFullingdege != null)
                onFullingdege.BeginInvoke(new AsyncCallback(Fulling), this);
        }
        protected void Fulling(IAsyncResult ar)
        {
            onFullingdege.EndInvoke(ar);
        }
    }
    public interface IInputBase
    {
        bool State { get; }
        event HRisFullingedgeEventHandler BeginRisingedge;
        event HRisFullingedgeEventHandler BeginFullingedge;
        event HRisFullingedgeEventHandler onRisingedge;
        event HRisFullingedgeEventHandler onFullingdege;
    }
    public interface IInputModel
    {
        /// <param name="index"></param>
        /// <returns></returns>
        IInputBase this[int index] { get; }

        int InputCount { get; }

        bool isOpen { get; }

        IControlCard ParentCard { get; set; }

        ushort SlaveNo { get; set; }

        void Close();

        void Open();

        void update();


        event HlogEventHandler onLogWriting;


        event HlogEventHandler onErrorLogWriting;
    }

    public abstract class EtherCAT_16input : IInputModel
    {
        private InputBase[] m_InputList;
        private ushort m_uhRC;
        private ushort m_uhInValueBuffer = 0;
        private short i;
        private bool m_inputBuffer;

        public event HlogEventHandler onLogWriting;

        public event HlogEventHandler onErrorLogWriting;

        /// <param name="SlaveType">SlaveType</param>
        public EtherCAT_16input(EEtherCAT_Slave_Type SlaveType)
        {
            this.SlaveType = SlaveType;
            m_InputList = new InputBase[16];
            for (int i = 0; i < m_InputList.Length; i++)
            {
                m_InputList[i] = new InputBase();
            }
        }

        public EEtherCAT_Slave_Type SlaveType { get; protected set; }

        /// <param name="index"></param>
        /// <returns></returns>
        public IInputBase this[int index]
        {
            get
            {
                return m_InputList[index];
            }
        }

        public bool isOpen { get; protected set; }

        public IControlCard ParentCard { get; set; }

        public ushort SlaveNo { get; set; }
        protected internal ushort _NodeID { get; set; }

        public uint visionNo { get; protected internal set; }

        public int InputCount { get { return m_InputList.Length; } }

        public void Close()
        {
            isOpen = false;
        }

        public void Open()
        {
            ushort uhNodeID = 0;
            uint uiVenderID = 0;
            uint uiProductCode = 0;
            uint uiRevisionNo = 0;
            uint uiDCTime = 0;
            if (ParentCard == null) { MessageBox.Show("ParentCard is null"); }
            if (ParentCard.BrandType != EControlCard.DELTA_EtherCAT) { MessageBox.Show("ParentCard is null"); }
            if (!ParentCard.isOpen) { MessageBox.Show("Card : " + ParentCard.CardName + " No " + ParentCard.CardNo + " is not Open"); }
            else
            {
                EtherCAT_DLL.CS_ECAT_Master_Get_Slave_Info(ParentCard.CardNo, SlaveNo, ref uhNodeID, ref uiVenderID, ref uiProductCode, ref uiRevisionNo, ref uiDCTime);
                if (uiVenderID != 0x1A05 && uiVenderID != 0x1DD) { MessageBox.Show(this.ToString() + " is not Delta vender"); }
                if (uiProductCode != (uint)SlaveType) { MessageBox.Show(this.ToString() + " is not the decive"); }
                _NodeID = uhNodeID;
                visionNo = uiRevisionNo;
                Invoke_onIOlog(this.ToString() + " Open success,NodeID:" + _NodeID + ",vision:" + visionNo);
                isOpen = true;

            }
        }

        public void update()
        {

            if (ParentCard.isOpen)
            {
                if (isOpen)
                {
                    m_uhRC = EtherCAT_DLL.CS_ECAT_Slave_DIO_Get_Input_Value(ParentCard.CardNo, _NodeID, 0, ref m_uhInValueBuffer);
                    if (m_uhRC != 0)
                        Invoke_onIOErrorlog("update function \"_ECAT_Slave_DIO_Get_Input_Value \" fail decive return error code : " + m_uhRC);
                    else
                    {
                        for (i = 0; i < 16; i++)
                        {
                            m_inputBuffer = (m_uhInValueBuffer & 1) == 1 ? true : false;
                            if (m_InputList[i].State != m_inputBuffer)
                            {
                                m_InputList[i].State = m_inputBuffer;
                                this.Invoke_onIOlog("Input " + i + (m_inputBuffer ? " Risingedge" : " Fullingdege"));
                            }
                            m_uhInValueBuffer >>= 1;
                        }
                    }
                }
            }

        }
        protected virtual void Invoke_onIOlog(string msg)
        {
            if (onLogWriting != null)
                onLogWriting(this, msg);
        }
        protected virtual void Invoke_onIOErrorlog(string msg)
        {
            if (onErrorLogWriting != null)
                onErrorLogWriting(this, msg);
        }
        public override string ToString()
        {
            return "Card : " + ParentCard.CardName + " No:" + ParentCard.CardNo + " slave type " + SlaveType.ToString() + " No:" + SlaveNo.ToString();
        }
    }
}
