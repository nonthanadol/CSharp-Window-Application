﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Communication.EtherCAT;

namespace Communication.IO_Commu
{
    public class R1_EC6022 : EtherCAT_16input
    {
        public R1_EC6022() : base(EtherCAT.EEtherCAT_Slave_Type.R1_EC6022)
        {
            ;
        }
    }
}
