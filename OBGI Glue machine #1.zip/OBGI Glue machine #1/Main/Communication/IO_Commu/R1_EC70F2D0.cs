﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Communication.EtherCAT;

namespace Communication.IO_Commu
{
    public class R1_EC70F2D0 : EtherCAT_16output
    {
        public R1_EC70F2D0() : base(EEtherCAT_Slave_Type.R1_EC70F2D0)
        {
            ;
        }
    }
}
