﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Communication.EtherCAT;
using Equipment_Control.Database;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.ASDA_XX_E;
using Equipment_Control.IO_Control;


namespace Equipment_Control.Interface
{
    public interface IVariableShare
    {
        Ini Config { get; }
        Ini Para { get; }
        IOSystem IOTable { get; }
        PCI_L221_B1D0 card { get;}


        ASDA_A2_E X1_AXIS { get;}

        ASDA_A2_E Y1_AXIS { get;}

        ASDA_A2_E Y2_AXIS { get;}

        ASDA_A2_E Z1_AXIS { get;}

        ASDA_B3_E RZ_AXIS { get; }

        MES PQM { get; set; }

        Shopfloor_Http_Client MES { get; set; }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        #region UI
        bool bPassLogin { get; set; }
        bool bChkMC_RUN_STOP { get; set; }
        bool bChkAuto_Manual { get; set; }
        bool bChkMC_Bypass { get; set; }
        bool bChkAlarm { get; set; }
        bool bChkWaitManual { get; set; }
        bool bChkPauseButtonPush { get; set; }
        bool bChkInitialButtonPush { get; set; }
        bool bChkErrorResetButtonPush { get; set; }
        bool bChkMuteButtonPush { get; set; }
        bool bChkFirstInitial { get; set; }
        bool bChkFirstAuto { get; set; }



        bool bTempStartTrig { get; set; } //Temporary signal for trig machine start.
        bool bEmerOnScreen { get; set; }
        string strErrorCode { get; set; }
        bool bTrigToolsChangeAlarm { get; set; }
        bool bSolenoidTimeOutAlarm { get; set; }
        bool bCalibrationAlarm { get; set; }
        bool bRFID_select_Fail { get; set; }
        bool bRFIDCommandFail { get; set; }
        bool bMESFail { get; set; }
        bool bPQMFail { get; set; }
        bool bCameraFail { get; set; }
        bool bEtherCatCommandFail { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        int iModelSelect { get; set; }
        int iToolsPick { get; set; }
        //////////////////////////////////////////////////////////////////////////////////
        bool bFlgInitial_onWork { get; set; }
        bool bFlgInitial_Finished { get; set; }
        int iInitialFlow_Step { get; set; }
        bool bFlgAutoRun_onWork { get; set; }
        bool bFlgAutoPurge_onWork { get; set; }
        bool bFlgAlreadyApplyGlue { get; set; }
        bool bFlgWorkFinished { get; set; }
        bool bUpperSendNext { get; set; }
        int iAutoRunFlow_Step { get; set; }
        int iAutoPurgeFlow_Step { get; set; }
        int iCamere_X_Offset { get; set; }
        int iCamera_Y_Offset { get; set; }
        int iTools_X_Original { get; set; }
        int iTools_Y_Original { get; set; }
        int iTools_Z_Original { get; set; }
        int iTools_X_Offset { get; set; }
        int iTools_Y_Offset { get; set; }
        int iTools_Z_Offset { get; set; }
        bool bFlgTrigStart { get; set; }
        bool bFlgAutoFlowTrigApplyGlue { get; set; }
        bool bFlgTrigApplyGlue { get; set; }
        bool bFlgTrigMoveStepByStep { get; set; }
        bool bSkipApplyGlue { get; set; }
        bool bApplyGluePointFinished { get; set; }
        int iTrigPositionApplyGlue { get; set; }
        string strTrigPotitionMove { get; set; }
        int iTrigStepMove { get; set; }
        int iMem_X_Home_Pos { get; set; }
        int iMem_Y_Home_Pos { get; set; }
        int iMem_Z_Home_Pos { get; set; }
        int iMem_RZ_Home_Pos { get; set; }
        int iMem_Z_Safety_Pos { get; set; }
        int iMem_Z_PCBBase_Pos { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        bool bChkCVUP_MOVE_L { get; set; }
        bool bChkCVUP_MOVE_R { get; set; }
        bool bChkRFID_L { get; set; }
        bool bChkRFID_R { get; set; }
        bool bChkStopperUP { get; set; }
        bool bChkPallet_Lock { get; set; }
        bool bChkCVDown_MOVE_L { get; set; }
        bool bChkCVDown_MOVE_R { get; set; }
        bool bChkStopperDown { get; set; }
        bool bChkAutoPurge { get; set; }
        bool bChkManualPurge { get; set; }
        bool bChkTool_1_Lock { get; set; }
        bool bChkTool_1_INOUT { get; set; }
        bool bChkTool_2_Lock { get; set; }
        bool bChkTool_2_INOUT { get; set; }
        bool bTool_1_Pick_Trig { get; set; }
        bool bTool_1_Place_Trig { get; set; }
        bool bTool_2_Pick_Trig { get; set; }
        bool bTool_2_Place_Trig { get; set; }
        bool bToolsClamp { get; set; }
        bool bManualPickPlaceOnWork { get; set; }
        bool bForce_unlockJog { get; set; }

        bool bChkCameraLight { get; set; }

        //int iTimetoPurge { get; set; }
        int iPurgeTimeCount { get; set; }
        double dbSetPurgeTime { get; set; }
        int iTimetoAutoPurge { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        bool bChkO208 { get; set; }
        bool bChkO209 { get; set; }
        bool bChkO212 { get; set; }
        bool bChkO213 { get; set; }
        bool bChkSafetyDoor { get; set; }
        bool bChkAreaSensor { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        string Connection_String { get; set; }
        String RFID_Read_Data { get; set; }
        bool RFID_MANUAL { get; set; }
        bool bChkRFID_BYPASS { get; set; }
        bool bChkPQM_BYPASS { get; set; }
        bool bChkMES_BYPASS { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        int iComponent_1_Warning { get; set; }
        int iComponent_1_Limit { get; set; }
        int iComponent_1_Usage { get; set; }
        int iComponent_2_Warning { get; set; }
        int iComponent_2_Limit { get; set; }
        int iComponent_2_Usage { get; set; }
        int iComponent_3_Warning { get; set; }
        int iComponent_3_Limit { get; set; }
        int iComponent_3_Usage { get; set; }
        int iComponent_4_Warning { get; set; }
        int iComponent_4_Limit { get; set; }
        int iComponent_4_Usage { get; set; }
        int iComponent_5_Warning { get; set; }
        int iComponent_5_Limit { get; set; }
        int iComponent_5_Usage { get; set; }
        int iComponent_6_Warning { get; set; }
        int iComponent_6_Limit { get; set; }
        int iComponent_6_Usage { get; set; }
        int iComponent_7_Warning { get; set; }
        int iComponent_7_Limit { get; set; }
        int iComponent_7_Usage { get; set; }
        int iComponent_8_Warning { get; set; }
        int iComponent_8_Limit { get; set; }
        int iComponent_8_Usage { get; set; }
        int iComponent_9_Warning { get; set; }
        int iComponent_9_Limit { get; set; }
        int iComponent_9_Usage { get; set; }
        int iComponent_10_Warning { get; set; }
        int iComponent_10_Limit { get; set; }
        int iComponent_10_Usage { get; set; }
        int iComponent_11_Warning { get; set; }
        int iComponent_11_Limit { get; set; }
        int iComponent_11_Usage { get; set; }
        int iComponent_12_Warning { get; set; }
        int iComponent_12_Limit { get; set; }
        int iComponent_12_Usage { get; set; }
        int iComponent_13_Warning { get; set; }
        int iComponent_13_Limit { get; set; }
        int iComponent_13_Usage { get; set; }
        int iComponent_14_Warning { get; set; }
        int iComponent_14_Limit { get; set; }
        int iComponent_14_Usage { get; set; }
        int iComponent_15_Warning { get; set; }
        int iComponent_15_Limit { get; set; }
        int iComponent_15_Usage { get; set; }
        bool bChkCompo_1 { get; set; }
        bool bChkCompo_2 { get; set; }
        bool bChkCompo_3 { get; set; }
        bool bChkCompo_4 { get; set; }
        bool bChkCompo_5 { get; set; }
        bool bChkCompo_6 { get; set; }
        bool bChkCompo_7 { get; set; }
        bool bChkCompo_8 { get; set; }
        bool bChkCompo_9 { get; set; }
        bool bChkCompo_10 { get; set; }
        bool bChkCompo_11 { get; set; }
        bool bChkCompo_12 { get; set; }
        bool bChkCompo_13 { get; set; }
        bool bChkCompo_14 { get; set; }
        bool bChkCompo_15 { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        double dbNozzle1_First_Set_X { get; set; }
        double dbNozzle1_First_Set_Y { get; set; }
        double dbNozzle1_First_Set_Z { get; set; }
        double dbNozzle1_Now_X { get; set; }
        double dbNozzle1_Now_Y { get; set; }
        double dbNozzle1_Now_Z { get; set; }
        double dbNozzle2_First_Set_X { get; set; }
        double dbNozzle2_First_Set_Y { get; set; }
        double dbNozzle2_First_Set_Z { get; set; }
        double dbNozzle2_Now_X { get; set; }
        double dbNozzle2_Now_Y { get; set; }
        double dbNozzle2_Now_Z { get; set; }
        double dbNozzle_X_Diff { get; set; }
        double dbNozzle_Y_Diff { get; set; }
        double dbNozzle_Z_Diff { get; set; }
        double dbNozzle_2_X_Diff { get; set; }
        double dbNozzle_2_Y_Diff { get; set; }
        double dbNozzle_2_Z_Diff { get; set; }
        int iNozzle_Cal_Select { get; set; }
        double dbCamera_X1 { get; set; }
        double dbCamera_X2 { get; set; }
        double dbCamera_Y1 { get; set; }
        double dbCamera_Y2 { get; set; }
        double dbServo_X1 { get; set; }
        double dbServo_X2 { get; set; }
        double dbServo_Y1 { get; set; }
        double dbServo_Y2 { get; set; }
        double dbCamera_X_Result { get; set; }
        double dbCamera_Y_Result { get; set; }
        double dbX_pixel_master { get; set; }
        double dbY_pixel_master { get; set; }
        bool bCalibrationToolsTrig { get; set; }
        bool bCalibration_onwork { get; set; }
        int bCalibration_FlowStep { get; set; }
        bool bChkCemeraOffset { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        int[] iCameraReadData { get; set; }
        double dbCam_1st_data { get; set; }
        double dbCam_2nd_data { get; set; }
        double dbCam_3rd_data { get; set; }
        double dbCam_4th_data { get; set; }
        double dbCam_5th_data { get; set; }

        double dbX_Center_ref { get; set; }
        double dbY_Center_ref { get; set; }
        double dbX_ChkZone { get; set; }
        double dbY_ChkZone { get; set; }
        double dbX_buffer_position { get; set; }
        double dbY_buffer_position { get; set; }
        double dbR_buffer_position { get; set; }
        double dbTheta_buffet_rad { get; set; }
        double dbMas_X_position { get; set; }
        double dbMas_Y_position { get; set; }
        double dbCam_X_position { get; set; }
        double dbCam_Y_position { get; set; }
        double dbCam_Theta_deg { get; set; }
        double dbCam_Theta_rad { get; set; }
        double dbX_offset_position { get; set; }
        double dbY_offset_position { get; set; }
        double dbTheta_changed { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        int iPQM_Status { get; set; }
        int iPQM_Status_Code { get; set; }
        int iPQM_PassQty { get; set; }
        int iPQM_FailQty { get; set; }
        int iPQM_Error_Count { get; set; }
        int iPQM_Error_Time { get; set; }
        int iPQM_Cycle_Time { get; set; }
        int iPQM_Running_Time { get; set; }
        int iPQM_Waiting_Time { get; set; }
        int iPQM_InputQty { get; set; }
        int iPQM_Self_Check { get; set; }
        int iPQM_CT_M { get; set; }
        int iPQM_CT_Q { get; set; }

        //////////////////////////////////////////////////////////////////////////////////

        #endregion

    }
}
