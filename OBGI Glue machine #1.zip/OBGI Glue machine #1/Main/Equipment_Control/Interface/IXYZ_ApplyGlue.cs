﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Communication.EtherCAT;
using Communication.IO_Commu;
using Communication.Motor_Control;
using Equipment_Control;
using Equipment_Control.IO_Control;
using Equipment_Control.Database;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.ASDA_XX_E;

namespace Equipment_Control.Interface
{
    public interface IXYZ_ApplyGlue
    {
        IOSystem IOTable { get; }
        Ini Config { get; }
        Ini Para { get; }
        ASDA_A2_E X1_AXIS { get; }
        ASDA_A2_E Y1_AXIS { get; }
        ASDA_A2_E Y2_AXIS { get; }
        ASDA_A2_E Z1_AXIS { get; }
        ASDA_B3_E RZ_AXIS { get; }


        ASDA_A2_E Y_Sync_Axis { get; }
        ASDA_A2_E XY_Multi { get; }
        ASDA_A2_E XYZ_MotionBuffer { get; }

    }
}
