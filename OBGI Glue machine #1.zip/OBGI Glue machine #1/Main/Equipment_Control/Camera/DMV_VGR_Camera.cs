﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;
///////////////////////////////////////////////
using EasyModbus;
///////////////////////////////////////////////
using Equipment_Control.Interface;

namespace Equipment_Control.Camera
{
    public class DMV_VGR_Camera
    {
        ModbusClient CameraIP;
        IVariableShare _Common;

        string IP_Read;

        #region Communication
        public DMV_VGR_Camera(IVariableShare common)
        {
            _Common = common;

            IP_Read = _Common.Config.ReadValue("Camera", "Camera_IP").ToString();

            CameraIP = new ModbusClient(IP_Read, 502);
        }

        public void Read_Holding_Registers()
        {
            int iChkRound = 0;

            try
            {
                Clear_Camera_data();

            ReadAgain:
                CameraIP.Connect();

                while (_Common.dbCam_1st_data == 0) //Read until camera system finished
                {
                    //Output from camera you need to setting what the data you need to return.
                    _Common.iCameraReadData = CameraIP.ReadHoldingRegisters(4112, 10); //Address 0x1010(Hex) to 4112(Dec) & 10 = Read 10 data from 4112 to 4122
                    _Common.dbCam_1st_data = (Convert.ToDouble(Two_wordIntToInt32(_Common.iCameraReadData[0], _Common.iCameraReadData[1]))); // 1st is system check finised
                    _Common.dbCam_2nd_data = (Convert.ToDouble(Two_wordIntToInt32(_Common.iCameraReadData[2], _Common.iCameraReadData[3]))); // 2nd is shape judge
                    _Common.dbCam_3rd_data = (Convert.ToDouble(Two_wordIntToInt32(_Common.iCameraReadData[4], _Common.iCameraReadData[5])) / 1000.00); // 3rd is X value
                    _Common.dbCam_4th_data = (Convert.ToDouble(Two_wordIntToInt32(_Common.iCameraReadData[6], _Common.iCameraReadData[7])) / 1000.00); // 4th is Y value
                    _Common.dbCam_5th_data = (Convert.ToDouble(Two_wordIntToInt32(_Common.iCameraReadData[8], _Common.iCameraReadData[9])) / 1000.00); // 5th is Angle value
                }

                if (_Common.dbCam_2nd_data != 1 && iChkRound < 4) { Thread.Sleep(200); Clear_Camera_data(); Write_Single_registor(4096, 1); iChkRound++; goto ReadAgain; }
                if (_Common.dbCam_2nd_data != 1 && iChkRound >= 4) { _Common.bCameraFail = true; return; }

                //_Common.dbCam_X_position = _Common.dbCam_3rd_data; //Normal direction
                //_Common.dbCam_Y_position = _Common.dbCam_4th_data; //Normal direction

                _Common.dbCam_X_position = _Common.dbCam_4th_data; //Camera miss direction then must to switch data
                _Common.dbCam_Y_position = _Common.dbCam_3rd_data; //Camera miss direction then must to switch data

                _Common.dbCam_Theta_deg = _Common.dbCam_5th_data;


                CameraIP.Disconnect();
            }
            catch { MessageBox.Show("Read Holdeing Registers Error"); _Common.bCameraFail = true; return; }
        }

        public void Write_Single_registor(int address, int va)
        {
            try
            {
                CameraIP.Connect();
                CameraIP.WriteSingleRegister(address, va);
                CameraIP.Disconnect();
            }
            catch { MessageBox.Show("Write Single Registor Error"); _Common.bCameraFail = true; return; }
        }

        public void Write_Multiple_registor(int address, int[] va)
        {
            try
            {
                CameraIP.Connect();
                CameraIP.WriteMultipleRegisters(address, va);
                CameraIP.Disconnect();
            }
            catch { MessageBox.Show("Write Multiple Registor Error"); }
        }

        private Int32 Two_wordIntToInt32(int w1, int w2)
        {
            byte[] intBytes1 = BitConverter.GetBytes(w1);
            byte[] intBytes2 = BitConverter.GetBytes(w2);
            byte[] vbyte = new byte[4];

            vbyte[0] = intBytes1[0];
            vbyte[1] = intBytes1[1];
            vbyte[2] = intBytes2[0];
            vbyte[3] = intBytes2[1];

            Int32 v1 = System.BitConverter.ToInt32(vbyte, 0);

            return v1;
        }
        #endregion

        public void Cal_offset_position(int X_position, int Y_position)
        {
            _Common.dbX_buffer_position = X_position; //X teaching position
            _Common.dbY_buffer_position = Y_position; //Y teaching position

            _Common.dbX_ChkZone = _Common.dbX_buffer_position - _Common.dbX_Center_ref;
            _Common.dbY_ChkZone = _Common.dbY_buffer_position - _Common.dbY_Center_ref;

            _Common.dbR_buffer_position = Math.Sqrt(Math.Pow(_Common.dbX_ChkZone, 2) + Math.Pow(_Common.dbY_ChkZone, 2));


            //Zone-A (X+,Y+)
            if (_Common.dbX_ChkZone > 0 && _Common.dbY_ChkZone > 0)
            {
                _Common.dbTheta_buffet_rad = Math.Atan2(_Common.dbY_ChkZone, _Common.dbX_ChkZone);

                _Common.dbCam_Theta_rad = _Common.dbCam_Theta_deg / 57.295778; //convert deg to rad.

                _Common.dbTheta_changed = _Common.dbTheta_buffet_rad + _Common.dbCam_Theta_rad;

                _Common.dbX_offset_position = _Common.dbR_buffer_position * Math.Cos(_Common.dbTheta_changed);
                _Common.dbY_offset_position = _Common.dbR_buffer_position * Math.Sin(_Common.dbTheta_changed);

                _Common.dbX_offset_position = _Common.dbX_offset_position + _Common.dbX_Center_ref - ((_Common.dbMas_X_position - _Common.dbCam_X_position) * _Common.dbCamera_X_Result);
                _Common.dbY_offset_position = _Common.dbY_offset_position + _Common.dbY_Center_ref - ((_Common.dbMas_Y_position - _Common.dbCam_Y_position) * _Common.dbCamera_Y_Result);
            }
            //Zone-B (X-,Y+)
            else if (_Common.dbX_ChkZone < 0 && _Common.dbY_ChkZone > 0)
            {
                _Common.dbX_ChkZone = _Common.dbX_ChkZone * (-1); //Convert X

                _Common.dbTheta_buffet_rad = Math.Atan2(_Common.dbY_ChkZone, _Common.dbX_ChkZone);

                _Common.dbCam_Theta_rad = _Common.dbCam_Theta_deg / 57.295778; //convert deg to rad.

                _Common.dbTheta_changed = _Common.dbTheta_buffet_rad - _Common.dbCam_Theta_rad; // - rad

                _Common.dbX_offset_position = _Common.dbR_buffer_position * Math.Cos(_Common.dbTheta_changed);
                _Common.dbX_offset_position = _Common.dbX_offset_position * (-1); //Convert X back
                _Common.dbY_offset_position = _Common.dbR_buffer_position * Math.Sin(_Common.dbTheta_changed);

                _Common.dbX_offset_position = _Common.dbX_offset_position + _Common.dbX_Center_ref - ((_Common.dbMas_X_position - _Common.dbCam_X_position) * _Common.dbCamera_X_Result);
                _Common.dbY_offset_position = _Common.dbY_offset_position + _Common.dbY_Center_ref - ((_Common.dbMas_Y_position - _Common.dbCam_Y_position) * _Common.dbCamera_Y_Result);
            }
            //Zone-C (X-,Y-)
            else if (_Common.dbX_ChkZone < 0 && _Common.dbY_ChkZone < 0)
            {
                _Common.dbX_ChkZone = _Common.dbX_ChkZone * (-1); //Convert X
                _Common.dbY_ChkZone = _Common.dbY_ChkZone * (-1); //Convert Y

                _Common.dbTheta_buffet_rad = Math.Atan2(_Common.dbY_ChkZone, _Common.dbX_ChkZone);

                _Common.dbCam_Theta_rad = _Common.dbCam_Theta_deg / 57.295778; //convert deg to rad.

                _Common.dbTheta_changed = _Common.dbTheta_buffet_rad + _Common.dbCam_Theta_rad;

                _Common.dbX_offset_position = _Common.dbR_buffer_position * Math.Cos(_Common.dbTheta_changed);
                _Common.dbX_offset_position = _Common.dbX_offset_position * (-1); //Convert X back
                _Common.dbY_offset_position = _Common.dbR_buffer_position * Math.Sin(_Common.dbTheta_changed);
                _Common.dbY_offset_position = _Common.dbY_offset_position * (-1); //Convert Y back

                _Common.dbX_offset_position = _Common.dbX_offset_position + _Common.dbX_Center_ref - ((_Common.dbMas_X_position - _Common.dbCam_X_position) * _Common.dbCamera_X_Result);
                _Common.dbY_offset_position = _Common.dbY_offset_position + _Common.dbY_Center_ref - ((_Common.dbMas_Y_position - _Common.dbCam_Y_position) * _Common.dbCamera_Y_Result);
            }
            //Zone-D (X+,Y-)
            else if (_Common.dbX_ChkZone > 0 && _Common.dbY_ChkZone < 0)
            {

                _Common.dbTheta_buffet_rad = Math.Atan2(_Common.dbY_ChkZone, _Common.dbX_ChkZone);

                _Common.dbCam_Theta_rad = _Common.dbCam_Theta_deg / 57.295778; //convert deg to rad.

                _Common.dbTheta_changed = _Common.dbTheta_buffet_rad + _Common.dbCam_Theta_rad;

                _Common.dbX_offset_position = _Common.dbR_buffer_position * Math.Cos(_Common.dbTheta_changed);
                _Common.dbY_offset_position = _Common.dbR_buffer_position * Math.Sin(_Common.dbTheta_changed);

                _Common.dbX_offset_position = _Common.dbX_offset_position + _Common.dbX_Center_ref - ((_Common.dbMas_X_position - _Common.dbCam_X_position) * _Common.dbCamera_X_Result);
                _Common.dbY_offset_position = _Common.dbY_offset_position + _Common.dbY_Center_ref - ((_Common.dbMas_Y_position - _Common.dbCam_Y_position) * _Common.dbCamera_Y_Result);
            }
            //Out of condition-1
            else if (_Common.dbX_ChkZone == 0 && _Common.dbY_ChkZone < 0)
            {
                _Common.dbX_ChkZone = _Common.dbX_ChkZone + 1;

                _Common.dbTheta_buffet_rad = Math.Atan2(_Common.dbY_ChkZone, _Common.dbX_ChkZone);

                _Common.dbCam_Theta_rad = _Common.dbCam_Theta_deg / 57.295778; //convert deg to rad.

                _Common.dbTheta_changed = _Common.dbTheta_buffet_rad - _Common.dbCam_Theta_rad; // - rad

                _Common.dbX_offset_position = _Common.dbR_buffer_position * Math.Cos(_Common.dbTheta_changed);
                _Common.dbY_offset_position = _Common.dbR_buffer_position * Math.Sin(_Common.dbTheta_changed);
                _Common.dbY_offset_position = _Common.dbY_offset_position * (-1); //Convert Y back

                _Common.dbX_offset_position = _Common.dbX_offset_position + _Common.dbX_Center_ref - ((_Common.dbMas_X_position - _Common.dbCam_X_position) * _Common.dbCamera_X_Result);
                _Common.dbY_offset_position = _Common.dbY_offset_position + _Common.dbY_Center_ref - ((_Common.dbMas_Y_position - _Common.dbCam_Y_position) * _Common.dbCamera_Y_Result);
            }
            //Out of condition-2
            else
            {
                _Common.dbX_ChkZone = _Common.dbX_ChkZone + 1;

                _Common.dbTheta_buffet_rad = Math.Atan2(_Common.dbY_ChkZone, _Common.dbX_ChkZone);

                _Common.dbCam_Theta_rad = _Common.dbCam_Theta_deg / 57.295778; //convert deg to rad.

                _Common.dbTheta_changed = _Common.dbTheta_buffet_rad + _Common.dbCam_Theta_rad;

                _Common.dbX_offset_position = _Common.dbR_buffer_position * Math.Cos(_Common.dbTheta_changed);
                _Common.dbY_offset_position = _Common.dbR_buffer_position * Math.Sin(_Common.dbTheta_changed);

                _Common.dbX_offset_position = _Common.dbX_offset_position + _Common.dbX_Center_ref - ((_Common.dbMas_X_position - _Common.dbCam_X_position) * _Common.dbCamera_X_Result);
                _Common.dbY_offset_position = _Common.dbY_offset_position + _Common.dbY_Center_ref - ((_Common.dbMas_Y_position - _Common.dbCam_Y_position) * _Common.dbCamera_Y_Result);
            }

        }

        public void Camera_Disconnect_WhenNG()
        {
            if (_Common.bCameraFail) { CameraIP.Disconnect(); }
        }

        public void Clear_Camera_data()
        {
            _Common.dbCam_1st_data = 0;
            _Common.dbCam_2nd_data = 0;
            _Common.dbCam_3rd_data = 0;
            _Common.dbCam_4th_data = 0;
            _Common.dbCam_5th_data = 0;

            _Common.iCameraReadData = null;
        }

    }
}
