﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//using Sygole.HFReader;
using Sygole.RfidReader;
///////////////////////////////////////////////
using Equipment_Control.Interface;

namespace Equipment_Control.RFID
{
    public class RFID_Control
    {
        //HFReader SygoleRFID = new HFReader();
        RfidReader SygoleRFID = new RfidReader();
        public bool bRFIDConnected { get; set; }
        public string sConnIP;
        public ushort uPort;
        public ushort uSgID;

        IVariableShare _Common;

        public RFID_Control(IVariableShare common)
        {
            _Common = common;
            bRFIDConnected = false;
            sConnIP = "192.168.1.10";
            uPort = 3001;
        }

        public void RFIDConnect()
        {
            try
            {
                if (!bRFIDConnected) { bRFIDConnected = SygoleRFID.Connect(sConnIP, uPort); }
                else { bRFIDConnected = true; }
            }
            catch { }
        }

        public void Disconnect()
        {
            bRFIDConnected = false;
            SygoleRFID.DisConnect();
        }

        public void DISpose()
        {
            SygoleRFID.Dispose();
        }

        //public byte[] ReadUID(byte ReaderID)
        //{
        //    byte[] readData = new byte[8];
        //    Status_enum result = SygoleRFID.Inventory(ReaderID, ref readData);
        //    if (result != Status_enum.SUCCESS) { MessageBox.Show("Read Fail，Status : " + result.ToString()); _Common.bRFIDCommandFail = true; }
        //    return readData;
        //}

        public byte[] ReadUserdata(byte ReaderID, byte address, byte length)
        {
            byte[] userData = new byte[length];
            try
            {
                Status_enum result = SygoleRFID.ReadBytes(ReaderID, 3, address, length, ref userData);
                if (_Common.RFID_MANUAL != true && result != Status_enum.SUCCESS)
                {
                    _Common.bRFID_select_Fail = true;
                }
                //if (_Common.RFID_MANUAL != true) { if (result != Status_enum.SUCCESS) { _Common.bRFID_select_Fail = true; } }
                _Common.RFID_MANUAL = false;
                return userData;
            }
            catch
            {
                return userData;
            }
        }

        public void WriteUserdata(byte ReaderID, byte address, byte[] userdata)
        {
            Status_enum result = SygoleRFID.WriteBytes(ReaderID, 3, address, (byte)userdata.Length, userdata, 0);
            if (result != Status_enum.SUCCESS) { MessageBox.Show("Write Fail，Status : " + result.ToString()); }
        }

        //public void SetReader(byte ReaderID, int workMode, byte DeviceID)
        //{
        //    if (workMode == 1)
        //    {
        //        UserCfg myCfg = new UserCfg(WorkMode_enum.OPERATOR_MODE, DeviceID, CommPort_enum.TCP, false, false);
        //        Status_enum result = SygoleRFID.SetUserCfg(ReaderID, myCfg);
        //        if (result != Status_enum.SUCCESS) { MessageBox.Show("Setup Fail，Status : " + result.ToString()); _Common.bRFIDCommandFail = true; }
        //    }
        //    else if (workMode == 2)
        //    {
        //        UserCfg myCfg = new UserCfg(WorkMode_enum.AUTO_MODE, DeviceID, CommPort_enum.TCP, false, false);
        //        Status_enum result = SygoleRFID.SetUserCfg(ReaderID, myCfg);
        //        if (result != Status_enum.SUCCESS) { MessageBox.Show("Setup Fail，Status : " + result.ToString()); _Common.bRFIDCommandFail = true; }
        //    }
        //    else { MessageBox.Show("Please enter the correct working mode, 1 = Manual acquisition, 2 = Automatic acquisition"); _Common.bRFIDCommandFail = true; }
        //}

        public void ResetReader(byte ReaderID)
        {
            Status_enum result = SygoleRFID.DefaultCfg(ReaderID);
            if (result != Status_enum.SUCCESS) { MessageBox.Show("Reset Fail，Status : " + result.ToString()); _Common.bRFIDCommandFail = true; }
        }

        //public void SetCommunication(string IP, string Mask, string Gateway, byte ReaderID)
        //{
        //    CommCfg communication = new CommCfg(IP, Mask, Gateway);
        //    Status_enum result = SygoleRFID.SetCommCfg(ReaderID, communication);
        //    if (result != Status_enum.SUCCESS) { MessageBox.Show("Setup Fail，Status : " + result.ToString()); _Common.bRFIDCommandFail = true; }
        //}

        public void GetCommParams(byte ReaderID, ref string IP, ref string Mask, ref string Gateway)
        {
            CommCfg communication = new CommCfg();
            Status_enum result = SygoleRFID.GetCommCfg(ReaderID, ref communication);
            if (result != Status_enum.SUCCESS) { MessageBox.Show("Get Fail，Status : " + result.ToString()); _Common.bRFIDCommandFail = true; }
            IP = communication.IPAddr;
            Mask = communication.Mask;
            Gateway = communication.GateWay;
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        public string UserData { get; private set; }
        public string UserData1 { get; private set; }
        public string UserData2 { get; private set; }
        public string UserData3 { get; private set; }
        public string UserData4 { get; private set; }
        public bool isReadFlag;
        public bool isOKFlag;
        public int antNum;
        public string[] strR = new string[10];

        public void Main_SygoleRFID()
        {
            isReadFlag = false;
            if (!bRFIDConnected)
            {
                RFIDConnect();
            }
            while (!isReadFlag)
            {
                UserData1 = " ";
                UserData2 = " ";
                UserData3 = " ";
                UserData4 = " ";
                if (!bRFIDConnected)
                {
                    RFIDConnect();
                }
                while (!isReadFlag)
                {
                    UserData = System.Text.Encoding.Default.GetString(ReadUserdata(6, 0, 50));
                    antNum = UserData.Length;
                    datashow();
                    isReadFlag = true;
                }
            }
        }

        public void datashow()
        {
            if (UserData != " ")
            {
                if (antNum == 1)
                {
                    strR[0] = UserData;
                    UserData1 = UserData;
                }
                else if (antNum == 2)
                {
                    strR[1] = UserData;
                    UserData2 = UserData;
                }
                else if (antNum == 3)
                {
                    strR[2] = UserData;
                    UserData3 = UserData;
                }
                else if (antNum == 4)
                {
                    strR[3] = UserData;
                    UserData4 = UserData;
                }
            }
            else
            {

            }
        }

    }


}
