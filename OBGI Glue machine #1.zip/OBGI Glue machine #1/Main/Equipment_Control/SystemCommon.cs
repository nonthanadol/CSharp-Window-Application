﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Communication.EtherCAT;
using Communication.IO_Commu;
using Communication.Motor_Control;
using Equipment_Control.IO_Control;
using Equipment_Control.Database;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.ASDA_XX_E;
using Equipment_Control.Interface;



namespace Equipment_Control
{
    public class SystemCommon : IVariableShare, IXYZ_ApplyGlue
    {
        #region Main
        public Ini Config { get; private set; }
        public Ini Para { get; private set; }
        public IOSystem IOTable { get; private set; }
        public PCI_L221_B1D0 card { get; private set; }



        public bool MesLinkState { get; set; }

        public bool FlagCT { get; set; }



        public ASDA_A2_E X1_AXIS { get; private set; }

        public ASDA_A2_E Y1_AXIS { get; private set; }

        public ASDA_A2_E Y2_AXIS { get; private set; }

        public ASDA_A2_E Z1_AXIS { get; private set; }

        public ASDA_B3_E RZ_AXIS { get; private set; }

        public ASDA_A2_E Y_Sync_Axis { get; private set; }

        public ASDA_A2_E XY_Multi { get; private set; }

        public ASDA_A2_E XYZ_MotionBuffer { get; private set; }


        public MES PQM { get; set; }

        public Shopfloor_Http_Client MES { get; set; }

        //public ASFA_A2_E M4 { get; private set; }
        //public R1_EC5621D0 MagneScale { get; private set; }
        //Step motor
        //public R1_EC5621D0 M10 { get; private set; }
        //public R1_EC5621D0 M11 { get; private set; }
        //public R1_EC5621D0 M12 { get; private set; }
        //public R1_EC5621D0 M13 { get; private set; }

        #endregion

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        #region UI
        public bool bPassLogin { get; set; }
        public bool bChkMC_RUN_STOP { get; set; }
        public bool bChkAuto_Manual { get; set; }
        public bool bChkMC_Bypass { get; set; }
        public bool bChkAlarm { get; set; }
        public bool bChkWaitManual { get; set; }
        public bool bChkPauseButtonPush { get; set; }
        public bool bChkInitialButtonPush { get; set; }
        public bool bChkErrorResetButtonPush { get; set; }
        public bool bChkMuteButtonPush { get; set; }
        public bool bChkFirstInitial { get; set; }
        public bool bChkFirstAuto { get; set; }


        public bool bTempStartTrig { get; set; } //Temporary signal for trig machine start.
        public bool bEmerOnScreen { get; set; }
        public string strErrorCode { get; set; }
        public bool bTrigToolsChangeAlarm { get; set; }
        public bool bSolenoidTimeOutAlarm { get; set; }
        public bool bCalibrationAlarm { get; set; }
        public bool bRFID_select_Fail { get; set; }
        public bool bRFIDCommandFail { get; set; }
        public bool bMESFail { get; set; }
        public bool bPQMFail { get; set; }
        public bool bCameraFail { get; set; }
        public bool bEtherCatCommandFail { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        public int iModelSelect { get; set; }
        public int iToolsPick { get; set; }
        //////////////////////////////////////////////////////////////////////////////////
        public bool bFlgInitial_onWork { get; set; }
        public bool bFlgInitial_Finished { get; set; }
        public int iInitialFlow_Step { get; set; }
        public bool bFlgAutoRun_onWork { get; set; }
        public bool bFlgAutoPurge_onWork { get; set; }
        public bool bFlgAlreadyApplyGlue { get; set; }
        public bool bFlgWorkFinished { get; set; }
        public bool bUpperSendNext { get; set; }
        public int iAutoRunFlow_Step { get; set; }
        public int iAutoPurgeFlow_Step { get; set; }
        public int iCamere_X_Offset { get; set; }
        public int iCamera_Y_Offset { get; set; }
        public int iTools_X_Original { get; set; }
        public int iTools_Y_Original { get; set; }
        public int iTools_Z_Original { get; set; }
        public int iTools_X_Offset { get; set; }
        public int iTools_Y_Offset { get; set; }
        public int iTools_Z_Offset { get; set; }
        public bool bFlgTrigStart { get; set; }
        public bool bFlgAutoFlowTrigApplyGlue { get; set; }
        public bool bFlgTrigApplyGlue { get; set; }
        public bool bFlgTrigMoveStepByStep { get; set; }
        public bool bSkipApplyGlue { get; set; }
        public bool bApplyGluePointFinished { get; set; }
        public int iTrigPositionApplyGlue { get; set; }
        public string strTrigPotitionMove { get; set; }
        public int iTrigStepMove { get; set; }
        public int iMem_X_Home_Pos { get; set; }
        public int iMem_Y_Home_Pos { get; set; }
        public int iMem_Z_Home_Pos { get; set; }
        public int iMem_RZ_Home_Pos { get; set; }
        public int iMem_Z_Safety_Pos { get; set; }
        public int iMem_Z_PCBBase_Pos { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        public bool bChkCVUP_MOVE_L { get; set; }
        public bool bChkCVUP_MOVE_R { get; set; }
        public bool bChkRFID_L { get; set; }
        public bool bChkRFID_R { get; set; }
        public bool bChkStopperUP { get; set; }
        public bool bChkPallet_Lock { get; set; }
        public bool bChkCVDown_MOVE_L { get; set; }
        public bool bChkCVDown_MOVE_R { get; set; }
        public bool bChkStopperDown { get; set; }
        public bool bChkAutoPurge { get; set; }
        public bool bChkManualPurge { get; set; }
        public bool bChkTool_1_Lock { get; set; }
        public bool bChkTool_1_INOUT { get; set; }
        public bool bChkTool_2_Lock { get; set; }
        public bool bChkTool_2_INOUT { get; set; }
        public bool bTool_1_Pick_Trig { get; set; }
        public bool bTool_1_Place_Trig { get; set; }
        public bool bTool_2_Pick_Trig { get; set; }
        public bool bTool_2_Place_Trig { get; set; }
        public bool bToolsClamp { get; set; }
        public bool bManualPickPlaceOnWork { get; set; }
        public bool bForce_unlockJog { get; set; }

        public bool bChkCameraLight { get; set; }

        //public int iTimetoPurge { get; set; }
        public int iPurgeTimeCount { get; set; }
        public double dbSetPurgeTime { get; set; }
        public int iTimetoAutoPurge { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        public bool bChkO208 { get; set; }
        public bool bChkO209 { get; set; }
        public bool bChkO212 { get; set; }
        public bool bChkO213 { get; set; }
        public bool bChkSafetyDoor { get; set; }
        public bool bChkAreaSensor { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        public string Connection_String { get; set; }
        public String RFID_Read_Data { get; set; }
        public bool RFID_MANUAL { get; set; }
        public bool bChkRFID_BYPASS { get; set; }
        public bool bChkPQM_BYPASS { get; set; }
        public bool bChkMES_BYPASS { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        public int iComponent_1_Warning { get; set; }
        public int iComponent_1_Limit { get; set; }
        public int iComponent_1_Usage { get; set; }
        public int iComponent_2_Warning { get; set; }
        public int iComponent_2_Limit { get; set; }
        public int iComponent_2_Usage { get; set; }
        public int iComponent_3_Warning { get; set; }
        public int iComponent_3_Limit { get; set; }
        public int iComponent_3_Usage { get; set; }
        public int iComponent_4_Warning { get; set; }
        public int iComponent_4_Limit { get; set; }
        public int iComponent_4_Usage { get; set; }
        public int iComponent_5_Warning { get; set; }
        public int iComponent_5_Limit { get; set; }
        public int iComponent_5_Usage { get; set; }
        public int iComponent_6_Warning { get; set; }
        public int iComponent_6_Limit { get; set; }
        public int iComponent_6_Usage { get; set; }
        public int iComponent_7_Warning { get; set; }
        public int iComponent_7_Limit { get; set; }
        public int iComponent_7_Usage { get; set; }
        public int iComponent_8_Warning { get; set; }
        public int iComponent_8_Limit { get; set; }
        public int iComponent_8_Usage { get; set; }
        public int iComponent_9_Warning { get; set; }
        public int iComponent_9_Limit { get; set; }
        public int iComponent_9_Usage { get; set; }
        public int iComponent_10_Warning { get; set; }
        public int iComponent_10_Limit { get; set; }
        public int iComponent_10_Usage { get; set; }
        public int iComponent_11_Warning { get; set; }
        public int iComponent_11_Limit { get; set; }
        public int iComponent_11_Usage { get; set; }
        public int iComponent_12_Warning { get; set; }
        public int iComponent_12_Limit { get; set; }
        public int iComponent_12_Usage { get; set; }
        public int iComponent_13_Warning { get; set; }
        public int iComponent_13_Limit { get; set; }
        public int iComponent_13_Usage { get; set; }
        public int iComponent_14_Warning { get; set; }
        public int iComponent_14_Limit { get; set; }
        public int iComponent_14_Usage { get; set; }
        public int iComponent_15_Warning { get; set; }
        public int iComponent_15_Limit { get; set; }
        public int iComponent_15_Usage { get; set; }
        public bool bChkCompo_1 { get; set; }
        public bool bChkCompo_2 { get; set; }
        public bool bChkCompo_3 { get; set; }
        public bool bChkCompo_4 { get; set; }
        public bool bChkCompo_5 { get; set; }
        public bool bChkCompo_6 { get; set; }
        public bool bChkCompo_7 { get; set; }
        public bool bChkCompo_8 { get; set; }
        public bool bChkCompo_9 { get; set; }
        public bool bChkCompo_10 { get; set; }
        public bool bChkCompo_11 { get; set; }
        public bool bChkCompo_12 { get; set; }
        public bool bChkCompo_13 { get; set; }
        public bool bChkCompo_14 { get; set; }
        public bool bChkCompo_15 { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        public double dbNozzle1_First_Set_X { get; set; }
        public double dbNozzle1_First_Set_Y { get; set; }
        public double dbNozzle1_First_Set_Z { get; set; }
        public double dbNozzle1_Now_X { get; set; }
        public double dbNozzle1_Now_Y { get; set; }
        public double dbNozzle1_Now_Z { get; set; }
        public double dbNozzle2_First_Set_X { get; set; }
        public double dbNozzle2_First_Set_Y { get; set; }
        public double dbNozzle2_First_Set_Z { get; set; }
        public double dbNozzle2_Now_X { get; set; }
        public double dbNozzle2_Now_Y { get; set; }
        public double dbNozzle2_Now_Z { get; set; }
        public double dbNozzle_X_Diff { get; set; }
        public double dbNozzle_Y_Diff { get; set; }
        public double dbNozzle_Z_Diff { get; set; }
        public double dbNozzle_2_X_Diff { get; set; }
        public double dbNozzle_2_Y_Diff { get; set; }
        public double dbNozzle_2_Z_Diff { get; set; }
        public int iNozzle_Cal_Select { get; set; }
        public double dbCamera_X1 { get; set; }
        public double dbCamera_X2 { get; set; }
        public double dbCamera_Y1 { get; set; }
        public double dbCamera_Y2 { get; set; }
        public double dbServo_X1 { get; set; }
        public double dbServo_X2 { get; set; }
        public double dbServo_Y1 { get; set; }
        public double dbServo_Y2 { get; set; }
        public double dbCamera_X_Result { get; set; }
        public double dbCamera_Y_Result { get; set; }
        public double dbX_pixel_master { get; set; }
        public double dbY_pixel_master { get; set; }
        public bool bCalibrationToolsTrig { get; set; }
        public bool bCalibration_onwork { get; set; }
        public int bCalibration_FlowStep { get; set; }
        public bool bChkCemeraOffset { get; set; }

        //////////////////////////////////////////////////////////////////////////////////
        public int[] iCameraReadData { get; set; }
        public double dbCam_1st_data { get; set; }
        public double dbCam_2nd_data { get; set; }
        public double dbCam_3rd_data { get; set; }
        public double dbCam_4th_data { get; set; }
        public double dbCam_5th_data { get; set; }

        public double dbX_Center_ref { get; set; }
        public double dbY_Center_ref { get; set; }
        public double dbX_ChkZone { get; set; }
        public double dbY_ChkZone { get; set; }
        public double dbX_buffer_position { get; set; }
        public double dbY_buffer_position { get; set; }
        public double dbR_buffer_position { get; set; }
        public double dbTheta_buffet_rad { get; set; }
        public double dbMas_X_position { get; set; }
        public double dbMas_Y_position { get; set; }
        public double dbCam_X_position { get; set; }
        public double dbCam_Y_position { get; set; }
        public double dbCam_Theta_deg { get; set; }
        public double dbCam_Theta_rad { get; set; }
        public double dbX_offset_position { get; set; }
        public double dbY_offset_position { get; set; }
        public double dbTheta_changed { get; set; }


        //////////////////////////////////////////////////////////////////////////////////
        public int iPQM_Status { get; set; }
        public int iPQM_Status_Code { get; set; }
        public int iPQM_PassQty { get; set; }
        public int iPQM_FailQty { get; set; }
        public int iPQM_Error_Count { get; set; }
        public int iPQM_Error_Time { get; set; }
        public int iPQM_Cycle_Time { get; set; }
        public int iPQM_Running_Time { get; set; }
        public int iPQM_Waiting_Time { get; set; }
        public int iPQM_InputQty { get; set; }
        public int iPQM_Self_Check { get; set; }
        public int iPQM_CT_M { get; set; }
        public int iPQM_CT_Q { get; set; }

        //////////////////////////////////////////////////////////////////////////////////

        #endregion

        public SystemCommon()
        {
            Config = new Ini(DPath.Config_PATH);
            Para = new Ini(DPath.PARA_PATH);
            IOTable = new IOSystem();
            card = new PCI_L221_B1D0();

            X1_AXIS = new ASDA_A2_E(this);
            Y1_AXIS = new ASDA_A2_E(this);
            Y2_AXIS = new ASDA_A2_E(this);
            Z1_AXIS = new ASDA_A2_E(this);
            RZ_AXIS = new ASDA_B3_E(this);


            PQM = new Database.MES(this, Para.ReadValue("MES", "Url").ToString());

            MES = new Database.Shopfloor_Http_Client(Para.ReadValue("MES", "MESUrl").ToString(), Para.ReadValue("MES", "KEY").ToString(), Para.ReadValue("MES", "TokenID").ToString());

        }

    }
}
