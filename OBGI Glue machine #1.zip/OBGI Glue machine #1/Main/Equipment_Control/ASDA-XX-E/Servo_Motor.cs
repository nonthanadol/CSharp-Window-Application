﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Communication.EtherCAT;
using Communication.Motor_Control;

namespace Equipment_Control.ASD_A2_E
{

    //public delegate void HCyErrorEventHandler(object sender, CyErrorEventArgs e); ////////////////////////////////
    public delegate bool HMoveStartEventHandler(object sender, MoveDataEventArgs e);

    public delegate void HDateRecive(double Data);

    public class MoveDataEventArgs : EventArgs
    {
        public MoveDataEventArgs(EMoveMode Mode, double MovePosition, double MoveSpeed, double MoveStrVal, double MoveAcc, double MoveDec, double TargetPosition)
        {
            this.Mode = Mode;
            this.MovePosition = MovePosition;
            this.MoveSpeed = MoveSpeed;
            this.MoveStrVal = MoveStrVal;
            this.MoveAcc = MoveAcc;
            this.MoveDec = MoveDec;
            this.TargetPosition = TargetPosition;
        }

        public double MovePosition { get; private set; }

        public double MoveSpeed { get; private set; }

        public double MoveStrVal { get; private set; }

        public double MoveAcc { get; private set; }

        public double MoveDec { get; private set; }

        public double TargetPosition { get; private set; }

        public EMoveMode Mode { get; private set; }
    }

    public enum EMoveMode
    {
        None = 0,
        Home = 1,
        Relative = 2,
        Absolute = 3,
        SpeedMove = 4,
        Torque = 5
    }

    public class ServoMotor
    {
        private IServoModel _motor;             //Internal motor
        private IServoModel _motor2;             //Internal motor2
        private double _dMemoryTargetPosition;  //Memory target position mm
        private double _dMemoryPosition;        //Memory motor moving position mm
        private double _dMemorySpeed;           //Memory motor moving speed mm
        private double _dMemoryStrVal;          //Memory motor moving initial speed mm
        private int _MemoryPosition;            //Memory motor gives command to move position pulse
        private int _MemorySpeed;               //The memory motor releases the movement speed pulse
        private int _MemoryStrVal;              //The memory motor releases the initial moving speed pulse
        private double _MemoryAcc;              //Memory motor release acceleration
        private double _MemoryDec;              //Memory motor movement deceleration

        ushort _X1_Slave_No;
        ushort _Y1_Slave_No;
        ushort _Y2_Slave_No;
        ushort _Z1_Slave_No;
        ushort _RZ_Slave_No;

        private short _MemoryTorque;              //Memory motor release torque value
        private uint _MemorySlope;              //Memory motor torque slope
        private ushort _MemoryVelocityLimit;              //Memory motor maximum speed limit
        private EMoveMode _MemoryMode;          //0:NoMove,1:Home,2:Rel,3:Abs
        private DateTime dtHomeMove;            //Check whether the return to the origin is completed.
        private DateTime MoveNoDownKeep;        //Operation switching delay


        public ServoMotor(IServoModel motor)
        {
            this._motor = motor;
            PARA = new MotorParameter();
            _MemoryPosition = 0;//Give the initial value pulse
            _MemorySpeed = 0;
            _MemoryStrVal = 0;
            _MemoryAcc = 0;
            _MemoryDec = 0;
            _MemoryMode = 0;
            isMoving = false;
        }

        public ServoMotor(IServoModel motor1, IServoModel motor2)
        {
            this._motor = motor1;
            this._motor2 = motor2;
            PARA = new MotorParameter();
            _MemoryPosition = 0;//Give the initial value pulse
            _MemorySpeed = 0;
            _MemoryStrVal = 0;
            _MemoryAcc = 0;
            _MemoryDec = 0;
            _MemoryMode = 0;
            isMoving = false;
        }

        #region Sort

        public bool MEL { get { return _motor.N_limit; } }

        public bool PEL { get { return _motor.P_limit; } }

        public bool ORG { get { return _motor.H_limit; } }

        public bool TargetDone { get { return _motor.TargetDone; } }

        public bool isMoving { get; private set; }

        public bool isArcMoving { get; private set; }

        public bool isGantryMoving { get; private set; }

        public bool bChkArcStartMove { get; private set; }
        public bool bChkGantryStartMove { get; private set; }

        public double Torque { get; private set; }

        public double Speed { get; private set; }

        public double Position { get; private set; }

        public double Command { get; private set; }
        //public double ExtPosition { get; private set; }

        public int ErrorCode { get { return _motor.ErrorCode; } }

        public bool ServoOn { get { return _motor.ServoOn; } set { _motor.ServoOn = value; } }

        public bool isPause { get; private set; }

        public MotorParameter PARA { get; private set; }

        #endregion

        #region Event


        public event HlogEventHandler onLogWrite;

        public event HMoveStartEventHandler onMoveStarted;

        #endregion

        #region Method

        /// <param name="Position"></param>
        public void PosMoveRel(double Position)
        {
            if (!isMoving)
            {
                int iPosition = MotorParameterChange.PositionReversal(PARA, Position);
                _motor.Pos_Move_Rel(PARA.intStrVal, PARA.intSpeed, iPosition, PARA.Acc, PARA.Dec);
                WriteMemory(PARA.intStrVal, PARA.intSpeed, iPosition, PARA.Acc, PARA.Dec);
                WriteChangeDateMemory(PARA.StrVal, PARA.Speed, Position);
                _MemoryMode = EMoveMode.Relative;
                _dMemoryTargetPosition = this.Position + Position;
                Move();
                isMoving = true;
            }
        }

        /// <param name="Position"></param>
        /// <param name="Speed"></param>
        public void PosMoveRel(double Position, double Speed)
        {
            if (!isMoving)
            {
                int iSpeed = MotorParameterChange.SpeedReversal(PARA, Speed);
                int iPosition = MotorParameterChange.PositionReversal(PARA, Position);
                WriteMemory(PARA.intStrVal, iSpeed, iPosition, PARA.Acc, PARA.Dec);
                WriteChangeDateMemory(PARA.StrVal, Speed, Position);
                _MemoryMode = EMoveMode.Relative;
                _dMemoryTargetPosition = this.Position + Position;
                Move();
                isMoving = true;
            }
        }

        /// <param name="StrVal"></param>
        /// <param name="Speed"></param>
        /// <param name="Position"></param>
        /// <param name="Acc"></param>
        /// <param name="Dec"></param>
        public void PosMoveRel(double StrVal, double Speed, double Position, double Acc, double Dec)
        {
            if (!isMoving)
            {
                int iStrVal = MotorParameterChange.SpeedReversal(PARA, StrVal);
                int iSpeed = MotorParameterChange.SpeedReversal(PARA, Speed);
                int iPosition = MotorParameterChange.PositionReversal(PARA, Position);
                WriteMemory(iStrVal, iSpeed, iPosition, Acc, Dec);
                WriteChangeDateMemory(StrVal, Speed, Position);
                _MemoryMode = EMoveMode.Relative;
                _dMemoryTargetPosition = this.Position + Position;
                Move();
                isMoving = true;
            }
        }

        /// <param name="Position"></param>
        public void PosMoveAbs(double Position)
        {
            if (!isMoving)
            {
                int iPosition = MotorParameterChange.PositionReversal(PARA, Position);
                WriteMemory(PARA.intStrVal, PARA.intSpeed, iPosition, PARA.Acc, PARA.Dec);
                WriteChangeDateMemory(PARA.StrVal, PARA.Speed, Position);
                _MemoryMode = EMoveMode.Absolute;
                _dMemoryTargetPosition = Position;
                Move();
                isMoving = true;
            }
        }

        /// <param name="Position"></param>
        /// <param name="Speed"></param>
        public void PosMoveAbs(double Position, double Speed)
        {
            if (!isMoving)
            {
                int iSpeed = MotorParameterChange.SpeedReversal(PARA, Speed);
                int iPosition = MotorParameterChange.PositionReversal(PARA, Position);
                WriteMemory(PARA.intStrVal, iSpeed, iPosition, PARA.Acc, PARA.Dec);
                WriteChangeDateMemory(PARA.StrVal, Speed, Position);
                _MemoryMode = EMoveMode.Absolute;
                _dMemoryTargetPosition = Position;
                Move();
                isMoving = true;
            }
        }

        /// <param name="Torque"></param>
        /// <param name="Slope"></param>
        public void TorqueMove(Double Torque, ushort VelocityLimit, uint Slope)
        {
            if (!isMoving)
            {
                _MemoryMode = EMoveMode.Torque;

                _MemoryTorque = (short)(((Torque + PARA.OffsetTorque) / PARA.DecelerationRatio) / (PARA.RatedTorque * 0.0098));

                _MemorySlope = Slope;
                _MemoryVelocityLimit = (ushort)(VelocityLimit * PARA.DecelerationRatio * 60 / 100);          
                Move();
                isMoving = true;
            }
        }

        /// <param name="StrVal"></param>
        /// <param name="Speed"></param>
        /// <param name="Position"></param>
        /// <param name="Acc"></param>
        /// <param name="Dec"></param>
        public void PosMoveAbs(double StrVal, double Speed, double Position, double Acc, double Dec)
        {
            if (!isMoving)
            {
                int iStrVal = MotorParameterChange.SpeedReversal(PARA, StrVal);
                int iSpeed = MotorParameterChange.SpeedReversal(PARA, Speed);
                int iPosition = MotorParameterChange.PositionReversal(PARA, Position);
                WriteMemory(iStrVal, iSpeed, iPosition, Acc, Dec);
                WriteChangeDateMemory(StrVal, Speed, Position);
                _MemoryMode = EMoveMode.Absolute;
                _dMemoryTargetPosition = Position;
                Move();
                isMoving = true;
            }
        }
        public void SpeedMove(double StrVal, double Speed, double Tacc, EDirection Direction)
        {
            if (!isMoving)
            {
                int iStrVal = MotorParameterChange.SpeedReversal(PARA, StrVal);
                int iSpeed = MotorParameterChange.SpeedReversal(PARA, Speed);
                _motor.Speed_Move(iStrVal, iSpeed, Tacc, Direction);
            }
        }


        public void Pause()
        {
            if (isMoving && !isPause)
            {
                isPause = true;
                _motor.EStop();
                isMoving = false;
            }
        }

        public void Resume()
        {
            if (isPause)
            {
                isPause = false;
                if (_MemoryMode == EMoveMode.Relative)
                {
                    double NewRelPosition = (this.Position - _dMemoryTargetPosition);
                    _dMemoryPosition = NewRelPosition;
                    _MemoryPosition = MotorParameterChange.PositionReversal(PARA, NewRelPosition);
                }
                Move();
                isMoving = true;
            }
        }

        public void HomeMove()
        {
            if (!isMoving)
            {
                _MemoryMode = EMoveMode.Home;
                Move();
                isMoving = true;
            }
        }

        /// <param name="Tdec"></param>
        public void Stop(double Tdec)
        {
            _motor.Stop(Tdec);
            isMoving = false;
        }

        public void EStop()
        {
            _motor.EStop();
            isMoving = false;
        }

        public void ClearAlarm()
        {
            _motor.ClearError();
        }

        public void Reset()
        {
            _motor.Reset();
        }
        DateTime s;

        public void update()
        {
            s = DateTime.Now;
            _motor.update();
            string str = (DateTime.Now - s).TotalMilliseconds.ToString();
            Position = MotorParameterChange.PositionChange(PARA, _motor.Position) + (PARA.isOffsetOpen ? PARA.Offset : 0);
            Command = MotorParameterChange.PositionChange(PARA, _motor.Command) + (PARA.isOffsetOpen ? PARA.Offset : 0);

            //Torque = _motor.Torque * PARA.RatedTorque * PARA.DecelerationRatio * 0.0098;

            //Speed = MotorParameterChange.PositionChange(PARA, _motor.Speed) / 100;

        }
        public void DriverUpdate()
        {
            _motor.DriverUpdate();
        }

        double RecordPositin = 0;
        private DateTime NomoveDelay;
        bool Resend = false;
        public bool CheckMoveDone()
        {
            bool retState = false;
            if (isArcMoving && isMoving)
            {
                if (_motor.MotionBufferStatus == 1 ) { bChkArcStartMove = true; }
                else if (_motor.MotionBufferStatus == 2 && bChkArcStartMove)
                {
                    isArcMoving = false;
                    isMoving = false;
                    bChkArcStartMove = false;
                    _MemoryMode = EMoveMode.None;
                    _motor.MotionBuffer_Stop();
                    retState = true;
                }
                else { MoveNoDownKeep = DateTime.Now; }
            }

            else if (isGantryMoving && isMoving)
            {
                if (_motor.GantryHomeStatus == 2 || _motor.GantryHomeStatus ==  7) { bChkGantryStartMove = true; }
                else if (_motor.GantryHomeStatus == 0 && bChkGantryStartMove && (DateTime.Now - MoveNoDownKeep).TotalMilliseconds > 100)
                {
                    isGantryMoving = false;
                    isMoving = false;
                    bChkGantryStartMove = false;
                    Disable_Follow_Enableushort();
                    retState = true;
                }
                else { MoveNoDownKeep = DateTime.Now; }                
            }

            else if (isMoving && !isPause)
            {
                switch (_MemoryMode)
                {
                    case EMoveMode.Home:
                        if (_motor.TargetDone && _motor.MotionDone == 0 && ((DateTime.Now - dtHomeMove).TotalMilliseconds > 500))
                        {
                            isMoving = false;
                            dtHomeMove = DateTime.Now;
                            _MemoryMode = EMoveMode.None;
                            retState = true;
                        }
                        break;
                    case EMoveMode.Relative:
                        if (_motor.TargetDone && _motor.MotionDone == 0 )
                        {
                            isMoving = false;
                            _MemoryMode = EMoveMode.None;
                            retState = true;
                        }
                        else
                        {
                            MoveNoDownKeep = DateTime.Now;
                        }
                        break;
                    case EMoveMode.Absolute:
                        if (_motor.TargetDone && _motor.MotionDone == 0 && (DateTime.Now - MoveNoDownKeep).TotalMilliseconds > 100 )
                        {
                            isMoving = false;
                            _MemoryMode = EMoveMode.None;
                            retState = true;
                        }
                        else
                        {
                            MoveNoDownKeep = DateTime.Now;
                        }
                        break;
                }
            }

            #region
            //else if ((_MemoryMode == EMoveMode.Absolute) && (retState == false))
            //{
            //    if (isMoving)
            //    {
            //        if (RecordPositin == Position)
            //        {
            //            if (((DateTime.Now - NomoveDelay).TotalMilliseconds > 5000) & (Resend == false))
            //            {
            //                Stop(0);
            //                Console.WriteLine(DateTime.Now + "Test Received but no motiondone ,Re send command");
            //                Resend = true;                      
            //            }
            //        }
            //        else
            //        {
            //            NomoveDelay = DateTime.Now;
            //        }
            //        RecordPositin = Position;
            //    }
            //    if (Resend)
            //    {
            //        Move();
            //        isMoving = true;
            //        Resend = false;
            //    }
            //}
            #endregion

            else if ((_MemoryMode == EMoveMode.Absolute) && _motor.TargetDone && _motor.MotionDone == 0 && retState == false) { retState = true; }

            else if ((_MemoryMode == EMoveMode.Relative) && _motor.TargetDone && _motor.MotionDone == 0 && retState == false) { retState = true; }

            else if ((_MemoryMode == EMoveMode.Home) && _motor.TargetDone && _motor.MotionDone == 0 && retState == false) { retState = true; }

            else if (_MemoryMode == EMoveMode.None && _motor.TargetDone && _motor.MotionDone == 0 && retState == false) { retState = true; }
            else { retState = false; }

            return retState;
        }

        #endregion

        private void WriteMemory(int StrVal, int Speed, int Position, double Acc, double Dec)
        {
            _MemoryStrVal = StrVal;
            _MemorySpeed = Speed;
            _MemoryPosition = Position;
            _MemoryAcc = Acc;
            _MemoryDec = Dec;
        }

        private void WriteChangeDateMemory(double StrVal, double Speed, double Position)
        {
            _dMemoryPosition = Position;
            _dMemorySpeed = Speed;
            _dMemoryStrVal = StrVal;
        }

        private void Move()
        {
            bool canRun = true;
            if (onMoveStarted != null)
                canRun = onMoveStarted(this, new MoveDataEventArgs(_MemoryMode, _dMemoryPosition, _dMemoryStrVal, _dMemorySpeed, _MemoryAcc, _MemoryDec, _dMemoryTargetPosition));
            if (canRun)
            {
                switch (_MemoryMode)
                {
                    case EMoveMode.Home:
                        _motor.Home_Move(PARA.HomeMode, (int)PARA.Offset, PARA.HomeLowSpeed, PARA.HomeHighSpeed, PARA.Acc);
                        dtHomeMove = DateTime.Now;
                        break;
                    case EMoveMode.Relative:
                        _motor.Pos_Move_Rel(_MemoryStrVal, _MemorySpeed, _MemoryPosition, _MemoryAcc, _MemoryDec);
                        break;
                    case EMoveMode.Absolute:
                        _motor.Pos_Move_Abs(_MemoryStrVal, _MemorySpeed, _MemoryPosition, _MemoryAcc, _MemoryDec);
                        break;
                    case EMoveMode.Torque:
  
                        _motor.Torque_Move(_MemoryTorque, _MemoryVelocityLimit, _MemorySlope);

                        break;
                }
            }
        }

        /// <param name="VelocityLimit"></param>
        public void AdjustVelocityLimit(ushort VelocityLimit)
        {
            _motor.AdjustVelocityLimit(VelocityLimit);
        }



        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public void Share_SlaveNo(ushort X1_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, ushort Z1_SlaveNo, ushort RZ_SlaveNo)
        {
            _X1_Slave_No = X1_SlaveNo;
            _Y1_Slave_No = Y1_SlaveNo;
            _Y2_Slave_No = Y2_SlaveNo;
            _Z1_Slave_No = Z1_SlaveNo;
            _RZ_Slave_No = RZ_SlaveNo;
        }
        public void Servo_P1_44_Para_Set()
        {
            _motor.Write_Sever_Config_P1_44(_X1_Slave_No);
            _motor.Write_Sever_Config_P1_44(_Y1_Slave_No);
            _motor.Write_Sever_Config_P1_44(_Y2_Slave_No);
            _motor.Write_Sever_Config_P1_44(_Z1_Slave_No);
            _motor.Write_Sever_Config_P1_44_B3(_RZ_Slave_No);
        }



        public void Servo_YAxis_Sync_Start_Set()
        {
            _motor.YAxis_Sync_Config(_Y1_Slave_No, _Y2_Slave_No);
            //_motor.Axis_Sync_Move();
        }
        public void Servo_XYAxis_Sync_Start_Set()
        {
            _motor.XYAxis_Sync_Config(_X1_Slave_No, _Y1_Slave_No, _Y2_Slave_No);
            //_motor.Axis_Sync_Move();
        }
        public void Servo_Axis_Sync_Start()
        {
            //_motor.YAxis_Sync_Config(_Y1_Slave_No, _Y2_Slave_No);
            _motor.Axis_Sync_Move();
        }
        public void MultiXY_Move_Abs(int iSpeed, int DistX, int DistY)
        {
            int Str_End_Vel = 0; //Start and End speed
            _MemoryMode = EMoveMode.Absolute;
            _motor.MultiXY_Pos_Move_Abs(_X1_Slave_No, _Y1_Slave_No, _Y2_Slave_No, Str_End_Vel, iSpeed, Str_End_Vel, DistX, DistY, PARA.Acc, PARA.Dec);
            isMoving = true;
        }
        public void MultiXY_Move_Rel(int iSpeed, int DistX, int DistY)
        {
            int Str_End_Vel = 0; //Start and End speed
            _MemoryMode = EMoveMode.Relative;
            _motor.MultiXY_Pos_Move_Rel(_X1_Slave_No, _Y1_Slave_No, _Y2_Slave_No, Str_End_Vel, iSpeed, Str_End_Vel, DistX, DistY, PARA.Acc, PARA.Dec);
            isMoving = true;
        }



        public void Enable_Follow_Enableushort ()
        {
            _motor.CSP_Follow_Enable(_Y1_Slave_No, _Y2_Slave_No,1);
        }
        public void Disable_Follow_Enableushort()
        {
            _motor.CSP_Follow_Enable(_Y1_Slave_No, _Y2_Slave_No, 0);
        }
        public void Set_Home_Config()
        {
            _motor.Gantry_Set_Home_Config( 10000, 10000, 1);
        }
        public void Gantry_Home_Move()
        {
            isGantryMoving = true;
            isMoving = true;
            _motor.Gantry_Home_Move();
        }
        public void Gantry_Disable_Home_Move()
        {
            isGantryMoving = false;
            isMoving = false;
            _motor.Gantry_Disable_Home_Move();
        }
        public void Home_Edge_Trigger_Level()
        {
            _motor.Set_Home_Edge_Trigger_Level();
        }



        public void Start_MotionBuffer_Set_card_parameter()
        {
            _motor.MotionBuffer_Set_card_parameter(_X1_Slave_No, _Y1_Slave_No, _Y2_Slave_No, _Z1_Slave_No, _RZ_Slave_No);
        }
        public void Start_MotionBuffer_Arc_90_Follow_CW(int iSpeed, int DistX, int DistY)
        {
            int Str_End_Vel = 0; //Start and End speed
            _MemoryMode = EMoveMode.Absolute;
            _motor.MotionBuffer_Arc_90_Follow(_X1_Slave_No, _Y1_Slave_No, _Y2_Slave_No, DistX, DistY, iSpeed, Str_End_Vel, 1);
        }
        public void Start_MotionBuffer_Arc_90_Follow_CCW(int iSpeed, int DistX, int DistY)
        {
            int Str_End_Vel = 0; //Start and End speed
            _MemoryMode = EMoveMode.Absolute;
            _motor.MotionBuffer_Arc_90_Follow(_X1_Slave_No, _Y1_Slave_No, _Y2_Slave_No, DistX, DistY, iSpeed, Str_End_Vel, 0);
        }
        public void Start_MotionBuffer_Arc_180_Follow_CW(int iSpeed, int DistX, int DistY)
        {
            int Str_End_Vel = 0; //Start and End speed
            _MemoryMode = EMoveMode.Absolute;
            _motor.MotionBuffer_Arc_180_Follow(_X1_Slave_No, _Y1_Slave_No, _Y2_Slave_No, DistX, DistY, iSpeed, Str_End_Vel, 1);
        }
        public void Start_MotionBuffer_Arc_180_Follow_CCW(int iSpeed, int DistX, int DistY)
        {
            int Str_End_Vel = 0; //Start and End speed
            _MemoryMode = EMoveMode.Absolute;
            _motor.MotionBuffer_Arc_180_Follow(_X1_Slave_No, _Y1_Slave_No, _Y2_Slave_No, DistX, DistY, iSpeed, Str_End_Vel, 0);
        }
        public void Start_MotionBuffer_Line_Multi(int iSpeed, int DistX, int DistY, int DistZ, int DistRZ)
        {
            int Str_End_Vel = 0; //Start and End speed
            _MemoryMode = EMoveMode.Absolute;
            _motor.MotionBuffer_Line_Multi(DistX, DistY, DistZ, DistRZ, iSpeed);
        }
        public void Start_MotionBuffer_Line_Multi_EndZero(int iSpeed, int DistX, int DistY, int DistZ, int DistRZ)
        {
            _MemoryMode = EMoveMode.Absolute;
            _motor.MotionBuffer_Line_Multi_EndVelZero(DistX, DistY, DistZ, DistRZ, iSpeed);
        }
        public void Start_MotionBuffer_Start()
        {
            isArcMoving = true;
            //isMoving = true;
            _motor.MotionBuffer_Start();
        }
        public void Start_MotionBuffer_Stop()
        {
            isArcMoving = false;
            //isMoving = false;
            _motor.MotionBuffer_Stop();
        }
        public void MotionBuffer_IOControl_Set(ushort SlaveNo, ushort BitNo)
        {

            _motor.MotionBuffer_IO_Control(SlaveNo, BitNo, 1);
        }
        public void MotionBuffer_IOControl_Reset(ushort SlaveNo, ushort BitNo)
        {

            _motor.MotionBuffer_IO_Control(SlaveNo, BitNo, 0);
        }
        public void MotionBuffer_DelayyTime(double DelayTime)
        {
            _motor.MotionBuffer_Delay(DelayTime);//Delay time unit sec
        }

        public ushort MotionBuffer_Get_Status()
        {
            ushort reMotionStatus;

            reMotionStatus = _motor.MotionBuffer_Motion_Status();

            return reMotionStatus;
        }

        public void Cancel_isMoveing()
        {
            isMoving = false;
        }
        public void Machine_Error_ClearBitStatus()
        {
            if (isArcMoving)
            {
                isArcMoving = false;
                isMoving = false;
                bChkArcStartMove = false;
                _MemoryMode = EMoveMode.None;
                _motor.MotionBuffer_Stop();

            }
            else if (isGantryMoving)
            {
                isGantryMoving = false;
                isMoving = false;
                bChkGantryStartMove = false;
                _MemoryMode = EMoveMode.None;
                Gantry_Disable_Home_Move();
                Disable_Follow_Enableushort();
            }
            else
            {
                isMoving = false;
                _MemoryMode = EMoveMode.None;
            }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    }



}
