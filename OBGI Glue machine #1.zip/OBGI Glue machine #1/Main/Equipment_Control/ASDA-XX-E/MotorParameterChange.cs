﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equipment_Control.ASD_A2_E
{
    public class MotorParameterChange
    {

        /// <param name="Motor"></param>
        /// <param name="Position"></param>
        /// <returns></returns>
        public static int PositionReversal(MotorParameter Motor, double Position)
        {
            //double temp = (Position / Motor.Pitch) * Motor.ReductionRation * Motor.CirclePulse;
            //if (temp > int.MaxValue)
            //{
            //    temp = int.MaxValue - 1000;
            //}

            //if (temp < int.MinValue)
            //{
            //    temp = int.MinValue + 1000;
            //}
            //int retAns = (int)(temp);
            //return retAns;

            int retAns = (int)Position;
            return retAns;
        }

        /// <param name="Motor"></param>
        /// <param name="Speed"></param>
        /// <returns></returns>
        public static int SpeedReversal(MotorParameter Motor, double Speed)
        {
            //double dBuffer = (Motor.ReductionRation * Motor.CirclePulse) / Motor.Pitch;
            //int retAns = (int)(Speed * dBuffer);
            //return retAns;

            int retAns = (int)Speed;
            return retAns;
        }

        /// <param name="Motor"></param>
        /// <param name="Position"></param>
        /// <returns></returns>
        public static double PositionChange(MotorParameter Motor, int Position)
        {
            //double retAns = Math.Round(Position / Motor.CirclePulse / Motor.ReductionRation * Motor.Pitch, 2);
            //return retAns;

            double retAns = Position;
            return retAns;
        }

        /// <param name="Motor"></param>
        /// <param name="Speed"></param>
        /// <returns></returns>
        public static ushort SpeedChange(MotorParameter Motor, int Speed)
        {
            //double retAns = Math.Round(Speed / Motor.CirclePulse / Motor.ReductionRation * Motor.Pitch, 2);
            //return (ushort)(retAns);

            double retAns = (double)Speed;
            return (ushort)(retAns);
        }
    }
}
