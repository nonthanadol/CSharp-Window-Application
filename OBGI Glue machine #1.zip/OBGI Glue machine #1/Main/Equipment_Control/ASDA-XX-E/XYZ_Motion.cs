﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Equipment_Control.Interface;

namespace Equipment_Control.ASD_A2_E
{
    public class XYZ_Motion
    {
        IXYZ_ApplyGlue _Common;
        public ServoMotor X1_AXIS { get; private set; }
        public ServoMotor Y1_AXIS { get; private set; }
        public ServoMotor Y2_AXIS { get; private set; }
        public ServoMotor Z1_AXIS { get; private set; }
        public ServoMotor RZ_AXIS { get; private set; }

        public ServoMotor Y_Sync_Axis { get; private set; }
        public ServoMotor XY_Multi { get; private set; }
        public ServoMotor XYZ_MotionBuffer { get; private set; }


        public XYZ_Motion(IXYZ_ApplyGlue common)
        {
            _Common = common;
            //ErrorBack = new AsyncCallback(m_ErrorBack);
            //RemindBack = new AsyncCallback(m_RemindBack);
            //ThreadErrWatch = new Thread(ErrWatch);       
        }

        public void ServoParaLoad()
        {
            X1_AXIS = new ServoMotor(_Common.X1_AXIS);
            Y1_AXIS = new ServoMotor(_Common.Y1_AXIS);
            Y2_AXIS = new ServoMotor(_Common.Y2_AXIS);
            Z1_AXIS = new ServoMotor(_Common.Z1_AXIS);
            RZ_AXIS = new ServoMotor(_Common.RZ_AXIS);

            Y_Sync_Axis = new ServoMotor(_Common.Y1_AXIS);
            XY_Multi = new ServoMotor(_Common.Y1_AXIS);
            XYZ_MotionBuffer = new ServoMotor(_Common.X1_AXIS);

            string StationName;
            StationName = "X1_AXIS";
            X1_AXIS.PARA.Acc = double.Parse(_Common.Para.ReadValue(StationName, "Acc").ToString());
            X1_AXIS.PARA.Dec = double.Parse(_Common.Para.ReadValue(StationName, "Dec").ToString());
            X1_AXIS.PARA.HomeHighSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeHighSpeed").ToString());
            X1_AXIS.PARA.HomeLowSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeLowSpeed").ToString());
            X1_AXIS.PARA.HomeMode = ushort.Parse(_Common.Para.ReadValue(StationName, "HomeMode").ToString());
            X1_AXIS.PARA.isOffsetOpen = bool.Parse(_Common.Para.ReadValue(StationName, "isOffsetOpen").ToString());
            X1_AXIS.PARA.StrVal = double.Parse(_Common.Para.ReadValue(StationName, "StrVal").ToString());
            X1_AXIS.PARA.Tolerance = double.Parse(_Common.Para.ReadValue(StationName, "Tolerance").ToString());

            StationName = "Y1_AXIS";
            Y1_AXIS.PARA.Acc = double.Parse(_Common.Para.ReadValue(StationName, "Acc").ToString());
            Y1_AXIS.PARA.Dec = double.Parse(_Common.Para.ReadValue(StationName, "Dec").ToString());
            Y1_AXIS.PARA.HomeHighSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeHighSpeed").ToString());
            Y1_AXIS.PARA.HomeLowSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeLowSpeed").ToString());
            Y1_AXIS.PARA.HomeMode = ushort.Parse(_Common.Para.ReadValue(StationName, "HomeMode").ToString());
            Y1_AXIS.PARA.isOffsetOpen = bool.Parse(_Common.Para.ReadValue(StationName, "isOffsetOpen").ToString());
            Y1_AXIS.PARA.StrVal = double.Parse(_Common.Para.ReadValue(StationName, "StrVal").ToString());
            Y1_AXIS.PARA.Tolerance = double.Parse(_Common.Para.ReadValue(StationName, "Tolerance").ToString());

            StationName = "Y2_AXIS";
            Y2_AXIS.PARA.Acc = double.Parse(_Common.Para.ReadValue(StationName, "Acc").ToString());
            Y2_AXIS.PARA.Dec = double.Parse(_Common.Para.ReadValue(StationName, "Dec").ToString());
            Y2_AXIS.PARA.HomeHighSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeHighSpeed").ToString());
            Y2_AXIS.PARA.HomeLowSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeLowSpeed").ToString());
            Y2_AXIS.PARA.HomeMode = ushort.Parse(_Common.Para.ReadValue(StationName, "HomeMode").ToString());
            Y2_AXIS.PARA.isOffsetOpen = bool.Parse(_Common.Para.ReadValue(StationName, "isOffsetOpen").ToString());
            Y2_AXIS.PARA.StrVal = double.Parse(_Common.Para.ReadValue(StationName, "StrVal").ToString());
            Y2_AXIS.PARA.Tolerance = double.Parse(_Common.Para.ReadValue(StationName, "Tolerance").ToString());

            StationName = "Z1_AXIS";
            Z1_AXIS.PARA.Acc = double.Parse(_Common.Para.ReadValue(StationName, "Acc").ToString());
            Z1_AXIS.PARA.Dec = double.Parse(_Common.Para.ReadValue(StationName, "Dec").ToString());
            Z1_AXIS.PARA.HomeHighSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeHighSpeed").ToString());
            Z1_AXIS.PARA.HomeLowSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeLowSpeed").ToString());
            Z1_AXIS.PARA.HomeMode = ushort.Parse(_Common.Para.ReadValue(StationName, "HomeMode").ToString());
            Z1_AXIS.PARA.isOffsetOpen = bool.Parse(_Common.Para.ReadValue(StationName, "isOffsetOpen").ToString());
            Z1_AXIS.PARA.StrVal = double.Parse(_Common.Para.ReadValue(StationName, "StrVal").ToString());
            Z1_AXIS.PARA.Tolerance = double.Parse(_Common.Para.ReadValue(StationName, "Tolerance").ToString());

            StationName = "RZ_AXIS";
            RZ_AXIS.PARA.Acc = double.Parse(_Common.Para.ReadValue(StationName, "Acc").ToString());
            RZ_AXIS.PARA.Dec = double.Parse(_Common.Para.ReadValue(StationName, "Dec").ToString());
            RZ_AXIS.PARA.HomeHighSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeHighSpeed").ToString());
            RZ_AXIS.PARA.HomeLowSpeed = uint.Parse(_Common.Para.ReadValue(StationName, "HomeLowSpeed").ToString());
            RZ_AXIS.PARA.HomeMode = ushort.Parse(_Common.Para.ReadValue(StationName, "HomeMode").ToString());
            RZ_AXIS.PARA.isOffsetOpen = bool.Parse(_Common.Para.ReadValue(StationName, "isOffsetOpen").ToString());
            RZ_AXIS.PARA.StrVal = double.Parse(_Common.Para.ReadValue(StationName, "StrVal").ToString());
            RZ_AXIS.PARA.Tolerance = double.Parse(_Common.Para.ReadValue(StationName, "Tolerance").ToString());


            #region Share Slave No
            X1_AXIS.Share_SlaveNo(_Common.X1_AXIS.SlaveNo, _Common.Y1_AXIS.SlaveNo, _Common.Y2_AXIS.SlaveNo, _Common.Z1_AXIS.SlaveNo, _Common.RZ_AXIS.SlaveNo);
            Y1_AXIS.Share_SlaveNo(_Common.X1_AXIS.SlaveNo, _Common.Y1_AXIS.SlaveNo, _Common.Y2_AXIS.SlaveNo, _Common.Z1_AXIS.SlaveNo, _Common.RZ_AXIS.SlaveNo);
            Y2_AXIS.Share_SlaveNo(_Common.X1_AXIS.SlaveNo, _Common.Y1_AXIS.SlaveNo, _Common.Y2_AXIS.SlaveNo, _Common.Z1_AXIS.SlaveNo, _Common.RZ_AXIS.SlaveNo);
            Z1_AXIS.Share_SlaveNo(_Common.X1_AXIS.SlaveNo, _Common.Y1_AXIS.SlaveNo, _Common.Y2_AXIS.SlaveNo, _Common.Z1_AXIS.SlaveNo, _Common.RZ_AXIS.SlaveNo);
            RZ_AXIS.Share_SlaveNo(_Common.X1_AXIS.SlaveNo, _Common.Y1_AXIS.SlaveNo, _Common.Y2_AXIS.SlaveNo, _Common.Z1_AXIS.SlaveNo, _Common.RZ_AXIS.SlaveNo);
            Y_Sync_Axis.Share_SlaveNo(_Common.X1_AXIS.SlaveNo, _Common.Y1_AXIS.SlaveNo, _Common.Y2_AXIS.SlaveNo, _Common.Z1_AXIS.SlaveNo, _Common.RZ_AXIS.SlaveNo);
            XY_Multi.Share_SlaveNo(_Common.X1_AXIS.SlaveNo, _Common.Y1_AXIS.SlaveNo, _Common.Y2_AXIS.SlaveNo, _Common.Z1_AXIS.SlaveNo, _Common.RZ_AXIS.SlaveNo);
            XYZ_MotionBuffer.Share_SlaveNo(_Common.X1_AXIS.SlaveNo, _Common.Y1_AXIS.SlaveNo, _Common.Y2_AXIS.SlaveNo, _Common.Z1_AXIS.SlaveNo, _Common.RZ_AXIS.SlaveNo);
            #endregion
            
            X1_AXIS.Servo_P1_44_Para_Set(); // Set paramerter P1-44 of all servo to 128 for adjust about speed control.

            /////////Servo ON
            X1_AXIS.ClearAlarm();
            X1_AXIS.ServoOn = true;

            Y1_AXIS.ClearAlarm();
            Y1_AXIS.ServoOn = true;

            Y2_AXIS.ClearAlarm();
            Y2_AXIS.ServoOn = true;

            Z1_AXIS.ClearAlarm();
            Z1_AXIS.ServoOn = true;

            RZ_AXIS.ClearAlarm();
            RZ_AXIS.ServoOn = true;

        }

    }
}
