﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Communication.EtherCAT;
using Equipment_Control.Interface;

namespace Equipment_Control.ASDA_XX_E
{
    public class ASDA_B3_E : EtherCAT_ServoMotor
    {
        IVariableShare Common;

        private bool _ServoOn;
        protected ushort uhRC_update;
        protected int iRC_update;

        private int _iGetDataBuffer = 0;
        private int _iGetDataBuffer1 = 0;

        private uint _uiGetDataBuffer = 0;
        private short _hGetDataBuffer = 0;
        private ushort _uhGetDataBuffer = 0;
        private ushort _uhGetDataMotionBuffer = 0;
        private ushort _uhGetGantryHomeStatus = 0;
        private int _iGetMDBlockNum = 0;
        private ushort _Status;
        private int _P0_09Buffer;

        [DllImport("kernel32.dll")]
        public static extern uint GetTickCount();
        public ASDA_B3_E(IVariableShare common)
            : base(EEtherCAT_Slave_Type.ASDA_B3_E)
        {
            Common = common;
            _ServoOn = false;
            _Status = 0;
        }

        public override bool ServoOn
        {
            get
            {
                return _ServoOn;
            }

            set
            {
                m_checkParentCardisOpen();
                ushort uhRC;
                uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Set_Svon(ParentCard.CardNo, SlaveNo, 0, value ? (ushort)1 : (ushort)0);
                if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Set_Svon,hRC:" + uhRC); Common.bEtherCatCommandFail = true; }
                _ServoOn = value;
            }
        }

        public override void ClearError()
        {
            m_checkParentCardisOpen();
            ushort uhRC;
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Ralm(ParentCard.CardNo, SlaveNo, _NodeID);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Ralm,hRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }

        public override void Close()
        {
            if (this.isOpen)
            {
                if (ServoOn)
                    ServoOn = false;
                isOpen = false;
            }
        }

        public override void EStop()
        {
            m_checkParentCardisOpen();
            ushort uhRC;
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Emg_Stop(ParentCard.CardNo, SlaveNo, _NodeID);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Emg_Stop,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }

        }

        public override void Home_Move(ushort Mode, int offset, uint lowSpeed, uint highSpeed, double acc)
        {
            m_checkParentCardisOpen();
            ushort uhRC;
            uint uiAcc = 0;
            try
            {
                uiAcc = Convert.ToUInt32(acc * 10);
            }
            catch
            {
                uiAcc = 0;
            }
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Home_Config(ParentCard.CardNo, SlaveNo, 0, Mode, offset, highSpeed, lowSpeed, uiAcc);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Home_Config,hRC:" + uhRC); Common.bEtherCatCommandFail = true; }
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Home_Move(ParentCard.CardNo, SlaveNo, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Home_Move,hRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }

        public override void Open()
        {
            base.Open();
            ushort uhRC;
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_DeltaServo_Write_Parameter(ParentCard.CardNo, SlaveNo, _NodeID, 0, 17, 39);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Home_Config,hRC:" + uhRC); Common.bEtherCatCommandFail = true; }
            _ServoOn = false;
            isOpen = true;
        }

        /// <param name="VelocityLimit"></param>
        public override void AdjustVelocityLimit(ushort VelocityLimit)
        {
            ushort uhRC = 0;

            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Emg_Stop(ParentCard.CardNo, SlaveNo, 0);
            if (uhRC != CEtherCAT_DLL_Err.ERR_ECAT_NO_ERROR) { MessageBox.Show("CS_ECAT_Slave_Motion_Emg_Stop,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Emg_Stop,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
            uint nVelocityLimit = 0;

            nVelocityLimit = VelocityLimit;
            m_checkParentCardisOpen();
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Set_Svon(ParentCard.CardNo, SlaveNo, 0, (ushort)0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Set_Svon,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }

            uhRC = EtherCAT_DLL.CS_ECAT_Slave_DeltaServo_Write_Parameter(ParentCard.CardNo, SlaveNo, 0, 1, 55, (int)nVelocityLimit);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_DeltaServo_Write_Parameter,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }

            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Set_Svon(ParentCard.CardNo, SlaveNo, 0, (ushort)1); ;
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Set_Svon,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }

        public override void Torque_Move(short Torque, ushort VelocityLimit, uint Slope)
        {
            ushort uhRC = 0;

            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Emg_Stop(ParentCard.CardNo, SlaveNo, 0);
            if (uhRC != CEtherCAT_DLL_Err.ERR_ECAT_NO_ERROR) { MessageBox.Show("CS_ECAT_Slave_Motion_Emg_Stop,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Emg_Stop,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
            short Torque_Profile = 0;
            ushort SetBit = 0x02;
            ushort Max_Current = 0;
            uint uSlope = 0;
            short nTorque = 0;
            uint nVelocityLimit = 0;
            uSlope = Slope;
            nTorque = Torque;
            nVelocityLimit = VelocityLimit;

            uSlope = (uSlope > 1000) ? 1000 : uSlope;
            nTorque = (nTorque > 1000) ? (short)1000 : nTorque;

            m_checkParentCardisOpen();


            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Set_Svon(ParentCard.CardNo, SlaveNo, 0, (ushort)0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Set_Svon,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }

            uhRC = EtherCAT_DLL.CS_ECAT_Slave_DeltaServo_Write_Parameter(ParentCard.CardNo, SlaveNo, 0, 1, 55, (int)nVelocityLimit);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_DeltaServo_Write_Parameter,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }

            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Set_Svon(ParentCard.CardNo, SlaveNo, 0, (ushort)1); ;
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Set_Svon,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }

            uhRC = EtherCAT_DLL.CS_ECAT_Slave_PT_Start_Move(ParentCard.CardNo, SlaveNo, 0, nTorque, uSlope);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_PT_Start_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }

        public override void Pos_Move_Abs(int StrVel, int MaxVel, int Dist, double Tacc, double Tdec)
        {
            m_checkParentCardisOpen();
            uint uiacc = (uint)(Tacc * 1000);
            uint uidec = (uint)(Tdec * 1000);
            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_Move(ParentCard.CardNo, SlaveNo, 0, Dist, StrVel, MaxVel, StrVel, Tacc, Tdec, (ushort)curveMode, 1);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }

        public override void Pos_Move_Rel(int StrVel, int MaxVel, int Dist, double Tacc, double Tdec)
        {
            m_checkParentCardisOpen();
            uint uiacc = (uint)(Tacc * 1000);
            uint uidec = (uint)(Tdec * 1000);
            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_Move(ParentCard.CardNo, SlaveNo, 0, Dist, StrVel, MaxVel, StrVel, Tacc, Tdec, (ushort)curveMode, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }





        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public override void Write_Sever_Config_P1_44(ushort XSlaveNo)
        {
            ushort uhRC;
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_DeltaServo_Write_Parameter(ParentCard.CardNo, XSlaveNo, 0, 1, 44, 128);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_DeltaServo_Write_Parameter,hRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void Write_Sever_Config_P1_44_B3(ushort XSlaveNo)
        {
            ushort uhRC;
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_DeltaServo_Write_Parameter(ParentCard.CardNo, XSlaveNo, 0, 1, 44, 167772);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_DeltaServo_Write_Parameter,hRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }



        public override void MultiXY_Pos_Move_Abs(ushort XSlaveNo, ushort Y1SlaveNo, ushort Y2SlaveNo, int StrVel, int MaxVel, int EndVel, int DistX, int DistY, double Tacc, double Tdec)
        {
            m_checkParentCardisOpen();
            ushort[] XYAxisSlaveNo = { XSlaveNo, Y1SlaveNo, Y2SlaveNo };
            ushort[] SlotXY = { 0, 0, 0 };
            int[] XYAxisvalue = { DistX, DistY, DistY };
            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_Multiaxes_Move(ParentCard.CardNo, 3, XYAxisSlaveNo, SlotXY, XYAxisvalue, StrVel, MaxVel, EndVel, Tacc, Tdec, (ushort)curveMode, 1);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_Multiaxes_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void MultiXY_Pos_Move_Rel(ushort XSlaveNo, ushort Y1SlaveNo, ushort Y2SlaveNo, int StrVel, int MaxVel, int EndVel, int DistX, int DistY, double Tacc, double Tdec)
        {
            m_checkParentCardisOpen();
            ushort[] XYAxisSlaveNo = { XSlaveNo, Y1SlaveNo, Y2SlaveNo };
            ushort[] SlotXY = { 0, 0, 0 };
            int[] XYAxisvalue = { DistX, DistY, DistY };
            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_Multiaxes_Move(ParentCard.CardNo, 3, XYAxisSlaveNo, SlotXY, XYAxisvalue, StrVel, MaxVel, EndVel, Tacc, Tdec, (ushort)curveMode, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_Multiaxes_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }





        public override void YAxis_Sync_Config(ushort Y1_SlaveNo, ushort Y2_SlaveNo)
        {
            m_checkParentCardisOpen();
            ushort[] YAxisSlaveNo = { Y1_SlaveNo, Y2_SlaveNo };
            ushort[] SlotY = { 0, 0 };
            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Sync_Config(ParentCard.CardNo, 2, YAxisSlaveNo, SlotY, 1);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Sync_Config,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void XYAxis_Sync_Config(ushort X1_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo)
        {
            m_checkParentCardisOpen();
            ushort[] XYAxisSlaveNo = { X1_SlaveNo, Y1_SlaveNo, Y2_SlaveNo };
            ushort[] SlotXY = { 0, 0, 0 };
            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Sync_Config(ParentCard.CardNo, 3, XYAxisSlaveNo, SlotXY, 1);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Sync_Config,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void Axis_Sync_Move()
        {
            m_checkParentCardisOpen();
            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Sync_Move(ParentCard.CardNo);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Sync_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }



        public override void CSP_Follow_Enable(ushort Y1_SlaveNo, ushort Y2_SlaveNo, ushort status)
        {
            m_checkParentCardisOpen();

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Follow_Enable(ParentCard.CardNo, 0, Y1_SlaveNo, 0, Y2_SlaveNo, 0, status);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Follow_Enable,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void Gantry_Set_Home_Config(ushort FirstVel, ushort SecondVel, double Acc)
        {
            m_checkParentCardisOpen();

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Gantry_Set_Home_Config(ParentCard.CardNo, 0, 0, 0, FirstVel, SecondVel, Acc, 1, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Gantry_Set_Home_Config,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void Gantry_Home_Move()
        {
            m_checkParentCardisOpen();

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Gantry_Home_Move(ParentCard.CardNo, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Gantry_Home_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void Gantry_Disable_Home_Move()
        {
            m_checkParentCardisOpen();

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Gantry_Disable_Home_Move(ParentCard.CardNo, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Gantry_Disable_Home_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void Set_Home_Edge_Trigger_Level()
        {
            m_checkParentCardisOpen();

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Gantry_Set_Home_Edge_Trigger_Level(ParentCard.CardNo, 0, 0, 0, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Gantry_Set_Home_Edge_Trigger_Level,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }




        public override void MotionBuffer_Set_card_parameter(ushort X_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, ushort Z1_SlaveNo, ushort RZ_SlaveNo)
        {
            m_checkParentCardisOpen();
            ushort[] XYAxisSlaveNo = { Y1_SlaveNo, X_SlaveNo, Y2_SlaveNo, Z1_SlaveNo, RZ_SlaveNo };
            ushort[] SlotXY = { 0, 0, 0, 0, 0 };
            ushort[] OrigrinPosition = { 0, 0, 0, 0, 0 };

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Set_Crd_Parameters(ParentCard.CardNo, 0, 5, XYAxisSlaveNo, SlotXY, 6400000, 6400000, (ushort)curveMode, 0, 0, OrigrinPosition);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_Set_Crd_Parameters,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void MotionBuffer_Arc_90_Follow(ushort X_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, int DistX, int DistY, int TargetVel, int EndVel, ushort CircleDir)
        {
            m_checkParentCardisOpen();
            ushort[] XYAxisSlaveNo = { X_SlaveNo, Y1_SlaveNo, Y2_SlaveNo };
            ushort[] ArcIndex = { X_SlaveNo, Y1_SlaveNo };
            int[] CenterPointArc3 = { 0, 0 };
            int[] PositionMove = { DistX, DistY };
            //int[] FollowTargetPos = { DistY, DistX, DistY };
            double CurveAngle = 90.0;

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Arc_follow(ParentCard.CardNo, 0, 3, XYAxisSlaveNo, 1, ArcIndex, Y1_SlaveNo, CenterPointArc3, PositionMove, CurveAngle, CircleDir, TargetVel, TargetVel, TargetVel, 1, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_Arc_follow,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void MotionBuffer_Arc_180_Follow(ushort X_SlaveNo, ushort Y1_SlaveNo, ushort Y2_SlaveNo, int DistX, int DistY, int TargetVel, int EndVel, ushort CircleDir)
        {
            m_checkParentCardisOpen();
            ushort[] XYAxisSlaveNo = { X_SlaveNo, Y1_SlaveNo, Y2_SlaveNo };
            ushort[] ArcIndex = { X_SlaveNo, Y1_SlaveNo };
            int[] CenterPointArc3 = { 0, 0 };
            int[] PositionMove = { DistX, DistY };
            //int[] FollowTargetPos = { DistY, DistX, DistY };
            double CurveAngle = 180.0;

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Arc_follow(ParentCard.CardNo, 0, 3, XYAxisSlaveNo, 1, ArcIndex, Y1_SlaveNo, CenterPointArc3, PositionMove, CurveAngle, CircleDir, TargetVel, TargetVel, TargetVel, 1, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_Arc_follow,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void MotionBuffer_Line_Multi(int DistX, int DistY, int DistZ, int DistRZ, int TargetVel)
        {
            m_checkParentCardisOpen();
            int[] XYZPositionMove = { DistY, DistX, DistY, DistZ, DistRZ };

            int EndVal = 40000;
            int FinalEndVal = 0;

            if (TargetVel >= EndVal) { FinalEndVal = EndVal; }
            else { FinalEndVal = TargetVel; }

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Line_MultiAxis(ParentCard.CardNo, 0, XYZPositionMove, TargetVel, FinalEndVal, TargetVel * 3, 1, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_Line_MultiAxis,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void MotionBuffer_Line_Multi_EndVelZero(int DistX, int DistY, int DistZ, int DistRZ, int TargetVel)
        {
            m_checkParentCardisOpen();
            int[] XYZPositionMove = { DistY, DistX, DistY, DistZ, DistRZ };

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Line_MultiAxis(ParentCard.CardNo, 0, XYZPositionMove, TargetVel, 0, TargetVel*3, 1, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_Line_MultiAxis,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void MotionBuffer_Start()
        {
            m_checkParentCardisOpen();
            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Start(ParentCard.CardNo, 0, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_Start,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void MotionBuffer_Stop()
        {
            m_checkParentCardisOpen();
            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Stop(ParentCard.CardNo, 0, 0, 1);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_Start,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void MotionBuffer_IO_Control(ushort SlaveNo, ushort BitNo, ushort Value)
        {
            m_checkParentCardisOpen();

            EtherCAT_DLL.MotionBuffer_IO_Set[] l_nIO_Set = new EtherCAT_DLL.MotionBuffer_IO_Set[1];
            l_nIO_Set[0].IO_Info.NodeID = SlaveNo;
            l_nIO_Set[0].IO_Info.SlotID = 0;
            l_nIO_Set[0].IO_Info.BitNo = BitNo;
            l_nIO_Set[0].Value = Value;

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_IOControl(ParentCard.CardNo, 0, 1, ref l_nIO_Set[0], 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_IOControl,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override void MotionBuffer_Delay(double DelayTime)
        {
            m_checkParentCardisOpen();

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Delay(ParentCard.CardNo, 0, DelayTime, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_Delay,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        public override ushort MotionBuffer_Motion_Status()
        {
            ushort Status = 0;
            int MD_Block = 0;

            ushort uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Get_Motion_Status(ParentCard.CardNo, 0, ref Status, ref MD_Block, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_MotionBuffer_Get_Motion_Status,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }

            return Status;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////







        public override void Reset()
        {
            ushort uhRC;
            m_checkParentCardisOpen();
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Set_Position(ParentCard.CardNo, SlaveNo, _NodeID, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Set_Position,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Set_Command(ParentCard.CardNo, SlaveNo, _NodeID, 0);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Set_Command,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }

        public override void Speed_Move(int StrVel, int MaxVel, double Tacc, EDirection Direction)
        {
            m_checkParentCardisOpen();
            ushort uhRC;
            uint uiacc = (uint)(Tacc * 1000);
            uint uidec = (uint)(Tacc * 1000);
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_PV_Start_Move(ParentCard.CardNo, SlaveNo, _NodeID, MaxVel, uiacc, uidec);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_PV_Start_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_V_Move(ParentCard.CardNo, SlaveNo, _NodeID, (ushort)Direction, StrVel, MaxVel, Tacc, (ushort)curveMode);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_CSP_Start_V_Move,uhRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }

        public override void Stop(double Tdec)
        {
            m_checkParentCardisOpen();
            ushort uhRC;
            uhRC = EtherCAT_DLL.CS_ECAT_Slave_Motion_Sd_Stop(ParentCard.CardNo, SlaveNo, _NodeID, Tdec);
            if (uhRC != 0) { MessageBox.Show("CS_ECAT_Slave_Motion_Sd_Stop,hRC:" + uhRC); Common.bEtherCatCommandFail = true; }
        }
        DateTime s;
        string str;
        public override void update()
        {
            if (ParentCard.isOpen)
            {
                if (isOpen)
                {
                    s = DateTime.Now;
                    uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_Motion_Get_Command(ParentCard.CardNo, SlaveNo, 0, ref _iGetDataBuffer);
                    str = (DateTime.Now - s).TotalMilliseconds.ToString();
                    if (uhRC_update == 0)
                    {
                        if (_iGetDataBuffer != Command)
                            Command = _iGetDataBuffer;
                    }
                    else
                        Invoke_onIOErrorlog("CS_ECAT_Slave_Motion_Get_Command,hRC:" + uhRC_update);
                    uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_Motion_Get_Position(ParentCard.CardNo, SlaveNo, 0, ref _iGetDataBuffer);

                    if (uhRC_update == 0)
                    {
                        if (_iGetDataBuffer != Position)
                            Position = _iGetDataBuffer;
                    }
                    else
                        Invoke_onIOErrorlog("CS_ECAT_Slave_Motion_Get_Position,hRC:" + uhRC_update);


                    uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_Motion_Get_Torque(ParentCard.CardNo, SlaveNo, 0, ref _hGetDataBuffer);

                    if (uhRC_update == 0)
                    {
                        Torque = _hGetDataBuffer;
                    }
                    else
                        Invoke_onIOErrorlog("CS_ECAT_Slave_Motion_Get_Torque,hRC:" + uhRC_update);


                    iRC_update = EtherCAT_DLL.CS_ECAT_Slave_Motion_Get_Current_Speed(ParentCard.CardNo, SlaveNo, 0, ref _iGetDataBuffer1);

                    if (iRC_update == 0)
                    {
                        if (_iGetDataBuffer1 != Speed)
                            Speed = _iGetDataBuffer1;
                    }
                    else
                        Invoke_onIOErrorlog("CS_ECAT_Slave_Motion_Get_Current_Speed,hRC:" + iRC_update);


                    str = (DateTime.Now - s).TotalMilliseconds.ToString();
                    uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_Motion_Get_StatusWord(ParentCard.CardNo, SlaveNo, 0, ref _uhGetDataBuffer);
                    if (uhRC_update == 0)
                    {
                        if (_uhGetDataBuffer != _Status)
                        {
                            _Status = _uhGetDataBuffer;
                            TargetDone = ((_uhGetDataBuffer & 0x0400) != 0) ? true : false;
                        }
                    }
                    else
                        Invoke_onIOErrorlog("CS_ECAT_Slave_Motion_Get_StatusWord,hRC:" + uhRC_update);

                    uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_Motion_Get_Mdone(ParentCard.CardNo, SlaveNo, 0, ref _uhGetDataBuffer);
                    if (uhRC_update == 0)
                    {
                        if (_uhGetDataBuffer != MotionDone)
                        {
                            MotionDone = _uhGetDataBuffer;
                        }
                    }
                    else
                        Invoke_onIOErrorlog("CS_ECAT_Slave_Motion_Get_Mdone,hRC:" + uhRC_update);


                    uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_CSP_Start_MotionBuffer_Get_Motion_Status(ParentCard.CardNo, 0, ref _uhGetDataMotionBuffer, ref _iGetMDBlockNum, 0);
                    if (uhRC_update == 0)
                    {
                        if (_uhGetDataMotionBuffer != MotionBufferStatus)
                        {
                            MotionBufferStatus = _uhGetDataMotionBuffer;
                        }
                    }
                    else
                        Invoke_onIOErrorlog("CS_ECAT_Slave_CSP_Start_MotionBuffer_Get_Motion_Status,hRC:" + uhRC_update);


                    uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_CSP_Gantry_Home_Status(ParentCard.CardNo, 0, ref _uhGetGantryHomeStatus);
                    if (uhRC_update == 0)
                    {
                        if (_uhGetGantryHomeStatus != GantryHomeStatus)
                        {
                            GantryHomeStatus = _uhGetGantryHomeStatus;
                        }
                    }
                    else
                        Invoke_onIOErrorlog("CS_ECAT_Slave_CSP_Gantry_Home_Status,hRC:" + uhRC_update);



                    ushort Status = 0;
                    ushort StatusWord = 0;

                    Status = EtherCAT_DLL.CS_ECAT_Slave_Motion_Get_StatusWord(ParentCard.CardNo, SlaveNo, _NodeID, ref StatusWord);
                    string _str = Convert.ToString(StatusWord, 2);
                    while (_str.Length < 16)
                    {
                        _str = "0" + _str;
                    }
                    if ((_str.Substring(12, 1) == "1") | (_str.Substring(8, 1) == "1"))
                    {
                        Console.WriteLine("Servo alarm！");

                        uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_DeltaServo_Read_Parameter(ParentCard.CardNo, SlaveNo, _NodeID, 0, 01, ref _iGetDataBuffer);
                        if (uhRC_update == 0)
                        {
                            if (_iGetDataBuffer != ErrorCode)
                            {
                                ErrorCode = _iGetDataBuffer;
                            }
                        }
                        else
                            Invoke_onIOErrorlog("CS_ECAT_Slave_DeltaServo_Read_ParameterP0-01,hRC:" + uhRC_update);
                    }
                    else
                    {
                        ErrorCode = 0;
                    }

                }
            }
        }

        public override void DriverUpdate()
        {
            object a = new object();
            lock (a)
            {
                uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_DeltaServo_Read_Parameter(ParentCard.CardNo, SlaveNo, _NodeID, 0, 01, ref _iGetDataBuffer);
                if (uhRC_update == 0)
                {
                    if (_iGetDataBuffer != ErrorCode)
                    {
                        ErrorCode = _iGetDataBuffer;
                    }
                }
                else
                    Invoke_onIOErrorlog("CS_ECAT_Slave_DeltaServo_Read_ParameterP0-01,hRC:" + uhRC_update);
                uhRC_update = EtherCAT_DLL.CS_ECAT_Slave_DeltaServo_Read_Parameter(ParentCard.CardNo, SlaveNo, _NodeID, 0, 09, ref _iGetDataBuffer);
                if (uhRC_update == 0)
                {
                    if (_iGetDataBuffer != _P0_09Buffer)
                    {
                        _P0_09Buffer = _iGetDataBuffer;
                        N_limit = (_iGetDataBuffer & (0x1 << 4)) != 0 ? true : false;
                        H_limit = (_iGetDataBuffer & (0x1 << 2)) != 0 ? true : false;
                        P_limit = (_iGetDataBuffer & (0x1 << 5)) != 0 ? true : false;
                    }
                }
                else
                    Invoke_onIOErrorlog("CS_ECAT_Slave_DeltaServo_Read_ParameterP0-09,hRC:" + uhRC_update);
            }

        }
    }
}
