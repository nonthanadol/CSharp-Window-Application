﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equipment_Control.ASD_A2_E
{
    public class MotorParameter
    {
        protected double _CirclePulse;
        protected double _Pitch;
        protected double _ReductionRation;
        protected double _StrVal;
        protected double _Speed;
        protected double _acc;
        protected double _dec;
        protected double _MaunalSpeed;

        protected double _ratedTorque;
        protected double _offsetTorque;
        protected double _decelerationRatio;

        internal int intSpeed;
        internal int intStrVal;
        internal int intMaunalSpeed;

        public enum EEncoderMode
        {
            InternalEncoder = 0,
            externalEncoder = 1,
            NoEncoder = 2
        }

        public MotorParameter()
        {
            _CirclePulse = 1;
            _Pitch = 1;
            _ReductionRation = 1;
            _StrVal = 1;
            _Speed = 1;
            _acc = 0.1;
            _dec = 0.1;
            _MaunalSpeed = 1;
            _ratedTorque = 1.27;
            _offsetTorque = 0;
            _decelerationRatio = 1;
        }

        public double DecelerationRatio
        {
            get { return _decelerationRatio; }
            set
            {
                _decelerationRatio = value;
            }
        }

        public double RatedTorque
        {
            get { return _ratedTorque; }
            set
            {
                _ratedTorque = value;
            }
        }
        public double OffsetTorque
        {
            get { return _offsetTorque; }
            set
            {
                _offsetTorque = value;
            }
        }

        //public double CirclePulse
        //{
        //    get { return _CirclePulse; }
        //    set
        //    {
        //        _CirclePulse = value;
        //        DataChange();
        //    }
        //}

        //public double Pitch
        //{
        //    get { return _Pitch; }
        //    set
        //    {
        //        _Pitch = value;
        //        DataChange();
        //    }
        //}

        //public double ReductionRation
        //{
        //    get { return _ReductionRation; }
        //    set
        //    {
        //        _ReductionRation = value;
        //        DataChange();
        //    }
        //}

        public ushort HomeMode { get; set; }

        public uint HomeHighSpeed { get; set; }

        public uint HomeLowSpeed { get; set; }

        public double Acc
        {
            get { return _acc; }
            set
            {
                _acc = value;
            }
        }

        public double Dec
        {
            get { return _dec; }
            set
            {
                _dec = value;
            }
        }

        public double StrVal
        {
            get { return _StrVal; }
            set
            {
                _StrVal = value;
                intStrVal = MotorParameterChange.PositionReversal(this, _StrVal);
            }
        }

        public double Speed
        {
            get { return _Speed; }
            set
            {
                _Speed = value;
                intSpeed = MotorParameterChange.PositionReversal(this, _Speed);
            }
        }

        //public double MaunalSpeed
        //{
        //    get { return _MaunalSpeed; }
        //    set
        //    {
        //        _MaunalSpeed = value;
        //        intMaunalSpeed = MotorParameterChange.PositionReversal(this, _MaunalSpeed);
        //    }
        //}

        //public double MaxPosition { get; set; }

        //public double MinPosition { get; set; }

        //public double MaxSpeed { get; set; }

        //public double MinSpeed { get; set; }

        public double Tolerance { get; set; }

        public EEncoderMode EncoderMode { get; set; }

        public double Offset { get; set; }

        public bool isOffsetOpen { get; set; }

        private void DataChange()
        {
            intMaunalSpeed = MotorParameterChange.PositionReversal(this, _MaunalSpeed);
            intSpeed = MotorParameterChange.PositionReversal(this, _Speed);
            intStrVal = MotorParameterChange.PositionReversal(this, _StrVal);
        }
    }
}
