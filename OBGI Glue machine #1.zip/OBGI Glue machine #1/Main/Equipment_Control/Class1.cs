﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equipment_Control
{
    public class Class1
    {
        public static bool saa { get; set; }
    }
}
