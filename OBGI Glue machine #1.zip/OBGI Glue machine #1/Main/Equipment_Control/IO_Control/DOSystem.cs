﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Communication.EtherCAT;

namespace Equipment_Control.IO_Control
{
    public class DOBase
    {
        List<IOutputBase> _list;
        public DOBase()
        {
            _list = new List<IOutputBase>();
        }
        internal void Add(IOutputBase output)
        {
            _list.Add(output);
        }
        public int Count { get { return _list.Count; } }
        public IOutputBase this[int index] { get { return _list[index]; } }
    }
    public class DOSystem
    {
        private List<IOutputModel> _OutputArray;
        private Dictionary<ushort, DOBase> _OutputDict;
        public DOSystem()
        {
            _OutputDict = new Dictionary<ushort, DOBase>();
            _OutputArray = new List<IOutputModel>();
        }

        public void Open()  
        {
            for (int i = 0; i < _OutputArray.Count; i++)
            {
                if (!_OutputArray[i].isOpen)
                    _OutputArray[i].Open();
            }
        }

        public void Close()
        {
            for (int i = 0; i < _OutputArray.Count; i++)
            {
                if (_OutputArray[i].isOpen)
                    _OutputArray[i].Close();
            }
        }
        public void Add(IOutputModel model)
        {

            ushort i = 0;
            Dictionary<int, IOutputModel> OutputList = new Dictionary<int, IOutputModel>();
            OutputList.Add(model.SlaveNo, model);

            for (i = 0; i < _OutputArray.Count; i++)
            {
                if (!OutputList.ContainsKey(_OutputArray[i].SlaveNo))
                    OutputList.Add(_OutputArray[i].SlaveNo, _OutputArray[i]);
            }

            int[] intArray = new int[OutputList.Count];
            i = 0;
            foreach (KeyValuePair<int, IOutputModel> item in OutputList)
            {
                intArray[i] = item.Key;
                i++;
            }

            Array.Sort(intArray);

            _OutputArray.Clear();
            _OutputDict.Clear();

            for (i = 0; i < intArray.Length; i++)
            {
                _OutputArray.Add(OutputList[intArray[i]]);
            }

            ushort uhMainIndex = 0;
            for (i = 0; i < _OutputArray.Count; i++)
            {
                int iCount;
                iCount = _OutputArray[i].OutputCount / 16;
                for (int j = 0; j < iCount; j++)
                {
                    _OutputDict.Add(uhMainIndex, new DOBase());
                    for (int k = 0; k < 16; k++)
                    {
                        try
                        {
                            _OutputDict[uhMainIndex].Add(_OutputArray[i][j * 16 + k]);
                        }
                        catch
                        {
                            break;
                        }
                    }
                    uhMainIndex++;
                }
            }
        }
        public IOutputBase this[string data]
        {
            get
            {
                string strData = data.ToUpper();
                string strDataNoFirst;
                int strIndex;
                if (strData.StartsWith("Y"))
                {
                    strDataNoFirst = strData.Remove(0, 1);
                    strIndex = strDataNoFirst.IndexOf(".");
                    string[] strTemp;
                    ushort uhMainIndex;
                    ushort uhIndex;
                    if (strIndex > 0)
                    {
                        strTemp = strDataNoFirst.Split('.');
                        try
                        {
                            uhMainIndex = ushort.Parse(strTemp[0]);
                            uhIndex = ushort.Parse(strTemp[1]);
                        }
                        catch
                        {
                            throw new Exception("this data the word can't transfer to number");
                        }
                        if (uhIndex > 15)
                        throw new Exception("this data the word can't transfer to number");
                        else
                        {
                            try
                            {
                                return _OutputDict[uhMainIndex][uhIndex];
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                        }
                    }
                    else
                    throw new Exception("this data the word havn't \".\"");
                }
                else
                throw new Exception("this data the frist word havn't X");
            }
        }
        public IOutputBase this[ushort MainIndex, ushort Index]
        {
            get
            {
                return _OutputDict[MainIndex][Index];
            }
        }
        public IOutputBase GetInput(ushort MainIndex, ushort Index)
        {
            return _OutputDict[MainIndex][Index];
        }
        public DOBase GetMainDI(ushort MainIndex)
        {
            return _OutputDict[MainIndex];
        }
        public int MainCount { get { return _OutputDict.Count; } }
        public IOutputModel GetOutputModel(int Index)
        {
            return _OutputArray[Index];
        }
        public int OutputModelCount { get { return _OutputArray.Count; } }
    }
}
