﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Communication.EtherCAT;

namespace Equipment_Control.IO_Control
{
    public class DIBase
    {
        List<IInputBase> _list;
        public DIBase()
        {
            _list = new List<IInputBase>();
        }
        internal void Add(IInputBase input)
        {
            _list.Add(input);
        }
        public int Count { get { return _list.Count; } }
        public IInputBase this[int index] { get { return _list[index]; } }
    }
    public class DISystem
    {
        private List<IInputModel> _InputArray;
        private Dictionary<ushort, DIBase> _InputDict;
        public DISystem()
        {
            _InputDict = new Dictionary<ushort, DIBase>();
            _InputArray = new List<IInputModel>();
        }

        public void Open() 
        {
            for (int i = 0; i < _InputArray.Count; i++)
            {
                if (!_InputArray[i].isOpen)
                    _InputArray[i].Open();
            }
        }

        public void Close()
        {
            for (int i = 0; i < _InputArray.Count; i++)
            {
                if (_InputArray[i].isOpen)
                    _InputArray[i].Close();
            }
        }

        /// <param name="model"></param>
        public void Add(IInputModel model)
        {

            ushort i = 0;
            Dictionary<int, IInputModel> InputList = new Dictionary<int, IInputModel>();
            InputList.Add(model.SlaveNo, model);

            for (i = 0; i < _InputArray.Count; i++)
            {
                if (!InputList.ContainsKey(_InputArray[i].SlaveNo))
                    InputList.Add(_InputArray[i].SlaveNo, _InputArray[i]);
            }

            int[] intArray = new int[InputList.Count];
            i = 0;
            foreach (KeyValuePair<int, IInputModel> item in InputList)
            {
                intArray[i] = item.Key;
                i++;
            }

            Array.Sort(intArray);

            _InputArray.Clear();
            _InputDict.Clear();

            for (i = 0; i < intArray.Length; i++)
            {
                _InputArray.Add(InputList[intArray[i]]);
            }

            ushort uhMainIndex = 0;
            for (i = 0; i < _InputArray.Count; i++)
            {
                int iCount;
                iCount = _InputArray[i].InputCount / 16;

                for (int j = 0; j < iCount; j++)
                {
                    _InputDict.Add(uhMainIndex, new DIBase());

                    for (int k = 0; k < 16; k++)
                    {
                        try
                        {
                            _InputDict[uhMainIndex].Add(_InputArray[i][j * 16 + k]);
                        }
                        catch
                        {
                            break;
                        }
                    }
                    uhMainIndex++;
                }
            }
        }

        /// <param name="data"></param>
        /// <returns></returns>
        public IInputBase this[string data]
        {
            get
            {
                string strData = data.ToUpper();
                string strDataNoFirst;
                int strIndex;
                if (strData.StartsWith("X"))
                {
                    strDataNoFirst = strData.Remove(0, 1);
                    strIndex = strDataNoFirst.IndexOf(".");
                    string[] strTemp;
                    ushort uhMainIndex;
                    ushort uhIndex;
                    if (strIndex > 0)
                    {
                        strTemp = strDataNoFirst.Split('.');
                        try
                        {
                            uhMainIndex = ushort.Parse(strTemp[0]);
                            uhIndex = ushort.Parse(strTemp[1]);
                        }
                        catch
                        {
                            throw new Exception("this data the word can't transfer to number");
                        }
                        if (uhIndex > 15)
                        throw new Exception("this data the word can't transfer to number");
                        else
                        {
                            try
                            {
                                return _InputDict[uhMainIndex][uhIndex];
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                        }
                    }
                    else
                    throw new Exception("this data the word havn't \".\"");
                }
                else
                throw new Exception("this data the frist word havn't X");
            }
        }
        public IInputBase this[ushort MainIndex, ushort Index]
        {
            get
            {
                //if (MainIndex < 3)
                //{
                    return _InputDict[MainIndex][Index];
                //}
                //else
                //{
                //    return _InputDict[0][0];
                //}
            }
        }
        public IInputBase GetInput(ushort MainIndex, ushort Index)
        {
            return _InputDict[MainIndex][Index];
        }
        public DIBase GetMainDI(ushort MainIndex)
        {
            return _InputDict[MainIndex];
        }
        public int MainCount { get { return _InputDict.Count; } }
        public IInputModel GetInputModel(int Index)
        {
            return _InputArray[Index];
        }
        public int InputModelCount { get { return _InputArray.Count; } }
    }
}
