﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equipment_Control.IO_Control
{
    public class IOSystem
    {


        public IOSystem()
        {
            DI = new DISystem();
            DO = new DOSystem();
        }

        public DISystem DI { get; private set; }

        public DOSystem DO { get; private set; }

        public void Open() 
        {
            DI.Open();
            DO.Open();
        }

        public void Close()  
        {
            DI.Close();
            DO.Close();
        }
    }
}
