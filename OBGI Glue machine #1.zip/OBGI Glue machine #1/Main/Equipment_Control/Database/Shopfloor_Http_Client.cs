﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Xml.Linq;
using System.Security.Cryptography;


namespace Equipment_Control.Database
{
    //public delegate void HMES_log(object sender, string msg);
    public class Shopfloor_Http_Client
    {
        private HttpWebRequest request;
        //public event HMES_log onMES_log;

        public string URL { get; private set; }
        //秘钥
        public string SecretKey { get; set; }
        //验证ID
        public string tokenID { get; set; }


        public Shopfloor_Http_Client(string url, string key, string token)
        {
            //只需要前段url和key
            URL = url;
            SecretKey = key;
            tokenID = token;
        }

        #region 对发送数据进行加密
        /// <summary>
        /// MD5加密(32位)
        /// </summary>
        /// <param name="str">加密字符</param>
        /// <returns></returns>
        public static string encrypt(string str)
        {
            string cl = str;
            string pwd = "";
            MD5 md5 = MD5.Create();
                                    　
            byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
           
            for (int i = 0; i < s.Length; i++)
            {
                
                pwd = pwd + s[i].ToString("X2");
            }
            return pwd;
        }

        //都是秘钥再加上升序排列的键值对
        private string GetSign(LineInfoAPI api)
        {
            //得到原文
            string code = SecretKey + "EMP_NO" + api.EMP_NO + "FACTORY" + api.FACTORY + "LINE_NAME" + api.LINE_NAME;
            //生成密文
            string key = encrypt(code);
            //得到最后一个参数sign
            string sign = "&sign=" + key;
            return sign;
        }

        private string GetSign(SNInfoAPI api)
        {
            //得到原文
            string code = SecretKey + "FACTORY" + api.FACTORY + "SERIAL_NUMBER" + api.SERIAL_NUMBER;
            //生成密文
            string key = encrypt(code);
            //得到最后一个参数sign
            string sign = "sign=" + key;
            return sign;
        }

        private string GetSign(MOListAPI api)
        {
            //得到原文
            string code = SecretKey + "EMP_NO" + api.EMP_NO + "FACTORY" + api.FACTORY + "GETDATA_TYPE" + api.GETDATA_TYPE + "LINE_NAME" + api.LINE_NAME + "MO_TYPE" + api.MO_TYPE;
            //生成密文
            string key = encrypt(code);
            //得到最后一个参数sign
            string sign = "sign=" + key;
            return sign;
        }

        private string GetSign(TDCAPI api)
        {
            //先获得body字符串
            string tdc = JsonConvert.SerializeObject(api);
            //拼接原文
            string code = SecretKey + tdc;
            //生成密文
            string key = encrypt(code);
            //得到最后一个参数sign
            string sign = "sign=" + key;
            return sign;
        }
        #endregion

        #region Shopfloor命令方法

        #region Get&Post
        public static string getHttpRequest(string url, string tokenID)
        {
            //预备请求的资源
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            StreamReader reader = null;

            string content = string.Empty;

            try
            {
                request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";
                request.Headers.Add("tokenID", tokenID);
                response = (HttpWebResponse)request.GetResponse();
                using (reader = new StreamReader(response.GetResponseStream()))
                {
                    content = reader.ReadToEnd();
                }
            }
            catch (System.Exception err)
            {
                //MessageBox.Show("1.GET出现了错误！\n错误来源：" + err.Source + "\n错误信息：" + err.Message + "\n" + err);
                Console.WriteLine("1.GET出现了错误！\n错误来源：" + err.Source + "错误信息：" + err.Message);
            }

            //用完销毁
            response.Close();
            reader.Dispose();

            return content;
        }

        public string postHttpRequest(string url, string msg)
        {
            string content = "";
            //预备请求的资源
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            Stream requestStream = null;
            StreamReader reader = null;

            //设置基础参数
            request = (HttpWebRequest)WebRequest.Create(url);
            request.Headers.Add("tokenID", tokenID);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.ContentLength = Encoding.UTF8.GetByteCount(msg);
            request.ProtocolVersion = HttpVersion.Version10;
            var data = Encoding.UTF8.GetBytes(msg);

            try
            {
                requestStream = request.GetRequestStream();
                requestStream.Write(data, 0, data.Length);
                response = (HttpWebResponse)request.GetResponse();
                using (reader = new StreamReader(response.GetResponseStream()))
                {
                    content = reader.ReadToEnd();
                }
            }
            catch (Exception err)
            {
                Console.WriteLine("1.POST出现了错误！\n错误来源：" + err.Source + "错误信息：" + err.Message);
            }

            //资源用完回收
            requestStream.Dispose();
            response.Close();
            reader.Dispose();

            return content;
        }

        #endregion

        public string MOList(MOListAPI api)
        {
            //首先排序,得到最后一个参数sign密文
            string sign = GetSign(api);
            //地址+API+参数+密文组成完整url
            string _url = URL + "/QueryData/MOList?" + api.ToString() + sign;
            //发到MES
            string backStr = getHttpRequest(_url, tokenID);
            //回传字符串,由UI进行解析
            return backStr;
        }

        public ResMsg DELTA_DEAL_TEST_DATA_I(TDCAPI api)
        {
            //得到最后一个参数sign
            string sign = GetSign(api);
            //地址+API+参数,得到完整url
            string _url = URL + "/TDC/DELTA_DEAL_TEST_DATA_I?" + sign;
            //转json,得到body
            string body = JsonConvert.SerializeObject(api);

            string backStr = postHttpRequest(_url, body);
            ResMsg re = JsonConvert.DeserializeObject<ResMsg>(backStr);
            return re;
        }

        //public ResMsg DELTA_DEAL_TEST_DATA_I_1(TDCAPI api)
        //{
        //    //得到最后一个参数sign
        //    string sign = GetSign(api);
        //    //地址+API+参数,得到完整url
        //    string _url = URL + "/TDC/DELTA_DEAL_TEST_DATA_I?" + sign;
        //    //转json,得到body
        //    string body = JsonConvert.SerializeObject(api);

        //    string backStr = postHttpRequest(_url, body);

        //    ResMsg re = JsonConvert.DeserializeObject<ResMsg>(backStr);
        //    return re;
        //}

        public string SNInfo(SNInfoAPI api)
        {
            //首先排序,得到最后一个参数sign密文
            string sign = GetSign(api);
            //地址+API+参数+密文组成完整url
            string _url = URL + "/QueryData/SNInfo?" + api.ToString() + sign;
            //发到MES
            string backStr = getHttpRequest(_url, tokenID);
            return backStr;
        }

        public string LineInfo(LineInfoAPI api)
        {
            //首先排序,得到最后一个参数sign密文
            string sign = GetSign(api);

            //地址+API+参数+密文组成完整url
            string _url = URL + "/QueryData/LineInfo?" + api.ToString() + sign;
            //发到MES
            string backStr = getHttpRequest(_url, tokenID);
            return backStr;
        }
        #endregion

        #region TDC函数使用方法
        /// <summary>
        /// 途程站别检查
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public ResMsg ROUTING_Check(string factory, string Test_Data, string Log_Data)
        {
            try
            {
                TDCAPI api = new TDCAPI();
                api.testType = "ROUTING_CHECK";
                api.factory = factory;
                api.routingData = Test_Data;
                api.testData = Log_Data;
                ResMsg res = DELTA_DEAL_TEST_DATA_I(api);
                return res;
            }
            catch (Exception ex)
            {
                ResMsg res1 = new ResMsg();
                res1.Result = "Fail";
                res1.Message = ex.ToString();
                return res1;
            }
        }
        public ResMsg_1 GET_SN_INFO(string factory, string Test_Data, string Log_Data)
        {
            try
            {
                TDCAPI api = new TDCAPI();
                api.testType = "GET_SN_INFO";
                api.factory = factory;
                api.routingData = Test_Data;
                api.testData = Log_Data;
               // ResMsg res = new ResMsg();
                string sign = GetSign(api);
                //地址+API+参数,得到完整url
                string _url = URL + "/TDC/DELTA_DEAL_TEST_DATA_I?" + sign;
                //转json,得到body
                string body = JsonConvert.SerializeObject(api);

                string backStr = postHttpRequest(_url, body).Replace("Wip ", "Wip").Replace("Next Group", "NextGroup");
                
                ResMsg_1 res = JsonConvert.DeserializeObject<ResMsg_1>(backStr);
             
               
                return res;
            }
            catch (Exception ex)
            {
                ResMsg_1 res1 = new ResMsg_1();
                res1.result = "Fail";
              //  res1.description = ex.ToString();
                return res1;
            }
        }

        public ResMsg ROUTING_INPUT(string factory, string Test_Data, string Log_Data)
        {
            try
            {
                TDCAPI api = new TDCAPI();
                api.testType = "ROUTING_INPUT";
                api.factory = factory;
                api.routingData = Test_Data;
                api.testData = Log_Data;
                ResMsg res = DELTA_DEAL_TEST_DATA_I(api);
                return res;
            }
            catch (Exception ex)
            {
                ResMsg res1 = new ResMsg();
                res1.Result = "Fail";
                res1.Message = ex.ToString();
                return res1;
            }
        }

        /// <summary>
        /// 产品上传测试结果记录,测试项数据,途程更新,过站数的统计以及不良品登记
        /// </summary>

        public ResMsg ROUTING_Update(string factory, string Test_Data, string Log_Data)
        {
            try
            {
                TDCAPI api = new TDCAPI();
                api.testType = "ROUTING_UPDATE";
                api.factory = factory;
                api.routingData = Test_Data;
                api.testData = Log_Data;
                ResMsg res = DELTA_DEAL_TEST_DATA_I(api);
                return res;
            }
            catch (Exception ex)
            {
                ResMsg res1 = new ResMsg();
                res1.Result = "Fail";
                res1.Message = ex.ToString();
                return res1;
            }
        }


        /// <summary>
        /// 产品途程的首站投入
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public ResMsg INPUT_UPDATE(string factory, string Test_Data, string Log_Data)
        {
            try
            {
                TDCAPI api = new TDCAPI();
                api.testType = "ROUTING_Update";
                api.factory = factory;
                api.routingData = Test_Data;
                api.testData = Log_Data;
                ResMsg res = DELTA_DEAL_TEST_DATA_I(api);
                return res;
            }
            catch (Exception ex)
            {
                ResMsg res1 = new ResMsg();
                res1.Result = "Fail";
                res1.Message = ex.ToString();
                return res1;
            }
        }
        //public ResMsg SN_INFO()
        //{

        //}
        #endregion

    }

    #region 发送API

    public class LineInfoAPI
    {
        public string FACTORY { get; set; }
        public string LINE_NAME { get; set; }
        public string EMP_NO { get; set; }

        new public string ToString()
        {
            string str = "";
            str = "FACTORY=" + FACTORY + "&LINE_NAME=" + LINE_NAME + "&EMP_NO=" + EMP_NO;
            return str;
        }
    }

    public class SNInfoAPI
    {
        public string FACTORY { get; set; }
        public string SERIAL_NUMBER { get; set; }
        new public string ToString()
        {
            string str = "";
            str = "FACTORY=" + FACTORY + "&SERIAL_NUMBER=" + SERIAL_NUMBER;
            return str;
        }
    }

    public class MOListAPI
    {
        public string EMP_NO { get; set; }
        public string FACTORY { get; set; }
        public string GETDATA_TYPE { get; set; }
        public string LINE_NAME { get; set; }
        public string MO_TYPE { get; set; }
        new public string ToString()
        {
            string str = "";
            str = "FACTORY=" + FACTORY + "&GETDATA_TYPE=" + GETDATA_TYPE + "&MO_TYPE=" + MO_TYPE + "&EMP_NO=" + EMP_NO + "&LINE_NAME=" + LINE_NAME;
            return str;
        }
    }

    public class TDCAPI
    {

        public string factory { get; set; }
        public string testType { get; set; }
        public string routingData { get; set; }
        public string testData { get; set; }
        //public string Test_Type { get; set; }
        //public string Test_Data { get; set; }
        //public string Log_Data { get; set; }
    }


    #endregion

    #region 回传类

    public class ResMsg
    {
        public string Result { get; set; }
        public string Message { get; set; }

    }
    public class ResMsg_1
    {
        public string result { get; set; }
        public Receivemessage description { get; set; }

    }

    public class TDC
    {
        public string factory { get; set; }
        public string pTest_Type { get; set; }
        public string pTest_Data { get; set; }
        public string pLog_Data { get; set; }
    }

    #region MO

    /// <summary>
    /// 查询工单返回的是工单列表
    /// </summary>
    public class ResMO
    {
        /// <summary>
        /// 
        /// </summary>
        public string Result { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Mo> MOList { get; set; }
    }
    /// <summary>
    /// 返回的工单,抽象类
    /// </summary>
    public class Mo
    {
        public string MO_NUMBER { get; set; }
        public string MODEL_NAME { get; set; }
        public string LINE_NAME { get; set; }
    }
    /// <summary>
    /// 给TDC函数用的完整工单信息
    /// </summary>
    public class MoInfo
    {
        //这是给TDC_DLL用的

        /// <summary>
        /// 工单
        /// </summary>
        public string MONumber { get; set; } = "NA";
        /// <summary>
        /// 机种
        /// </summary>
        public string ModelName { get; set; } = "NA";
        /// <summary>
        /// 线别
        /// </summary>
        public string LineName { get; set; } = "NA";
        /// <summary>
        /// 段别
        /// </summary>
        public string SectionName { get; set; } = "NA";
        /// <summary>
        /// 组别
        /// </summary>
        public string GroupName { get; set; } = "NA";
        /// <summary>
        /// 站别
        /// </summary>
        public string StationName { get; set; } = "NA";
    }

    #endregion

    #region LineInfo

    public class LineInfo
    {
        public string LINE_NAME { get; set; }
        public string SECTION_NAME { get; set; }
        public string GROUP_NAME { get; set; }
        public string STATION_NAME { get; set; }

    }
    public class ResLineInfo
    {
        /// <summary>
        /// 
        /// </summary>
        public string Result { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<LineInfo> LineInfoList { get; set; }
    }

    #endregion

    #region MyRegion

    public class SNInfo
    {
        public string SERIAL_NUMBER { get; set; }
        public string MO_NUMBER { get; set; }
        public string MODEL_NAME { get; set; }
        public string LINE_NAME { get; set; }
    }
    public class ResSNInfo
    {
        /// <summary>
        /// 
        /// </summary>
        public string Result { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<SNInfo> SNInfoList { get; set; }
    }
    public class Receivemessage
    {
        public string SN;
        public string MO;
        public string Model;
        public string WipLine;
        public string WipSection;
        public string WipGroup;
        public string WipStation;

        public List<string> NextGroup;
        public string CaseSN;

        public string SSN;

        public string MACSN;
        public string CustomerCode;

        public string CustomerName;

        public string MOVer;




    }
    #endregion

    #endregion
}