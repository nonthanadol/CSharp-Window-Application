﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Equipment_Control.Database
{
    public class Xml_Node
    {
        internal XmlNode m_node = null;

        /// <param name="node"></param>
        public Xml_Node(XmlNode node)
        {
            this.m_node = node;
        }
        public Xml_Node RemoveAll()
        {
            m_node.RemoveAll();

            Xml_Node xmlnode = new Xml_Node(m_node);
            return xmlnode;

        }

        /// <param name="idx"></param>
        /// <returns></returns>
        public Xml_Node this[string idx]
        {
            get
            {
                if (m_node == null)
                {
                    return null;
                }

                return new Xml_Node(this.m_node.SelectSingleNode(idx));
            }
        }


        /// <param name="Key"></param>
        /// <returns></returns>
        public Xml_Node GetNode(string Key)
        {
            XmlNode node = null;
            Xml_Node DGnodetemp = null;
            if (m_node == null)
            {
                throw new Exception("this Node is Null");
            }
            node = m_node.SelectSingleNode(Key);
            if (node == null)
            {
                throw new Exception("can not find the " + Key + " in the " + this.Name + " Node");
            }
            DGnodetemp = new Xml_Node(node);
            return DGnodetemp;
        }
        public bool ContainsNodeKey(string Key)
        {
            XmlNode node = null;
            node = m_node.SelectSingleNode(Key);
            return (node == null) ? false : true;
        }

        public Xml_Node GetNodeByAttr(string AttrName, string AttrValue)
        {
            Xml_Node rtnNode = null;
            XmlNode myNode = null;

            if (this.m_node == null)
            {
                throw new Exception("this node is null");
            }

            foreach (XmlNode nodeItem in this.m_node.ChildNodes)
            {

                foreach (XmlAttribute attr in nodeItem.Attributes)
                {
                    if (attr.Name.Trim() == AttrName && attr.Value.Trim() == AttrValue)
                    {
                        myNode = nodeItem;
                        break;
                    }
                }

                if (myNode != null)
                {
                    break;
                }
            }
            if (myNode == null)
            {
                throw new Exception("can not find the xml item, AttrName= " + AttrName + ", AttrValue=" + AttrValue);
            }

            rtnNode = new Xml_Node(myNode);
            return rtnNode;
        }

        public Xml_Node[] ToList()
        {
            List<Xml_Node> itemList = new List<Xml_Node>();

            if (m_node == null)
            {
                return itemList.ToArray();
            }

            foreach (XmlNode node in m_node.ChildNodes)
            {
                if (node.NodeType != System.Xml.XmlNodeType.Comment)
                {
                    itemList.Add(new Xml_Node(node));
                }
            }

            return itemList.ToArray();
        }

        public string Name
        {
            get
            {
                return m_node.Name;
            }
        }

        public XmlValue Value
        {
            get
            {
                XmlValue buffer;
                if (m_node.ChildNodes.Count > 1)
                    throw new Exception("this XmlChildNodes Count more than one");
                else
                {
                    buffer = new XmlValue(this);
                    return buffer;
                }
            }
        }

        public void SetValue(string value)
        {
            if (m_node.ChildNodes.Count > 1)
                throw new Exception("this XmlChildNodes Count more than one");
            else
            {
                m_node.InnerText = value;
            }
        }

        internal string value
        {
            get
            {
                if (m_node.ChildNodes.Count > 1)
                    throw new Exception("this XmlChildNodes Count more than one");
                else
                    return m_node.InnerXml;
            }
            set
            {
                if (m_node.ChildNodes.Count <= 1)
                    m_node.InnerXml = value;
                else
                    throw new Exception("this XmlChildNodes Count more than one");
            }
        }

        public int ChirdNodeCount { get { return this.m_node.ChildNodes.Count; } }

        /// <param name="Key"></param>
        /// <returns></returns>
        public int GetNodeCount(string Key)
        {
            int iConut = 0;
            for (int i = 0; i < this.m_node.ChildNodes.Count; i++)
            {
                if (Key == this.m_node.ChildNodes[i].Name)
                    iConut++;
            }
            return iConut;
        }

        /// <param name="Name"></param>
        /// <param name="Value"></param>
        public Xml_Node AddNode(string Name, string Value)
        {
            XmlElement xmlBufffer = this.m_node.OwnerDocument.CreateElement(Name);
            xmlBufffer.InnerText = Value;
            this.m_node.AppendChild(xmlBufffer);
            return new Xml_Node(xmlBufffer);
        }

        public void RemoveNode(Xml_Node Node)
        {
            this.m_node.RemoveChild(Node.m_node);
            Node = null;
        }
        public void RemoveFristNode(string Name)
        {
            this.m_node.RemoveChild(this.GetNode(Name).m_node);
        }
    }

    public class XmlValue
    {
        private Xml_Node m_node;
        public XmlValue(Xml_Node node)
        {
            this.m_node = node;
        }
        public bool ToBool()
        {
            try
            {
                return bool.Parse(m_node.value);
            }
            catch
            {
                throw new Exception("Name : " + m_node.Name + ", Value :" + m_node.value + ", can't transform bool");
            }
        }

        public ushort ToUshort()
        {
            try
            {
                return ushort.Parse(m_node.value);
            }
            catch
            {
                throw new Exception("Name : " + m_node.Name + ", Value :" + m_node.value + ", can't transform ushort");
            }
        }

        public short ToShort()
        {
            try
            {
                return short.Parse(m_node.value);
            }
            catch
            {
                throw new Exception("Name : " + m_node.Name + ", Value :" + m_node.value + ", can't transform short");
            }
        }

        public int ToInt()
        {
            try
            {
                return int.Parse(m_node.value);
            }
            catch
            {
                throw new Exception("Name : " + m_node.Name + ", Value :" + m_node.value + ", can't transform int");
            }
        }

        public uint ToUint()
        {
            try
            {
                return uint.Parse(m_node.value);
            }
            catch
            {
                throw new Exception("Name : " + m_node.Name + ", Value :" + m_node.value + ", can't transform uint");
            }
        }


        public long ToLong()
        {
            try
            {
                return long.Parse(m_node.value);
            }
            catch
            {
                throw new Exception("Name : " + m_node.Name + ", Value :" + m_node.value + ", can't transform long");
            }
        }

        public ulong ToUlong()
        {
            try
            {
                return ulong.Parse(m_node.value);
            }
            catch
            {
                throw new Exception("Name : " + m_node.Name + ", Value :" + m_node.value + ", can't transform ulong");
            }
        }

        public float ToFloat()
        {
            try
            {
                return float.Parse(m_node.value);
            }
            catch
            {
                throw new Exception("Name : " + m_node.Name + ", Value :" + m_node.value + ", can't transform float");
            }
        }

        public double ToDouble()
        {
            try
            {
                return double.Parse(m_node.value);
            }
            catch
            {
                throw new Exception("Name : " + m_node.Name + ", Value :" + m_node.value + ", can't transform double");
            }
        }

        public override string ToString()
        {
            return m_node.value;
        }
    }
}
