﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Equipment_Control.Database
{
    #region DPath
    public static class DPath
    {
        public static readonly string BarcodeFitModel_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"\Product\BarcodeFitModel.ini";
        public static readonly string Config_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"\Ini\Config.ini";
        public static readonly string PARA_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"\Ini\Parameter.ini";
        public static readonly string Errorlog_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"\ErrorLog\ErrorLog.xml";
        public static readonly string IO_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"\Others\IOTable.xml";
        public static readonly string Language_Path = System.AppDomain.CurrentDomain.BaseDirectory + @"\Others\LanguageCode.xlsx";
        public static readonly string ErrorList_PATHCN = System.AppDomain.CurrentDomain.BaseDirectory + @"\Others\ErrorCodeListCN.xml";
        public static readonly string ErrorList_PATHEN = System.AppDomain.CurrentDomain.BaseDirectory + @"\Others\ErrorCodeListEN.xml";
        public static readonly string MesData_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"\Others\MesData.xml";
        public static readonly string MAINTAINING_DATA_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"\Others\Maintaining.xml";
        public static readonly string Systemlog_PATH = System.AppDomain.CurrentDomain.BaseDirectory + "Systemlog";
        public static readonly string WorkLog_PATH = System.AppDomain.CurrentDomain.BaseDirectory + "WorkLog";
        public static readonly string DebugLog_PATH = System.AppDomain.CurrentDomain.BaseDirectory + "DebugLog";
        public static readonly string TestData_PATH = System.AppDomain.CurrentDomain.BaseDirectory + "TestData";
        public static readonly string ShopFloorParameter_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"Shopfloor\Debug\ShopFloorParameter.ini";
        public static readonly string ShopFloorHeartBeat_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"Shopfloor\Debug\ShopFloorHeartBeat.ini";
        public static readonly string UserAdministration_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"\Others\UserManagement.Pro";
        public static readonly string ProductPara_PATH = System.AppDomain.CurrentDomain.BaseDirectory + @"\Product";

    }
    #endregion
}
