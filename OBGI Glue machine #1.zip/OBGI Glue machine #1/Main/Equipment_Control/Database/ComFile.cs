﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Equipment_Control.Database
{
    public class ComFile
    {
        /// <param name="filePath"></param>
        /// <param name="searchPattern"></param>
        /// <returns></returns>
        public static string[] GetFileList(string filePath, string searchPattern)
        {
            List<string> itemList = new List<string>();

            FileInfo[] objFileList = GetFileInfoList(filePath, searchPattern);

            if (objFileList == null)
            {
                return itemList.ToArray();
            }
            foreach (FileInfo item in objFileList)
            {
                itemList.Add(item.ToString());
            }

            return itemList.ToArray();
        }

        /// <param name="FullName"></param>
        public static void Delete(string FullName)
        {
            File.Delete(FullName);
        }

        private static FileInfo[] GetFileInfoList(string dir, string searchPattern)
        {
            DirectoryInfo objDirInfo = new DirectoryInfo(dir);

            if (!objDirInfo.Exists)
            {
                return null;
            }

            return objDirInfo.GetFiles(searchPattern);
        }

        /// <param name="ExpireDay"></param>
        /// <param name="path"></param>
        /// <param name="searchPattern"></param>
        /// <returns></returns>
        public static string[] Purge(double ExpireDay, string path, string searchPattern)
        {
            List<string> itemList = new List<string>();
            FileInfo[] fileInfoList = GetFileInfoList(path, searchPattern);

            if (fileInfoList == null)
            {
                return itemList.ToArray();
            }


            foreach (FileInfo item in fileInfoList)
            {
                TimeSpan ts = new TimeSpan(DateTime.Now.Ticks - item.LastWriteTime.Ticks);

                if (ts.TotalDays > ExpireDay && item.IsReadOnly == false)
                {
                    itemList.Add(item.FullName);
                    File.Delete(item.FullName);
                }
            }

            return itemList.ToArray();
        }

        /// <param name="path"></param>
        /// <returns></returns>
        public static bool IsDirExist(string path)
        {
            DirectoryInfo objDirInfo = new DirectoryInfo(path);

            return objDirInfo.Exists;

        }

        /// <param name="filePath"></param>
        /// <returns></returns>
        public static bool IsFileExist(string filePath)
        {
            return File.Exists(filePath);
        }

        /// <param name="dir"></param>
        public static void CreateDir(string dir)
        {
            DirectoryInfo objDirInfo = new DirectoryInfo(dir);

            if (objDirInfo.Exists == false)
            {
                objDirInfo.Create();
            }

        }
        public static void CreateFile(string FullName)
        {
            using (File.Create(FullName))
            {
                ;
            }
        }
    }
}
