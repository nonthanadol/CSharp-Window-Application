﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Runtime.InteropServices;

namespace Equipment_Control.Database
{
    public class Ini
    {
        private string path;

        [DllImport("kernel32.dll")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32.dll")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        /// <PARAM name="INIPath"></PARAM>
        public Ini(string INIPath)
        {
            this.path = INIPath;
        }

        /// <param name="fileName"></param>
        /// <returns></returns>
        public bool FileExists()
        {
            return (System.IO.File.Exists(this.path));
        }

        /// <PARAM name="Section"></PARAM>
        /// Section name
        /// <PARAM name="Key"></PARAM>
        /// Key Name
        /// <PARAM name="Value"></PARAM>
        /// Value Name
        public void WriteValue(string Section, string Key, string Value)
        {
            WritePrivateProfileString(Section, Key, Value, this.path);
        }

        /// <PARAM name="Section"></PARAM>
        /// <PARAM name="Key"></PARAM>
        /// <PARAM name="Path"></PARAM>
        /// <returns></returns>

        public IniData ReadValue(string Section, string Key)
        {
            StringBuilder temp = new StringBuilder(255);
            int i = GetPrivateProfileString(Section, Key, "", temp, 255, this.path);
            IniData data = new IniData(Section, Key, temp.ToString());
            return data;
        }
    }


    public class IniData
    {
        public IniData(string Section, string Key, string Value)
        {
            this.Section = Section;
            this.Key = Key;
            this.Value = Value;
        }
        public string Section { get; private set; }
        public string Key { get; private set; }
        public string Value { get; private set; }

        public bool ToBool()
        {
            try
            {
                return bool.Parse(Value);
            }
            catch
            {
                throw new Exception("Section : " + Section + ", Key :" + Key + ", " + Value + " can't transform bool");
            }
        }

        public ushort ToUshort()
        {
            try
            {
                return ushort.Parse(Value);
            }
            catch
            {
                throw new Exception("Section : " + Section + ", Key :" + Key + ", " + Value + " can't transform ushort");
            }
        }

        public short ToShort()
        {
            try
            {
                return short.Parse(Value);
            }
            catch
            {
                throw new Exception("Section : " + Section + ", Key :" + Key + ", " + Value + " can't transform short");
            }
        }

        public int ToInt()
        {
            try
            {
                return int.Parse(Value);
            }
            catch
            {
                throw new Exception("Section : " + Section + ", Key :" + Key + ", " + Value + " can't transform int");
            }
        }

        public uint ToUint()
        {
            try
            {
                return uint.Parse(Value);
            }
            catch
            {
                throw new Exception("Section : " + Section + ", Key :" + Key + ", " + Value + " can't transform uint");
            }
        }


        public long ToLong()
        {
            try
            {
                return long.Parse(Value);
            }
            catch
            {
                throw new Exception("Section : " + Section + ", Key :" + Key + ", " + Value + " can't transform long");
            }
        }

        public ulong ToUlong()
        {
            try
            {
                return ulong.Parse(Value);
            }
            catch
            {
                throw new Exception("Section : " + Section + ", Key :" + Key + ", " + Value + " can't transform ulong");
            }
        }

        public float ToFloat()
        {
            try
            {
                return float.Parse(Value);
            }
            catch
            {
                throw new Exception("Section : " + Section + ", Key :" + Key + ", " + Value + " can't transform float");
            }
        }

        public double ToDouble()
        {
            try
            {
                return double.Parse(Value);
            }
            catch
            {
                throw new Exception("Section : " + Section + ", Key :" + Key + ", " + Value + " can't transform double");
            }
        }

        public override string ToString()
        {
            return Value;
        }

    }
}
