﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Equipment_Control.Database
{
    public class XmlFile : XmlDocument
    {

        public string RootTag { get; private set; }

        public string path { get; private set; }

        public XmlFile()
        {
            RootTag = "ROOT";
        }

        public Xml_Node CreateRoot(string rootName)
        {
            return CreateRoot(rootName, false);
        }

        /// <param name="rootName"></param>
        /// <param name="isDeclaration"></param>
        /// <returns></returns>
        public Xml_Node CreateRoot(string rootName, bool isDeclaration)
        {
            XmlElement rootNode = this.CreateElement(rootName);

            if (isDeclaration)
            {
                XmlDeclaration xmlDeclaration = this.CreateXmlDeclaration("1.0", "utf-8", null);

                this.InsertBefore(xmlDeclaration, this.DocumentElement);
            }

            this.AppendChild(rootNode);
            this.RootTag = rootName;
            return new Xml_Node(rootNode);
        }

        /// <param name="path"></param>
        public override void Load(string path)
        {
            this.path = path;
            base.Load(path);
            this.RootTag = this.DocumentElement.Name;
        }

        /// <param name="Key"></param>
        /// <returns></returns>
        public Xml_Node GetNode(string Key)
        {
            Xml_Node tempDGNode;
            XmlNode tempNode;
            tempNode = this[this.RootTag];
            if (tempNode == null)
            {
                throw new Exception("can not find the xml item: " + RootTag);
            }
            tempNode = tempNode[Key];
            if (tempNode == null)
            {
                throw new Exception("can not find the xml item: " + Key);
            }
            tempDGNode = new Xml_Node(tempNode);
            return tempDGNode;
        }

        /// <param name="Key"></param>
        /// <returns></returns>
        public int GetNodeCount(string Key)
        {
            int iConut = 0;
            for (int i = 0; i < this[this.RootTag].ChildNodes.Count; i++)
            {
                if (Key == this[this.RootTag].ChildNodes[i].Name)
                    iConut++;
            }
            return iConut;
        }

        /// <param name="Node"></param>
        public void AddNode(Xml_Node Node)
        {
            this.DocumentElement.AppendChild(Node.m_node);
        }

        /// <param name="Name"></param>
        public void AddNode(string Name)
        {
            XmlElement xmlBufffer = base.CreateElement(Name);
            this.DocumentElement.AppendChild(xmlBufffer);
        }

        /// <param name="Name"></param>
        /// <param name="Value"></param>
        public void AddNode(string Name, string Value)
        {
            XmlElement xmlBufffer = base.CreateElement(Name);
            xmlBufffer.InnerText = Value;
            this.DocumentElement.AppendChild(xmlBufffer);
        }

        /// <param name="Node"></param>
        public void RemoveNode(Xml_Node Node)
        {
            this.DocumentElement.RemoveChild(Node.m_node);
            Node = null;
        }

        /// <param name="Name"></param>
        public void RemoveFristNode(string Name)
        {
            this.DocumentElement.RemoveChild(this.GetNode(Name).m_node);
        }

        /// <param name="RootTag"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static XmlFile CreatXML(string RootTag, string path)
        {
            XmlFile xmlBuffer = new XmlFile();
            XmlDocument xdoc = new XmlDocument();
            xdoc.AppendChild(xdoc.CreateXmlDeclaration("1.0", "UTF-8", "yes"));
            XmlElement rootElement = xdoc.CreateElement(RootTag);
            xdoc.AppendChild(rootElement);
            xdoc.Save(path);
            xmlBuffer.Load(path);
            return xmlBuffer;
        }

        /// <param name="RootTag"></param>
        /// <returns></returns>
        public static XmlFile CreatXML(string RootTag)
        {
            XmlFile xmlBuffer = new XmlFile();
            XmlDocument xdoc = new XmlDocument();
            xdoc.AppendChild(xdoc.CreateXmlDeclaration("1.0", "UTF-8", "yes"));
            XmlElement rootElement = xdoc.CreateElement(RootTag);
            xdoc.AppendChild(rootElement);
            xmlBuffer.CreateRoot(RootTag);
            return xmlBuffer;
        }
    }
}
