﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using Equipment_Control;
using Equipment_Control.IO_Control;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class Form_Password : Form
    {
        MainGUI _mainGUI;
        public Form_Password(MainGUI mainGUI)
        {
            this._mainGUI = mainGUI;

            InitializeComponent();

            tbPassInput.PasswordChar = '*';
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            CheckPass();
        }

        private void tbPassInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals((char)13))
            {
                CheckPass();
            }
        }

        private void CheckPass()
        {
            if (tbPassInput.Text == "2222")
            {
                _mainGUI.Common.bPassLogin = true;
                this.Close();
            }
            else { this.Close(); }
        }
    }
}
