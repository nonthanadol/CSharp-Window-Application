﻿namespace UI_Common
{
    partial class MainGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainGUI));
            this.panelMain = new System.Windows.Forms.Panel();
            this.btnMain = new System.Windows.Forms.Button();
            this.btnIO = new System.Windows.Forms.Button();
            this.btnSetting = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnEmergency = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnErr_Reset = new System.Windows.Forms.Button();
            this.btnMute = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbRunning_status = new System.Windows.Forms.Label();
            this.lbALM_Status = new System.Windows.Forms.Label();
            this.lbMode_Status = new System.Windows.Forms.Label();
            this.lbBypass_Status = new System.Windows.Forms.Label();
            this.tbRFID_Data = new System.Windows.Forms.TextBox();
            this.btnAuto_Select = new System.Windows.Forms.Button();
            this.btnManual_Select = new System.Windows.Forms.Button();
            this.btnBypass_ON = new System.Windows.Forms.Button();
            this.btnBypass_OFF = new System.Windows.Forms.Button();
            this.timerSec = new System.Windows.Forms.Timer(this.components);
            this.tbTimeCountToPurge = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbAutoPurge_status = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbRFIDBypass_Status = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbMESBypass_Status = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbSafetyDoor_status = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbAreaSensor_status = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbINITIAL_Status = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tbModelNo = new System.Windows.Forms.TextBox();
            this.timer5Sec = new System.Windows.Forms.Timer(this.components);
            this.lbModelshow = new System.Windows.Forms.Label();
            this.btnHistory = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.lbCamOffsetStatus = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.Location = new System.Drawing.Point(9, 12);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1000, 600);
            this.panelMain.TabIndex = 0;
            // 
            // btnMain
            // 
            this.btnMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnMain.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMain.Location = new System.Drawing.Point(499, 635);
            this.btnMain.Name = "btnMain";
            this.btnMain.Size = new System.Drawing.Size(157, 60);
            this.btnMain.TabIndex = 1;
            this.btnMain.Text = "MAIN";
            this.btnMain.UseVisualStyleBackColor = false;
            this.btnMain.Click += new System.EventHandler(this.btnMain_Click);
            // 
            // btnIO
            // 
            this.btnIO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnIO.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIO.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIO.Location = new System.Drawing.Point(662, 635);
            this.btnIO.Name = "btnIO";
            this.btnIO.Size = new System.Drawing.Size(157, 60);
            this.btnIO.TabIndex = 2;
            this.btnIO.Text = "I/O MONITOR";
            this.btnIO.UseVisualStyleBackColor = false;
            this.btnIO.Click += new System.EventHandler(this.btnIO_Click);
            // 
            // btnSetting
            // 
            this.btnSetting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSetting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetting.Location = new System.Drawing.Point(825, 635);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(157, 59);
            this.btnSetting.TabIndex = 3;
            this.btnSetting.Text = "SETTING";
            this.btnSetting.UseVisualStyleBackColor = false;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(9, 618);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1000, 157);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Location = new System.Drawing.Point(1015, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(333, 763);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.LightGray;
            this.btnStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.ForestGreen;
            this.btnStart.Location = new System.Drawing.Point(30, 635);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(90, 60);
            this.btnStart.TabIndex = 6;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            this.btnStart.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnStart_MouseDown);
            this.btnStart.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnStart_MouseUp);
            // 
            // btnStop
            // 
            this.btnStop.BackColor = System.Drawing.Color.LightGray;
            this.btnStop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStop.ForeColor = System.Drawing.Color.Firebrick;
            this.btnStop.Location = new System.Drawing.Point(139, 635);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(90, 60);
            this.btnStop.TabIndex = 7;
            this.btnStop.Text = "STOP";
            this.btnStop.UseVisualStyleBackColor = false;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            this.btnStop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnStop_MouseDown);
            this.btnStop.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnStop_MouseUp);
            // 
            // btnEmergency
            // 
            this.btnEmergency.BackColor = System.Drawing.Color.LightGray;
            this.btnEmergency.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmergency.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmergency.ForeColor = System.Drawing.Color.Red;
            this.btnEmergency.Location = new System.Drawing.Point(248, 706);
            this.btnEmergency.Name = "btnEmergency";
            this.btnEmergency.Size = new System.Drawing.Size(132, 60);
            this.btnEmergency.TabIndex = 8;
            this.btnEmergency.Text = "EMERGENCY STOP";
            this.btnEmergency.UseVisualStyleBackColor = false;
            this.btnEmergency.Click += new System.EventHandler(this.btnEmergency_Click);
            this.btnEmergency.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnEmergency_MouseDown);
            this.btnEmergency.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnEmergency_MouseUp);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.LightGray;
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.Black;
            this.btnHome.Location = new System.Drawing.Point(248, 635);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(90, 60);
            this.btnHome.TabIndex = 9;
            this.btnHome.Text = "INITIAL (HOME)";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            this.btnHome.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnHome_MouseDown);
            this.btnHome.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnHome_MouseUp);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1015, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(333, 40);
            this.label1.TabIndex = 10;
            this.label1.Text = "MACHINE STATUS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnErr_Reset
            // 
            this.btnErr_Reset.BackColor = System.Drawing.Color.LightGray;
            this.btnErr_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnErr_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnErr_Reset.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.btnErr_Reset.Location = new System.Drawing.Point(139, 706);
            this.btnErr_Reset.Name = "btnErr_Reset";
            this.btnErr_Reset.Size = new System.Drawing.Size(90, 60);
            this.btnErr_Reset.TabIndex = 8;
            this.btnErr_Reset.Text = "ERROR RESET";
            this.btnErr_Reset.UseVisualStyleBackColor = false;
            this.btnErr_Reset.Click += new System.EventHandler(this.btnErr_Reset_Click);
            this.btnErr_Reset.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnErr_Reset_MouseDown);
            this.btnErr_Reset.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnErr_Reset_MouseUp);
            // 
            // btnMute
            // 
            this.btnMute.BackColor = System.Drawing.Color.LightGray;
            this.btnMute.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMute.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMute.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnMute.Location = new System.Drawing.Point(30, 706);
            this.btnMute.Name = "btnMute";
            this.btnMute.Size = new System.Drawing.Size(90, 60);
            this.btnMute.TabIndex = 9;
            this.btnMute.Text = "UN-MUTE";
            this.btnMute.UseVisualStyleBackColor = false;
            this.btnMute.Click += new System.EventHandler(this.btnMute_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1026, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "RUNNING STATUS :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1026, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "RUNNING MODE :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1026, 142);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "ALARM STATUS :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1026, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "MACHINE BYPASS :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1026, 310);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "RFID DATA :";
            // 
            // lbRunning_status
            // 
            this.lbRunning_status.AutoSize = true;
            this.lbRunning_status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbRunning_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRunning_status.Location = new System.Drawing.Point(1194, 65);
            this.lbRunning_status.Name = "lbRunning_status";
            this.lbRunning_status.Size = new System.Drawing.Size(78, 32);
            this.lbRunning_status.TabIndex = 12;
            this.lbRunning_status.Text = "RUN";
            // 
            // lbALM_Status
            // 
            this.lbALM_Status.AutoSize = true;
            this.lbALM_Status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbALM_Status.Location = new System.Drawing.Point(1170, 142);
            this.lbALM_Status.Name = "lbALM_Status";
            this.lbALM_Status.Size = new System.Drawing.Size(67, 17);
            this.lbALM_Status.TabIndex = 12;
            this.lbALM_Status.Text = "NORMAL";
            // 
            // lbMode_Status
            // 
            this.lbMode_Status.AutoSize = true;
            this.lbMode_Status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbMode_Status.Location = new System.Drawing.Point(1177, 173);
            this.lbMode_Status.Name = "lbMode_Status";
            this.lbMode_Status.Size = new System.Drawing.Size(92, 17);
            this.lbMode_Status.TabIndex = 12;
            this.lbMode_Status.Text = "AUTO MODE";
            // 
            // lbBypass_Status
            // 
            this.lbBypass_Status.AutoSize = true;
            this.lbBypass_Status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbBypass_Status.Location = new System.Drawing.Point(1189, 240);
            this.lbBypass_Status.Name = "lbBypass_Status";
            this.lbBypass_Status.Size = new System.Drawing.Size(96, 17);
            this.lbBypass_Status.TabIndex = 12;
            this.lbBypass_Status.Text = "NOT BYPASS";
            // 
            // tbRFID_Data
            // 
            this.tbRFID_Data.Location = new System.Drawing.Point(1133, 306);
            this.tbRFID_Data.Name = "tbRFID_Data";
            this.tbRFID_Data.ReadOnly = true;
            this.tbRFID_Data.Size = new System.Drawing.Size(200, 22);
            this.tbRFID_Data.TabIndex = 14;
            this.tbRFID_Data.Text = "ABCDEFGHIJKLMNOPQRST";
            // 
            // btnAuto_Select
            // 
            this.btnAuto_Select.BackColor = System.Drawing.Color.LightGray;
            this.btnAuto_Select.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAuto_Select.Location = new System.Drawing.Point(1029, 197);
            this.btnAuto_Select.Name = "btnAuto_Select";
            this.btnAuto_Select.Size = new System.Drawing.Size(144, 33);
            this.btnAuto_Select.TabIndex = 15;
            this.btnAuto_Select.Text = "AUTO MODE";
            this.btnAuto_Select.UseVisualStyleBackColor = false;
            this.btnAuto_Select.Click += new System.EventHandler(this.btnAuto_Select_Click);
            this.btnAuto_Select.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnAuto_Select_MouseDown);
            this.btnAuto_Select.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnAuto_Select_MouseUp);
            // 
            // btnManual_Select
            // 
            this.btnManual_Select.BackColor = System.Drawing.Color.LightGray;
            this.btnManual_Select.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManual_Select.Location = new System.Drawing.Point(1181, 197);
            this.btnManual_Select.Name = "btnManual_Select";
            this.btnManual_Select.Size = new System.Drawing.Size(144, 33);
            this.btnManual_Select.TabIndex = 15;
            this.btnManual_Select.Text = "MANUAL MODE";
            this.btnManual_Select.UseVisualStyleBackColor = false;
            this.btnManual_Select.Click += new System.EventHandler(this.btnManual_Select_Click);
            this.btnManual_Select.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnManual_Select_MouseDown);
            this.btnManual_Select.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnManual_Select_MouseUp);
            // 
            // btnBypass_ON
            // 
            this.btnBypass_ON.BackColor = System.Drawing.Color.LightGray;
            this.btnBypass_ON.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBypass_ON.Location = new System.Drawing.Point(1029, 264);
            this.btnBypass_ON.Name = "btnBypass_ON";
            this.btnBypass_ON.Size = new System.Drawing.Size(144, 33);
            this.btnBypass_ON.TabIndex = 15;
            this.btnBypass_ON.Text = "BYPASS ON";
            this.btnBypass_ON.UseVisualStyleBackColor = false;
            this.btnBypass_ON.Click += new System.EventHandler(this.btnBypass_ON_Click);
            this.btnBypass_ON.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnBypass_ON_MouseDown);
            this.btnBypass_ON.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnBypass_ON_MouseUp);
            // 
            // btnBypass_OFF
            // 
            this.btnBypass_OFF.BackColor = System.Drawing.Color.LightGray;
            this.btnBypass_OFF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBypass_OFF.Location = new System.Drawing.Point(1181, 264);
            this.btnBypass_OFF.Name = "btnBypass_OFF";
            this.btnBypass_OFF.Size = new System.Drawing.Size(144, 33);
            this.btnBypass_OFF.TabIndex = 15;
            this.btnBypass_OFF.Text = "BYPASS OFF";
            this.btnBypass_OFF.UseVisualStyleBackColor = false;
            this.btnBypass_OFF.Click += new System.EventHandler(this.btnBypass_OFF_Click);
            this.btnBypass_OFF.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnBypass_OFF_MouseDown);
            this.btnBypass_OFF.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnBypass_OFF_MouseUp);
            // 
            // timerSec
            // 
            this.timerSec.Enabled = true;
            this.timerSec.Interval = 1000;
            this.timerSec.Tick += new System.EventHandler(this.timerSec_Tick);
            // 
            // tbTimeCountToPurge
            // 
            this.tbTimeCountToPurge.Location = new System.Drawing.Point(1199, 744);
            this.tbTimeCountToPurge.MaxLength = 2;
            this.tbTimeCountToPurge.Name = "tbTimeCountToPurge";
            this.tbTimeCountToPurge.ReadOnly = true;
            this.tbTimeCountToPurge.Size = new System.Drawing.Size(70, 22);
            this.tbTimeCountToPurge.TabIndex = 55;
            this.tbTimeCountToPurge.Text = "0";
            this.tbTimeCountToPurge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1275, 747);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 17);
            this.label10.TabIndex = 54;
            this.label10.Text = "sec.";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1026, 747);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(167, 17);
            this.label11.TabIndex = 53;
            this.label11.Text = "Time count to auto purge";
            // 
            // lbAutoPurge_status
            // 
            this.lbAutoPurge_status.AutoSize = true;
            this.lbAutoPurge_status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbAutoPurge_status.Location = new System.Drawing.Point(1177, 719);
            this.lbAutoPurge_status.Name = "lbAutoPurge_status";
            this.lbAutoPurge_status.Size = new System.Drawing.Size(104, 17);
            this.lbAutoPurge_status.TabIndex = 57;
            this.lbAutoPurge_status.Text = "Auto Purge ON";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(1026, 719);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(141, 17);
            this.label22.TabIndex = 56;
            this.label22.Text = "Auto Purge function :";
            // 
            // lbRFIDBypass_Status
            // 
            this.lbRFIDBypass_Status.AutoSize = true;
            this.lbRFIDBypass_Status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbRFIDBypass_Status.Location = new System.Drawing.Point(1170, 636);
            this.lbRFIDBypass_Status.Name = "lbRFIDBypass_Status";
            this.lbRFIDBypass_Status.Size = new System.Drawing.Size(96, 17);
            this.lbRFIDBypass_Status.TabIndex = 82;
            this.lbRFIDBypass_Status.Text = "NOT BYPASS";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(1026, 635);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(138, 17);
            this.label21.TabIndex = 81;
            this.label21.Text = "RFID bypass status :";
            // 
            // lbMESBypass_Status
            // 
            this.lbMESBypass_Status.AutoSize = true;
            this.lbMESBypass_Status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbMESBypass_Status.Location = new System.Drawing.Point(1170, 663);
            this.lbMESBypass_Status.Name = "lbMESBypass_Status";
            this.lbMESBypass_Status.Size = new System.Drawing.Size(96, 17);
            this.lbMESBypass_Status.TabIndex = 84;
            this.lbMESBypass_Status.Text = "NOT BYPASS";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(1026, 662);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(136, 17);
            this.label12.TabIndex = 83;
            this.label12.Text = "MES bypass status :";
            // 
            // lbSafetyDoor_status
            // 
            this.lbSafetyDoor_status.AutoSize = true;
            this.lbSafetyDoor_status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbSafetyDoor_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSafetyDoor_status.Location = new System.Drawing.Point(1177, 585);
            this.lbSafetyDoor_status.Name = "lbSafetyDoor_status";
            this.lbSafetyDoor_status.Size = new System.Drawing.Size(108, 17);
            this.lbSafetyDoor_status.TabIndex = 98;
            this.lbSafetyDoor_status.Text = "Safety Door ON";
            this.lbSafetyDoor_status.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(1026, 585);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(145, 17);
            this.label13.TabIndex = 97;
            this.label13.Text = "Safety Door function :";
            this.label13.Visible = false;
            // 
            // lbAreaSensor_status
            // 
            this.lbAreaSensor_status.AutoSize = true;
            this.lbAreaSensor_status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbAreaSensor_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAreaSensor_status.Location = new System.Drawing.Point(1177, 611);
            this.lbAreaSensor_status.Name = "lbAreaSensor_status";
            this.lbAreaSensor_status.Size = new System.Drawing.Size(112, 17);
            this.lbAreaSensor_status.TabIndex = 100;
            this.lbAreaSensor_status.Text = "Area Sensor ON";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(1026, 611);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(147, 17);
            this.label14.TabIndex = 99;
            this.label14.Text = "Area sensor function :";
            // 
            // lbINITIAL_Status
            // 
            this.lbINITIAL_Status.AutoSize = true;
            this.lbINITIAL_Status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbINITIAL_Status.Location = new System.Drawing.Point(1170, 110);
            this.lbINITIAL_Status.Name = "lbINITIAL_Status";
            this.lbINITIAL_Status.Size = new System.Drawing.Size(119, 17);
            this.lbINITIAL_Status.TabIndex = 12;
            this.lbINITIAL_Status.Text = "INITIAL FINISHED";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(1026, 110);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(136, 17);
            this.label16.TabIndex = 13;
            this.label16.Text = "INITIAL STATUS :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(1026, 565);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(133, 17);
            this.label15.TabIndex = 101;
            this.label15.Text = "OPTION STATUS";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(1026, 542);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(141, 17);
            this.label17.TabIndex = 103;
            this.label17.Text = "MODEL SELECT : ";
            // 
            // tbModelNo
            // 
            this.tbModelNo.Location = new System.Drawing.Point(1173, 539);
            this.tbModelNo.Name = "tbModelNo";
            this.tbModelNo.ReadOnly = true;
            this.tbModelNo.Size = new System.Drawing.Size(42, 22);
            this.tbModelNo.TabIndex = 104;
            this.tbModelNo.Text = "0";
            this.tbModelNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timer5Sec
            // 
            this.timer5Sec.Enabled = true;
            this.timer5Sec.Interval = 5000;
            this.timer5Sec.Tick += new System.EventHandler(this.timer5Sec_Tick);
            // 
            // lbModelshow
            // 
            this.lbModelshow.AutoSize = true;
            this.lbModelshow.BackColor = System.Drawing.Color.White;
            this.lbModelshow.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbModelshow.ForeColor = System.Drawing.Color.Red;
            this.lbModelshow.Location = new System.Drawing.Point(1228, 540);
            this.lbModelshow.Name = "lbModelshow";
            this.lbModelshow.Size = new System.Drawing.Size(59, 20);
            this.lbModelshow.TabIndex = 105;
            this.lbModelshow.Text = "Model";
            // 
            // btnHistory
            // 
            this.btnHistory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnHistory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHistory.Location = new System.Drawing.Point(499, 701);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(157, 60);
            this.btnHistory.TabIndex = 106;
            this.btnHistory.Text = "ERROR HISTORY";
            this.btnHistory.UseVisualStyleBackColor = false;
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(1026, 690);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 17);
            this.label7.TabIndex = 108;
            this.label7.Text = "Camera offset function :";
            // 
            // lbCamOffsetStatus
            // 
            this.lbCamOffsetStatus.AutoSize = true;
            this.lbCamOffsetStatus.BackColor = System.Drawing.Color.PaleGreen;
            this.lbCamOffsetStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCamOffsetStatus.Location = new System.Drawing.Point(1190, 690);
            this.lbCamOffsetStatus.Name = "lbCamOffsetStatus";
            this.lbCamOffsetStatus.Size = new System.Drawing.Size(122, 17);
            this.lbCamOffsetStatus.TabIndex = 109;
            this.lbCamOffsetStatus.Text = "Position offset ON";
            // 
            // MainGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1358, 787);
            this.Controls.Add(this.lbCamOffsetStatus);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnHistory);
            this.Controls.Add(this.lbModelshow);
            this.Controls.Add(this.tbModelNo);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.lbAreaSensor_status);
            this.Controls.Add(this.lbMESBypass_Status);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lbSafetyDoor_status);
            this.Controls.Add(this.lbRFIDBypass_Status);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.lbAutoPurge_status);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.tbTimeCountToPurge);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnBypass_OFF);
            this.Controls.Add(this.btnManual_Select);
            this.Controls.Add(this.btnBypass_ON);
            this.Controls.Add(this.btnAuto_Select);
            this.Controls.Add(this.tbRFID_Data);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbINITIAL_Status);
            this.Controls.Add(this.lbALM_Status);
            this.Controls.Add(this.lbBypass_Status);
            this.Controls.Add(this.lbMode_Status);
            this.Controls.Add(this.lbRunning_status);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnMute);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnErr_Reset);
            this.Controls.Add(this.btnEmergency);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnMain);
            this.Controls.Add(this.btnSetting);
            this.Controls.Add(this.btnIO);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainGUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OBGI_AutoGlue_MC1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainGUI_FormClosing);
            this.Load += new System.EventHandler(this.MainGUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Button btnMain;
        private System.Windows.Forms.Button btnIO;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnEmergency;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnErr_Reset;
        private System.Windows.Forms.Button btnMute;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbRunning_status;
        private System.Windows.Forms.Label lbALM_Status;
        private System.Windows.Forms.Label lbMode_Status;
        private System.Windows.Forms.Label lbBypass_Status;
        private System.Windows.Forms.TextBox tbRFID_Data;
        private System.Windows.Forms.Button btnAuto_Select;
        private System.Windows.Forms.Button btnManual_Select;
        private System.Windows.Forms.Button btnBypass_ON;
        private System.Windows.Forms.Button btnBypass_OFF;
        protected System.Windows.Forms.Timer timerSec;
        private System.Windows.Forms.TextBox tbTimeCountToPurge;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbAutoPurge_status;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbRFIDBypass_Status;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbMESBypass_Status;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbSafetyDoor_status;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbAreaSensor_status;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbINITIAL_Status;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbModelNo;
        protected System.Windows.Forms.Timer timer5Sec;
        private System.Windows.Forms.Label lbModelshow;
        private System.Windows.Forms.Button btnHistory;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbCamOffsetStatus;
    }
}

