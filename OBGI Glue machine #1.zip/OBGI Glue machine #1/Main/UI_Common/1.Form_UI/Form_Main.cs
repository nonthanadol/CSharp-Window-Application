﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using Equipment_Control;
using Equipment_Control.IO_Control;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.Interface;
using Equipment_Control.RFID;


namespace UI_Common
{
    public partial class MainGUI : Form
    {
        internal IVariableShare Common;
        internal XYZ_Motion _AG;
        internal RFID_Control _RFID;

        String sql;

        SqlConnection Conn;

        private System.Windows.Forms.Timer UIUpdatetime = null;
        public MainGUI(IVariableShare Common, XYZ_Motion AG, RFID_Control RFID)
        {
            InitializeComponent();

            this.Common = Common;
            this._AG = AG;
            this._RFID = RFID;

            panelMain.Controls.Add(new ucMain(this));
            panelMain.Controls.Add(new ucIOmonitor(this));
            panelMain.Controls.Add(new ucIOmonitor_2(this));
            panelMain.Controls.Add(new ucSetting(this));
            panelMain.Controls.Add(new ucErrorHistory(this));
            panelMain.Controls.Add(new ucModelSelect(this));
            panelMain.Controls.Add(new ucXYZControls(this, _AG));
            panelMain.Controls.Add(new ucEquipmentControls(this));
            panelMain.Controls.Add(new ucSignalSafety(this));
            panelMain.Controls.Add(new ucPQM(this));
            panelMain.Controls.Add(new ucRFIDMes(this, _RFID));
            panelMain.Controls.Add(new ucCalibration(this, _AG));
            panelMain.Controls.Add(new ucSpeedDelay_M1(this));

            UIUpdatetime = new System.Windows.Forms.Timer();
            UIUpdatetime.Interval = 100;
        }

        private void MainGUI_Load(object sender, EventArgs e)
        {
            foreach (Control item in panelMain.Controls)
            {
                if (item is ucMain)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }

            #region First set
            btnMute.BackColor = Color.LightGray;
            btnMute.ForeColor = Color.RoyalBlue;
            btnMute.Text = "UN-MUTE";
            Common.bChkMuteButtonPush = false;
            lbMode_Status.BackColor = Color.PaleGoldenrod;
            lbMode_Status.Text = "MANAUL MODE";
            Common.bChkAuto_Manual = false;
            lbBypass_Status.BackColor = Color.PaleGreen;
            lbBypass_Status.Text = "NOT BYPASS";
            Common.bChkMC_Bypass = false;
            lbINITIAL_Status.BackColor = Color.LightCoral;
            lbINITIAL_Status.Text = "NOT INITIAL";
            Common.bFlgInitial_Finished = false;
            lbRunning_status.BackColor = Color.LightCoral;
            lbRunning_status.Text = "STOP";
            Common.bChkMC_RUN_STOP = false;
            lbALM_Status.BackColor = Color.PaleGreen;
            lbALM_Status.Text = "NORMAL";
            Common.bChkAlarm = false;

            btnStop.BackColor = Color.LightCoral;
            btnStop.ForeColor = Color.Black;

            CallPQM_Data();
            Thread.Sleep(1000);
            Call_Z_at_PCB_Base();
            Call_Z_Safety();
            Thread.Sleep(1000);
            Call_Z_at_PCB_Base();
            Call_Z_Safety();

            #endregion

            this.UIUpdatetime.Tick += new EventHandler(UiUpdate_Tick);
            this.UIUpdatetime.Interval = 50;
            this.UIUpdatetime.Enabled = true;
        }

        private void UiUpdate_Tick(object sender, EventArgs e)
        {
            foreach (object item in panelMain.Controls)
            {
                if (item is IUpdateUI)
                    ((IUpdateUI)item).UpdateUI();
            }

            #region UI status & mode update
            if (Common.bChkMC_RUN_STOP) 
            {
                if (!Common.bChkAlarm)
                {
                    //Common.IOTable.DO[0, 10].Reset();//Reset red light
                    //Common.IOTable.DO[0, 11].Reset();//Reset Yellow light
                    //Common.IOTable.DO[0, 12].Set();//Set Green light
                    Common.IOTable.DO[0, 14].Set();//Start switch light on
                    btnManual_Select.Enabled = false;
                }
            }
                
            else
            {
                if (!Common.bChkAlarm)
                {
                    Common.IOTable.DO[0, 10].Reset();//Reset red light
                    Common.IOTable.DO[0, 11].Set();//Set Yellow light
                    Common.IOTable.DO[0, 12].Reset();//Reset Green light
                    Common.IOTable.DO[0, 14].Reset();//Start switch light off
                    btnManual_Select.Enabled = true;
                }                
            }

            if(Common.IOTable.DI[0, 14].State) //Push SW start
            {
                if (Common.bChkAuto_Manual && Common.bFlgInitial_Finished)
                {
                    lbRunning_status.BackColor = Color.PaleGreen;
                    lbRunning_status.Text = "RUN";
                    Common.bChkMC_RUN_STOP = true;

                    btnStart.BackColor = Color.PaleGreen;
                    btnStart.ForeColor = Color.Black;

                    btnStop.BackColor = Color.LightGray;
                    btnStop.ForeColor = Color.Firebrick;
                }
            }

            if (Common.IOTable.DI[0, 15].State) //Push SW Pause
            {
                if (!Common.bChkPauseButtonPush) { Common.bChkPauseButtonPush = true; Common.IOTable.DO[0, 15].Set(); }
                else { Common.bChkPauseButtonPush = false; Common.IOTable.DO[0, 15].Reset(); }
                while(Common.IOTable.DI[0, 15].State) { if (!Common.IOTable.DI[0, 15].State) { break; } }
            }

            if (Common.bChkAuto_Manual) 
            { 
                btnSetting.Enabled = false; 
            }
            else 
            { 
                btnSetting.Enabled = true; 
            }

            if (Common.bFlgAutoPurge_onWork)
            {
                lbRunning_status.BackColor = Color.Gold;
                lbRunning_status.Text = "PURGE";
            }

            if (Common.bChkAuto_Manual && Common.bFlgInitial_Finished && Common.bChkMC_RUN_STOP && !Common.bFlgAutoPurge_onWork)
            {
                lbRunning_status.BackColor = Color.PaleGreen;
                lbRunning_status.Text = "RUN";
            }

            if (Common.bChkAlarm)
            {
                lbALM_Status.BackColor = Color.Crimson;
                lbALM_Status.Text = "ALARM";

                lbRunning_status.BackColor = Color.LightCoral;
                lbRunning_status.Text = "STOP";
                Common.bChkMC_RUN_STOP = false;

                btnStop.BackColor = Color.LightCoral;
                btnStop.ForeColor = Color.Black;

                btnStart.BackColor = Color.LightGray;
                btnStart.ForeColor = Color.ForestGreen;

            }
            else
            {
                lbALM_Status.BackColor = Color.PaleGreen;
                lbALM_Status.Text = "NORMAL";                
            }

            if (Common.bFlgInitial_onWork)
            {
                btnManual_Select.Enabled = false;
                btnStart.Enabled = false;
                btnHome.Enabled = false;
            }
            else
            {
                btnManual_Select.Enabled = true;
                btnStart.Enabled = true;
                btnHome.Enabled = true;
            }

            if (Common.bChkSafetyDoor)
            {
                lbSafetyDoor_status.BackColor = Color.PaleGreen;
                lbSafetyDoor_status.Text = "Safety Door ON";
            }
            else
            {
                lbSafetyDoor_status.BackColor = Color.Crimson;
                lbSafetyDoor_status.Text = "Safety Door OFF";
            }

            if (Common.bChkAreaSensor)
            {
                lbAreaSensor_status.BackColor = Color.PaleGreen;
                lbAreaSensor_status.Text = "Area Sensor ON";
            }
            else
            {
                lbAreaSensor_status.BackColor = Color.Crimson;
                lbAreaSensor_status.Text = "Area Sensor OFF";
            }

            if (Common.bChkRFID_BYPASS) 
            {
                lbRFIDBypass_Status.BackColor = Color.Crimson;
                lbRFIDBypass_Status.Text = "BYPASS";
            }
            else 
            {
                lbRFIDBypass_Status.BackColor = Color.PaleGreen;
                lbRFIDBypass_Status.Text = "NOT BYPASS";                
            }

            if (Common.bChkMES_BYPASS)
            {
                lbMESBypass_Status.BackColor = Color.Crimson;
                lbMESBypass_Status.Text = "BYPASS";
            }
            else
            {
                lbMESBypass_Status.BackColor = Color.PaleGreen;
                lbMESBypass_Status.Text = "NOT BYPASS";                
            }

            if (Common.bChkCemeraOffset)
            {
                lbCamOffsetStatus.BackColor = Color.PaleGreen;
                lbCamOffsetStatus.Text = "Position Offset ON";
            }
            else
            {
                lbCamOffsetStatus.BackColor = Color.Crimson;
                lbCamOffsetStatus.Text = "Position Offset OFF";
            }

            if (Common.bChkAutoPurge) 
            {
                lbAutoPurge_status.BackColor = Color.PaleGreen;
                lbAutoPurge_status.Text = "Auto Purge ON";
            }
            else
            {
                lbAutoPurge_status.BackColor = Color.Crimson;
                lbAutoPurge_status.Text = "Auto Purge OFF";
            }

            if (Common.bFlgInitial_Finished)
            {
                lbINITIAL_Status.BackColor = Color.PaleGreen;
                lbINITIAL_Status.Text = "INITIAL FINISHED";
            }
            else
            {
                lbINITIAL_Status.BackColor = Color.LightCoral;
                lbINITIAL_Status.Text = "NOT INITIAL";
            }

            tbTimeCountToPurge.Text = Common.iPurgeTimeCount.ToString();
            #endregion

            tbModelNo.Text = Convert.ToString(Common.iModelSelect);
            if (Common.iModelSelect == 1) { lbModelshow.Text = "BUSCAP"; }
            //else if (Common.iModelSelect == 2) { lbModelshow.Text = "IPE"; }
            else { lbModelshow.Text = ""; }

            tbRFID_Data.Text = Common.RFID_Read_Data;
            //Code her for alway update on UI            

        }


        #region Select AUTO/MANUAL MODE
        private void btnAuto_Select_Click(object sender, EventArgs e)
        {
            if(!Common.bChkAlarm)
            {
                foreach (Control item in panelMain.Controls)
                {
                    if (item is ucMain)
                    {
                        item.Visible = true;
                    }
                    else
                    {
                        item.Visible = false;
                    }
                }

                lbMode_Status.BackColor = Color.PaleGreen;
                lbMode_Status.Text = "AUTO MODE";
                Common.bChkAuto_Manual = true;
            }            
        }
        private void btnManual_Select_Click(object sender, EventArgs e)
        {
            if (!Common.bChkMC_RUN_STOP)
            {
                lbMode_Status.BackColor = Color.PaleGoldenrod;
                lbMode_Status.Text = "MANAUL MODE";
                Common.bChkAuto_Manual = false;
            }
        }
        #endregion
        #region Select BYPASS MODE
        private void btnBypass_ON_Click(object sender, EventArgs e)
        {
            lbBypass_Status.BackColor = Color.Crimson;
            lbBypass_Status.Text = "BYPASS";
            Common.bChkMC_Bypass = true;
        }
        private void btnBypass_OFF_Click(object sender, EventArgs e)
        {
            lbBypass_Status.BackColor = Color.PaleGreen;
            lbBypass_Status.Text = "NOT BYPASS";
            Common.bChkMC_Bypass = false;
        }
        #endregion
        #region MOUSE UP/DOWN EVENT
        private void btnStart_MouseDown(object sender, MouseEventArgs e)
        {
            //btnStart.BackColor = Color.PaleGreen;
            //btnStart.ForeColor = Color.Black;
        }

        private void btnStart_MouseUp(object sender, MouseEventArgs e)
        {
            //btnStart.BackColor = Color.LightGray;
            //btnStart.ForeColor = Color.ForestGreen;
        }

        private void btnStop_MouseDown(object sender, MouseEventArgs e)
        {
            //btnStop.BackColor = Color.LightCoral;
            //btnStop.ForeColor = Color.Black;
        }

        private void btnStop_MouseUp(object sender, MouseEventArgs e)
        {
            //btnStop.BackColor = Color.LightGray;
            //btnStop.ForeColor = Color.Firebrick;
        }

        private void btnEmergency_MouseDown(object sender, MouseEventArgs e)
        {
            btnEmergency.BackColor = Color.Red;
            btnEmergency.ForeColor = Color.Black;
        }

        private void btnEmergency_MouseUp(object sender, MouseEventArgs e)
        {
            btnEmergency.BackColor = Color.LightGray;
            btnEmergency.ForeColor = Color.Red;
        }

        private void btnHome_MouseDown(object sender, MouseEventArgs e)
        {
            btnHome.BackColor = Color.White;
            btnHome.ForeColor = Color.Black;
        }

        private void btnHome_MouseUp(object sender, MouseEventArgs e)
        {
            btnHome.BackColor = Color.LightGray;
            btnHome.ForeColor = Color.Black;
        }

        private void btnErr_Reset_MouseDown(object sender, MouseEventArgs e)
        {
            btnErr_Reset.BackColor = Color.LemonChiffon;
            btnErr_Reset.ForeColor = Color.Black;
        }

        private void btnErr_Reset_MouseUp(object sender, MouseEventArgs e)
        {
            btnErr_Reset.BackColor = Color.LightGray;
            btnErr_Reset.ForeColor = Color.DarkGoldenrod;
        }
        
        private void btnAuto_Select_MouseDown(object sender, MouseEventArgs e)
        {
            btnAuto_Select.BackColor = Color.LightCoral;
        }

        private void btnAuto_Select_MouseUp(object sender, MouseEventArgs e)
        {
            btnAuto_Select.BackColor = Color.LightGray;
        }

        private void btnManual_Select_MouseDown(object sender, MouseEventArgs e)
        {
            btnManual_Select.BackColor = Color.LightCoral;
        }

        private void btnManual_Select_MouseUp(object sender, MouseEventArgs e)
        {
            btnManual_Select.BackColor = Color.LightGray;
        }

        private void btnBypass_ON_MouseDown(object sender, MouseEventArgs e)
        {
            btnBypass_ON.BackColor = Color.LightCoral;
        }

        private void btnBypass_ON_MouseUp(object sender, MouseEventArgs e)
        {
            btnBypass_ON.BackColor = Color.LightGray;
        }

        private void btnBypass_OFF_MouseDown(object sender, MouseEventArgs e)
        {
            btnBypass_OFF.BackColor = Color.LightCoral;
        }

        private void btnBypass_OFF_MouseUp(object sender, MouseEventArgs e)
        {
            btnBypass_OFF.BackColor = Color.LightGray;
        }
        #endregion
        #region MOUSE CLICK EVENT
        private void btnMain_Click(object sender, EventArgs e)
        {
            foreach (Control item in panelMain.Controls)
            {
                if (item is ucMain)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }
        private void btnIO_Click(object sender, EventArgs e)
        {
            foreach (Control item in panelMain.Controls)
            {
                if (item is ucIOmonitor)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }
        private void btnSetting_Click(object sender, EventArgs e)
        {
            foreach (Control item in panelMain.Controls)
            {
                if (item is ucSetting)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }
        private void btnHistory_Click(object sender, EventArgs e)
        {
            foreach (Control item in panelMain.Controls)
            {
                if (item is ucErrorHistory)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }
        private void timerSec_Tick(object sender, EventArgs e)
        {
            //Input condition time count. tbTimeCountToPurge
            if (Common.bChkAutoPurge && !Common.bChkPauseButtonPush)
            {
                if (Common.bChkMC_RUN_STOP && (!Common.bFlgInitial_onWork && !Common.bFlgAutoRun_onWork))
                {
                    Common.iPurgeTimeCount++;
                }
            }
            else { Common.iPurgeTimeCount = 0; }

            if (Common.bChkAlarm) { Common.iPQM_Error_Time++; }
            else { Common.iPQM_Error_Time = 0; }

            if (Common.bFlgAutoRun_onWork) { Common.iPQM_Cycle_Time++; Common.iPQM_Waiting_Time = 0; }
            else { Common.iPQM_Waiting_Time++; }

            Common.iPQM_Running_Time++;

            #region LifeTime Servo X, Y1, Y2, Z Axis
            Common.iComponent_6_Usage++;
            Common.Config.WriteValue("LifeTime", "Component_6_Usage ", Convert.ToString(Common.iComponent_6_Usage));

            Common.iComponent_7_Usage++;
            Common.Config.WriteValue("LifeTime", "Component_7_Usage ", Convert.ToString(Common.iComponent_7_Usage));

            Common.iComponent_8_Usage++;
            Common.Config.WriteValue("LifeTime", "Component_8_Usage ", Convert.ToString(Common.iComponent_8_Usage));

            Common.iComponent_9_Usage++;
            Common.Config.WriteValue("LifeTime", "Component_9_Usage ", Convert.ToString(Common.iComponent_9_Usage));
            #endregion

        }
        private void timer5Sec_Tick(object sender, EventArgs e)
        {
            PQM_Save_RunningTime();

            if (!Common.bChkPQM_BYPASS && !Common.bPQMFail)
            {
                Common.PQM.Send(); //Update PQM
            }
        }


        private void btnStart_Click(object sender, EventArgs e)
        {
            if (Common.bChkAuto_Manual && Common.bFlgInitial_Finished)
            {
                lbRunning_status.BackColor = Color.PaleGreen;
                lbRunning_status.Text = "RUN";
                Common.bChkMC_RUN_STOP = true;

                btnStart.BackColor = Color.PaleGreen;
                btnStart.ForeColor = Color.Black;

                btnStop.BackColor = Color.LightGray;
                btnStop.ForeColor = Color.Firebrick;
            }
        }
        private void btnStop_Click(object sender, EventArgs e)
        {
            if (Common.bChkMC_RUN_STOP)
            {
                DialogResult re = MessageBox.Show("Confirm to STOP Machine running?", "STOP Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                if (re == DialogResult.Yes)
                {
                    if (Common.bFlgAutoRun_onWork)
                    {
                        _AG.X1_AXIS.Machine_Error_ClearBitStatus();
                        _AG.Y1_AXIS.Machine_Error_ClearBitStatus();
                        _AG.Y2_AXIS.Machine_Error_ClearBitStatus();
                        _AG.Z1_AXIS.Machine_Error_ClearBitStatus();
                        _AG.Y_Sync_Axis.Machine_Error_ClearBitStatus();
                        _AG.XY_Multi.Machine_Error_ClearBitStatus();
                        _AG.XYZ_MotionBuffer.Machine_Error_ClearBitStatus();
                        _AG.X1_AXIS.EStop();
                        _AG.Y1_AXIS.EStop();
                        _AG.Y2_AXIS.EStop();
                        _AG.Z1_AXIS.EStop();
                        Common.IOTable.DO[0, 0].Reset(); //Reset Glue purge wait edit

                        Common.bFlgInitial_Finished = false;
                    }

                    Common.bFlgAutoRun_onWork = false;
                    Common.iAutoRunFlow_Step = 0;
                    Common.iAutoPurgeFlow_Step = 0;
                    Common.bFlgTrigApplyGlue = false;
                    Common.bFlgAutoFlowTrigApplyGlue = false;
                    Common.iTrigPositionApplyGlue = 0;
                    Common.bSkipApplyGlue = false;
                    Common.bApplyGluePointFinished = false;
                    Common.bChkFirstAuto = false;

                    Common.IOTable.DO[2, 8].Reset();//OFF Upper receive in from before
                    Common.IOTable.DO[2, 12].Reset();//OFF Under receive in from before

                    Common.IOTable.DO[1, 5].Reset();//Conveyer Upper CW OFF
                    Common.IOTable.DO[1, 12].Reset();//CConveyer Under CCW OFF

                    lbRunning_status.BackColor = Color.LightCoral;
                    lbRunning_status.Text = "STOP";
                    Common.bChkMC_RUN_STOP = false;

                    btnStop.BackColor = Color.LightCoral;
                    btnStop.ForeColor = Color.Black;

                    btnStart.BackColor = Color.LightGray;
                    btnStart.ForeColor = Color.ForestGreen;

                }
            }
        }
        private void btnEmergency_Click(object sender, EventArgs e)
        {
            Common.bEmerOnScreen = true;
        }
        private void btnHome_Click(object sender, EventArgs e)
        {
            Common.bChkInitialButtonPush = true;
        }
        private void btnErr_Reset_Click(object sender, EventArgs e)
        {
            Common.bChkErrorResetButtonPush = true;
            Thread.Sleep(300);
        }
        private void btnMute_Click(object sender, EventArgs e)
        {
            if (Common.bChkMuteButtonPush) 
            {
                btnMute.BackColor = Color.LightGray;
                btnMute.ForeColor = Color.RoyalBlue;
                btnMute.Text = "UN-MUTE";
                Common.bChkMuteButtonPush = false;
            }
            else
            {
                btnMute.BackColor = Color.SkyBlue;
                btnMute.ForeColor = Color.Black;
                btnMute.Text = "MUTE";
                Common.bChkMuteButtonPush = true;
            }
        }
        #endregion
        
        
        private void MainGUI_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Coding for Servo OFF or anything need to OFF before closing UI window.

            Common.IOTable.DO[0, 4].Reset(); //Reset Glue purge

            _AG.X1_AXIS.Machine_Error_ClearBitStatus();
            _AG.Y1_AXIS.Machine_Error_ClearBitStatus();
            _AG.Y2_AXIS.Machine_Error_ClearBitStatus();
            _AG.Z1_AXIS.Machine_Error_ClearBitStatus();
            _AG.RZ_AXIS.Machine_Error_ClearBitStatus();
            _AG.Y_Sync_Axis.Machine_Error_ClearBitStatus();
            _AG.XY_Multi.Machine_Error_ClearBitStatus();
            _AG.XYZ_MotionBuffer.Machine_Error_ClearBitStatus();

            _AG.X1_AXIS.ClearAlarm();
            _AG.Y1_AXIS.ClearAlarm();
            _AG.Y2_AXIS.ClearAlarm();
            _AG.Z1_AXIS.ClearAlarm();
            _AG.RZ_AXIS.ClearAlarm();

            Common.IOTable.DO[0, 10].Reset();//Reset red light
            Common.IOTable.DO[0, 11].Reset();//Reset Yellow light
            Common.IOTable.DO[0, 12].Reset();//Reset Green light
            Common.IOTable.DO[0, 14].Reset();//Start switch light off
            Common.IOTable.DO[0, 15].Reset();//Pause switch light off

            Common.X1_AXIS.Close();
            Common.Y1_AXIS.Close();
            Common.Y2_AXIS.Close();
            Common.Z1_AXIS.Close();
            Common.RZ_AXIS.Close();
            Common.card.Close();
            
            System.Environment.Exit(0);
        }

        public void CallPQM_Data()
        {
            Common.iModelSelect = Convert.ToInt16(Common.Config.ReadValue("OptionSelect", "ModelSelect").ToString());

            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            sql = "SELECT * FROM dbo.PQM_Data_View WHERE ID = '" + "1" + "';";

            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    Common.iPQM_PassQty = SQLRead.GetInt32(1);
                    Common.iPQM_FailQty = SQLRead.GetInt32(2);
                    Common.iPQM_Error_Count = SQLRead.GetInt32(3);
                    Common.iPQM_Running_Time = SQLRead.GetInt32(4);
                    Common.iPQM_InputQty = SQLRead.GetInt32(5);
                }
            }
        }

        public void Call_Z_Safety()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            if (Common.iModelSelect == 1)
            {
                sql = "SELECT * FROM dbo.XYZ_Position_View WHERE STEP = '" + "ZS1_1" + "';";
            }
            else
            {
                sql = "SELECT * FROM dbo.XYZ_Position_M2_View WHERE STEP = '" + "ZS1_1" + "';";
            }
            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    Common.iMem_Z_Safety_Pos = SQLRead.GetInt32(5);
                }
            }
        }

        public void Call_Z_at_PCB_Base()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();
            if (Common.iModelSelect == 1)
            {
                sql = "SELECT * FROM dbo.XYZ_Position_View WHERE STEP = '" + "P1_1" + "';";
            }
            else
            {
                sql = "SELECT * FROM dbo.XYZ_Position_M2_View WHERE STEP = '" + "P1_1" + "';";
            }
            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    Common.iMem_Z_PCBBase_Pos = SQLRead.GetInt32(5);
                }
            }
        }

        public void PQM_Save_RunningTime()
        {
            Conn = new SqlConnection(Common.Connection_String);
            Conn.Open();

            sql = "UPDATE dbo.PQM_Data SET Running_Time = " + Common.iPQM_Running_Time + " WHERE ID = '" + "1" + "';";
            using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
        }

    }
}
