﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucXYZControls : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        XYZ_Motion _ApplyGlue;

        SqlConnection Conn;

        string strStepRead;
        int iPos;
        int iStep;

        int iXJogSpeed = 0;
        int iYJogSpeed = 0;
        int iZJogSpeed = 0;
        int iRZJogSpeed = 0;
        int iSpeedVerySlow = 2000;
        int iSpeedSlow = 4000;
        int iSpeedNormal = 8000;
        int iSpeedFast = 16000;

        int X_Axis_Value;
        int Y_Axis_Value;
        int Z_Axis_Value;
        int RZ_Axis_Value;

        bool bMouseUpStop;

        private float fX1current_pos;
        private float fY1current_pos;
        private float fZ1current_pos;
        private float fRZcurrent_pos;

        private float fX1Save_pos;
        private float fY1Save_pos;
        private float fZ1Save_pos;
        private float fRZSave_pos;

        String sql;

        private string formatStr = "0.000";

        public ucXYZControls(MainGUI mainGUI, XYZ_Motion applyGlue)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;
            this._ApplyGlue = applyGlue;

            #region Add data default UI
            cbPosition.Items.Add("Home");
            cbPosition.Items.Add("Glue Cut T1");
            //cbPosition.Items.Add("Glue Purge");
            cbPosition.Items.Add("Camera");
            cbPosition.Items.Add("Calibration Tools 1");
            //cbPosition.Items.Add("Calibration Tools 2");
            //cbPosition.Items.Add("Tools Change-1");
            //cbPosition.Items.Add("Tools Change-2");
            cbPosition.Items.Add("Z Safety T1");
            //cbPosition.Items.Add("Z Safety T2");
            cbPosition.Items.Add("Point-1");
            cbPosition.Items.Add("Point-2");
            cbPosition.Items.Add("Point-3");
            cbPosition.Items.Add("Point-4");
            cbPosition.Items.Add("Point-5");
            cbPosition.Items.Add("Point-6");
            cbPosition.Items.Add("Point-7");
            cbPosition.Items.Add("Point-8");
            cbPosition.Items.Add("Point-9");
            cbPosition.Items.Add("Point-10");

            cbPosition.SelectedItem = "Home";

            if (cbPosition.Text == "Home") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            else if (cbPosition.Text == "Glue Cut T1") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }
            else if (cbPosition.Text == "Glue Purge") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            else if (cbPosition.Text == "Camera") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            else if (cbPosition.Text == "Calibration Tools 1") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            //else if (cbPosition.Text == "Calibration Tools 2") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            //else if (cbPosition.Text == "Tools Change-1") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); cbStep.Items.Add("3"); }
            //else if (cbPosition.Text == "Tools Change-2") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); cbStep.Items.Add("3"); }
            else if (cbPosition.Text == "Z Safety T1") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            //else if (cbPosition.Text == "Z Safety T2") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            else
            {
                cbStep.Items.Clear();
                cbStep.Items.Add("1");
                cbStep.Items.Add("2");
                cbStep.Items.Add("3");
                cbStep.Items.Add("4");
                cbStep.Items.Add("5");
                cbStep.Items.Add("6");
                cbStep.Items.Add("7");
                cbStep.Items.Add("8");
                cbStep.Items.Add("9");
                cbStep.Items.Add("10");
                cbStep.Items.Add("11");
                cbStep.Items.Add("12");
                cbStep.Items.Add("13");
                cbStep.Items.Add("14");
                cbStep.Items.Add("15");
                cbStep.Items.Add("16");
                cbStep.Items.Add("17");
                cbStep.Items.Add("18");
                cbStep.Items.Add("19");
                cbStep.Items.Add("20");
            }

            cbStep.SelectedItem = "1";

            cbJogXSpeed.Items.Add("Very Slow");
            cbJogXSpeed.Items.Add("Slow");
            cbJogXSpeed.Items.Add("Normal");
            cbJogXSpeed.Items.Add("Fast");
            cbJogYSpeed.Items.Add("Very Slow");
            cbJogYSpeed.Items.Add("Slow");
            cbJogYSpeed.Items.Add("Normal");
            cbJogYSpeed.Items.Add("Fast");
            cbJogZSpeed.Items.Add("Very Slow");
            cbJogZSpeed.Items.Add("Slow");
            cbJogZSpeed.Items.Add("Normal");
            cbJogZSpeed.Items.Add("Fast");
            cbJogRZSpeed.Items.Add("Very Slow");
            cbJogRZSpeed.Items.Add("Slow");
            cbJogRZSpeed.Items.Add("Normal");
            cbJogRZSpeed.Items.Add("Fast");

            cbJogXSpeed.SelectedItem = "Slow";
            cbJogYSpeed.SelectedItem = "Slow";
            cbJogZSpeed.SelectedItem = "Slow";
            cbJogRZSpeed.SelectedItem = "Slow";

            tbCurrentXaxis.Text = "X value";
            tbCurrentYaxis.Text = "Y value";
            tbCurrentZaxis.Text = "Z value";
            tbCurrentZaxis.Text = "RZ value";

            tbManualXaxis.Text = "0";
            tbManualYaxis.Text = "0";
            tbManualZaxis.Text = "0";
            tbManualRZaxis.Text = "0";

            #endregion
            #region Add Mouse Event
            btnJogX_plus.MouseDown += BtnJogX_plus_MouseDown;
            btnJogX_plus.MouseUp += BtnJogX_plus_MouseUp;
            btnJogX_minus.MouseDown += BtnJogX_minus_MouseDown;
            btnJogX_minus.MouseUp += BtnJogX_minus_MouseUp;
            btnJogY_plus.MouseDown += BtnJogY_plus_MouseDown;
            btnJogY_plus.MouseUp += BtnJogY_plus_MouseUp;
            btnJogY_minus.MouseDown += BtnJogY_minus_MouseDown;
            btnJogY_minus.MouseUp += BtnJogY_minus_MouseUp;
            btnJogZ_plus.MouseDown += BtnJogZ_plus_MouseDown;
            btnJogZ_plus.MouseUp += BtnJogZ_plus_MouseUp;
            btnJogZ_minus.MouseDown += BtnJogZ_minus_MouseDown;
            btnJogZ_minus.MouseUp += BtnJogZ_minus_MouseUp;
            btnJogRZ_plus.MouseDown += BtnJogRZ_plus_MouseDown;
            btnJogRZ_plus.MouseUp += BtnJogRZ_plus_MouseUp;
            btnJogRZ_minus.MouseDown += BtnJogRZ_minus_MouseDown;
            btnJogRZ_minus.MouseUp += BtnJogRZ_minus_MouseUp;
            #endregion

            LoadPositionData();

        }

        public void UpdateUI()
        {
            if (Visible)
            {
                if ((!_mainGUI.Common.bFlgInitial_Finished && !_mainGUI.Common.bForce_unlockJog) || _mainGUI.Common.bFlgTrigMoveStepByStep || _mainGUI.Common.bFlgTrigApplyGlue)
                {
                    btnJogY_plus.Enabled = false;
                    btnJogY_minus.Enabled = false;
                    btnJogX_plus.Enabled = false;
                    btnJogX_minus.Enabled = false;
                    btnJogZ_plus.Enabled = false;
                    btnJogZ_minus.Enabled = false;
                    if (!_mainGUI.Common.bFlgInitial_Finished || _mainGUI.Common.bFlgTrigMoveStepByStep || _mainGUI.Common.bFlgTrigApplyGlue)
                    {
                        btnSaveAll.Enabled = false;
                        btnManualSave_X.Enabled = false;
                        btnManualSave_Y.Enabled = false;
                        btnManualSave_Z.Enabled = false;
                        btnMoveStep.Enabled = false;
                        btnMovePosition.Enabled = false;
                        btnMovePos_Apply.Enabled = false;
                    }
                }
                else
                {
                    btnJogY_plus.Enabled = true;
                    btnJogY_minus.Enabled = true;
                    btnJogX_plus.Enabled = true;
                    btnJogX_minus.Enabled = true;
                    btnJogZ_plus.Enabled = true;
                    btnJogZ_minus.Enabled = true;
                    btnSaveAll.Enabled = true;
                    btnManualSave_X.Enabled = true;
                    btnManualSave_Y.Enabled = true;
                    btnManualSave_Z.Enabled = true;
                    btnMoveStep.Enabled = true;
                    btnMovePosition.Enabled = true;
                    btnMovePos_Apply.Enabled = true;
                }

                #region Enavle/Disable Manual Button
                if (cbPosition.Text == "Home") { DisableManualMove(); }
                else if (cbPosition.Text == "Glue Cut T1") { DisableManualMove(); }
                else if (cbPosition.Text == "Glue Purge") { DisableManualMove(); }
                else if (cbPosition.Text == "Camera") { DisableManualMove(); }
                else if (cbPosition.Text == "Calibration Tools 1") { DisableManualMove(); }
                else if (cbPosition.Text == "Calibration Tools 2") { DisableManualMove(); }
                else if (cbPosition.Text == "Tools Change-1") { DisableManualMove(); }
                else if (cbPosition.Text == "Tools Change-2") { DisableManualMove(); }
                else if (cbPosition.Text == "Z Safety T1") { DisableManualMove(); }
                else if (cbPosition.Text == "Z Safety T2") { DisableManualMove(); }
                else { EnableManualMove(); }
                #endregion

                updateUIXYZPos();
            }
        }


        #region Jog button control
        private void BtnJogX_plus_MouseDown(object sender, MouseEventArgs e)
        {
            btnJogX_plus.BackColor = Color.Crimson;
            if (cbJogXSpeed.Text == "Very Slow"){ iXJogSpeed = iSpeedVerySlow; }
            else if (cbJogXSpeed.Text == "Slow") { iXJogSpeed = iSpeedSlow; }
            else if (cbJogXSpeed.Text == "Normal") { iXJogSpeed = iSpeedNormal; }
            else if (cbJogXSpeed.Text == "Fast") { iXJogSpeed = iSpeedFast; }

            _ApplyGlue.X1_AXIS.PosMoveRel(100000000, iXJogSpeed);
        }

        private void BtnJogX_plus_MouseUp(object sender, MouseEventArgs e)
        {
            _ApplyGlue.X1_AXIS.Stop(0);
            btnJogX_plus.BackColor = Color.LightGray;
        }

        private void BtnJogX_minus_MouseDown(object sender, MouseEventArgs e)
        {
            btnJogX_minus.BackColor = Color.Crimson;
            if (cbJogXSpeed.Text == "Very Slow") { iXJogSpeed = iSpeedVerySlow; }
            else if (cbJogXSpeed.Text == "Slow") { iXJogSpeed = iSpeedSlow; }
            else if (cbJogXSpeed.Text == "Normal") { iXJogSpeed = iSpeedNormal; }
            else if (cbJogXSpeed.Text == "Fast") { iXJogSpeed = iSpeedFast; }

            _ApplyGlue.X1_AXIS.PosMoveRel(-100000000, iXJogSpeed);
        }

        private void BtnJogX_minus_MouseUp(object sender, MouseEventArgs e)
        {
            _ApplyGlue.X1_AXIS.Stop(0);
            btnJogX_minus.BackColor = Color.LightGray;
        }

        private void BtnJogY_plus_MouseDown(object sender, MouseEventArgs e)
        {
            btnJogY_plus.BackColor = Color.Crimson;
            if (cbJogYSpeed.Text == "Very Slow") { iYJogSpeed = iSpeedVerySlow; }
            else if (cbJogYSpeed.Text == "Slow") { iYJogSpeed = iSpeedSlow; }
            else if (cbJogYSpeed.Text == "Normal") { iYJogSpeed = iSpeedNormal; }
            else if (cbJogYSpeed.Text == "Fast") { iYJogSpeed = iSpeedFast; }

            _ApplyGlue.Y_Sync_Axis.Servo_YAxis_Sync_Start_Set();
            _ApplyGlue.Y1_AXIS.PosMoveRel(100000000, iYJogSpeed);
            _ApplyGlue.Y1_AXIS.Cancel_isMoveing();
            _ApplyGlue.Y2_AXIS.PosMoveRel(100000000, iYJogSpeed);
            _ApplyGlue.Y_Sync_Axis.Servo_Axis_Sync_Start();
        }

        private void BtnJogY_plus_MouseUp(object sender, MouseEventArgs e)
        {
            _ApplyGlue.Y1_AXIS.Stop(0);
            _ApplyGlue.Y2_AXIS.Stop(0);
            btnJogY_plus.BackColor = Color.LightGray;
        }

        private void BtnJogY_minus_MouseDown(object sender, MouseEventArgs e)
        {
            btnJogY_minus.BackColor = Color.Crimson;
            if (cbJogYSpeed.Text == "Very Slow") { iYJogSpeed = iSpeedVerySlow; }
            else if (cbJogYSpeed.Text == "Slow") { iYJogSpeed = iSpeedSlow; }
            else if (cbJogYSpeed.Text == "Normal") { iYJogSpeed = iSpeedNormal; }
            else if (cbJogYSpeed.Text == "Fast") { iYJogSpeed = iSpeedFast; }

            _ApplyGlue.Y_Sync_Axis.Servo_YAxis_Sync_Start_Set();
            _ApplyGlue.Y1_AXIS.PosMoveRel(-100000000, iYJogSpeed);
            _ApplyGlue.Y1_AXIS.Cancel_isMoveing();
            _ApplyGlue.Y2_AXIS.PosMoveRel(-100000000, iYJogSpeed);
            _ApplyGlue.Y_Sync_Axis.Servo_Axis_Sync_Start();
        }

        private void BtnJogY_minus_MouseUp(object sender, MouseEventArgs e)
        {
            _ApplyGlue.Y1_AXIS.Stop(0);
            _ApplyGlue.Y2_AXIS.Stop(0);
            btnJogY_minus.BackColor = Color.LightGray;
        }

        private void BtnJogZ_plus_MouseDown(object sender, MouseEventArgs e)
        {
            btnJogZ_plus.BackColor = Color.Crimson;
            if (cbJogZSpeed.Text == "Very Slow") { iZJogSpeed = iSpeedVerySlow; }
            else if (cbJogZSpeed.Text == "Slow") { iZJogSpeed = iSpeedSlow; }
            else if (cbJogZSpeed.Text == "Normal") { iZJogSpeed = iSpeedNormal; }
            else if (cbJogZSpeed.Text == "Fast") { iZJogSpeed = iSpeedFast; }

            _ApplyGlue.Z1_AXIS.PosMoveRel(100000000, iZJogSpeed);
        }

        private void BtnJogZ_plus_MouseUp(object sender, MouseEventArgs e)
        {
            _ApplyGlue.Z1_AXIS.Stop(0);
            btnJogZ_plus.BackColor = Color.LightGray;
        }

        private void BtnJogZ_minus_MouseDown(object sender, MouseEventArgs e)
        {
            btnJogZ_minus.BackColor = Color.Crimson;
            if (cbJogZSpeed.Text == "Very Slow") { iZJogSpeed = iSpeedVerySlow; }
            else if (cbJogZSpeed.Text == "Slow") { iZJogSpeed = iSpeedSlow; }
            else if (cbJogZSpeed.Text == "Normal") { iZJogSpeed = iSpeedNormal; }
            else if (cbJogZSpeed.Text == "Fast") { iZJogSpeed = iSpeedFast; }

            _ApplyGlue.Z1_AXIS.PosMoveRel(-100000000, iZJogSpeed);
        }

        private void BtnJogZ_minus_MouseUp(object sender, MouseEventArgs e)
        {
            _ApplyGlue.Z1_AXIS.Stop(0);
            btnJogZ_minus.BackColor = Color.LightGray;
        }

        private void BtnJogRZ_plus_MouseDown(object sender, MouseEventArgs e)
        {
            btnJogRZ_plus.BackColor = Color.Crimson;
            if (cbJogRZSpeed.Text == "Very Slow") { iRZJogSpeed = iSpeedVerySlow / 100; }
            else if (cbJogRZSpeed.Text == "Slow") { iRZJogSpeed = iSpeedSlow / 100; }
            else if (cbJogRZSpeed.Text == "Normal") { iRZJogSpeed = iSpeedNormal / 100; }
            else if (cbJogRZSpeed.Text == "Fast") { iRZJogSpeed = iSpeedFast / 100; }

            _ApplyGlue.RZ_AXIS.PosMoveRel(100000000, iRZJogSpeed);
        }

        private void BtnJogRZ_plus_MouseUp(object sender, MouseEventArgs e)
        {
            _ApplyGlue.RZ_AXIS.Stop(0);
            btnJogRZ_plus.BackColor = Color.LightGray;
        }

        private void BtnJogRZ_minus_MouseDown(object sender, MouseEventArgs e)
        {
            btnJogRZ_minus.BackColor = Color.Crimson;
            if (cbJogRZSpeed.Text == "Very Slow") { iRZJogSpeed = iSpeedVerySlow / 100; }
            else if (cbJogRZSpeed.Text == "Slow") { iRZJogSpeed = iSpeedSlow / 100; }
            else if (cbJogRZSpeed.Text == "Normal") { iRZJogSpeed = iSpeedNormal / 100; }
            else if (cbJogRZSpeed.Text == "Fast") { iRZJogSpeed = iSpeedFast / 100; }

            _ApplyGlue.RZ_AXIS.PosMoveRel(-100000000, iRZJogSpeed);
        }

        private void BtnJogRZ_minus_MouseUp(object sender, MouseEventArgs e)
        {
            _ApplyGlue.RZ_AXIS.Stop(0);
            btnJogRZ_minus.BackColor = Color.LightGray;
        }

        private void updateUIXYZPos()
        {
            fX1current_pos = ((float)_ApplyGlue.X1_AXIS.Position);
            tbCurrentXaxis.Text = fX1current_pos.ToString();
            //tbCurrentXaxis.Text = fX1current_pos.ToString(formatStr);
            //tbCurrentXaxis.Text = _ApplyGlue.X1_AXIS.Position.ToString();

            fY1current_pos = ((float)_ApplyGlue.Y1_AXIS.Position);
            tbCurrentYaxis.Text = fY1current_pos.ToString();
            //tbCurrentYaxis.Text = fY1current_pos.ToString(formatStr);
            //tbCurrentYaxis.Text = _ApplyGlue.Y1_AXIS.Position.ToString();

            fZ1current_pos = ((float)_ApplyGlue.Z1_AXIS.Position);
            tbCurrentZaxis.Text = fZ1current_pos.ToString();
            //tbCurrentZaxis.Text = fZ1current_pos.ToString(formatStr);
            //tbCurrentZaxis.Text = _ApplyGlue.Y2_AXIS.Position.ToString();

            fRZcurrent_pos = ((float)_ApplyGlue.RZ_AXIS.Position);
            tbCurrentRZaxis.Text = fRZcurrent_pos.ToString();
        }

        #endregion

        #region Disable keypress
        private void tbManualXaxis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbManualYaxis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbManualZaxis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != '.'  && e.KeyChar != '-' && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbManualRZaxis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '-' && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void cbPosition_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbStep_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbJogXSpeed_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbJogYSpeed_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbJogZSpeed_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        #endregion

        #region Load Saved data position to show
        private void cbPosition_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbPosition.Text == "Home") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            else if (cbPosition.Text == "Glue Cut T1") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }
            else if (cbPosition.Text == "Glue Purge") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            else if (cbPosition.Text == "Camera") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            else if (cbPosition.Text == "Calibration Tools 1") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            //else if (cbPosition.Text == "Calibration Tools 2") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            //else if (cbPosition.Text == "Tools Change-1") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); cbStep.Items.Add("3"); }
            //else if (cbPosition.Text == "Tools Change-2") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); cbStep.Items.Add("3"); }
            else if (cbPosition.Text == "Z Safety T1") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }
            //else if (cbPosition.Text == "Z Safety T2") { cbStep.Items.Clear(); cbStep.Items.Add("1"); }

            else if (cbPosition.Text == "Point-1") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else if (cbPosition.Text == "Point-2") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else if (cbPosition.Text == "Point-3") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else if (cbPosition.Text == "Point-4") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else if (cbPosition.Text == "Point-5") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else if (cbPosition.Text == "Point-6") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else if (cbPosition.Text == "Point-7") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else if (cbPosition.Text == "Point-8") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else if (cbPosition.Text == "Point-9") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else if (cbPosition.Text == "Point-10") { cbStep.Items.Clear(); cbStep.Items.Add("1"); cbStep.Items.Add("2"); }

            else
            {
                cbStep.Items.Clear();
                cbStep.Items.Add("1");
                cbStep.Items.Add("2");
                cbStep.Items.Add("3");
                cbStep.Items.Add("4");
                cbStep.Items.Add("5");
                cbStep.Items.Add("6");
                cbStep.Items.Add("7");
                cbStep.Items.Add("8");
                cbStep.Items.Add("9");
                cbStep.Items.Add("10");
                cbStep.Items.Add("11");
                cbStep.Items.Add("12");
                cbStep.Items.Add("13");
                cbStep.Items.Add("14");
                cbStep.Items.Add("15");
                cbStep.Items.Add("16");
                cbStep.Items.Add("17");
                cbStep.Items.Add("18");
                cbStep.Items.Add("19");
                cbStep.Items.Add("20");
            }
            cbStep.SelectedItem = "1";

            //For load Position saved data to show when index changed
            LoadPositionData();
        }

        private void cbStep_SelectedIndexChanged(object sender, EventArgs e)
        {
            //For load Step saved data to show when index changed
            LoadPositionData();
        }

        private void LoadPositionData()
        {
            Read_POS_STEP();

            Conn = new SqlConnection(_mainGUI.Common.Connection_String);
            Conn.Open();

            if (_mainGUI.Common.iModelSelect == 1) { sql = "SELECT * FROM dbo.XYZ_Position_View WHERE STEP = '" + strStepRead + "';"; }
            else if (_mainGUI.Common.iModelSelect == 2) { sql = "SELECT * FROM dbo.XYZ_Position_M2_View WHERE STEP = '" + strStepRead + "';"; }

            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    fX1Save_pos = SQLRead.GetInt32(3);
                    fY1Save_pos = SQLRead.GetInt32(4);
                    fZ1Save_pos = SQLRead.GetInt32(5);
                    fRZSave_pos = SQLRead.GetInt32(6);
                    tbSavedXaxis.Text = Convert.ToString(fX1Save_pos);
                    tbSavedYaxis.Text = Convert.ToString(fY1Save_pos);
                    tbSavedZaxis.Text = Convert.ToString(fZ1Save_pos);
                    tbSavedRZaxis.Text = Convert.ToString(fRZSave_pos);
                }

            }
        }

        #endregion

        #region Save position data

        private void Read_POS_STEP()
        {
            if (cbPosition.Text == "Home" && cbStep.Text == "1") { strStepRead = "H1"; }
            else if (cbPosition.Text == "Glue Cut T1" && cbStep.Text == "1") { strStepRead = "GCT1_1"; }
            else if (cbPosition.Text == "Glue Cut T1" && cbStep.Text == "2") { strStepRead = "GCT1_2"; }
            else if (cbPosition.Text == "Glue Cut T2" && cbStep.Text == "1") { strStepRead = "GCT2_1"; }
            else if (cbPosition.Text == "Glue Cut T2" && cbStep.Text == "2") { strStepRead = "GCT2_2"; }
            else if (cbPosition.Text == "Glue Purge" && cbStep.Text == "1") { strStepRead = "GP1"; }
            else if (cbPosition.Text == "Glue Purge" && cbStep.Text == "2") { strStepRead = "GP2"; }
            else if (cbPosition.Text == "Camera" && cbStep.Text == "1") { strStepRead = "C1"; }
            else if (cbPosition.Text == "Camera" && cbStep.Text == "2") { strStepRead = "C2"; }
            else if (cbPosition.Text == "Calibration Tools 1" && cbStep.Text == "1") { strStepRead = "CT1_1"; }
            else if (cbPosition.Text == "Calibration Tools 2" && cbStep.Text == "1") { strStepRead = "CT2_1"; }
            else if (cbPosition.Text == "Tools Change-1" && cbStep.Text == "1") { strStepRead = "TC1_1"; }
            else if (cbPosition.Text == "Tools Change-1" && cbStep.Text == "2") { strStepRead = "TC1_2"; }
            else if (cbPosition.Text == "Tools Change-1" && cbStep.Text == "3") { strStepRead = "TC1_3"; }
            else if (cbPosition.Text == "Tools Change-2" && cbStep.Text == "1") { strStepRead = "TC2_1"; }
            else if (cbPosition.Text == "Tools Change-2" && cbStep.Text == "2") { strStepRead = "TC2_2"; }
            else if (cbPosition.Text == "Tools Change-2" && cbStep.Text == "3") { strStepRead = "TC2_3"; }
            else if (cbPosition.Text == "Z Safety T1" && cbStep.Text == "1") { strStepRead = "ZS1_1"; }
            else if (cbPosition.Text == "Z Safety T2" && cbStep.Text == "1") { strStepRead = "ZS2_1"; }
            for (iPos = 1; iPos <= 20; iPos++ )
            { 
                if(cbPosition.Text == "Point-" + iPos)
                {
                    for (iStep = 1; iStep <= 20; iStep++)
                    {
                        if (cbStep.Text == iStep.ToString())
                        {
                            strStepRead = "P" + iPos +"_" + iStep;
                        }
                    }
                }                
            }
        }

        private void btnSaveAll_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to save XYZ position?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(re == DialogResult.Yes)
            {

                Read_POS_STEP();

                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();

                X_Axis_Value = Convert.ToInt32(_ApplyGlue.X1_AXIS.Position);  //X Axis read position
                Y_Axis_Value = Convert.ToInt32(_ApplyGlue.Y1_AXIS.Position);  //Y Axis read position
                Z_Axis_Value = Convert.ToInt32(_ApplyGlue.Z1_AXIS.Position);  //Z Axis read position
                RZ_Axis_Value = Convert.ToInt32(_ApplyGlue.RZ_AXIS.Position);  //RZ Axis read position

                if (_mainGUI.Common.iModelSelect == 1)
                {
                    //Save X
                    sql = "UPDATE dbo.XYZ_POSITION SET X_VALUE = '" + X_Axis_Value + "' WHERE STEP = '" + strStepRead + "';";
                    using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
                    //Save Y
                    sql = "UPDATE dbo.XYZ_POSITION SET Y_VALUE = '" + Y_Axis_Value + "' WHERE STEP = '" + strStepRead + "';";
                    using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
                    //Save Z
                    sql = "UPDATE dbo.XYZ_POSITION SET Z_VALUE = '" + Z_Axis_Value + "' WHERE STEP = '" + strStepRead + "';";
                    using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
                    //Save RZ
                    sql = "UPDATE dbo.XYZ_POSITION SET RZ_VALUE = '" + RZ_Axis_Value + "' WHERE STEP = '" + strStepRead + "';";
                    using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
                }
                else if(_mainGUI.Common.iModelSelect == 2)
                {
                    //Save X
                    sql = "UPDATE dbo.XYZ_POSITION_M2 SET X_VALUE = '" + X_Axis_Value + "' WHERE STEP = '" + strStepRead + "';";
                    using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
                    //Save Y
                    sql = "UPDATE dbo.XYZ_POSITION_M2 SET Y_VALUE = '" + Y_Axis_Value + "' WHERE STEP = '" + strStepRead + "';";
                    using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
                    //Save Z
                    sql = "UPDATE dbo.XYZ_POSITION_M2 SET Z_VALUE = '" + Z_Axis_Value + "' WHERE STEP = '" + strStepRead + "';";
                    using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
                    //Save RZ
                    sql = "UPDATE dbo.XYZ_POSITION_M2 SET RZ_VALUE = '" + RZ_Axis_Value + "' WHERE STEP = '" + strStepRead + "';";
                    using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
                }
                

                LoadPositionData();
            }
        }

        private void btnManualSave_X_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Manual save X position?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (re == DialogResult.Yes)
            {
                Read_POS_STEP();

                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();

                //Save X
                if (_mainGUI.Common.iModelSelect == 1)
                {
                    sql = "UPDATE dbo.XYZ_POSITION SET X_VALUE = " + Convert.ToDouble(tbManualXaxis.Text) + " WHERE STEP = '" + strStepRead + "';";
                }
                else if (_mainGUI.Common.iModelSelect == 2)
                {
                    sql = "UPDATE dbo.XYZ_POSITION_M2 SET X_VALUE = " + Convert.ToDouble(tbManualXaxis.Text) + " WHERE STEP = '" + strStepRead + "';";
                }
                
                using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }


                LoadPositionData();
            }
        }

        private void btnManualSave_Y_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Manual save Y position?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (re == DialogResult.Yes)
            {

                Read_POS_STEP();

                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();

                //Save Y
                if (_mainGUI.Common.iModelSelect == 1)
                {
                    sql = "UPDATE dbo.XYZ_POSITION SET Y_VALUE = " + Convert.ToDouble(tbManualYaxis.Text) + " WHERE STEP = '" + strStepRead + "';";
                }
                else if(_mainGUI.Common.iModelSelect == 2)
                {
                    sql = "UPDATE dbo.XYZ_POSITION_M2 SET Y_VALUE = " + Convert.ToDouble(tbManualYaxis.Text) + " WHERE STEP = '" + strStepRead + "';";
                }
                
                using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }


                LoadPositionData();
            }
        }

        private void btnManualSave_Z_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Manual save Z position?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (re == DialogResult.Yes)
            {

                Read_POS_STEP();

                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();
                //Save Z
                if (_mainGUI.Common.iModelSelect == 1)
                {
                    sql = "UPDATE dbo.XYZ_POSITION SET Z_VALUE = " + Convert.ToDouble(tbManualZaxis.Text) + " WHERE STEP = '" + strStepRead + "';";
                }
                else if(_mainGUI.Common.iModelSelect == 2)
                {
                    sql = "UPDATE dbo.XYZ_POSITION_M2 SET Z_VALUE = " + Convert.ToDouble(tbManualZaxis.Text) + " WHERE STEP = '" + strStepRead + "';";
                }
                
                using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }


                LoadPositionData();
            }
        }

        private void btnManualSave_RZ_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Manual save RZ position?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (re == DialogResult.Yes)
            {

                Read_POS_STEP();

                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();
                //Save RZ
                if (_mainGUI.Common.iModelSelect == 1)
                {
                    sql = "UPDATE dbo.XYZ_POSITION SET RZ_VALUE = " + Convert.ToDouble(tbManualRZaxis.Text) + " WHERE STEP = '" + strStepRead + "';";
                }
                else if (_mainGUI.Common.iModelSelect == 2)
                {
                    sql = "UPDATE dbo.XYZ_POSITION_M2 SET RZ_VALUE = " + Convert.ToDouble(tbManualRZaxis.Text) + " WHERE STEP = '" + strStepRead + "';";
                }

                using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }


                LoadPositionData();
            }
        }
        #endregion

        #region XYZ Move Event
        private void btnMoveStep_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm Move Step?", "Position move confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                #region check condition
                if (cbPosition.Text == "Home") { _mainGUI.Common.strTrigPotitionMove = "H"; }
                if (cbPosition.Text == "Glue Cut T1") { _mainGUI.Common.strTrigPotitionMove = "GCT1_"; }
                if (cbPosition.Text == "Glue Cut T2") { _mainGUI.Common.strTrigPotitionMove = "GCT2_"; }
                if (cbPosition.Text == "Glue Purge") { _mainGUI.Common.strTrigPotitionMove = "GP"; }
                if (cbPosition.Text == "Camera") { _mainGUI.Common.strTrigPotitionMove = "C"; }
                if (cbPosition.Text == "Calibration Tools 1") { _mainGUI.Common.strTrigPotitionMove = "CT1_"; }
                if (cbPosition.Text == "Calibration Tools 2") { _mainGUI.Common.strTrigPotitionMove = "CT2_"; }
                if (cbPosition.Text == "Tools Change-1") { _mainGUI.Common.strTrigPotitionMove = "TC1_"; }
                if (cbPosition.Text == "Tools Change-2") { _mainGUI.Common.strTrigPotitionMove = "TC2_"; }
                if (cbPosition.Text == "Z Safety T1") { _mainGUI.Common.strTrigPotitionMove = "ZS1_"; }
                if (cbPosition.Text == "Z Safety T2") { _mainGUI.Common.strTrigPotitionMove = "ZS2_"; }
                if (cbPosition.Text == "Point-1") { _mainGUI.Common.strTrigPotitionMove = "P1_"; }
                if (cbPosition.Text == "Point-2") { _mainGUI.Common.strTrigPotitionMove = "P2_"; }
                if (cbPosition.Text == "Point-3") { _mainGUI.Common.strTrigPotitionMove = "P3_"; }
                if (cbPosition.Text == "Point-4") { _mainGUI.Common.strTrigPotitionMove = "P4_"; }
                if (cbPosition.Text == "Point-5") { _mainGUI.Common.strTrigPotitionMove = "P5_"; }
                if (cbPosition.Text == "Point-6") { _mainGUI.Common.strTrigPotitionMove = "P6_"; }
                if (cbPosition.Text == "Point-7") { _mainGUI.Common.strTrigPotitionMove = "P7_"; }
                if (cbPosition.Text == "Point-8") { _mainGUI.Common.strTrigPotitionMove = "P8_"; }
                if (cbPosition.Text == "Point-9") { _mainGUI.Common.strTrigPotitionMove = "P9_"; }
                if (cbPosition.Text == "Point-10") { _mainGUI.Common.strTrigPotitionMove = "P10_"; }
                if (cbPosition.Text == "Point-11") { _mainGUI.Common.strTrigPotitionMove = "P11_"; }
                if (cbPosition.Text == "Point-12") { _mainGUI.Common.strTrigPotitionMove = "P12_"; }
                if (cbPosition.Text == "Point-13") { _mainGUI.Common.strTrigPotitionMove = "P13_"; }
                if (cbPosition.Text == "Point-14") { _mainGUI.Common.strTrigPotitionMove = "P14_"; }
                if (cbPosition.Text == "Point-15") { _mainGUI.Common.strTrigPotitionMove = "P15_"; }
                if (cbPosition.Text == "Point-16") { _mainGUI.Common.strTrigPotitionMove = "P16_"; }
                if (cbPosition.Text == "Point-17") { _mainGUI.Common.strTrigPotitionMove = "P17_"; }
                if (cbPosition.Text == "Point-18") { _mainGUI.Common.strTrigPotitionMove = "P18_"; }
                if (cbPosition.Text == "Point-19") { _mainGUI.Common.strTrigPotitionMove = "P19_"; }
                if (cbPosition.Text == "Point-20") { _mainGUI.Common.strTrigPotitionMove = "P20_"; }

                _mainGUI.Common.iTrigStepMove = Convert.ToInt32(cbStep.Text);

                #endregion

                _mainGUI.Common.bFlgTrigMoveStepByStep = true;
            }
        }
        private void btnMovePosition_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm Move Position?", "Position move confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                #region check condition
                if (cbPosition.Text == "Point-1") { _mainGUI.Common.iTrigPositionApplyGlue = 1; }
                if (cbPosition.Text == "Point-2") { _mainGUI.Common.iTrigPositionApplyGlue = 2; }
                if (cbPosition.Text == "Point-3") { _mainGUI.Common.iTrigPositionApplyGlue = 3; }
                if (cbPosition.Text == "Point-4") { _mainGUI.Common.iTrigPositionApplyGlue = 4; }
                if (cbPosition.Text == "Point-5") { _mainGUI.Common.iTrigPositionApplyGlue = 5; }
                if (cbPosition.Text == "Point-6") { _mainGUI.Common.iTrigPositionApplyGlue = 6; }
                if (cbPosition.Text == "Point-7") { _mainGUI.Common.iTrigPositionApplyGlue = 7; }
                if (cbPosition.Text == "Point-8") { _mainGUI.Common.iTrigPositionApplyGlue = 8; }
                if (cbPosition.Text == "Point-9") { _mainGUI.Common.iTrigPositionApplyGlue = 9; }
                if (cbPosition.Text == "Point-10") { _mainGUI.Common.iTrigPositionApplyGlue = 10; }
                if (cbPosition.Text == "Point-11") { _mainGUI.Common.iTrigPositionApplyGlue = 11; }
                if (cbPosition.Text == "Point-12") { _mainGUI.Common.iTrigPositionApplyGlue = 12; }
                if (cbPosition.Text == "Point-13") { _mainGUI.Common.iTrigPositionApplyGlue = 13; }
                if (cbPosition.Text == "Point-14") { _mainGUI.Common.iTrigPositionApplyGlue = 14; }
                if (cbPosition.Text == "Point-15") { _mainGUI.Common.iTrigPositionApplyGlue = 15; }
                if (cbPosition.Text == "Point-16") { _mainGUI.Common.iTrigPositionApplyGlue = 16; }
                if (cbPosition.Text == "Point-17") { _mainGUI.Common.iTrigPositionApplyGlue = 17; }
                if (cbPosition.Text == "Point-18") { _mainGUI.Common.iTrigPositionApplyGlue = 18; }
                if (cbPosition.Text == "Point-19") { _mainGUI.Common.iTrigPositionApplyGlue = 19; }
                if (cbPosition.Text == "Point-20") { _mainGUI.Common.iTrigPositionApplyGlue = 20; }
                #endregion

                _mainGUI.Common.bSkipApplyGlue = true;
                _mainGUI.Common.bFlgTrigApplyGlue = true;
            }
        }
        private void btnMovePos_Apply_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm Move Position & Apply Glue?", "Position move confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                #region check condition
                if (cbPosition.Text == "Point-1") { _mainGUI.Common.iTrigPositionApplyGlue = 1; }
                if (cbPosition.Text == "Point-2") { _mainGUI.Common.iTrigPositionApplyGlue = 2; }
                if (cbPosition.Text == "Point-3") { _mainGUI.Common.iTrigPositionApplyGlue = 3; }
                if (cbPosition.Text == "Point-4") { _mainGUI.Common.iTrigPositionApplyGlue = 4; }
                if (cbPosition.Text == "Point-5") { _mainGUI.Common.iTrigPositionApplyGlue = 5; }
                if (cbPosition.Text == "Point-6") { _mainGUI.Common.iTrigPositionApplyGlue = 6; }
                if (cbPosition.Text == "Point-7") { _mainGUI.Common.iTrigPositionApplyGlue = 7; }
                if (cbPosition.Text == "Point-8") { _mainGUI.Common.iTrigPositionApplyGlue = 8; }
                if (cbPosition.Text == "Point-9") { _mainGUI.Common.iTrigPositionApplyGlue = 9; }
                if (cbPosition.Text == "Point-10") { _mainGUI.Common.iTrigPositionApplyGlue = 10; }
                if (cbPosition.Text == "Point-11") { _mainGUI.Common.iTrigPositionApplyGlue = 11; }
                if (cbPosition.Text == "Point-12") { _mainGUI.Common.iTrigPositionApplyGlue = 12; }
                if (cbPosition.Text == "Point-13") { _mainGUI.Common.iTrigPositionApplyGlue = 13; }
                if (cbPosition.Text == "Point-14") { _mainGUI.Common.iTrigPositionApplyGlue = 14; }
                if (cbPosition.Text == "Point-15") { _mainGUI.Common.iTrigPositionApplyGlue = 15; }
                if (cbPosition.Text == "Point-16") { _mainGUI.Common.iTrigPositionApplyGlue = 16; }
                if (cbPosition.Text == "Point-17") { _mainGUI.Common.iTrigPositionApplyGlue = 17; }
                if (cbPosition.Text == "Point-18") { _mainGUI.Common.iTrigPositionApplyGlue = 18; }
                if (cbPosition.Text == "Point-19") { _mainGUI.Common.iTrigPositionApplyGlue = 19; }
                if (cbPosition.Text == "Point-20") { _mainGUI.Common.iTrigPositionApplyGlue = 20; }
                #endregion

                _mainGUI.Common.bSkipApplyGlue = false;
                _mainGUI.Common.bFlgTrigApplyGlue = true;
            }
        }
        #endregion

        private void EnableManualMove()
        {
            if (_mainGUI.Common.bFlgInitial_Finished && !_mainGUI.Common.bFlgTrigMoveStepByStep && !_mainGUI.Common.bFlgTrigApplyGlue)
            {
                btnMovePosition.Enabled = true;
                btnMovePos_Apply.Enabled = true;
            }            
        }
        private void DisableManualMove()
        {
            btnMovePosition.Enabled = false;
            btnMovePos_Apply.Enabled = false;
        }

        private void btnForceJog_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to change?", "Force Jog", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (re == DialogResult.Yes)
            {
                if (_mainGUI.Common.bForce_unlockJog)
                {
                    _mainGUI.Common.bForce_unlockJog = false;
                    btnForceJog.Text = "Force Jog OFF";
                    btnForceJog.BackColor = Color.LightGray;
                }
                else
                {
                    _mainGUI.Common.bForce_unlockJog = true;
                    btnForceJog.Text = "Force Jog ON";
                    btnForceJog.BackColor = Color.Red;
                }
            }
        }
    }
}
