﻿
namespace UI_Common
{
    partial class ucRFIDMes
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbRFID_R_ID = new System.Windows.Forms.TextBox();
            this.tbRFID_R_Name = new System.Windows.Forms.TextBox();
            this.tbRFID_R_WorkOrder = new System.Windows.Forms.TextBox();
            this.tbRFID_R_Status = new System.Windows.Forms.TextBox();
            this.tbRFID_R_SerialNO = new System.Windows.Forms.TextBox();
            this.btnRFID_READ = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.btnRFID_BYPASS = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.lbRFIDBypass_Status = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btnMES_BYPASS = new System.Windows.Forms.Button();
            this.lbMESBypass_Status = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tbStation = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tbGroup = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tbSection = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tbLineName = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tbModel = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbMO_Num = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tbFactory = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tbTokenID = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tbKEY = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnSaveMESPara = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.btnLoadMESPara = new System.Windows.Forms.Button();
            this.tbMESUrl = new System.Windows.Forms.TextBox();
            this.tbUrl = new System.Windows.Forms.TextBox();
            this.tbInterfaceID = new System.Windows.Forms.TextBox();
            this.tbLocalPort = new System.Windows.Forms.TextBox();
            this.tbLocalIP = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1000, 40);
            this.label1.TabIndex = 5;
            this.label1.Text = "RFID | MES";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(167, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "ID :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(136, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "NAME :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(66, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "WORK ORDER :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(119, 277);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "STATUS :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(47, 328);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "SERIAL NUMBER :";
            // 
            // tbRFID_R_ID
            // 
            this.tbRFID_R_ID.Location = new System.Drawing.Point(209, 124);
            this.tbRFID_R_ID.Name = "tbRFID_R_ID";
            this.tbRFID_R_ID.ReadOnly = true;
            this.tbRFID_R_ID.Size = new System.Drawing.Size(198, 22);
            this.tbRFID_R_ID.TabIndex = 7;
            this.tbRFID_R_ID.Text = "-";
            this.tbRFID_R_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRFID_R_Name
            // 
            this.tbRFID_R_Name.Location = new System.Drawing.Point(209, 175);
            this.tbRFID_R_Name.Name = "tbRFID_R_Name";
            this.tbRFID_R_Name.ReadOnly = true;
            this.tbRFID_R_Name.Size = new System.Drawing.Size(198, 22);
            this.tbRFID_R_Name.TabIndex = 7;
            this.tbRFID_R_Name.Text = "-";
            this.tbRFID_R_Name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRFID_R_WorkOrder
            // 
            this.tbRFID_R_WorkOrder.Location = new System.Drawing.Point(209, 226);
            this.tbRFID_R_WorkOrder.Name = "tbRFID_R_WorkOrder";
            this.tbRFID_R_WorkOrder.ReadOnly = true;
            this.tbRFID_R_WorkOrder.Size = new System.Drawing.Size(198, 22);
            this.tbRFID_R_WorkOrder.TabIndex = 7;
            this.tbRFID_R_WorkOrder.Text = "-";
            this.tbRFID_R_WorkOrder.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRFID_R_Status
            // 
            this.tbRFID_R_Status.Location = new System.Drawing.Point(209, 277);
            this.tbRFID_R_Status.Name = "tbRFID_R_Status";
            this.tbRFID_R_Status.ReadOnly = true;
            this.tbRFID_R_Status.Size = new System.Drawing.Size(198, 22);
            this.tbRFID_R_Status.TabIndex = 7;
            this.tbRFID_R_Status.Text = "-";
            this.tbRFID_R_Status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRFID_R_SerialNO
            // 
            this.tbRFID_R_SerialNO.Location = new System.Drawing.Point(209, 328);
            this.tbRFID_R_SerialNO.Name = "tbRFID_R_SerialNO";
            this.tbRFID_R_SerialNO.ReadOnly = true;
            this.tbRFID_R_SerialNO.Size = new System.Drawing.Size(198, 22);
            this.tbRFID_R_SerialNO.TabIndex = 7;
            this.tbRFID_R_SerialNO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnRFID_READ
            // 
            this.btnRFID_READ.BackColor = System.Drawing.Color.LightGray;
            this.btnRFID_READ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRFID_READ.Location = new System.Drawing.Point(209, 378);
            this.btnRFID_READ.Name = "btnRFID_READ";
            this.btnRFID_READ.Size = new System.Drawing.Size(85, 43);
            this.btnRFID_READ.TabIndex = 8;
            this.btnRFID_READ.Text = "RFID READ";
            this.btnRFID_READ.UseVisualStyleBackColor = false;
            this.btnRFID_READ.Click += new System.EventHandler(this.btnRFID_READ_Click);
            this.btnRFID_READ.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnRFID_READ_MouseDown);
            this.btnRFID_READ.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnRFID_READ_MouseUp);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.White;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(239, 69);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(124, 25);
            this.label51.TabIndex = 76;
            this.label51.Text = "RFID READ";
            // 
            // btnRFID_BYPASS
            // 
            this.btnRFID_BYPASS.BackColor = System.Drawing.Color.LightGray;
            this.btnRFID_BYPASS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRFID_BYPASS.Location = new System.Drawing.Point(80, 518);
            this.btnRFID_BYPASS.Name = "btnRFID_BYPASS";
            this.btnRFID_BYPASS.Size = new System.Drawing.Size(85, 43);
            this.btnRFID_BYPASS.TabIndex = 79;
            this.btnRFID_BYPASS.Text = "RFID BYPASS";
            this.btnRFID_BYPASS.UseVisualStyleBackColor = false;
            this.btnRFID_BYPASS.Click += new System.EventHandler(this.btnRFID_BYPASS_Click);
            this.btnRFID_BYPASS.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnRFID_BYPASS_MouseDown);
            this.btnRFID_BYPASS.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnRFID_BYPASS_MouseUp);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(181, 531);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(138, 17);
            this.label21.TabIndex = 77;
            this.label21.Text = "RFID bypass status :";
            // 
            // lbRFIDBypass_Status
            // 
            this.lbRFIDBypass_Status.AutoSize = true;
            this.lbRFIDBypass_Status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbRFIDBypass_Status.Location = new System.Drawing.Point(325, 532);
            this.lbRFIDBypass_Status.Name = "lbRFIDBypass_Status";
            this.lbRFIDBypass_Status.Size = new System.Drawing.Size(96, 17);
            this.lbRFIDBypass_Status.TabIndex = 80;
            this.lbRFIDBypass_Status.Text = "NOT BYPASS";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(663, 532);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(136, 17);
            this.label22.TabIndex = 77;
            this.label22.Text = "MES bypass status :";
            // 
            // btnMES_BYPASS
            // 
            this.btnMES_BYPASS.BackColor = System.Drawing.Color.LightGray;
            this.btnMES_BYPASS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMES_BYPASS.Location = new System.Drawing.Point(562, 519);
            this.btnMES_BYPASS.Name = "btnMES_BYPASS";
            this.btnMES_BYPASS.Size = new System.Drawing.Size(85, 43);
            this.btnMES_BYPASS.TabIndex = 79;
            this.btnMES_BYPASS.Text = "MES BYPASS";
            this.btnMES_BYPASS.UseVisualStyleBackColor = false;
            this.btnMES_BYPASS.Click += new System.EventHandler(this.btnMES_BYPASS_Click);
            this.btnMES_BYPASS.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnMES_BYPASS_MouseDown);
            this.btnMES_BYPASS.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnMES_BYPASS_MouseUp);
            // 
            // lbMESBypass_Status
            // 
            this.lbMESBypass_Status.AutoSize = true;
            this.lbMESBypass_Status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbMESBypass_Status.Location = new System.Drawing.Point(807, 533);
            this.lbMESBypass_Status.Name = "lbMESBypass_Status";
            this.lbMESBypass_Status.Size = new System.Drawing.Size(96, 17);
            this.lbMESBypass_Status.TabIndex = 80;
            this.lbMESBypass_Status.Text = "NOT BYPASS";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(566, 570);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(349, 17);
            this.label23.TabIndex = 77;
            this.label23.Text = "**IF RFID is Bypass program will auto bypass MES too.";
            // 
            // tbStation
            // 
            this.tbStation.Location = new System.Drawing.Point(652, 451);
            this.tbStation.MaxLength = 200;
            this.tbStation.Name = "tbStation";
            this.tbStation.Size = new System.Drawing.Size(198, 22);
            this.tbStation.TabIndex = 131;
            this.tbStation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(577, 451);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(71, 20);
            this.label24.TabIndex = 130;
            this.label24.Text = "Station :";
            // 
            // tbGroup
            // 
            this.tbGroup.Location = new System.Drawing.Point(652, 423);
            this.tbGroup.MaxLength = 200;
            this.tbGroup.Name = "tbGroup";
            this.tbGroup.Size = new System.Drawing.Size(198, 22);
            this.tbGroup.TabIndex = 129;
            this.tbGroup.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(583, 423);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 20);
            this.label20.TabIndex = 128;
            this.label20.Text = "Group :";
            // 
            // tbSection
            // 
            this.tbSection.Location = new System.Drawing.Point(652, 395);
            this.tbSection.MaxLength = 200;
            this.tbSection.Name = "tbSection";
            this.tbSection.Size = new System.Drawing.Size(198, 22);
            this.tbSection.TabIndex = 127;
            this.tbSection.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(573, 395);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(75, 20);
            this.label19.TabIndex = 126;
            this.label19.Text = "Section :";
            // 
            // tbLineName
            // 
            this.tbLineName.Location = new System.Drawing.Point(652, 367);
            this.tbLineName.MaxLength = 200;
            this.tbLineName.Name = "tbLineName";
            this.tbLineName.ReadOnly = true;
            this.tbLineName.Size = new System.Drawing.Size(198, 22);
            this.tbLineName.TabIndex = 125;
            this.tbLineName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(553, 367);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(95, 20);
            this.label18.TabIndex = 124;
            this.label18.Text = "LineName :";
            // 
            // tbModel
            // 
            this.tbModel.Location = new System.Drawing.Point(652, 339);
            this.tbModel.MaxLength = 200;
            this.tbModel.Name = "tbModel";
            this.tbModel.ReadOnly = true;
            this.tbModel.Size = new System.Drawing.Size(198, 22);
            this.tbModel.TabIndex = 123;
            this.tbModel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(584, 339);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 20);
            this.label17.TabIndex = 122;
            this.label17.Text = "Model :";
            // 
            // tbMO_Num
            // 
            this.tbMO_Num.Location = new System.Drawing.Point(652, 311);
            this.tbMO_Num.MaxLength = 200;
            this.tbMO_Num.Name = "tbMO_Num";
            this.tbMO_Num.ReadOnly = true;
            this.tbMO_Num.Size = new System.Drawing.Size(198, 22);
            this.tbMO_Num.TabIndex = 121;
            this.tbMO_Num.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(558, 311);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 20);
            this.label16.TabIndex = 120;
            this.label16.Text = "MO_Num :";
            // 
            // tbFactory
            // 
            this.tbFactory.Location = new System.Drawing.Point(652, 283);
            this.tbFactory.MaxLength = 200;
            this.tbFactory.Name = "tbFactory";
            this.tbFactory.Size = new System.Drawing.Size(198, 22);
            this.tbFactory.TabIndex = 119;
            this.tbFactory.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(573, 283);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 20);
            this.label15.TabIndex = 118;
            this.label15.Text = "Factory :";
            // 
            // tbTokenID
            // 
            this.tbTokenID.Location = new System.Drawing.Point(652, 255);
            this.tbTokenID.MaxLength = 200;
            this.tbTokenID.Name = "tbTokenID";
            this.tbTokenID.Size = new System.Drawing.Size(198, 22);
            this.tbTokenID.TabIndex = 117;
            this.tbTokenID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(567, 255);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 20);
            this.label14.TabIndex = 116;
            this.label14.Text = "TokenID :";
            // 
            // tbKEY
            // 
            this.tbKEY.Location = new System.Drawing.Point(652, 227);
            this.tbKEY.MaxLength = 200;
            this.tbKEY.Name = "tbKEY";
            this.tbKEY.Size = new System.Drawing.Size(198, 22);
            this.tbKEY.TabIndex = 115;
            this.tbKEY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(597, 227);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 20);
            this.label13.TabIndex = 114;
            this.label13.Text = "KEY :";
            // 
            // btnSaveMESPara
            // 
            this.btnSaveMESPara.BackColor = System.Drawing.Color.LightGray;
            this.btnSaveMESPara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveMESPara.Location = new System.Drawing.Point(884, 403);
            this.btnSaveMESPara.Name = "btnSaveMESPara";
            this.btnSaveMESPara.Size = new System.Drawing.Size(85, 43);
            this.btnSaveMESPara.TabIndex = 113;
            this.btnSaveMESPara.Text = "Save";
            this.btnSaveMESPara.UseVisualStyleBackColor = false;
            this.btnSaveMESPara.Click += new System.EventHandler(this.btnSaveMESPara_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(680, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(197, 25);
            this.label12.TabIndex = 112;
            this.label12.Text = "MES PARAMETER";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Black;
            this.pictureBox7.Location = new System.Drawing.Point(496, 50);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(10, 452);
            this.pictureBox7.TabIndex = 111;
            this.pictureBox7.TabStop = false;
            // 
            // btnLoadMESPara
            // 
            this.btnLoadMESPara.BackColor = System.Drawing.Color.LightGray;
            this.btnLoadMESPara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoadMESPara.Location = new System.Drawing.Point(884, 329);
            this.btnLoadMESPara.Name = "btnLoadMESPara";
            this.btnLoadMESPara.Size = new System.Drawing.Size(85, 43);
            this.btnLoadMESPara.TabIndex = 110;
            this.btnLoadMESPara.Text = "Load";
            this.btnLoadMESPara.UseVisualStyleBackColor = false;
            this.btnLoadMESPara.Click += new System.EventHandler(this.btnLoadMESPara_Click);
            // 
            // tbMESUrl
            // 
            this.tbMESUrl.Location = new System.Drawing.Point(652, 199);
            this.tbMESUrl.MaxLength = 200;
            this.tbMESUrl.Name = "tbMESUrl";
            this.tbMESUrl.Size = new System.Drawing.Size(198, 22);
            this.tbMESUrl.TabIndex = 109;
            this.tbMESUrl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUrl
            // 
            this.tbUrl.Location = new System.Drawing.Point(652, 171);
            this.tbUrl.MaxLength = 200;
            this.tbUrl.Name = "tbUrl";
            this.tbUrl.Size = new System.Drawing.Size(198, 22);
            this.tbUrl.TabIndex = 108;
            this.tbUrl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbInterfaceID
            // 
            this.tbInterfaceID.Location = new System.Drawing.Point(652, 143);
            this.tbInterfaceID.MaxLength = 200;
            this.tbInterfaceID.Name = "tbInterfaceID";
            this.tbInterfaceID.Size = new System.Drawing.Size(198, 22);
            this.tbInterfaceID.TabIndex = 107;
            this.tbInterfaceID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbLocalPort
            // 
            this.tbLocalPort.Location = new System.Drawing.Point(652, 115);
            this.tbLocalPort.MaxLength = 200;
            this.tbLocalPort.Name = "tbLocalPort";
            this.tbLocalPort.Size = new System.Drawing.Size(198, 22);
            this.tbLocalPort.TabIndex = 106;
            this.tbLocalPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbLocalIP
            // 
            this.tbLocalIP.Location = new System.Drawing.Point(652, 87);
            this.tbLocalIP.MaxLength = 200;
            this.tbLocalIP.Name = "tbLocalIP";
            this.tbLocalIP.Size = new System.Drawing.Size(198, 22);
            this.tbLocalIP.TabIndex = 105;
            this.tbLocalIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(571, 199);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 20);
            this.label11.TabIndex = 103;
            this.label11.Text = "MESUrl :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(607, 171);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 20);
            this.label10.TabIndex = 102;
            this.label10.Text = "Url :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(547, 143);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 20);
            this.label9.TabIndex = 101;
            this.label9.Text = "InterfaceID :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(557, 115);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 20);
            this.label8.TabIndex = 104;
            this.label8.Text = "LocalPort :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(575, 87);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 20);
            this.label7.TabIndex = 100;
            this.label7.Text = "LocalIp :";
            // 
            // ucRFIDMes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.tbStation);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.tbGroup);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.tbSection);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.tbLineName);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.tbModel);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.tbMO_Num);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.tbFactory);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.tbTokenID);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tbKEY);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnSaveMESPara);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.btnLoadMESPara);
            this.Controls.Add(this.tbMESUrl);
            this.Controls.Add(this.tbUrl);
            this.Controls.Add(this.tbInterfaceID);
            this.Controls.Add(this.tbLocalPort);
            this.Controls.Add(this.tbLocalIP);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbMESBypass_Status);
            this.Controls.Add(this.lbRFIDBypass_Status);
            this.Controls.Add(this.btnMES_BYPASS);
            this.Controls.Add(this.btnRFID_BYPASS);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.btnRFID_READ);
            this.Controls.Add(this.tbRFID_R_SerialNO);
            this.Controls.Add(this.tbRFID_R_Status);
            this.Controls.Add(this.tbRFID_R_WorkOrder);
            this.Controls.Add(this.tbRFID_R_Name);
            this.Controls.Add(this.tbRFID_R_ID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ucRFIDMes";
            this.Size = new System.Drawing.Size(1000, 600);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbRFID_R_ID;
        private System.Windows.Forms.TextBox tbRFID_R_Name;
        private System.Windows.Forms.TextBox tbRFID_R_WorkOrder;
        private System.Windows.Forms.TextBox tbRFID_R_Status;
        private System.Windows.Forms.TextBox tbRFID_R_SerialNO;
        private System.Windows.Forms.Button btnRFID_READ;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button btnRFID_BYPASS;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbRFIDBypass_Status;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btnMES_BYPASS;
        private System.Windows.Forms.Label lbMESBypass_Status;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbStation;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tbGroup;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbSection;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tbLineName;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbModel;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbMO_Num;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbFactory;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbTokenID;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbKEY;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnSaveMESPara;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Button btnLoadMESPara;
        private System.Windows.Forms.TextBox tbMESUrl;
        private System.Windows.Forms.TextBox tbUrl;
        private System.Windows.Forms.TextBox tbInterfaceID;
        private System.Windows.Forms.TextBox tbLocalPort;
        private System.Windows.Forms.TextBox tbLocalIP;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}
