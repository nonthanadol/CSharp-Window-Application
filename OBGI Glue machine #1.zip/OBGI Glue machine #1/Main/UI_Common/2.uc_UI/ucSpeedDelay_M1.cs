﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucSpeedDelay_M1 : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;

        public ucSpeedDelay_M1(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;

            Load_SPD_DT();
        }

        public void UpdateUI()
        {
            if (Visible)
            {

            }
        }

        public void Load_SPD_DT()
        {
            tbSpdDT_P1.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P1_Speed").ToString();
            tbSpdDT_P2.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P2_Speed").ToString();
            tbSpdDT_P3.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P3_Speed").ToString();
            tbSpdDT_P4.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P4_Speed").ToString();
            tbSpdDT_P5.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P5_Speed").ToString();
            tbSpdDT_P6.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P6_Speed").ToString();
            tbSpdDT_P7.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P7_Speed").ToString();
            tbSpdDT_P8.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P8_Speed").ToString();
            tbSpdDT_P9.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P9_Speed").ToString();
            tbSpdDT_P10.Text = _mainGUI.Common.Config.ReadValue("Model_1_Speed_GlueTime", "P10_Speed").ToString();
        }
        public void Save_SPD_DT()
        {
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P1_Speed", " " + Convert.ToInt32(tbSpdDT_P1.Text));
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P2_Speed", " " + Convert.ToInt32(tbSpdDT_P2.Text));
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P3_Speed", " " + Convert.ToInt32(tbSpdDT_P3.Text));
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P4_Speed", " " + Convert.ToInt32(tbSpdDT_P4.Text));
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P5_Speed", " " + Convert.ToInt32(tbSpdDT_P5.Text));
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P6_Speed", " " + Convert.ToInt32(tbSpdDT_P6.Text));
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P7_Speed", " " + Convert.ToInt32(tbSpdDT_P7.Text));
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P8_Speed", " " + Convert.ToInt32(tbSpdDT_P8.Text));
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P9_Speed", " " + Convert.ToInt32(tbSpdDT_P9.Text));
            _mainGUI.Common.Config.WriteValue("Model_1_Speed_GlueTime", "P10_Speed", " " + Convert.ToInt32(tbSpdDT_P10.Text));
        }

        private void btnNozzle_Load_Click(object sender, EventArgs e)
        {
            Load_SPD_DT();
        }

        private void btnNozzleFirstSet_Save_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to save parameter?", "Parameter save", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                Save_SPD_DT();
            }
        }

        //private void btnNextpage_Click(object sender, EventArgs e)
        //{
        //    foreach (Control item in Parent.Controls)
        //    {
        //        if (item is ucSpeedDelay_M2)
        //        {
        //            item.Visible = true;
        //        }
        //        else
        //        {
        //            item.Visible = false;
        //        }
        //    }
        //}

        #region Keypress
        private void tbSpdDT_P1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P8_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P9_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P10_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbSpdDT_P11_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        #endregion
    }
}
