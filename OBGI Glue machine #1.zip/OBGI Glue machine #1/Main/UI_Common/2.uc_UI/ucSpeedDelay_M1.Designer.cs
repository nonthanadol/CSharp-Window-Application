﻿
namespace UI_Common
{
    partial class ucSpeedDelay_M1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnNozzleFirstSet_Save = new System.Windows.Forms.Button();
            this.btnNozzle_Load = new System.Windows.Forms.Button();
            this.tbSpdDT_P6 = new System.Windows.Forms.TextBox();
            this.tbSpdDT_P5 = new System.Windows.Forms.TextBox();
            this.tbSpdDT_P4 = new System.Windows.Forms.TextBox();
            this.tbSpdDT_P3 = new System.Windows.Forms.TextBox();
            this.tbSpdDT_P2 = new System.Windows.Forms.TextBox();
            this.tbSpdDT_P1 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbSpdDT_P10 = new System.Windows.Forms.TextBox();
            this.tbSpdDT_P9 = new System.Windows.Forms.TextBox();
            this.tbSpdDT_P8 = new System.Windows.Forms.TextBox();
            this.tbSpdDT_P7 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.picSample = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSample)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1000, 40);
            this.label1.TabIndex = 98;
            this.label1.Text = "SPEED / DELAY TIME";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNozzleFirstSet_Save
            // 
            this.btnNozzleFirstSet_Save.Location = new System.Drawing.Point(205, 447);
            this.btnNozzleFirstSet_Save.Name = "btnNozzleFirstSet_Save";
            this.btnNozzleFirstSet_Save.Size = new System.Drawing.Size(86, 38);
            this.btnNozzleFirstSet_Save.TabIndex = 172;
            this.btnNozzleFirstSet_Save.Text = "Save";
            this.btnNozzleFirstSet_Save.UseVisualStyleBackColor = true;
            this.btnNozzleFirstSet_Save.Click += new System.EventHandler(this.btnNozzleFirstSet_Save_Click);
            // 
            // btnNozzle_Load
            // 
            this.btnNozzle_Load.Location = new System.Drawing.Point(70, 447);
            this.btnNozzle_Load.Name = "btnNozzle_Load";
            this.btnNozzle_Load.Size = new System.Drawing.Size(86, 38);
            this.btnNozzle_Load.TabIndex = 171;
            this.btnNozzle_Load.Text = "Load";
            this.btnNozzle_Load.UseVisualStyleBackColor = true;
            this.btnNozzle_Load.Click += new System.EventHandler(this.btnNozzle_Load_Click);
            // 
            // tbSpdDT_P6
            // 
            this.tbSpdDT_P6.Location = new System.Drawing.Point(167, 294);
            this.tbSpdDT_P6.MaxLength = 10;
            this.tbSpdDT_P6.Name = "tbSpdDT_P6";
            this.tbSpdDT_P6.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P6.TabIndex = 165;
            this.tbSpdDT_P6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P6_KeyPress);
            // 
            // tbSpdDT_P5
            // 
            this.tbSpdDT_P5.Location = new System.Drawing.Point(167, 267);
            this.tbSpdDT_P5.MaxLength = 10;
            this.tbSpdDT_P5.Name = "tbSpdDT_P5";
            this.tbSpdDT_P5.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P5.TabIndex = 166;
            this.tbSpdDT_P5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P5_KeyPress);
            // 
            // tbSpdDT_P4
            // 
            this.tbSpdDT_P4.Location = new System.Drawing.Point(167, 240);
            this.tbSpdDT_P4.MaxLength = 10;
            this.tbSpdDT_P4.Name = "tbSpdDT_P4";
            this.tbSpdDT_P4.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P4.TabIndex = 167;
            this.tbSpdDT_P4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P4_KeyPress);
            // 
            // tbSpdDT_P3
            // 
            this.tbSpdDT_P3.Location = new System.Drawing.Point(167, 213);
            this.tbSpdDT_P3.MaxLength = 10;
            this.tbSpdDT_P3.Name = "tbSpdDT_P3";
            this.tbSpdDT_P3.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P3.TabIndex = 168;
            this.tbSpdDT_P3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P3_KeyPress);
            // 
            // tbSpdDT_P2
            // 
            this.tbSpdDT_P2.Location = new System.Drawing.Point(167, 186);
            this.tbSpdDT_P2.MaxLength = 10;
            this.tbSpdDT_P2.Name = "tbSpdDT_P2";
            this.tbSpdDT_P2.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P2.TabIndex = 169;
            this.tbSpdDT_P2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P2_KeyPress);
            // 
            // tbSpdDT_P1
            // 
            this.tbSpdDT_P1.Location = new System.Drawing.Point(167, 159);
            this.tbSpdDT_P1.MaxLength = 6;
            this.tbSpdDT_P1.Name = "tbSpdDT_P1";
            this.tbSpdDT_P1.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P1.TabIndex = 170;
            this.tbSpdDT_P1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P1_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(272, 294);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(42, 17);
            this.label24.TabIndex = 163;
            this.label24.Text = "pulse";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(54, 294);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 17);
            this.label9.TabIndex = 164;
            this.label9.Text = "Point-6 Speed :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(272, 267);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(42, 17);
            this.label23.TabIndex = 162;
            this.label23.Text = "pulse";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(54, 267);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 17);
            this.label10.TabIndex = 161;
            this.label10.Text = "Point-5 Speed :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(272, 240);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(42, 17);
            this.label22.TabIndex = 160;
            this.label22.Text = "pulse";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 17);
            this.label5.TabIndex = 159;
            this.label5.Text = "Point-4 Speed :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(272, 213);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(42, 17);
            this.label21.TabIndex = 158;
            this.label21.Text = "pulse";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(54, 213);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 17);
            this.label6.TabIndex = 157;
            this.label6.Text = "Point-3 Speed :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(272, 186);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(42, 17);
            this.label20.TabIndex = 156;
            this.label20.Text = "pulse";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 17);
            this.label3.TabIndex = 155;
            this.label3.Text = "Point-2 Speed :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(272, 159);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(42, 17);
            this.label19.TabIndex = 154;
            this.label19.Text = "pulse";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(54, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 17);
            this.label4.TabIndex = 153;
            this.label4.Text = "Point-1 Speed :";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(631, 100);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(101, 25);
            this.label36.TabIndex = 151;
            this.label36.Text = "BUSCAP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(67, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(224, 25);
            this.label2.TabIndex = 152;
            this.label2.Text = "Speed and Delay time";
            // 
            // tbSpdDT_P10
            // 
            this.tbSpdDT_P10.Location = new System.Drawing.Point(167, 403);
            this.tbSpdDT_P10.MaxLength = 10;
            this.tbSpdDT_P10.Name = "tbSpdDT_P10";
            this.tbSpdDT_P10.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P10.TabIndex = 184;
            this.tbSpdDT_P10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P10_KeyPress);
            // 
            // tbSpdDT_P9
            // 
            this.tbSpdDT_P9.Location = new System.Drawing.Point(167, 376);
            this.tbSpdDT_P9.MaxLength = 10;
            this.tbSpdDT_P9.Name = "tbSpdDT_P9";
            this.tbSpdDT_P9.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P9.TabIndex = 185;
            this.tbSpdDT_P9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P9_KeyPress);
            // 
            // tbSpdDT_P8
            // 
            this.tbSpdDT_P8.Location = new System.Drawing.Point(167, 349);
            this.tbSpdDT_P8.MaxLength = 10;
            this.tbSpdDT_P8.Name = "tbSpdDT_P8";
            this.tbSpdDT_P8.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P8.TabIndex = 186;
            this.tbSpdDT_P8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P8_KeyPress);
            // 
            // tbSpdDT_P7
            // 
            this.tbSpdDT_P7.Location = new System.Drawing.Point(167, 322);
            this.tbSpdDT_P7.MaxLength = 10;
            this.tbSpdDT_P7.Name = "tbSpdDT_P7";
            this.tbSpdDT_P7.Size = new System.Drawing.Size(100, 22);
            this.tbSpdDT_P7.TabIndex = 187;
            this.tbSpdDT_P7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpdDT_P7_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(272, 403);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 17);
            this.label11.TabIndex = 180;
            this.label11.Text = "pulse";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(46, 403);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(114, 17);
            this.label12.TabIndex = 179;
            this.label12.Text = "Point-10 Speed :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(272, 376);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 17);
            this.label13.TabIndex = 178;
            this.label13.Text = "pulse";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(54, 376);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(106, 17);
            this.label14.TabIndex = 177;
            this.label14.Text = "Point-9 Speed :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(272, 349);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 17);
            this.label15.TabIndex = 176;
            this.label15.Text = "pulse";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(54, 349);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(106, 17);
            this.label16.TabIndex = 175;
            this.label16.Text = "Point-8 Speed :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(272, 322);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(42, 17);
            this.label17.TabIndex = 174;
            this.label17.Text = "pulse";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(54, 322);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(106, 17);
            this.label18.TabIndex = 173;
            this.label18.Text = "Point-7 Speed :";
            // 
            // picSample
            // 
            this.picSample.BackgroundImage = global::UI_Common.Properties.Resources._22_333;
            this.picSample.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSample.Location = new System.Drawing.Point(443, 144);
            this.picSample.Name = "picSample";
            this.picSample.Size = new System.Drawing.Size(487, 325);
            this.picSample.TabIndex = 188;
            this.picSample.TabStop = false;
            // 
            // ucSpeedDelay_M1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.picSample);
            this.Controls.Add(this.tbSpdDT_P10);
            this.Controls.Add(this.tbSpdDT_P9);
            this.Controls.Add(this.tbSpdDT_P8);
            this.Controls.Add(this.tbSpdDT_P7);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.btnNozzleFirstSet_Save);
            this.Controls.Add(this.btnNozzle_Load);
            this.Controls.Add(this.tbSpdDT_P6);
            this.Controls.Add(this.tbSpdDT_P5);
            this.Controls.Add(this.tbSpdDT_P4);
            this.Controls.Add(this.tbSpdDT_P3);
            this.Controls.Add(this.tbSpdDT_P2);
            this.Controls.Add(this.tbSpdDT_P1);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ucSpeedDelay_M1";
            this.Size = new System.Drawing.Size(1000, 600);
            ((System.ComponentModel.ISupportInitialize)(this.picSample)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnNozzleFirstSet_Save;
        private System.Windows.Forms.Button btnNozzle_Load;
        private System.Windows.Forms.TextBox tbSpdDT_P6;
        private System.Windows.Forms.TextBox tbSpdDT_P5;
        private System.Windows.Forms.TextBox tbSpdDT_P4;
        private System.Windows.Forms.TextBox tbSpdDT_P3;
        private System.Windows.Forms.TextBox tbSpdDT_P2;
        private System.Windows.Forms.TextBox tbSpdDT_P1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbSpdDT_P10;
        private System.Windows.Forms.TextBox tbSpdDT_P9;
        private System.Windows.Forms.TextBox tbSpdDT_P8;
        private System.Windows.Forms.TextBox tbSpdDT_P7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox picSample;
    }
}
