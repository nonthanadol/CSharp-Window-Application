﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucErrorHistory : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;

        //Glue 2
        SqlConnection Conn = new SqlConnection(@"Data Source=DESKTOP-4AGMG63\SQLEXPRESS;Initial Catalog=GlueMC;integrated security=true;");

        public ucErrorHistory(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;

            Conn.Open();
            SqlDataAdapter SqlDa = new SqlDataAdapter("SELECT * FROM ERROR_View", Conn);
            DataTable dtbl = new DataTable();
            SqlDa.Fill(dtbl);
            dataGridView1.DataSource = dtbl;

            int nRowIndex = dataGridView1.Rows.Count - 2;
            dataGridView1.CurrentCell = dataGridView1.Rows[nRowIndex].Cells[0];
            Conn.Close();
            Thread.Sleep(1000);
        }
        public void UpdateUI()
        {
            if (Visible)
            {
                
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Conn.Open();
            SqlDataAdapter SqlDa = new SqlDataAdapter("SELECT * FROM ERROR_View", Conn);
            DataTable dtbl = new DataTable();
            SqlDa.Fill(dtbl);
            dataGridView1.DataSource = dtbl;

            int nRowIndex = dataGridView1.Rows.Count - 2;
            dataGridView1.CurrentCell = dataGridView1.Rows[nRowIndex].Cells[0];
            Conn.Close();
            Thread.Sleep(1000);
        }
    }
}
