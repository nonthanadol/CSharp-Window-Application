﻿
namespace UI_Common
{
    partial class ucMain
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbMain = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lbSigUp_R_acc = new System.Windows.Forms.Label();
            this.lbSigUp_L_acc = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbDownStopL2_IN = new System.Windows.Forms.Label();
            this.lbDownStopL2_OUT = new System.Windows.Forms.Label();
            this.pbDownCV_2 = new System.Windows.Forms.PictureBox();
            this.lbDownStopL1_OUT = new System.Windows.Forms.Label();
            this.lbDownStopL1_IN = new System.Windows.Forms.Label();
            this.lbSigUp_R_req = new System.Windows.Forms.Label();
            this.lbSigUp_L_req = new System.Windows.Forms.Label();
            this.lbDownChkPart_R = new System.Windows.Forms.Label();
            this.lbDownChkPart_L = new System.Windows.Forms.Label();
            this.lbDownChkPart_M = new System.Windows.Forms.Label();
            this.pbDownCV_1 = new System.Windows.Forms.PictureBox();
            this.lbUpStopR2_IN = new System.Windows.Forms.Label();
            this.lbUpStopR2_OUT = new System.Windows.Forms.Label();
            this.pbUpCV_2 = new System.Windows.Forms.PictureBox();
            this.lbUpStopR1_OUT = new System.Windows.Forms.Label();
            this.lbUpStopR1_IN = new System.Windows.Forms.Label();
            this.lbUpChkPart_R = new System.Windows.Forms.Label();
            this.lbUpChkPart_L = new System.Windows.Forms.Label();
            this.lbUpChkPart_M = new System.Windows.Forms.Label();
            this.lbRFID_R_OUT = new System.Windows.Forms.Label();
            this.lbRFID_R_IN = new System.Windows.Forms.Label();
            this.lbUpper_Lock = new System.Windows.Forms.Label();
            this.lbRFID_L_OUT = new System.Windows.Forms.Label();
            this.lbRFID_L_IN = new System.Windows.Forms.Label();
            this.lbUpper_UnLock = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pbUpCV_1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDownCV_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDownCV_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUpCV_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUpCV_1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbMain
            // 
            this.lbMain.BackColor = System.Drawing.Color.DodgerBlue;
            this.lbMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMain.Location = new System.Drawing.Point(0, 0);
            this.lbMain.Name = "lbMain";
            this.lbMain.Size = new System.Drawing.Size(1000, 40);
            this.lbMain.TabIndex = 0;
            this.lbMain.Text = "MAIN";
            this.lbMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(37, 71);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(913, 119);
            this.dataGridView1.TabIndex = 73;
            // 
            // lbSigUp_R_acc
            // 
            this.lbSigUp_R_acc.AutoSize = true;
            this.lbSigUp_R_acc.BackColor = System.Drawing.Color.LightGray;
            this.lbSigUp_R_acc.Location = new System.Drawing.Point(631, 315);
            this.lbSigUp_R_acc.Name = "lbSigUp_R_acc";
            this.lbSigUp_R_acc.Size = new System.Drawing.Size(37, 17);
            this.lbSigUp_R_acc.TabIndex = 184;
            this.lbSigUp_R_acc.Text = "  IN  ";
            // 
            // lbSigUp_L_acc
            // 
            this.lbSigUp_L_acc.AutoSize = true;
            this.lbSigUp_L_acc.BackColor = System.Drawing.Color.LightGray;
            this.lbSigUp_L_acc.Location = new System.Drawing.Point(953, 318);
            this.lbSigUp_L_acc.Name = "lbSigUp_L_acc";
            this.lbSigUp_L_acc.Size = new System.Drawing.Size(38, 17);
            this.lbSigUp_L_acc.TabIndex = 183;
            this.lbSigUp_L_acc.Text = "OUT";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(691, 318);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 17);
            this.label6.TabIndex = 182;
            this.label6.Text = "Up Left accept";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(821, 318);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 17);
            this.label4.TabIndex = 181;
            this.label4.Text = "Up Right accept";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(676, 506);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 17);
            this.label5.TabIndex = 180;
            this.label5.Text = "Down Left request";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(821, 506);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 17);
            this.label1.TabIndex = 179;
            this.label1.Text = "Down Right request";
            // 
            // lbDownStopL2_IN
            // 
            this.lbDownStopL2_IN.AutoSize = true;
            this.lbDownStopL2_IN.BackColor = System.Drawing.Color.LightGray;
            this.lbDownStopL2_IN.Location = new System.Drawing.Point(95, 568);
            this.lbDownStopL2_IN.Name = "lbDownStopL2_IN";
            this.lbDownStopL2_IN.Size = new System.Drawing.Size(75, 17);
            this.lbDownStopL2_IN.TabIndex = 178;
            this.lbDownStopL2_IN.Text = "Stopper IN";
            // 
            // lbDownStopL2_OUT
            // 
            this.lbDownStopL2_OUT.AutoSize = true;
            this.lbDownStopL2_OUT.BackColor = System.Drawing.Color.LightGray;
            this.lbDownStopL2_OUT.Location = new System.Drawing.Point(86, 526);
            this.lbDownStopL2_OUT.Name = "lbDownStopL2_OUT";
            this.lbDownStopL2_OUT.Size = new System.Drawing.Size(92, 17);
            this.lbDownStopL2_OUT.TabIndex = 177;
            this.lbDownStopL2_OUT.Text = "Stopper OUT";
            // 
            // pbDownCV_2
            // 
            this.pbDownCV_2.BackColor = System.Drawing.Color.Gray;
            this.pbDownCV_2.Location = new System.Drawing.Point(20, 546);
            this.pbDownCV_2.Name = "pbDownCV_2";
            this.pbDownCV_2.Size = new System.Drawing.Size(586, 19);
            this.pbDownCV_2.TabIndex = 176;
            this.pbDownCV_2.TabStop = false;
            // 
            // lbDownStopL1_OUT
            // 
            this.lbDownStopL1_OUT.AutoSize = true;
            this.lbDownStopL1_OUT.BackColor = System.Drawing.Color.LightGray;
            this.lbDownStopL1_OUT.Location = new System.Drawing.Point(86, 486);
            this.lbDownStopL1_OUT.Name = "lbDownStopL1_OUT";
            this.lbDownStopL1_OUT.Size = new System.Drawing.Size(92, 17);
            this.lbDownStopL1_OUT.TabIndex = 175;
            this.lbDownStopL1_OUT.Text = "Stopper OUT";
            // 
            // lbDownStopL1_IN
            // 
            this.lbDownStopL1_IN.AutoSize = true;
            this.lbDownStopL1_IN.BackColor = System.Drawing.Color.LightGray;
            this.lbDownStopL1_IN.Location = new System.Drawing.Point(95, 444);
            this.lbDownStopL1_IN.Name = "lbDownStopL1_IN";
            this.lbDownStopL1_IN.Size = new System.Drawing.Size(75, 17);
            this.lbDownStopL1_IN.TabIndex = 174;
            this.lbDownStopL1_IN.Text = "Stopper IN";
            // 
            // lbSigUp_R_req
            // 
            this.lbSigUp_R_req.AutoSize = true;
            this.lbSigUp_R_req.BackColor = System.Drawing.Color.LightGray;
            this.lbSigUp_R_req.Location = new System.Drawing.Point(630, 506);
            this.lbSigUp_R_req.Name = "lbSigUp_R_req";
            this.lbSigUp_R_req.Size = new System.Drawing.Size(38, 17);
            this.lbSigUp_R_req.TabIndex = 173;
            this.lbSigUp_R_req.Text = "OUT";
            // 
            // lbSigUp_L_req
            // 
            this.lbSigUp_L_req.AutoSize = true;
            this.lbSigUp_L_req.BackColor = System.Drawing.Color.LightGray;
            this.lbSigUp_L_req.Location = new System.Drawing.Point(954, 506);
            this.lbSigUp_L_req.Name = "lbSigUp_L_req";
            this.lbSigUp_L_req.Size = new System.Drawing.Size(37, 17);
            this.lbSigUp_L_req.TabIndex = 172;
            this.lbSigUp_L_req.Text = "  IN  ";
            // 
            // lbDownChkPart_R
            // 
            this.lbDownChkPart_R.AutoSize = true;
            this.lbDownChkPart_R.BackColor = System.Drawing.Color.LightGray;
            this.lbDownChkPart_R.Location = new System.Drawing.Point(17, 486);
            this.lbDownChkPart_R.Name = "lbDownChkPart_R";
            this.lbDownChkPart_R.Size = new System.Drawing.Size(63, 17);
            this.lbDownChkPart_R.TabIndex = 171;
            this.lbDownChkPart_R.Text = "Chk-Part";
            // 
            // lbDownChkPart_L
            // 
            this.lbDownChkPart_L.AutoSize = true;
            this.lbDownChkPart_L.BackColor = System.Drawing.Color.LightGray;
            this.lbDownChkPart_L.Location = new System.Drawing.Point(543, 486);
            this.lbDownChkPart_L.Name = "lbDownChkPart_L";
            this.lbDownChkPart_L.Size = new System.Drawing.Size(63, 17);
            this.lbDownChkPart_L.TabIndex = 170;
            this.lbDownChkPart_L.Text = "Chk-Part";
            // 
            // lbDownChkPart_M
            // 
            this.lbDownChkPart_M.AutoSize = true;
            this.lbDownChkPart_M.BackColor = System.Drawing.Color.LightGray;
            this.lbDownChkPart_M.Location = new System.Drawing.Point(279, 506);
            this.lbDownChkPart_M.Name = "lbDownChkPart_M";
            this.lbDownChkPart_M.Size = new System.Drawing.Size(63, 17);
            this.lbDownChkPart_M.TabIndex = 169;
            this.lbDownChkPart_M.Text = "Chk-Part";
            // 
            // pbDownCV_1
            // 
            this.pbDownCV_1.BackColor = System.Drawing.Color.Gray;
            this.pbDownCV_1.Location = new System.Drawing.Point(20, 464);
            this.pbDownCV_1.Name = "pbDownCV_1";
            this.pbDownCV_1.Size = new System.Drawing.Size(586, 19);
            this.pbDownCV_1.TabIndex = 168;
            this.pbDownCV_1.TabStop = false;
            // 
            // lbUpStopR2_IN
            // 
            this.lbUpStopR2_IN.AutoSize = true;
            this.lbUpStopR2_IN.BackColor = System.Drawing.Color.LightGray;
            this.lbUpStopR2_IN.Location = new System.Drawing.Point(455, 377);
            this.lbUpStopR2_IN.Name = "lbUpStopR2_IN";
            this.lbUpStopR2_IN.Size = new System.Drawing.Size(75, 17);
            this.lbUpStopR2_IN.TabIndex = 167;
            this.lbUpStopR2_IN.Text = "Stopper IN";
            // 
            // lbUpStopR2_OUT
            // 
            this.lbUpStopR2_OUT.AutoSize = true;
            this.lbUpStopR2_OUT.BackColor = System.Drawing.Color.LightGray;
            this.lbUpStopR2_OUT.Location = new System.Drawing.Point(445, 335);
            this.lbUpStopR2_OUT.Name = "lbUpStopR2_OUT";
            this.lbUpStopR2_OUT.Size = new System.Drawing.Size(92, 17);
            this.lbUpStopR2_OUT.TabIndex = 166;
            this.lbUpStopR2_OUT.Text = "Stopper OUT";
            // 
            // pbUpCV_2
            // 
            this.pbUpCV_2.BackColor = System.Drawing.Color.Gray;
            this.pbUpCV_2.Location = new System.Drawing.Point(20, 355);
            this.pbUpCV_2.Name = "pbUpCV_2";
            this.pbUpCV_2.Size = new System.Drawing.Size(586, 19);
            this.pbUpCV_2.TabIndex = 165;
            this.pbUpCV_2.TabStop = false;
            // 
            // lbUpStopR1_OUT
            // 
            this.lbUpStopR1_OUT.AutoSize = true;
            this.lbUpStopR1_OUT.BackColor = System.Drawing.Color.LightGray;
            this.lbUpStopR1_OUT.Location = new System.Drawing.Point(445, 295);
            this.lbUpStopR1_OUT.Name = "lbUpStopR1_OUT";
            this.lbUpStopR1_OUT.Size = new System.Drawing.Size(92, 17);
            this.lbUpStopR1_OUT.TabIndex = 164;
            this.lbUpStopR1_OUT.Text = "Stopper OUT";
            // 
            // lbUpStopR1_IN
            // 
            this.lbUpStopR1_IN.AutoSize = true;
            this.lbUpStopR1_IN.BackColor = System.Drawing.Color.LightGray;
            this.lbUpStopR1_IN.Location = new System.Drawing.Point(455, 253);
            this.lbUpStopR1_IN.Name = "lbUpStopR1_IN";
            this.lbUpStopR1_IN.Size = new System.Drawing.Size(75, 17);
            this.lbUpStopR1_IN.TabIndex = 163;
            this.lbUpStopR1_IN.Text = "Stopper IN";
            // 
            // lbUpChkPart_R
            // 
            this.lbUpChkPart_R.AutoSize = true;
            this.lbUpChkPart_R.BackColor = System.Drawing.Color.LightGray;
            this.lbUpChkPart_R.Location = new System.Drawing.Point(17, 295);
            this.lbUpChkPart_R.Name = "lbUpChkPart_R";
            this.lbUpChkPart_R.Size = new System.Drawing.Size(63, 17);
            this.lbUpChkPart_R.TabIndex = 162;
            this.lbUpChkPart_R.Text = "Chk-Part";
            // 
            // lbUpChkPart_L
            // 
            this.lbUpChkPart_L.AutoSize = true;
            this.lbUpChkPart_L.BackColor = System.Drawing.Color.LightGray;
            this.lbUpChkPart_L.Location = new System.Drawing.Point(543, 295);
            this.lbUpChkPart_L.Name = "lbUpChkPart_L";
            this.lbUpChkPart_L.Size = new System.Drawing.Size(63, 17);
            this.lbUpChkPart_L.TabIndex = 161;
            this.lbUpChkPart_L.Text = "Chk-Part";
            // 
            // lbUpChkPart_M
            // 
            this.lbUpChkPart_M.AutoSize = true;
            this.lbUpChkPart_M.BackColor = System.Drawing.Color.LightGray;
            this.lbUpChkPart_M.Location = new System.Drawing.Point(279, 315);
            this.lbUpChkPart_M.Name = "lbUpChkPart_M";
            this.lbUpChkPart_M.Size = new System.Drawing.Size(63, 17);
            this.lbUpChkPart_M.TabIndex = 160;
            this.lbUpChkPart_M.Text = "Chk-Part";
            // 
            // lbRFID_R_OUT
            // 
            this.lbRFID_R_OUT.AutoSize = true;
            this.lbRFID_R_OUT.BackColor = System.Drawing.Color.LightGray;
            this.lbRFID_R_OUT.Location = new System.Drawing.Point(366, 295);
            this.lbRFID_R_OUT.Name = "lbRFID_R_OUT";
            this.lbRFID_R_OUT.Size = new System.Drawing.Size(73, 17);
            this.lbRFID_R_OUT.TabIndex = 159;
            this.lbRFID_R_OUT.Text = "RFID OUT";
            // 
            // lbRFID_R_IN
            // 
            this.lbRFID_R_IN.AutoSize = true;
            this.lbRFID_R_IN.BackColor = System.Drawing.Color.LightGray;
            this.lbRFID_R_IN.Location = new System.Drawing.Point(375, 253);
            this.lbRFID_R_IN.Name = "lbRFID_R_IN";
            this.lbRFID_R_IN.Size = new System.Drawing.Size(56, 17);
            this.lbRFID_R_IN.TabIndex = 158;
            this.lbRFID_R_IN.Text = "RFID IN";
            // 
            // lbUpper_Lock
            // 
            this.lbUpper_Lock.AutoSize = true;
            this.lbUpper_Lock.BackColor = System.Drawing.Color.LightGray;
            this.lbUpper_Lock.Location = new System.Drawing.Point(289, 295);
            this.lbUpper_Lock.Name = "lbUpper_Lock";
            this.lbUpper_Lock.Size = new System.Drawing.Size(45, 17);
            this.lbUpper_Lock.TabIndex = 157;
            this.lbUpper_Lock.Text = "LOCK";
            // 
            // lbRFID_L_OUT
            // 
            this.lbRFID_L_OUT.AutoSize = true;
            this.lbRFID_L_OUT.BackColor = System.Drawing.Color.LightGray;
            this.lbRFID_L_OUT.Location = new System.Drawing.Point(184, 295);
            this.lbRFID_L_OUT.Name = "lbRFID_L_OUT";
            this.lbRFID_L_OUT.Size = new System.Drawing.Size(73, 17);
            this.lbRFID_L_OUT.TabIndex = 156;
            this.lbRFID_L_OUT.Text = "RFID OUT";
            // 
            // lbRFID_L_IN
            // 
            this.lbRFID_L_IN.AutoSize = true;
            this.lbRFID_L_IN.BackColor = System.Drawing.Color.LightGray;
            this.lbRFID_L_IN.Location = new System.Drawing.Point(192, 253);
            this.lbRFID_L_IN.Name = "lbRFID_L_IN";
            this.lbRFID_L_IN.Size = new System.Drawing.Size(56, 17);
            this.lbRFID_L_IN.TabIndex = 155;
            this.lbRFID_L_IN.Text = "RFID IN";
            // 
            // lbUpper_UnLock
            // 
            this.lbUpper_UnLock.AutoSize = true;
            this.lbUpper_UnLock.BackColor = System.Drawing.Color.LightGray;
            this.lbUpper_UnLock.Location = new System.Drawing.Point(279, 253);
            this.lbUpper_UnLock.Name = "lbUpper_UnLock";
            this.lbUpper_UnLock.Size = new System.Drawing.Size(65, 17);
            this.lbUpper_UnLock.TabIndex = 154;
            this.lbUpper_UnLock.Text = "UNLOCK";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Black;
            this.pictureBox7.Location = new System.Drawing.Point(805, 290);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(10, 71);
            this.pictureBox7.TabIndex = 153;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Black;
            this.pictureBox6.Location = new System.Drawing.Point(805, 480);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(10, 71);
            this.pictureBox6.TabIndex = 152;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Black;
            this.pictureBox5.Location = new System.Drawing.Point(3, 399);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(992, 10);
            this.pictureBox5.TabIndex = 151;
            this.pictureBox5.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 411);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(210, 25);
            this.label3.TabIndex = 150;
            this.label3.Text = "UNDER CONVEYER";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(208, 25);
            this.label2.TabIndex = 149;
            this.label2.Text = "UPPER CONVEYER";
            // 
            // pbUpCV_1
            // 
            this.pbUpCV_1.BackColor = System.Drawing.Color.Gray;
            this.pbUpCV_1.Location = new System.Drawing.Point(20, 273);
            this.pbUpCV_1.Name = "pbUpCV_1";
            this.pbUpCV_1.Size = new System.Drawing.Size(586, 19);
            this.pbUpCV_1.TabIndex = 148;
            this.pbUpCV_1.TabStop = false;
            // 
            // ucMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.lbSigUp_R_acc);
            this.Controls.Add(this.lbSigUp_L_acc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbDownStopL2_IN);
            this.Controls.Add(this.lbDownStopL2_OUT);
            this.Controls.Add(this.pbDownCV_2);
            this.Controls.Add(this.lbDownStopL1_OUT);
            this.Controls.Add(this.lbDownStopL1_IN);
            this.Controls.Add(this.lbSigUp_R_req);
            this.Controls.Add(this.lbSigUp_L_req);
            this.Controls.Add(this.lbDownChkPart_R);
            this.Controls.Add(this.lbDownChkPart_L);
            this.Controls.Add(this.lbDownChkPart_M);
            this.Controls.Add(this.pbDownCV_1);
            this.Controls.Add(this.lbUpStopR2_IN);
            this.Controls.Add(this.lbUpStopR2_OUT);
            this.Controls.Add(this.pbUpCV_2);
            this.Controls.Add(this.lbUpStopR1_OUT);
            this.Controls.Add(this.lbUpStopR1_IN);
            this.Controls.Add(this.lbUpChkPart_R);
            this.Controls.Add(this.lbUpChkPart_L);
            this.Controls.Add(this.lbUpChkPart_M);
            this.Controls.Add(this.lbRFID_R_OUT);
            this.Controls.Add(this.lbRFID_R_IN);
            this.Controls.Add(this.lbUpper_Lock);
            this.Controls.Add(this.lbRFID_L_OUT);
            this.Controls.Add(this.lbRFID_L_IN);
            this.Controls.Add(this.lbUpper_UnLock);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pbUpCV_1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lbMain);
            this.Name = "ucMain";
            this.Size = new System.Drawing.Size(1000, 600);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDownCV_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDownCV_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUpCV_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUpCV_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbMain;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lbSigUp_R_acc;
        private System.Windows.Forms.Label lbSigUp_L_acc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbDownStopL2_IN;
        private System.Windows.Forms.Label lbDownStopL2_OUT;
        private System.Windows.Forms.PictureBox pbDownCV_2;
        private System.Windows.Forms.Label lbDownStopL1_OUT;
        private System.Windows.Forms.Label lbDownStopL1_IN;
        private System.Windows.Forms.Label lbSigUp_R_req;
        private System.Windows.Forms.Label lbSigUp_L_req;
        private System.Windows.Forms.Label lbDownChkPart_R;
        private System.Windows.Forms.Label lbDownChkPart_L;
        private System.Windows.Forms.Label lbDownChkPart_M;
        private System.Windows.Forms.PictureBox pbDownCV_1;
        private System.Windows.Forms.Label lbUpStopR2_IN;
        private System.Windows.Forms.Label lbUpStopR2_OUT;
        private System.Windows.Forms.PictureBox pbUpCV_2;
        private System.Windows.Forms.Label lbUpStopR1_OUT;
        private System.Windows.Forms.Label lbUpStopR1_IN;
        private System.Windows.Forms.Label lbUpChkPart_R;
        private System.Windows.Forms.Label lbUpChkPart_L;
        private System.Windows.Forms.Label lbUpChkPart_M;
        private System.Windows.Forms.Label lbRFID_R_OUT;
        private System.Windows.Forms.Label lbRFID_R_IN;
        private System.Windows.Forms.Label lbUpper_Lock;
        private System.Windows.Forms.Label lbRFID_L_OUT;
        private System.Windows.Forms.Label lbRFID_L_IN;
        private System.Windows.Forms.Label lbUpper_UnLock;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbUpCV_1;
    }
}
