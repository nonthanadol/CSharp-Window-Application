﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucPQM : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;

        String sql;

        SqlConnection Conn;

        public ucPQM(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;

            #region Read warning & limit of component
            tbComp1_Limit.Text = _mainGUI.Common.iComponent_1_Limit.ToString();
            tbComp1_Warning.Text = _mainGUI.Common.iComponent_1_Warning.ToString();
            tbComp1_Usage.Text = _mainGUI.Common.iComponent_1_Usage.ToString();
            tbComp2_Limit.Text = _mainGUI.Common.iComponent_2_Limit.ToString();
            tbComp2_Warning.Text = _mainGUI.Common.iComponent_2_Warning.ToString();
            tbComp2_Usage.Text = _mainGUI.Common.iComponent_2_Usage.ToString();
            tbComp3_Limit.Text = _mainGUI.Common.iComponent_3_Limit.ToString();
            tbComp3_Warning.Text = _mainGUI.Common.iComponent_3_Warning.ToString();
            tbComp3_Usage.Text = _mainGUI.Common.iComponent_3_Usage.ToString();
            tbComp4_Limit.Text = _mainGUI.Common.iComponent_4_Limit.ToString();
            tbComp4_Warning.Text = _mainGUI.Common.iComponent_4_Warning.ToString();
            tbComp4_Usage.Text = _mainGUI.Common.iComponent_4_Usage.ToString();
            tbComp5_Limit.Text = _mainGUI.Common.iComponent_5_Limit.ToString();
            tbComp5_Warning.Text = _mainGUI.Common.iComponent_5_Warning.ToString();
            tbComp5_Usage.Text = _mainGUI.Common.iComponent_5_Usage.ToString();
            tbComp6_Limit.Text = _mainGUI.Common.iComponent_6_Limit.ToString();
            tbComp6_Warning.Text = _mainGUI.Common.iComponent_6_Warning.ToString();
            tbComp6_Usage.Text = _mainGUI.Common.iComponent_6_Usage.ToString();
            tbComp7_Limit.Text = _mainGUI.Common.iComponent_7_Limit.ToString();
            tbComp7_Warning.Text = _mainGUI.Common.iComponent_7_Warning.ToString();
            tbComp7_Usage.Text = _mainGUI.Common.iComponent_7_Usage.ToString();
            tbComp8_Limit.Text = _mainGUI.Common.iComponent_8_Limit.ToString();
            tbComp8_Warning.Text = _mainGUI.Common.iComponent_8_Warning.ToString();
            tbComp8_Usage.Text = _mainGUI.Common.iComponent_8_Usage.ToString();
            tbComp9_Limit.Text = _mainGUI.Common.iComponent_9_Limit.ToString();
            tbComp9_Warning.Text = _mainGUI.Common.iComponent_9_Warning.ToString();
            tbComp9_Usage.Text = _mainGUI.Common.iComponent_9_Usage.ToString();
            tbComp10_Limit.Text = _mainGUI.Common.iComponent_10_Limit.ToString();
            tbComp10_Warning.Text = _mainGUI.Common.iComponent_10_Warning.ToString();
            tbComp10_Usage.Text = _mainGUI.Common.iComponent_10_Usage.ToString();
            tbComp11_Limit.Text = _mainGUI.Common.iComponent_11_Limit.ToString();
            tbComp11_Warning.Text = _mainGUI.Common.iComponent_11_Warning.ToString();
            tbComp11_Usage.Text = _mainGUI.Common.iComponent_11_Usage.ToString();
            tbComp12_Limit.Text = _mainGUI.Common.iComponent_12_Limit.ToString();
            tbComp12_Warning.Text = _mainGUI.Common.iComponent_12_Warning.ToString();
            tbComp12_Usage.Text = _mainGUI.Common.iComponent_12_Usage.ToString();
            tbComp13_Limit.Text = _mainGUI.Common.iComponent_13_Limit.ToString();
            tbComp13_Warning.Text = _mainGUI.Common.iComponent_13_Warning.ToString();
            tbComp13_Usage.Text = _mainGUI.Common.iComponent_13_Usage.ToString();
            tbComp14_Limit.Text = _mainGUI.Common.iComponent_14_Limit.ToString();
            tbComp14_Warning.Text = _mainGUI.Common.iComponent_14_Warning.ToString();
            tbComp14_Usage.Text = _mainGUI.Common.iComponent_14_Usage.ToString();
            tbComp15_Limit.Text = _mainGUI.Common.iComponent_15_Limit.ToString();
            tbComp15_Warning.Text = _mainGUI.Common.iComponent_15_Warning.ToString();
            tbComp15_Usage.Text = _mainGUI.Common.iComponent_15_Usage.ToString();
            #endregion

            _mainGUI.Common.bChkPQM_BYPASS = Convert.ToBoolean(_mainGUI.Common.Config.ReadValue("OptionSelect", "PQM_bypass").ToString());
            if (_mainGUI.Common.bChkPQM_BYPASS)
            {
                _mainGUI.Common.bChkPQM_BYPASS = true;
                _mainGUI.Common.Config.WriteValue("OptionSelect", "PQM_bypass", _mainGUI.Common.bChkPQM_BYPASS.ToString());
                btnPQM_BYPASS.Text = "PQM BYPASS";
                btnPQM_BYPASS.BackColor = Color.Red;
            }
            else
            {
                _mainGUI.Common.bChkPQM_BYPASS = false;
                _mainGUI.Common.Config.WriteValue("OptionSelect", "PQM_bypass", _mainGUI.Common.bChkPQM_BYPASS.ToString());
                btnPQM_BYPASS.Text = "PQM UPDATE";
                btnPQM_BYPASS.BackColor = Color.LawnGreen;
            }

        }

        public void UpdateUI()
        {
            if (Visible)
            {
                tbStatus.Text = Convert.ToString(_mainGUI.Common.iPQM_Status);
                tbStatusCode.Text = Convert.ToString(_mainGUI.Common.iPQM_Status_Code);
                tbPassQty.Text = Convert.ToString(_mainGUI.Common.iPQM_PassQty);
                tbFailQty.Text = Convert.ToString(_mainGUI.Common.iPQM_FailQty);
                tbErrorCount.Text = Convert.ToString(_mainGUI.Common.iPQM_Error_Count);
                tbErrorTime.Text = Convert.ToString(_mainGUI.Common.iPQM_Error_Time);
                tbCycleTime.Text = Convert.ToString(_mainGUI.Common.iPQM_Cycle_Time);
                tbRunningTime.Text = Convert.ToString(_mainGUI.Common.iPQM_Running_Time);
                tbWaitingTime.Text = Convert.ToString(_mainGUI.Common.iPQM_Waiting_Time);
                tbInputQty.Text = Convert.ToString(_mainGUI.Common.iPQM_InputQty);
                tbSelfcheck.Text = Convert.ToString(_mainGUI.Common.iPQM_Self_Check);
                tbCT_M.Text = "0";
                tbCT_Q.Text = "0";

                #region LifeTime Usage Update
                tbComp1_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_1_Usage ").ToString();
                tbComp2_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_2_Usage ").ToString();
                tbComp3_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_3_Usage ").ToString();
                tbComp4_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_4_Usage ").ToString();
                tbComp5_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_5_Usage ").ToString();
                tbComp6_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_6_Usage ").ToString();
                tbComp7_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_7_Usage ").ToString();
                tbComp8_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_8_Usage ").ToString();
                tbComp9_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_9_Usage ").ToString();
                tbComp10_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_10_Usage ").ToString();
                tbComp11_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_11_Usage ").ToString();
                tbComp12_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_12_Usage ").ToString();
                tbComp13_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_13_Usage ").ToString();
                tbComp14_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_14_Usage ").ToString();
                tbComp15_Usage.Text = _mainGUI.Common.Config.ReadValue("LifeTime", "Component_15_Usage ").ToString();
                #endregion

            }

            #region PQM Machine ID
            tbMachineID.Text = _mainGUI.Common.Config.ReadValue("PQM", "MachineID").ToString();
            #endregion

            #region PQM Machine Status
            if (_mainGUI.Common.bFlgInitial_Finished && _mainGUI.Common.bChkMC_RUN_STOP && _mainGUI.Common.bFlgAutoRun_onWork && !_mainGUI.Common.bChkPauseButtonPush && !_mainGUI.Common.bChkAlarm)
            {
                if (_mainGUI.Common.bChkAreaSensor && _mainGUI.Common.IOTable.DI[0, 0].State && _mainGUI.Common.IOTable.DI[0, 3].State)
                {
                    _mainGUI.Common.iPQM_Status = 0; // Machine Running
                    _mainGUI.Common.IOTable.DO[0, 10].Reset();//Reset red light
                    _mainGUI.Common.IOTable.DO[0, 11].Reset();//Reset Yellow light
                    _mainGUI.Common.IOTable.DO[0, 12].Set();//Set Green light
                }
                else if (!_mainGUI.Common.bChkAreaSensor)
                {
                    _mainGUI.Common.iPQM_Status = 0; // Machine Running
                    _mainGUI.Common.IOTable.DO[0, 10].Reset();//Reset red light
                    _mainGUI.Common.IOTable.DO[0, 11].Reset();//Reset Yellow light
                    _mainGUI.Common.IOTable.DO[0, 12].Set();//Set Green light
                }
            }
            else if (!_mainGUI.Common.bChkPauseButtonPush && _mainGUI.Common.bChkAlarm)
            {
                _mainGUI.Common.iPQM_Status = 1; // Machine Error
            }
            else if (_mainGUI.Common.bChkPauseButtonPush && !_mainGUI.Common.bChkAlarm)
            {
                _mainGUI.Common.iPQM_Status = 2; // Machine Pause
                _mainGUI.Common.IOTable.DO[0, 10].Reset();//Reset red light
                _mainGUI.Common.IOTable.DO[0, 11].Set();//Set Yellow light
                _mainGUI.Common.IOTable.DO[0, 12].Reset();//Reset Green light

            }
            else
            {
                _mainGUI.Common.IOTable.DO[0, 10].Reset();//Reset red light
                _mainGUI.Common.IOTable.DO[0, 11].Set();//Set Yellow light
                _mainGUI.Common.IOTable.DO[0, 12].Reset();//Reset Green light
            }
            if (!_mainGUI.Common.bChkMC_RUN_STOP && !_mainGUI.Common.bChkPauseButtonPush && !_mainGUI.Common.bChkAlarm)
            {
                _mainGUI.Common.iPQM_Status = 3; // Machine Standby (No production)
            }
            if (_mainGUI.Common.bFlgInitial_Finished && _mainGUI.Common.bChkMC_RUN_STOP && !_mainGUI.Common.bFlgAutoRun_onWork && !_mainGUI.Common.bChkPauseButtonPush && !_mainGUI.Common.bChkAlarm)
            {
                _mainGUI.Common.iPQM_Status = 4; // Machine wait for material
            }
            if (_mainGUI.Common.bFlgAutoRun_onWork && _mainGUI.Common.bChkAreaSensor && (!_mainGUI.Common.IOTable.DI[0, 0].State || !_mainGUI.Common.IOTable.DI[0, 3].State))
            {
                _mainGUI.Common.iPQM_Status = 10; // Safety Error

                _mainGUI.Common.IOTable.DO[0, 10].Set();//Set red light
                _mainGUI.Common.IOTable.DO[0, 11].Reset();//Reset Yellow light
                _mainGUI.Common.IOTable.DO[0, 12].Reset();//Reset Green light
                _mainGUI.Common.IOTable.DO[0, 13].Set();//Buzzer on and off for alarm
                Thread.Sleep(500);
                _mainGUI.Common.IOTable.DO[0, 13].Reset();
                _mainGUI.Common.IOTable.DO[0, 10].Reset();//Reset red light
                Thread.Sleep(500);
            }
            #endregion
            #region PQM Status Code
            if (_mainGUI.Common.bChkAlarm)
            {
                if (_mainGUI.Common.strErrorCode == "ERR_001") { _mainGUI.Common.iPQM_Status_Code = 1; }
                if (_mainGUI.Common.strErrorCode == "ERR_002") { _mainGUI.Common.iPQM_Status_Code = 2; }
                if (_mainGUI.Common.strErrorCode == "ERR_003") { _mainGUI.Common.iPQM_Status_Code = 3; }
                if (_mainGUI.Common.strErrorCode == "ERR_004") { _mainGUI.Common.iPQM_Status_Code = 4; }
                if (_mainGUI.Common.strErrorCode == "ERR_005") { _mainGUI.Common.iPQM_Status_Code = 5; }
                if (_mainGUI.Common.strErrorCode == "ERR_006") { _mainGUI.Common.iPQM_Status_Code = 6; }
                if (_mainGUI.Common.strErrorCode == "ERR_007") { _mainGUI.Common.iPQM_Status_Code = 7; }
                if (_mainGUI.Common.strErrorCode == "ERR_008") { _mainGUI.Common.iPQM_Status_Code = 8; }
                if (_mainGUI.Common.strErrorCode == "ERR_009") { _mainGUI.Common.iPQM_Status_Code = 9; }
                if (_mainGUI.Common.strErrorCode == "ERR_010") { _mainGUI.Common.iPQM_Status_Code = 10; }
                if (_mainGUI.Common.strErrorCode == "ERR_011") { _mainGUI.Common.iPQM_Status_Code = 11; }
                if (_mainGUI.Common.strErrorCode == "ERR_012") { _mainGUI.Common.iPQM_Status_Code = 12; }
                if (_mainGUI.Common.strErrorCode == "ERR_013") { _mainGUI.Common.iPQM_Status_Code = 13; }
                if (_mainGUI.Common.strErrorCode == "ERR_014") { _mainGUI.Common.iPQM_Status_Code = 14; }
                if (_mainGUI.Common.strErrorCode == "ERR_015") { _mainGUI.Common.iPQM_Status_Code = 15; }
            }
            else { _mainGUI.Common.iPQM_Status_Code = 0; }


            #endregion

            #region PQM Pass Q'ty
            //IN AUTO CLASS
            #endregion
            #region PQM Fail Q'ty
            //IN ERROR CLASS
            #endregion
            #region PQM Error count
            //IN ERROR CLASS
            #endregion

            #region PQM Error time
            //IN FORM_MAIN
            #endregion
            #region PQM Cycle time
            //IN FORM_MAIN
            #endregion
            #region PQM Running time
            //IN FORM_MAIN
            #endregion
            #region PQM Waiting time
            //IN FORM_MAIN
            #endregion

            #region PQM Input Q'ty
            //IN AUTO CLASS
            #endregion

            #region PQM Self check
            //Fix
            _mainGUI.Common.iPQM_Self_Check = 1;
            #endregion
            #region PQM CT-M
            //Fix
            #endregion
            #region PQM CT-Q
            //Fix
            #endregion


            #region LifeTime
            if(_mainGUI.Common.IOTable.DO[1, 0].State && !_mainGUI.Common.bChkCompo_1)//Stopper Upper
            {
                _mainGUI.Common.bChkCompo_1 = true;
                _mainGUI.Common.iComponent_1_Usage++;
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_1_Usage ", Convert.ToString(_mainGUI.Common.iComponent_1_Usage));
            }
            else if (!_mainGUI.Common.IOTable.DO[1, 0].State && _mainGUI.Common.bChkCompo_1) { _mainGUI.Common.bChkCompo_1 = false; }

            if (_mainGUI.Common.IOTable.DO[1, 7].State && !_mainGUI.Common.bChkCompo_2)//Stopper Under
            {
                _mainGUI.Common.bChkCompo_2 = true;
                _mainGUI.Common.iComponent_2_Usage++;
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_2_Usage ", Convert.ToString(_mainGUI.Common.iComponent_2_Usage));
            }
            else if (!_mainGUI.Common.IOTable.DO[1, 7].State && _mainGUI.Common.bChkCompo_2) { _mainGUI.Common.bChkCompo_2 = false; }

            if (_mainGUI.Common.IOTable.DO[1, 14].State && !_mainGUI.Common.bChkCompo_3)//Clamp - Un-Clamp
            {
                _mainGUI.Common.bChkCompo_3 = true;
                _mainGUI.Common.iComponent_3_Usage++;
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_3_Usage ", Convert.ToString(_mainGUI.Common.iComponent_3_Usage));
            }
            else if (!_mainGUI.Common.IOTable.DO[1, 14].State && _mainGUI.Common.bChkCompo_3) { _mainGUI.Common.bChkCompo_3 = false; }

            if (_mainGUI.Common.IOTable.DO[2, 0].State && !_mainGUI.Common.bChkCompo_4)//RFID-L
            {
                _mainGUI.Common.bChkCompo_4 = true;
                _mainGUI.Common.iComponent_4_Usage++;
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_4_Usage ", Convert.ToString(_mainGUI.Common.iComponent_4_Usage));
            }
            else if (!_mainGUI.Common.IOTable.DO[2, 0].State && _mainGUI.Common.bChkCompo_4) { _mainGUI.Common.bChkCompo_4 = false; }

            if (_mainGUI.Common.IOTable.DO[2, 2].State && !_mainGUI.Common.bChkCompo_5)//RFID-R
            {
                _mainGUI.Common.bChkCompo_5 = true;
                _mainGUI.Common.iComponent_5_Usage++;
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_5_Usage ", Convert.ToString(_mainGUI.Common.iComponent_5_Usage));
            }
            else if (!_mainGUI.Common.IOTable.DO[2, 2].State && _mainGUI.Common.bChkCompo_5) { _mainGUI.Common.bChkCompo_5 = false; }


            #endregion

        }

        #region Key press
        private void tbComp1_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp1_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp2_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp2_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp3_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp3_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp4_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp4_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp5_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp5_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp6_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp6_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp7_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp7_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp8_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp8_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp9_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp9_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp10_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp10_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp11_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp11_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp12_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp12_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp13_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp13_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp14_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp14_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp15_Limit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbComp15_Warning_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        #endregion
        #region MOUSE CLICK EVENT
        private void btnPassQty_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset Pass Q'ty?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();

                _mainGUI.Common.iPQM_PassQty = 0;

                sql = "UPDATE dbo.PQM_Data SET Pass_Qty = " + _mainGUI.Common.iPQM_PassQty + " WHERE ID = '" + "1" + "';";
                using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
            }
            CallPQM_Data();
        }

        private void btnFailQty_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset Fail Q'ty?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();

                _mainGUI.Common.iPQM_FailQty = 0;

                sql = "UPDATE dbo.PQM_Data SET Fail_Qty = " + _mainGUI.Common.iPQM_FailQty + " WHERE ID = '" + "1" + "';";
                using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
            }
            CallPQM_Data();
        }

        private void btnErrorCount_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset Error count?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();

                _mainGUI.Common.iPQM_Error_Count = 0;

                sql = "UPDATE dbo.PQM_Data SET Error_Count = " + _mainGUI.Common.iPQM_Error_Count + " WHERE ID = '" + "1" + "';";
                using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
            }
            CallPQM_Data();
        }

        private void btnRunTime_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset Run time?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();

                _mainGUI.Common.iPQM_Running_Time = 0;

                sql = "UPDATE dbo.PQM_Data SET Running_Time = " + _mainGUI.Common.iPQM_Running_Time + " WHERE ID = '" + "1" + "';";
                using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
            }
            CallPQM_Data();
        }

        private void btnInputQty_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset Input?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                Conn = new SqlConnection(_mainGUI.Common.Connection_String);
                Conn.Open();

                _mainGUI.Common.iPQM_InputQty = 0;

                sql = "UPDATE dbo.PQM_Data SET Input_Qty = " + _mainGUI.Common.iPQM_InputQty + " WHERE ID = '" + "1" + "';";
                using (SqlCommand commandd = new SqlCommand(sql, Conn)) { commandd.ExecuteNonQuery(); }
            }
            CallPQM_Data();
        }

        private void tbComp1_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_1_Usage ", "0");
                _mainGUI.Common.iComponent_1_Usage = 0;
            }
        }

        private void tbComp2_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_2_Usage ", "0");
                _mainGUI.Common.iComponent_2_Usage = 0;
            }
        }

        private void tbComp3_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_3_Usage ", "0");
                _mainGUI.Common.iComponent_3_Usage = 0;
            }
        }

        private void tbComp4_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_4_Usage ", "0");
                _mainGUI.Common.iComponent_4_Usage = 0;
            }
        }

        private void tbComp5_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_5_Usage ", "0");
                _mainGUI.Common.iComponent_5_Usage = 0;
            }
        }

        private void tbComp6_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_6_Usage ", "0");
                _mainGUI.Common.iComponent_6_Usage = 0;
            }
        }

        private void tbComp7_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_7_Usage ", "0");
                _mainGUI.Common.iComponent_7_Usage = 0;
            }
        }

        private void tbComp8_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_8_Usage ", "0");
                _mainGUI.Common.iComponent_8_Usage = 0;
            }
        }

        private void tbComp9_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_9_Usage ", "0");
                _mainGUI.Common.iComponent_9_Usage = 0;
            }
        }

        private void tbComp10_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_10_Usage ", "0");
                _mainGUI.Common.iComponent_10_Usage = 0;
            }
        }

        private void tbComp11_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_11_Usage ", "0");
                _mainGUI.Common.iComponent_11_Usage = 0;
            }
        }

        private void tbComp12_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_12_Usage ", "0");
                _mainGUI.Common.iComponent_12_Usage = 0;
            }
        }

        private void tbComp13_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_13_Usage ", "0");
                _mainGUI.Common.iComponent_13_Usage = 0;
            }
        }

        private void tbComp14_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_14_Usage ", "0");
                _mainGUI.Common.iComponent_14_Usage = 0;
            }
        }

        private void tbComp15_Reset_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset usage?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("LifeTime", "Component_15_Usage ", "0");
                _mainGUI.Common.iComponent_15_Usage = 0;
            }
        }
        #endregion

        public void CallPQM_Data()
        {
            Conn = new SqlConnection(_mainGUI.Common.Connection_String);
            Conn.Open();
            sql = "SELECT * FROM dbo.PQM_Data_View WHERE ID = '" + "1" + "';";

            using (SqlCommand commandd = new SqlCommand(sql, Conn))
            {
                SqlDataReader SQLRead = commandd.ExecuteReader();
                while (SQLRead.Read())
                {
                    _mainGUI.Common.iPQM_PassQty = SQLRead.GetInt32(1);
                    _mainGUI.Common.iPQM_FailQty = SQLRead.GetInt32(2);
                    _mainGUI.Common.iPQM_Error_Count = SQLRead.GetInt32(3);
                    _mainGUI.Common.iPQM_InputQty = SQLRead.GetInt32(5);
                }
            }
        }

        private void btnPQM_BYPASS_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkPQM_BYPASS)
            {
                _mainGUI.Common.bChkPQM_BYPASS = false;
                _mainGUI.Common.Config.WriteValue("OptionSelect", "PQM_bypass", _mainGUI.Common.bChkPQM_BYPASS.ToString());
                btnPQM_BYPASS.Text = "PQM UPDATE";
                btnPQM_BYPASS.BackColor = Color.LawnGreen;
            }
            else
            {
                _mainGUI.Common.bChkPQM_BYPASS = true;
                _mainGUI.Common.Config.WriteValue("OptionSelect", "PQM_bypass", _mainGUI.Common.bChkPQM_BYPASS.ToString());
                btnPQM_BYPASS.Text = "PQM BYPASS";
                btnPQM_BYPASS.BackColor = Color.Red;
            }
        }
    }
}
