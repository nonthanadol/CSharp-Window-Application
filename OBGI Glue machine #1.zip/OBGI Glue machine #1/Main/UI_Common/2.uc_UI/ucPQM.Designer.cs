﻿
namespace UI_Common
{
    partial class ucPQM
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tbMachineID = new System.Windows.Forms.TextBox();
            this.tbBarcodeID = new System.Windows.Forms.TextBox();
            this.tbStatus = new System.Windows.Forms.TextBox();
            this.tbStatusCode = new System.Windows.Forms.TextBox();
            this.tbPassQty = new System.Windows.Forms.TextBox();
            this.tbFailQty = new System.Windows.Forms.TextBox();
            this.tbErrorCount = new System.Windows.Forms.TextBox();
            this.tbErrorTime = new System.Windows.Forms.TextBox();
            this.tbCycleTime = new System.Windows.Forms.TextBox();
            this.tbRunningTime = new System.Windows.Forms.TextBox();
            this.tbWaitingTime = new System.Windows.Forms.TextBox();
            this.tbInputQty = new System.Windows.Forms.TextBox();
            this.tbSelfcheck = new System.Windows.Forms.TextBox();
            this.tbCT_M = new System.Windows.Forms.TextBox();
            this.tbCT_Q = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.tbComp2_Limit = new System.Windows.Forms.TextBox();
            this.tbComp2_Warning = new System.Windows.Forms.TextBox();
            this.tbComp2_Usage = new System.Windows.Forms.TextBox();
            this.tbComp1_Limit = new System.Windows.Forms.TextBox();
            this.tbComp1_Warning = new System.Windows.Forms.TextBox();
            this.tbComp1_Usage = new System.Windows.Forms.TextBox();
            this.tbComp3_Limit = new System.Windows.Forms.TextBox();
            this.tbComp3_Warning = new System.Windows.Forms.TextBox();
            this.tbComp3_Usage = new System.Windows.Forms.TextBox();
            this.tbComp4_Limit = new System.Windows.Forms.TextBox();
            this.tbComp4_Warning = new System.Windows.Forms.TextBox();
            this.tbComp4_Usage = new System.Windows.Forms.TextBox();
            this.tbComp5_Limit = new System.Windows.Forms.TextBox();
            this.tbComp5_Warning = new System.Windows.Forms.TextBox();
            this.tbComp5_Usage = new System.Windows.Forms.TextBox();
            this.tbComp6_Limit = new System.Windows.Forms.TextBox();
            this.tbComp6_Warning = new System.Windows.Forms.TextBox();
            this.tbComp6_Usage = new System.Windows.Forms.TextBox();
            this.tbComp7_Limit = new System.Windows.Forms.TextBox();
            this.tbComp7_Warning = new System.Windows.Forms.TextBox();
            this.tbComp7_Usage = new System.Windows.Forms.TextBox();
            this.tbComp8_Limit = new System.Windows.Forms.TextBox();
            this.tbComp8_Warning = new System.Windows.Forms.TextBox();
            this.tbComp8_Usage = new System.Windows.Forms.TextBox();
            this.tbComp9_Limit = new System.Windows.Forms.TextBox();
            this.tbComp9_Warning = new System.Windows.Forms.TextBox();
            this.tbComp9_Usage = new System.Windows.Forms.TextBox();
            this.tbComp10_Limit = new System.Windows.Forms.TextBox();
            this.tbComp10_Warning = new System.Windows.Forms.TextBox();
            this.tbComp10_Usage = new System.Windows.Forms.TextBox();
            this.tbComp11_Limit = new System.Windows.Forms.TextBox();
            this.tbComp11_Warning = new System.Windows.Forms.TextBox();
            this.tbComp11_Usage = new System.Windows.Forms.TextBox();
            this.tbComp12_Limit = new System.Windows.Forms.TextBox();
            this.tbComp12_Warning = new System.Windows.Forms.TextBox();
            this.tbComp12_Usage = new System.Windows.Forms.TextBox();
            this.tbComp13_Limit = new System.Windows.Forms.TextBox();
            this.tbComp13_Warning = new System.Windows.Forms.TextBox();
            this.tbComp13_Usage = new System.Windows.Forms.TextBox();
            this.tbComp14_Limit = new System.Windows.Forms.TextBox();
            this.tbComp14_Warning = new System.Windows.Forms.TextBox();
            this.tbComp14_Usage = new System.Windows.Forms.TextBox();
            this.tbComp15_Limit = new System.Windows.Forms.TextBox();
            this.tbComp15_Warning = new System.Windows.Forms.TextBox();
            this.tbComp15_Usage = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.tbComp1_Reset = new System.Windows.Forms.Button();
            this.tbComp2_Reset = new System.Windows.Forms.Button();
            this.tbComp3_Reset = new System.Windows.Forms.Button();
            this.tbComp4_Reset = new System.Windows.Forms.Button();
            this.tbComp5_Reset = new System.Windows.Forms.Button();
            this.tbComp6_Reset = new System.Windows.Forms.Button();
            this.tbComp7_Reset = new System.Windows.Forms.Button();
            this.tbComp8_Reset = new System.Windows.Forms.Button();
            this.tbComp9_Reset = new System.Windows.Forms.Button();
            this.tbComp10_Reset = new System.Windows.Forms.Button();
            this.tbComp11_Reset = new System.Windows.Forms.Button();
            this.tbComp12_Reset = new System.Windows.Forms.Button();
            this.tbComp13_Reset = new System.Windows.Forms.Button();
            this.tbComp14_Reset = new System.Windows.Forms.Button();
            this.tbComp15_Reset = new System.Windows.Forms.Button();
            this.btnPassQty_Reset = new System.Windows.Forms.Button();
            this.btnFailQty_Reset = new System.Windows.Forms.Button();
            this.btnErrorCount_Reset = new System.Windows.Forms.Button();
            this.btnRunTime_Reset = new System.Windows.Forms.Button();
            this.btnInputQty_Reset = new System.Windows.Forms.Button();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.btnPQM_BYPASS = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1000, 40);
            this.label1.TabIndex = 4;
            this.label1.Text = "PQM | LIFETIME";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 304);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 17);
            this.label8.TabIndex = 5;
            this.label8.Text = "Error count";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Pass Q\'ty";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Status Code";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 332);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 17);
            this.label10.TabIndex = 6;
            this.label10.Text = "Error time";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(51, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Status";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 388);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 17);
            this.label9.TabIndex = 5;
            this.label9.Text = "Running time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Barcode ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Fail Q\'ty";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 416);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 17);
            this.label11.TabIndex = 6;
            this.label11.Text = "Waiting time";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(27, 360);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 17);
            this.label12.TabIndex = 7;
            this.label12.Text = "Cycle time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Machine ID";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(26, 472);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 17);
            this.label14.TabIndex = 5;
            this.label14.Text = "Self check";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(31, 444);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 17);
            this.label13.TabIndex = 7;
            this.label13.Text = "Input Q\'ty";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(57, 500);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 17);
            this.label15.TabIndex = 6;
            this.label15.Text = "CT-M";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(57, 528);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 17);
            this.label16.TabIndex = 7;
            this.label16.Text = "CT-Q";
            // 
            // tbMachineID
            // 
            this.tbMachineID.Location = new System.Drawing.Point(105, 136);
            this.tbMachineID.Name = "tbMachineID";
            this.tbMachineID.ReadOnly = true;
            this.tbMachineID.Size = new System.Drawing.Size(193, 22);
            this.tbMachineID.TabIndex = 8;
            this.tbMachineID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBarcodeID
            // 
            this.tbBarcodeID.Location = new System.Drawing.Point(105, 164);
            this.tbBarcodeID.Name = "tbBarcodeID";
            this.tbBarcodeID.ReadOnly = true;
            this.tbBarcodeID.Size = new System.Drawing.Size(193, 22);
            this.tbBarcodeID.TabIndex = 8;
            this.tbBarcodeID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbStatus
            // 
            this.tbStatus.Location = new System.Drawing.Point(105, 192);
            this.tbStatus.Name = "tbStatus";
            this.tbStatus.ReadOnly = true;
            this.tbStatus.Size = new System.Drawing.Size(193, 22);
            this.tbStatus.TabIndex = 8;
            this.tbStatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbStatusCode
            // 
            this.tbStatusCode.Location = new System.Drawing.Point(105, 220);
            this.tbStatusCode.Name = "tbStatusCode";
            this.tbStatusCode.ReadOnly = true;
            this.tbStatusCode.Size = new System.Drawing.Size(193, 22);
            this.tbStatusCode.TabIndex = 8;
            this.tbStatusCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbPassQty
            // 
            this.tbPassQty.Location = new System.Drawing.Point(105, 248);
            this.tbPassQty.Name = "tbPassQty";
            this.tbPassQty.ReadOnly = true;
            this.tbPassQty.Size = new System.Drawing.Size(193, 22);
            this.tbPassQty.TabIndex = 8;
            this.tbPassQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFailQty
            // 
            this.tbFailQty.Location = new System.Drawing.Point(105, 276);
            this.tbFailQty.Name = "tbFailQty";
            this.tbFailQty.ReadOnly = true;
            this.tbFailQty.Size = new System.Drawing.Size(193, 22);
            this.tbFailQty.TabIndex = 8;
            this.tbFailQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbErrorCount
            // 
            this.tbErrorCount.Location = new System.Drawing.Point(105, 304);
            this.tbErrorCount.Name = "tbErrorCount";
            this.tbErrorCount.ReadOnly = true;
            this.tbErrorCount.Size = new System.Drawing.Size(193, 22);
            this.tbErrorCount.TabIndex = 8;
            this.tbErrorCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbErrorTime
            // 
            this.tbErrorTime.Location = new System.Drawing.Point(105, 332);
            this.tbErrorTime.Name = "tbErrorTime";
            this.tbErrorTime.ReadOnly = true;
            this.tbErrorTime.Size = new System.Drawing.Size(193, 22);
            this.tbErrorTime.TabIndex = 8;
            this.tbErrorTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbCycleTime
            // 
            this.tbCycleTime.Location = new System.Drawing.Point(105, 360);
            this.tbCycleTime.Name = "tbCycleTime";
            this.tbCycleTime.ReadOnly = true;
            this.tbCycleTime.Size = new System.Drawing.Size(193, 22);
            this.tbCycleTime.TabIndex = 8;
            this.tbCycleTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRunningTime
            // 
            this.tbRunningTime.Location = new System.Drawing.Point(105, 388);
            this.tbRunningTime.Name = "tbRunningTime";
            this.tbRunningTime.ReadOnly = true;
            this.tbRunningTime.Size = new System.Drawing.Size(193, 22);
            this.tbRunningTime.TabIndex = 8;
            this.tbRunningTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbWaitingTime
            // 
            this.tbWaitingTime.Location = new System.Drawing.Point(105, 416);
            this.tbWaitingTime.Name = "tbWaitingTime";
            this.tbWaitingTime.ReadOnly = true;
            this.tbWaitingTime.Size = new System.Drawing.Size(193, 22);
            this.tbWaitingTime.TabIndex = 8;
            this.tbWaitingTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbInputQty
            // 
            this.tbInputQty.Location = new System.Drawing.Point(105, 444);
            this.tbInputQty.Name = "tbInputQty";
            this.tbInputQty.ReadOnly = true;
            this.tbInputQty.Size = new System.Drawing.Size(193, 22);
            this.tbInputQty.TabIndex = 8;
            this.tbInputQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbSelfcheck
            // 
            this.tbSelfcheck.Location = new System.Drawing.Point(105, 472);
            this.tbSelfcheck.Name = "tbSelfcheck";
            this.tbSelfcheck.ReadOnly = true;
            this.tbSelfcheck.Size = new System.Drawing.Size(193, 22);
            this.tbSelfcheck.TabIndex = 8;
            this.tbSelfcheck.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbCT_M
            // 
            this.tbCT_M.Location = new System.Drawing.Point(105, 500);
            this.tbCT_M.Name = "tbCT_M";
            this.tbCT_M.ReadOnly = true;
            this.tbCT_M.Size = new System.Drawing.Size(193, 22);
            this.tbCT_M.TabIndex = 8;
            this.tbCT_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbCT_Q
            // 
            this.tbCT_Q.Location = new System.Drawing.Point(105, 528);
            this.tbCT_Q.Name = "tbCT_Q";
            this.tbCT_Q.ReadOnly = true;
            this.tbCT_Q.Size = new System.Drawing.Size(193, 22);
            this.tbCT_Q.TabIndex = 8;
            this.tbCT_Q.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(304, 136);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(127, 17);
            this.label17.TabIndex = 5;
            this.label17.Text = "Equipment number";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(304, 164);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 17);
            this.label18.TabIndex = 5;
            this.label18.Text = "Barcode";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(304, 192);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(105, 17);
            this.label19.TabIndex = 5;
            this.label19.Text = "Machine Status";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(304, 220);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 17);
            this.label20.TabIndex = 5;
            this.label20.Text = "Error code";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(304, 248);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(134, 17);
            this.label21.TabIndex = 5;
            this.label21.Text = "Good product count";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(304, 276);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(120, 17);
            this.label22.TabIndex = 5;
            this.label22.Text = "NG product count";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(304, 304);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 17);
            this.label23.TabIndex = 5;
            this.label23.Text = "Error count";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(304, 332);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(73, 17);
            this.label24.TabIndex = 5;
            this.label24.Text = "Down time";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(304, 360);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(209, 17);
            this.label25.TabIndex = 5;
            this.label25.Text = "Single product / Production time";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(304, 388);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(64, 17);
            this.label26.TabIndex = 5;
            this.label26.Text = "Run time";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(304, 416);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(89, 17);
            this.label27.TabIndex = 5;
            this.label27.Text = "Waitting time";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(304, 444);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(93, 17);
            this.label28.TabIndex = 5;
            this.label28.Text = "Input quantity";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(304, 472);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(88, 17);
            this.label29.TabIndex = 5;
            this.label29.Text = "1.OK, 2.FAIL";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(304, 500);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(153, 17);
            this.label30.TabIndex = 5;
            this.label30.Text = "0.NO FAULT, 1.FAULT";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(304, 528);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(199, 17);
            this.label31.TabIndex = 5;
            this.label31.Text = "0.NO PROBLEM, 1.PROBLEM";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(549, 304);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(95, 17);
            this.label32.TabIndex = 5;
            this.label32.Text = "Servo Y1 Axis";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(549, 332);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(95, 17);
            this.label33.TabIndex = 6;
            this.label33.Text = "Servo Y2 Axis";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(549, 276);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(87, 17);
            this.label34.TabIndex = 7;
            this.label34.Text = "Servo X Axis";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(549, 248);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(76, 17);
            this.label35.TabIndex = 6;
            this.label35.Text = "RFID Right";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(549, 220);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(67, 17);
            this.label36.TabIndex = 5;
            this.label36.Text = "RFID Left";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(549, 388);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(101, 17);
            this.label37.TabIndex = 5;
            this.label37.Text = "Component-10";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(549, 360);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(87, 17);
            this.label38.TabIndex = 7;
            this.label38.Text = "Servo Z Axis";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(549, 416);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(101, 17);
            this.label39.TabIndex = 6;
            this.label39.Text = "Component-11";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(549, 192);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(93, 17);
            this.label40.TabIndex = 7;
            this.label40.Text = "Fixture Clamp";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(549, 164);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(101, 17);
            this.label41.TabIndex = 6;
            this.label41.Text = "Stopper Under";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(549, 444);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(101, 17);
            this.label42.TabIndex = 7;
            this.label42.Text = "Component-12";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(549, 470);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(101, 17);
            this.label43.TabIndex = 5;
            this.label43.Text = "Component-13";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(549, 136);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(101, 17);
            this.label44.TabIndex = 5;
            this.label44.Text = "Stopper Upper";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(549, 498);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(101, 17);
            this.label45.TabIndex = 6;
            this.label45.Text = "Component-14";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(549, 526);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(101, 17);
            this.label46.TabIndex = 7;
            this.label46.Text = "Component-15";
            // 
            // tbComp2_Limit
            // 
            this.tbComp2_Limit.Enabled = false;
            this.tbComp2_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp2_Limit.Location = new System.Drawing.Point(660, 164);
            this.tbComp2_Limit.MaxLength = 8;
            this.tbComp2_Limit.Name = "tbComp2_Limit";
            this.tbComp2_Limit.ReadOnly = true;
            this.tbComp2_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp2_Limit.TabIndex = 8;
            this.tbComp2_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp2_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp2_Limit_KeyPress);
            // 
            // tbComp2_Warning
            // 
            this.tbComp2_Warning.Enabled = false;
            this.tbComp2_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp2_Warning.Location = new System.Drawing.Point(739, 164);
            this.tbComp2_Warning.MaxLength = 8;
            this.tbComp2_Warning.Name = "tbComp2_Warning";
            this.tbComp2_Warning.ReadOnly = true;
            this.tbComp2_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp2_Warning.TabIndex = 8;
            this.tbComp2_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp2_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp2_Warning_KeyPress);
            // 
            // tbComp2_Usage
            // 
            this.tbComp2_Usage.Enabled = false;
            this.tbComp2_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp2_Usage.Location = new System.Drawing.Point(818, 164);
            this.tbComp2_Usage.Name = "tbComp2_Usage";
            this.tbComp2_Usage.ReadOnly = true;
            this.tbComp2_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp2_Usage.TabIndex = 8;
            this.tbComp2_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp1_Limit
            // 
            this.tbComp1_Limit.Enabled = false;
            this.tbComp1_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp1_Limit.Location = new System.Drawing.Point(660, 136);
            this.tbComp1_Limit.MaxLength = 8;
            this.tbComp1_Limit.Name = "tbComp1_Limit";
            this.tbComp1_Limit.ReadOnly = true;
            this.tbComp1_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp1_Limit.TabIndex = 8;
            this.tbComp1_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp1_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp1_Limit_KeyPress);
            // 
            // tbComp1_Warning
            // 
            this.tbComp1_Warning.Enabled = false;
            this.tbComp1_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp1_Warning.Location = new System.Drawing.Point(739, 136);
            this.tbComp1_Warning.MaxLength = 8;
            this.tbComp1_Warning.Name = "tbComp1_Warning";
            this.tbComp1_Warning.ReadOnly = true;
            this.tbComp1_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp1_Warning.TabIndex = 8;
            this.tbComp1_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp1_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp1_Warning_KeyPress);
            // 
            // tbComp1_Usage
            // 
            this.tbComp1_Usage.Enabled = false;
            this.tbComp1_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp1_Usage.Location = new System.Drawing.Point(818, 136);
            this.tbComp1_Usage.Name = "tbComp1_Usage";
            this.tbComp1_Usage.ReadOnly = true;
            this.tbComp1_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp1_Usage.TabIndex = 8;
            this.tbComp1_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp3_Limit
            // 
            this.tbComp3_Limit.Enabled = false;
            this.tbComp3_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp3_Limit.Location = new System.Drawing.Point(660, 192);
            this.tbComp3_Limit.MaxLength = 8;
            this.tbComp3_Limit.Name = "tbComp3_Limit";
            this.tbComp3_Limit.ReadOnly = true;
            this.tbComp3_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp3_Limit.TabIndex = 8;
            this.tbComp3_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp3_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp3_Limit_KeyPress);
            // 
            // tbComp3_Warning
            // 
            this.tbComp3_Warning.Enabled = false;
            this.tbComp3_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp3_Warning.Location = new System.Drawing.Point(739, 192);
            this.tbComp3_Warning.MaxLength = 8;
            this.tbComp3_Warning.Name = "tbComp3_Warning";
            this.tbComp3_Warning.ReadOnly = true;
            this.tbComp3_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp3_Warning.TabIndex = 8;
            this.tbComp3_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp3_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp3_Warning_KeyPress);
            // 
            // tbComp3_Usage
            // 
            this.tbComp3_Usage.Enabled = false;
            this.tbComp3_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp3_Usage.Location = new System.Drawing.Point(818, 192);
            this.tbComp3_Usage.Name = "tbComp3_Usage";
            this.tbComp3_Usage.ReadOnly = true;
            this.tbComp3_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp3_Usage.TabIndex = 8;
            this.tbComp3_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp4_Limit
            // 
            this.tbComp4_Limit.Enabled = false;
            this.tbComp4_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp4_Limit.Location = new System.Drawing.Point(660, 220);
            this.tbComp4_Limit.MaxLength = 8;
            this.tbComp4_Limit.Name = "tbComp4_Limit";
            this.tbComp4_Limit.ReadOnly = true;
            this.tbComp4_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp4_Limit.TabIndex = 8;
            this.tbComp4_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp4_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp4_Limit_KeyPress);
            // 
            // tbComp4_Warning
            // 
            this.tbComp4_Warning.Enabled = false;
            this.tbComp4_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp4_Warning.Location = new System.Drawing.Point(739, 220);
            this.tbComp4_Warning.MaxLength = 8;
            this.tbComp4_Warning.Name = "tbComp4_Warning";
            this.tbComp4_Warning.ReadOnly = true;
            this.tbComp4_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp4_Warning.TabIndex = 8;
            this.tbComp4_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp4_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp4_Warning_KeyPress);
            // 
            // tbComp4_Usage
            // 
            this.tbComp4_Usage.Enabled = false;
            this.tbComp4_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp4_Usage.Location = new System.Drawing.Point(818, 220);
            this.tbComp4_Usage.Name = "tbComp4_Usage";
            this.tbComp4_Usage.ReadOnly = true;
            this.tbComp4_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp4_Usage.TabIndex = 8;
            this.tbComp4_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp5_Limit
            // 
            this.tbComp5_Limit.Enabled = false;
            this.tbComp5_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp5_Limit.Location = new System.Drawing.Point(660, 248);
            this.tbComp5_Limit.MaxLength = 8;
            this.tbComp5_Limit.Name = "tbComp5_Limit";
            this.tbComp5_Limit.ReadOnly = true;
            this.tbComp5_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp5_Limit.TabIndex = 8;
            this.tbComp5_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp5_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp5_Limit_KeyPress);
            // 
            // tbComp5_Warning
            // 
            this.tbComp5_Warning.Enabled = false;
            this.tbComp5_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp5_Warning.Location = new System.Drawing.Point(739, 248);
            this.tbComp5_Warning.MaxLength = 8;
            this.tbComp5_Warning.Name = "tbComp5_Warning";
            this.tbComp5_Warning.ReadOnly = true;
            this.tbComp5_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp5_Warning.TabIndex = 8;
            this.tbComp5_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp5_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp5_Warning_KeyPress);
            // 
            // tbComp5_Usage
            // 
            this.tbComp5_Usage.Enabled = false;
            this.tbComp5_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp5_Usage.Location = new System.Drawing.Point(818, 248);
            this.tbComp5_Usage.Name = "tbComp5_Usage";
            this.tbComp5_Usage.ReadOnly = true;
            this.tbComp5_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp5_Usage.TabIndex = 8;
            this.tbComp5_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp6_Limit
            // 
            this.tbComp6_Limit.Enabled = false;
            this.tbComp6_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp6_Limit.Location = new System.Drawing.Point(660, 276);
            this.tbComp6_Limit.MaxLength = 8;
            this.tbComp6_Limit.Name = "tbComp6_Limit";
            this.tbComp6_Limit.ReadOnly = true;
            this.tbComp6_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp6_Limit.TabIndex = 8;
            this.tbComp6_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp6_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp6_Limit_KeyPress);
            // 
            // tbComp6_Warning
            // 
            this.tbComp6_Warning.Enabled = false;
            this.tbComp6_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp6_Warning.Location = new System.Drawing.Point(739, 276);
            this.tbComp6_Warning.MaxLength = 8;
            this.tbComp6_Warning.Name = "tbComp6_Warning";
            this.tbComp6_Warning.ReadOnly = true;
            this.tbComp6_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp6_Warning.TabIndex = 8;
            this.tbComp6_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp6_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp6_Warning_KeyPress);
            // 
            // tbComp6_Usage
            // 
            this.tbComp6_Usage.Enabled = false;
            this.tbComp6_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp6_Usage.Location = new System.Drawing.Point(818, 276);
            this.tbComp6_Usage.Name = "tbComp6_Usage";
            this.tbComp6_Usage.ReadOnly = true;
            this.tbComp6_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp6_Usage.TabIndex = 8;
            this.tbComp6_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp7_Limit
            // 
            this.tbComp7_Limit.Enabled = false;
            this.tbComp7_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp7_Limit.Location = new System.Drawing.Point(660, 304);
            this.tbComp7_Limit.MaxLength = 8;
            this.tbComp7_Limit.Name = "tbComp7_Limit";
            this.tbComp7_Limit.ReadOnly = true;
            this.tbComp7_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp7_Limit.TabIndex = 8;
            this.tbComp7_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp7_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp7_Limit_KeyPress);
            // 
            // tbComp7_Warning
            // 
            this.tbComp7_Warning.Enabled = false;
            this.tbComp7_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp7_Warning.Location = new System.Drawing.Point(739, 304);
            this.tbComp7_Warning.MaxLength = 8;
            this.tbComp7_Warning.Name = "tbComp7_Warning";
            this.tbComp7_Warning.ReadOnly = true;
            this.tbComp7_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp7_Warning.TabIndex = 8;
            this.tbComp7_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp7_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp7_Warning_KeyPress);
            // 
            // tbComp7_Usage
            // 
            this.tbComp7_Usage.Enabled = false;
            this.tbComp7_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp7_Usage.Location = new System.Drawing.Point(818, 304);
            this.tbComp7_Usage.Name = "tbComp7_Usage";
            this.tbComp7_Usage.ReadOnly = true;
            this.tbComp7_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp7_Usage.TabIndex = 8;
            this.tbComp7_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp8_Limit
            // 
            this.tbComp8_Limit.Enabled = false;
            this.tbComp8_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp8_Limit.Location = new System.Drawing.Point(660, 332);
            this.tbComp8_Limit.MaxLength = 8;
            this.tbComp8_Limit.Name = "tbComp8_Limit";
            this.tbComp8_Limit.ReadOnly = true;
            this.tbComp8_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp8_Limit.TabIndex = 8;
            this.tbComp8_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp8_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp8_Limit_KeyPress);
            // 
            // tbComp8_Warning
            // 
            this.tbComp8_Warning.Enabled = false;
            this.tbComp8_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp8_Warning.Location = new System.Drawing.Point(739, 332);
            this.tbComp8_Warning.MaxLength = 8;
            this.tbComp8_Warning.Name = "tbComp8_Warning";
            this.tbComp8_Warning.ReadOnly = true;
            this.tbComp8_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp8_Warning.TabIndex = 8;
            this.tbComp8_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp8_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp8_Warning_KeyPress);
            // 
            // tbComp8_Usage
            // 
            this.tbComp8_Usage.Enabled = false;
            this.tbComp8_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp8_Usage.Location = new System.Drawing.Point(818, 332);
            this.tbComp8_Usage.Name = "tbComp8_Usage";
            this.tbComp8_Usage.ReadOnly = true;
            this.tbComp8_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp8_Usage.TabIndex = 8;
            this.tbComp8_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp9_Limit
            // 
            this.tbComp9_Limit.Enabled = false;
            this.tbComp9_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp9_Limit.Location = new System.Drawing.Point(660, 360);
            this.tbComp9_Limit.MaxLength = 8;
            this.tbComp9_Limit.Name = "tbComp9_Limit";
            this.tbComp9_Limit.ReadOnly = true;
            this.tbComp9_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp9_Limit.TabIndex = 8;
            this.tbComp9_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp9_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp9_Limit_KeyPress);
            // 
            // tbComp9_Warning
            // 
            this.tbComp9_Warning.Enabled = false;
            this.tbComp9_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp9_Warning.Location = new System.Drawing.Point(739, 360);
            this.tbComp9_Warning.MaxLength = 8;
            this.tbComp9_Warning.Name = "tbComp9_Warning";
            this.tbComp9_Warning.ReadOnly = true;
            this.tbComp9_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp9_Warning.TabIndex = 8;
            this.tbComp9_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp9_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp9_Warning_KeyPress);
            // 
            // tbComp9_Usage
            // 
            this.tbComp9_Usage.Enabled = false;
            this.tbComp9_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp9_Usage.Location = new System.Drawing.Point(818, 360);
            this.tbComp9_Usage.Name = "tbComp9_Usage";
            this.tbComp9_Usage.ReadOnly = true;
            this.tbComp9_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp9_Usage.TabIndex = 8;
            this.tbComp9_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp10_Limit
            // 
            this.tbComp10_Limit.Enabled = false;
            this.tbComp10_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp10_Limit.Location = new System.Drawing.Point(660, 388);
            this.tbComp10_Limit.MaxLength = 8;
            this.tbComp10_Limit.Name = "tbComp10_Limit";
            this.tbComp10_Limit.ReadOnly = true;
            this.tbComp10_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp10_Limit.TabIndex = 8;
            this.tbComp10_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp10_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp10_Limit_KeyPress);
            // 
            // tbComp10_Warning
            // 
            this.tbComp10_Warning.Enabled = false;
            this.tbComp10_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp10_Warning.Location = new System.Drawing.Point(739, 388);
            this.tbComp10_Warning.MaxLength = 8;
            this.tbComp10_Warning.Name = "tbComp10_Warning";
            this.tbComp10_Warning.ReadOnly = true;
            this.tbComp10_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp10_Warning.TabIndex = 8;
            this.tbComp10_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp10_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp10_Warning_KeyPress);
            // 
            // tbComp10_Usage
            // 
            this.tbComp10_Usage.Enabled = false;
            this.tbComp10_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp10_Usage.Location = new System.Drawing.Point(818, 388);
            this.tbComp10_Usage.Name = "tbComp10_Usage";
            this.tbComp10_Usage.ReadOnly = true;
            this.tbComp10_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp10_Usage.TabIndex = 8;
            this.tbComp10_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp11_Limit
            // 
            this.tbComp11_Limit.Enabled = false;
            this.tbComp11_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp11_Limit.Location = new System.Drawing.Point(660, 416);
            this.tbComp11_Limit.MaxLength = 8;
            this.tbComp11_Limit.Name = "tbComp11_Limit";
            this.tbComp11_Limit.ReadOnly = true;
            this.tbComp11_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp11_Limit.TabIndex = 8;
            this.tbComp11_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp11_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp11_Limit_KeyPress);
            // 
            // tbComp11_Warning
            // 
            this.tbComp11_Warning.Enabled = false;
            this.tbComp11_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp11_Warning.Location = new System.Drawing.Point(739, 416);
            this.tbComp11_Warning.MaxLength = 8;
            this.tbComp11_Warning.Name = "tbComp11_Warning";
            this.tbComp11_Warning.ReadOnly = true;
            this.tbComp11_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp11_Warning.TabIndex = 8;
            this.tbComp11_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp11_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp11_Warning_KeyPress);
            // 
            // tbComp11_Usage
            // 
            this.tbComp11_Usage.Enabled = false;
            this.tbComp11_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp11_Usage.Location = new System.Drawing.Point(818, 416);
            this.tbComp11_Usage.Name = "tbComp11_Usage";
            this.tbComp11_Usage.ReadOnly = true;
            this.tbComp11_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp11_Usage.TabIndex = 8;
            this.tbComp11_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp12_Limit
            // 
            this.tbComp12_Limit.Enabled = false;
            this.tbComp12_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp12_Limit.Location = new System.Drawing.Point(660, 444);
            this.tbComp12_Limit.MaxLength = 8;
            this.tbComp12_Limit.Name = "tbComp12_Limit";
            this.tbComp12_Limit.ReadOnly = true;
            this.tbComp12_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp12_Limit.TabIndex = 8;
            this.tbComp12_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp12_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp12_Limit_KeyPress);
            // 
            // tbComp12_Warning
            // 
            this.tbComp12_Warning.Enabled = false;
            this.tbComp12_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp12_Warning.Location = new System.Drawing.Point(739, 444);
            this.tbComp12_Warning.MaxLength = 8;
            this.tbComp12_Warning.Name = "tbComp12_Warning";
            this.tbComp12_Warning.ReadOnly = true;
            this.tbComp12_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp12_Warning.TabIndex = 8;
            this.tbComp12_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp12_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp12_Warning_KeyPress);
            // 
            // tbComp12_Usage
            // 
            this.tbComp12_Usage.Enabled = false;
            this.tbComp12_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp12_Usage.Location = new System.Drawing.Point(818, 444);
            this.tbComp12_Usage.Name = "tbComp12_Usage";
            this.tbComp12_Usage.ReadOnly = true;
            this.tbComp12_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp12_Usage.TabIndex = 8;
            this.tbComp12_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp13_Limit
            // 
            this.tbComp13_Limit.Enabled = false;
            this.tbComp13_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp13_Limit.Location = new System.Drawing.Point(660, 470);
            this.tbComp13_Limit.MaxLength = 8;
            this.tbComp13_Limit.Name = "tbComp13_Limit";
            this.tbComp13_Limit.ReadOnly = true;
            this.tbComp13_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp13_Limit.TabIndex = 8;
            this.tbComp13_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp13_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp13_Limit_KeyPress);
            // 
            // tbComp13_Warning
            // 
            this.tbComp13_Warning.Enabled = false;
            this.tbComp13_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp13_Warning.Location = new System.Drawing.Point(739, 470);
            this.tbComp13_Warning.MaxLength = 8;
            this.tbComp13_Warning.Name = "tbComp13_Warning";
            this.tbComp13_Warning.ReadOnly = true;
            this.tbComp13_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp13_Warning.TabIndex = 8;
            this.tbComp13_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp13_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp13_Warning_KeyPress);
            // 
            // tbComp13_Usage
            // 
            this.tbComp13_Usage.Enabled = false;
            this.tbComp13_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp13_Usage.Location = new System.Drawing.Point(818, 470);
            this.tbComp13_Usage.Name = "tbComp13_Usage";
            this.tbComp13_Usage.ReadOnly = true;
            this.tbComp13_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp13_Usage.TabIndex = 8;
            this.tbComp13_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp14_Limit
            // 
            this.tbComp14_Limit.Enabled = false;
            this.tbComp14_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp14_Limit.Location = new System.Drawing.Point(660, 498);
            this.tbComp14_Limit.MaxLength = 8;
            this.tbComp14_Limit.Name = "tbComp14_Limit";
            this.tbComp14_Limit.ReadOnly = true;
            this.tbComp14_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp14_Limit.TabIndex = 8;
            this.tbComp14_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp14_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp14_Limit_KeyPress);
            // 
            // tbComp14_Warning
            // 
            this.tbComp14_Warning.Enabled = false;
            this.tbComp14_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp14_Warning.Location = new System.Drawing.Point(739, 498);
            this.tbComp14_Warning.MaxLength = 8;
            this.tbComp14_Warning.Name = "tbComp14_Warning";
            this.tbComp14_Warning.ReadOnly = true;
            this.tbComp14_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp14_Warning.TabIndex = 8;
            this.tbComp14_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp14_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp14_Warning_KeyPress);
            // 
            // tbComp14_Usage
            // 
            this.tbComp14_Usage.Enabled = false;
            this.tbComp14_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp14_Usage.Location = new System.Drawing.Point(818, 498);
            this.tbComp14_Usage.Name = "tbComp14_Usage";
            this.tbComp14_Usage.ReadOnly = true;
            this.tbComp14_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp14_Usage.TabIndex = 8;
            this.tbComp14_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbComp15_Limit
            // 
            this.tbComp15_Limit.Enabled = false;
            this.tbComp15_Limit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp15_Limit.Location = new System.Drawing.Point(660, 526);
            this.tbComp15_Limit.MaxLength = 8;
            this.tbComp15_Limit.Name = "tbComp15_Limit";
            this.tbComp15_Limit.ReadOnly = true;
            this.tbComp15_Limit.Size = new System.Drawing.Size(76, 21);
            this.tbComp15_Limit.TabIndex = 8;
            this.tbComp15_Limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp15_Limit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp15_Limit_KeyPress);
            // 
            // tbComp15_Warning
            // 
            this.tbComp15_Warning.Enabled = false;
            this.tbComp15_Warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp15_Warning.Location = new System.Drawing.Point(739, 526);
            this.tbComp15_Warning.MaxLength = 8;
            this.tbComp15_Warning.Name = "tbComp15_Warning";
            this.tbComp15_Warning.ReadOnly = true;
            this.tbComp15_Warning.Size = new System.Drawing.Size(76, 21);
            this.tbComp15_Warning.TabIndex = 8;
            this.tbComp15_Warning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbComp15_Warning.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComp15_Warning_KeyPress);
            // 
            // tbComp15_Usage
            // 
            this.tbComp15_Usage.Enabled = false;
            this.tbComp15_Usage.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp15_Usage.Location = new System.Drawing.Point(818, 526);
            this.tbComp15_Usage.Name = "tbComp15_Usage";
            this.tbComp15_Usage.ReadOnly = true;
            this.tbComp15_Usage.Size = new System.Drawing.Size(76, 19);
            this.tbComp15_Usage.TabIndex = 8;
            this.tbComp15_Usage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(572, 103);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(51, 17);
            this.label47.TabIndex = 5;
            this.label47.Text = "NAME";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(680, 103);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(42, 17);
            this.label48.TabIndex = 5;
            this.label48.Text = "Limit";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(745, 103);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(68, 17);
            this.label49.TabIndex = 5;
            this.label49.Text = "Warning";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(831, 103);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(54, 17);
            this.label50.TabIndex = 5;
            this.label50.Text = "Usage";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Black;
            this.pictureBox7.Location = new System.Drawing.Point(528, 65);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(10, 511);
            this.pictureBox7.TabIndex = 74;
            this.pictureBox7.TabStop = false;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.White;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(176, 51);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(61, 25);
            this.label51.TabIndex = 75;
            this.label51.Text = "PQM";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.White;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(741, 51);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(109, 25);
            this.label52.TabIndex = 76;
            this.label52.Text = "LIFETIME";
            // 
            // tbComp1_Reset
            // 
            this.tbComp1_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp1_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp1_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp1_Reset.Location = new System.Drawing.Point(900, 136);
            this.tbComp1_Reset.Name = "tbComp1_Reset";
            this.tbComp1_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp1_Reset.TabIndex = 77;
            this.tbComp1_Reset.Text = "RESET";
            this.tbComp1_Reset.UseVisualStyleBackColor = false;
            this.tbComp1_Reset.Click += new System.EventHandler(this.tbComp1_Reset_Click);
            // 
            // tbComp2_Reset
            // 
            this.tbComp2_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp2_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp2_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp2_Reset.Location = new System.Drawing.Point(900, 164);
            this.tbComp2_Reset.Name = "tbComp2_Reset";
            this.tbComp2_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp2_Reset.TabIndex = 77;
            this.tbComp2_Reset.Text = "RESET";
            this.tbComp2_Reset.UseVisualStyleBackColor = false;
            this.tbComp2_Reset.Click += new System.EventHandler(this.tbComp2_Reset_Click);
            // 
            // tbComp3_Reset
            // 
            this.tbComp3_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp3_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp3_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp3_Reset.Location = new System.Drawing.Point(900, 192);
            this.tbComp3_Reset.Name = "tbComp3_Reset";
            this.tbComp3_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp3_Reset.TabIndex = 77;
            this.tbComp3_Reset.Text = "RESET";
            this.tbComp3_Reset.UseVisualStyleBackColor = false;
            this.tbComp3_Reset.Click += new System.EventHandler(this.tbComp3_Reset_Click);
            // 
            // tbComp4_Reset
            // 
            this.tbComp4_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp4_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp4_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp4_Reset.Location = new System.Drawing.Point(900, 220);
            this.tbComp4_Reset.Name = "tbComp4_Reset";
            this.tbComp4_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp4_Reset.TabIndex = 77;
            this.tbComp4_Reset.Text = "RESET";
            this.tbComp4_Reset.UseVisualStyleBackColor = false;
            this.tbComp4_Reset.Click += new System.EventHandler(this.tbComp4_Reset_Click);
            // 
            // tbComp5_Reset
            // 
            this.tbComp5_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp5_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp5_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp5_Reset.Location = new System.Drawing.Point(900, 248);
            this.tbComp5_Reset.Name = "tbComp5_Reset";
            this.tbComp5_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp5_Reset.TabIndex = 77;
            this.tbComp5_Reset.Text = "RESET";
            this.tbComp5_Reset.UseVisualStyleBackColor = false;
            this.tbComp5_Reset.Click += new System.EventHandler(this.tbComp5_Reset_Click);
            // 
            // tbComp6_Reset
            // 
            this.tbComp6_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp6_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp6_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp6_Reset.Location = new System.Drawing.Point(900, 276);
            this.tbComp6_Reset.Name = "tbComp6_Reset";
            this.tbComp6_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp6_Reset.TabIndex = 77;
            this.tbComp6_Reset.Text = "RESET";
            this.tbComp6_Reset.UseVisualStyleBackColor = false;
            this.tbComp6_Reset.Click += new System.EventHandler(this.tbComp6_Reset_Click);
            // 
            // tbComp7_Reset
            // 
            this.tbComp7_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp7_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp7_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp7_Reset.Location = new System.Drawing.Point(900, 304);
            this.tbComp7_Reset.Name = "tbComp7_Reset";
            this.tbComp7_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp7_Reset.TabIndex = 77;
            this.tbComp7_Reset.Text = "RESET";
            this.tbComp7_Reset.UseVisualStyleBackColor = false;
            this.tbComp7_Reset.Click += new System.EventHandler(this.tbComp7_Reset_Click);
            // 
            // tbComp8_Reset
            // 
            this.tbComp8_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp8_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp8_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp8_Reset.Location = new System.Drawing.Point(900, 332);
            this.tbComp8_Reset.Name = "tbComp8_Reset";
            this.tbComp8_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp8_Reset.TabIndex = 77;
            this.tbComp8_Reset.Text = "RESET";
            this.tbComp8_Reset.UseVisualStyleBackColor = false;
            this.tbComp8_Reset.Click += new System.EventHandler(this.tbComp8_Reset_Click);
            // 
            // tbComp9_Reset
            // 
            this.tbComp9_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp9_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp9_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp9_Reset.Location = new System.Drawing.Point(900, 360);
            this.tbComp9_Reset.Name = "tbComp9_Reset";
            this.tbComp9_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp9_Reset.TabIndex = 77;
            this.tbComp9_Reset.Text = "RESET";
            this.tbComp9_Reset.UseVisualStyleBackColor = false;
            this.tbComp9_Reset.Click += new System.EventHandler(this.tbComp9_Reset_Click);
            // 
            // tbComp10_Reset
            // 
            this.tbComp10_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp10_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp10_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp10_Reset.Location = new System.Drawing.Point(900, 388);
            this.tbComp10_Reset.Name = "tbComp10_Reset";
            this.tbComp10_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp10_Reset.TabIndex = 77;
            this.tbComp10_Reset.Text = "RESET";
            this.tbComp10_Reset.UseVisualStyleBackColor = false;
            this.tbComp10_Reset.Click += new System.EventHandler(this.tbComp10_Reset_Click);
            // 
            // tbComp11_Reset
            // 
            this.tbComp11_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp11_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp11_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp11_Reset.Location = new System.Drawing.Point(900, 416);
            this.tbComp11_Reset.Name = "tbComp11_Reset";
            this.tbComp11_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp11_Reset.TabIndex = 77;
            this.tbComp11_Reset.Text = "RESET";
            this.tbComp11_Reset.UseVisualStyleBackColor = false;
            this.tbComp11_Reset.Click += new System.EventHandler(this.tbComp11_Reset_Click);
            // 
            // tbComp12_Reset
            // 
            this.tbComp12_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp12_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp12_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp12_Reset.Location = new System.Drawing.Point(900, 444);
            this.tbComp12_Reset.Name = "tbComp12_Reset";
            this.tbComp12_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp12_Reset.TabIndex = 77;
            this.tbComp12_Reset.Text = "RESET";
            this.tbComp12_Reset.UseVisualStyleBackColor = false;
            this.tbComp12_Reset.Click += new System.EventHandler(this.tbComp12_Reset_Click);
            // 
            // tbComp13_Reset
            // 
            this.tbComp13_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp13_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp13_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp13_Reset.Location = new System.Drawing.Point(900, 472);
            this.tbComp13_Reset.Name = "tbComp13_Reset";
            this.tbComp13_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp13_Reset.TabIndex = 77;
            this.tbComp13_Reset.Text = "RESET";
            this.tbComp13_Reset.UseVisualStyleBackColor = false;
            this.tbComp13_Reset.Click += new System.EventHandler(this.tbComp13_Reset_Click);
            // 
            // tbComp14_Reset
            // 
            this.tbComp14_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp14_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp14_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp14_Reset.Location = new System.Drawing.Point(900, 500);
            this.tbComp14_Reset.Name = "tbComp14_Reset";
            this.tbComp14_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp14_Reset.TabIndex = 77;
            this.tbComp14_Reset.Text = "RESET";
            this.tbComp14_Reset.UseVisualStyleBackColor = false;
            this.tbComp14_Reset.Click += new System.EventHandler(this.tbComp14_Reset_Click);
            // 
            // tbComp15_Reset
            // 
            this.tbComp15_Reset.BackColor = System.Drawing.Color.Silver;
            this.tbComp15_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbComp15_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbComp15_Reset.Location = new System.Drawing.Point(900, 528);
            this.tbComp15_Reset.Name = "tbComp15_Reset";
            this.tbComp15_Reset.Size = new System.Drawing.Size(68, 22);
            this.tbComp15_Reset.TabIndex = 77;
            this.tbComp15_Reset.Text = "RESET";
            this.tbComp15_Reset.UseVisualStyleBackColor = false;
            this.tbComp15_Reset.Click += new System.EventHandler(this.tbComp15_Reset_Click);
            // 
            // btnPassQty_Reset
            // 
            this.btnPassQty_Reset.BackColor = System.Drawing.Color.Silver;
            this.btnPassQty_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPassQty_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPassQty_Reset.Location = new System.Drawing.Point(445, 248);
            this.btnPassQty_Reset.Name = "btnPassQty_Reset";
            this.btnPassQty_Reset.Size = new System.Drawing.Size(68, 22);
            this.btnPassQty_Reset.TabIndex = 77;
            this.btnPassQty_Reset.Text = "RESET";
            this.btnPassQty_Reset.UseVisualStyleBackColor = false;
            this.btnPassQty_Reset.Click += new System.EventHandler(this.btnPassQty_Reset_Click);
            // 
            // btnFailQty_Reset
            // 
            this.btnFailQty_Reset.BackColor = System.Drawing.Color.Silver;
            this.btnFailQty_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFailQty_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFailQty_Reset.Location = new System.Drawing.Point(445, 276);
            this.btnFailQty_Reset.Name = "btnFailQty_Reset";
            this.btnFailQty_Reset.Size = new System.Drawing.Size(68, 22);
            this.btnFailQty_Reset.TabIndex = 77;
            this.btnFailQty_Reset.Text = "RESET";
            this.btnFailQty_Reset.UseVisualStyleBackColor = false;
            this.btnFailQty_Reset.Click += new System.EventHandler(this.btnFailQty_Reset_Click);
            // 
            // btnErrorCount_Reset
            // 
            this.btnErrorCount_Reset.BackColor = System.Drawing.Color.Silver;
            this.btnErrorCount_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnErrorCount_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnErrorCount_Reset.Location = new System.Drawing.Point(445, 304);
            this.btnErrorCount_Reset.Name = "btnErrorCount_Reset";
            this.btnErrorCount_Reset.Size = new System.Drawing.Size(68, 22);
            this.btnErrorCount_Reset.TabIndex = 77;
            this.btnErrorCount_Reset.Text = "RESET";
            this.btnErrorCount_Reset.UseVisualStyleBackColor = false;
            this.btnErrorCount_Reset.Click += new System.EventHandler(this.btnErrorCount_Reset_Click);
            // 
            // btnRunTime_Reset
            // 
            this.btnRunTime_Reset.BackColor = System.Drawing.Color.Silver;
            this.btnRunTime_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRunTime_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRunTime_Reset.Location = new System.Drawing.Point(445, 388);
            this.btnRunTime_Reset.Name = "btnRunTime_Reset";
            this.btnRunTime_Reset.Size = new System.Drawing.Size(68, 22);
            this.btnRunTime_Reset.TabIndex = 77;
            this.btnRunTime_Reset.Text = "RESET";
            this.btnRunTime_Reset.UseVisualStyleBackColor = false;
            this.btnRunTime_Reset.Click += new System.EventHandler(this.btnRunTime_Reset_Click);
            // 
            // btnInputQty_Reset
            // 
            this.btnInputQty_Reset.BackColor = System.Drawing.Color.Silver;
            this.btnInputQty_Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInputQty_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInputQty_Reset.Location = new System.Drawing.Point(445, 444);
            this.btnInputQty_Reset.Name = "btnInputQty_Reset";
            this.btnInputQty_Reset.Size = new System.Drawing.Size(68, 22);
            this.btnInputQty_Reset.TabIndex = 77;
            this.btnInputQty_Reset.Text = "RESET";
            this.btnInputQty_Reset.UseVisualStyleBackColor = false;
            this.btnInputQty_Reset.Click += new System.EventHandler(this.btnInputQty_Reset_Click);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(31, 103);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(51, 17);
            this.label53.TabIndex = 5;
            this.label53.Text = "NAME";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(178, 103);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(42, 17);
            this.label54.TabIndex = 5;
            this.label54.Text = "Data";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(324, 103);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(50, 17);
            this.label55.TabIndex = 5;
            this.label55.Text = "Detail";
            // 
            // btnPQM_BYPASS
            // 
            this.btnPQM_BYPASS.BackColor = System.Drawing.Color.LightGray;
            this.btnPQM_BYPASS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPQM_BYPASS.Location = new System.Drawing.Point(105, 556);
            this.btnPQM_BYPASS.Name = "btnPQM_BYPASS";
            this.btnPQM_BYPASS.Size = new System.Drawing.Size(146, 33);
            this.btnPQM_BYPASS.TabIndex = 81;
            this.btnPQM_BYPASS.Text = "PQM UPDATE";
            this.btnPQM_BYPASS.UseVisualStyleBackColor = false;
            this.btnPQM_BYPASS.Click += new System.EventHandler(this.btnPQM_BYPASS_Click);
            // 
            // ucPQM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnPQM_BYPASS);
            this.Controls.Add(this.tbComp15_Reset);
            this.Controls.Add(this.tbComp14_Reset);
            this.Controls.Add(this.tbComp13_Reset);
            this.Controls.Add(this.btnInputQty_Reset);
            this.Controls.Add(this.tbComp12_Reset);
            this.Controls.Add(this.btnRunTime_Reset);
            this.Controls.Add(this.tbComp11_Reset);
            this.Controls.Add(this.tbComp10_Reset);
            this.Controls.Add(this.tbComp9_Reset);
            this.Controls.Add(this.tbComp8_Reset);
            this.Controls.Add(this.btnErrorCount_Reset);
            this.Controls.Add(this.btnFailQty_Reset);
            this.Controls.Add(this.tbComp7_Reset);
            this.Controls.Add(this.btnPassQty_Reset);
            this.Controls.Add(this.tbComp6_Reset);
            this.Controls.Add(this.tbComp5_Reset);
            this.Controls.Add(this.tbComp4_Reset);
            this.Controls.Add(this.tbComp3_Reset);
            this.Controls.Add(this.tbComp2_Reset);
            this.Controls.Add(this.tbComp1_Reset);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.tbCT_Q);
            this.Controls.Add(this.tbCT_M);
            this.Controls.Add(this.tbSelfcheck);
            this.Controls.Add(this.tbInputQty);
            this.Controls.Add(this.tbWaitingTime);
            this.Controls.Add(this.tbRunningTime);
            this.Controls.Add(this.tbCycleTime);
            this.Controls.Add(this.tbErrorTime);
            this.Controls.Add(this.tbErrorCount);
            this.Controls.Add(this.tbFailQty);
            this.Controls.Add(this.tbPassQty);
            this.Controls.Add(this.tbStatusCode);
            this.Controls.Add(this.tbStatus);
            this.Controls.Add(this.tbComp1_Usage);
            this.Controls.Add(this.tbComp15_Usage);
            this.Controls.Add(this.tbComp14_Usage);
            this.Controls.Add(this.tbComp13_Usage);
            this.Controls.Add(this.tbComp12_Usage);
            this.Controls.Add(this.tbComp11_Usage);
            this.Controls.Add(this.tbComp10_Usage);
            this.Controls.Add(this.tbComp9_Usage);
            this.Controls.Add(this.tbComp8_Usage);
            this.Controls.Add(this.tbComp7_Usage);
            this.Controls.Add(this.tbComp6_Usage);
            this.Controls.Add(this.tbComp5_Usage);
            this.Controls.Add(this.tbComp4_Usage);
            this.Controls.Add(this.tbComp3_Usage);
            this.Controls.Add(this.tbComp2_Usage);
            this.Controls.Add(this.tbComp1_Warning);
            this.Controls.Add(this.tbComp15_Warning);
            this.Controls.Add(this.tbComp14_Warning);
            this.Controls.Add(this.tbComp13_Warning);
            this.Controls.Add(this.tbComp12_Warning);
            this.Controls.Add(this.tbComp11_Warning);
            this.Controls.Add(this.tbComp10_Warning);
            this.Controls.Add(this.tbComp9_Warning);
            this.Controls.Add(this.tbComp8_Warning);
            this.Controls.Add(this.tbComp7_Warning);
            this.Controls.Add(this.tbComp6_Warning);
            this.Controls.Add(this.tbComp5_Warning);
            this.Controls.Add(this.tbComp4_Warning);
            this.Controls.Add(this.tbComp3_Warning);
            this.Controls.Add(this.tbComp2_Warning);
            this.Controls.Add(this.tbComp1_Limit);
            this.Controls.Add(this.tbComp15_Limit);
            this.Controls.Add(this.tbComp14_Limit);
            this.Controls.Add(this.tbComp13_Limit);
            this.Controls.Add(this.tbComp12_Limit);
            this.Controls.Add(this.tbComp11_Limit);
            this.Controls.Add(this.tbComp10_Limit);
            this.Controls.Add(this.tbComp9_Limit);
            this.Controls.Add(this.tbComp8_Limit);
            this.Controls.Add(this.tbComp7_Limit);
            this.Controls.Add(this.tbComp6_Limit);
            this.Controls.Add(this.tbComp5_Limit);
            this.Controls.Add(this.tbComp4_Limit);
            this.Controls.Add(this.tbComp3_Limit);
            this.Controls.Add(this.tbComp2_Limit);
            this.Controls.Add(this.tbBarcodeID);
            this.Controls.Add(this.tbMachineID);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Name = "ucPQM";
            this.Size = new System.Drawing.Size(1000, 600);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbMachineID;
        private System.Windows.Forms.TextBox tbBarcodeID;
        private System.Windows.Forms.TextBox tbStatus;
        private System.Windows.Forms.TextBox tbStatusCode;
        private System.Windows.Forms.TextBox tbPassQty;
        private System.Windows.Forms.TextBox tbFailQty;
        private System.Windows.Forms.TextBox tbErrorCount;
        private System.Windows.Forms.TextBox tbErrorTime;
        private System.Windows.Forms.TextBox tbCycleTime;
        private System.Windows.Forms.TextBox tbRunningTime;
        private System.Windows.Forms.TextBox tbWaitingTime;
        private System.Windows.Forms.TextBox tbInputQty;
        private System.Windows.Forms.TextBox tbSelfcheck;
        private System.Windows.Forms.TextBox tbCT_M;
        private System.Windows.Forms.TextBox tbCT_Q;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox tbComp2_Limit;
        private System.Windows.Forms.TextBox tbComp2_Warning;
        private System.Windows.Forms.TextBox tbComp2_Usage;
        private System.Windows.Forms.TextBox tbComp1_Limit;
        private System.Windows.Forms.TextBox tbComp1_Warning;
        private System.Windows.Forms.TextBox tbComp1_Usage;
        private System.Windows.Forms.TextBox tbComp3_Limit;
        private System.Windows.Forms.TextBox tbComp3_Warning;
        private System.Windows.Forms.TextBox tbComp3_Usage;
        private System.Windows.Forms.TextBox tbComp4_Limit;
        private System.Windows.Forms.TextBox tbComp4_Warning;
        private System.Windows.Forms.TextBox tbComp4_Usage;
        private System.Windows.Forms.TextBox tbComp5_Limit;
        private System.Windows.Forms.TextBox tbComp5_Warning;
        private System.Windows.Forms.TextBox tbComp5_Usage;
        private System.Windows.Forms.TextBox tbComp6_Limit;
        private System.Windows.Forms.TextBox tbComp6_Warning;
        private System.Windows.Forms.TextBox tbComp6_Usage;
        private System.Windows.Forms.TextBox tbComp7_Limit;
        private System.Windows.Forms.TextBox tbComp7_Warning;
        private System.Windows.Forms.TextBox tbComp7_Usage;
        private System.Windows.Forms.TextBox tbComp8_Limit;
        private System.Windows.Forms.TextBox tbComp8_Warning;
        private System.Windows.Forms.TextBox tbComp8_Usage;
        private System.Windows.Forms.TextBox tbComp9_Limit;
        private System.Windows.Forms.TextBox tbComp9_Warning;
        private System.Windows.Forms.TextBox tbComp9_Usage;
        private System.Windows.Forms.TextBox tbComp10_Limit;
        private System.Windows.Forms.TextBox tbComp10_Warning;
        private System.Windows.Forms.TextBox tbComp10_Usage;
        private System.Windows.Forms.TextBox tbComp11_Limit;
        private System.Windows.Forms.TextBox tbComp11_Warning;
        private System.Windows.Forms.TextBox tbComp11_Usage;
        private System.Windows.Forms.TextBox tbComp12_Limit;
        private System.Windows.Forms.TextBox tbComp12_Warning;
        private System.Windows.Forms.TextBox tbComp12_Usage;
        private System.Windows.Forms.TextBox tbComp13_Limit;
        private System.Windows.Forms.TextBox tbComp13_Warning;
        private System.Windows.Forms.TextBox tbComp13_Usage;
        private System.Windows.Forms.TextBox tbComp14_Limit;
        private System.Windows.Forms.TextBox tbComp14_Warning;
        private System.Windows.Forms.TextBox tbComp14_Usage;
        private System.Windows.Forms.TextBox tbComp15_Limit;
        private System.Windows.Forms.TextBox tbComp15_Warning;
        private System.Windows.Forms.TextBox tbComp15_Usage;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button tbComp1_Reset;
        private System.Windows.Forms.Button tbComp2_Reset;
        private System.Windows.Forms.Button tbComp3_Reset;
        private System.Windows.Forms.Button tbComp4_Reset;
        private System.Windows.Forms.Button tbComp5_Reset;
        private System.Windows.Forms.Button tbComp6_Reset;
        private System.Windows.Forms.Button tbComp7_Reset;
        private System.Windows.Forms.Button tbComp8_Reset;
        private System.Windows.Forms.Button tbComp9_Reset;
        private System.Windows.Forms.Button tbComp10_Reset;
        private System.Windows.Forms.Button tbComp11_Reset;
        private System.Windows.Forms.Button tbComp12_Reset;
        private System.Windows.Forms.Button tbComp13_Reset;
        private System.Windows.Forms.Button tbComp14_Reset;
        private System.Windows.Forms.Button tbComp15_Reset;
        private System.Windows.Forms.Button btnPassQty_Reset;
        private System.Windows.Forms.Button btnFailQty_Reset;
        private System.Windows.Forms.Button btnErrorCount_Reset;
        private System.Windows.Forms.Button btnRunTime_Reset;
        private System.Windows.Forms.Button btnInputQty_Reset;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button btnPQM_BYPASS;
    }
}
