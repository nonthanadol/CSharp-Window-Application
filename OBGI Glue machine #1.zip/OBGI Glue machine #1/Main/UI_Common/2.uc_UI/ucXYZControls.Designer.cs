﻿
namespace UI_Common
{
    partial class ucXYZControls
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnJogY_plus = new System.Windows.Forms.Button();
            this.btnJogX_minus = new System.Windows.Forms.Button();
            this.btnJogX_plus = new System.Windows.Forms.Button();
            this.btnJogY_minus = new System.Windows.Forms.Button();
            this.btnJogZ_plus = new System.Windows.Forms.Button();
            this.btnJogZ_minus = new System.Windows.Forms.Button();
            this.btnSaveAll = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.picSample = new System.Windows.Forms.PictureBox();
            this.cbPosition = new System.Windows.Forms.ComboBox();
            this.cbStep = new System.Windows.Forms.ComboBox();
            this.tbCurrentXaxis = new System.Windows.Forms.TextBox();
            this.tbCurrentYaxis = new System.Windows.Forms.TextBox();
            this.tbCurrentZaxis = new System.Windows.Forms.TextBox();
            this.tbSavedXaxis = new System.Windows.Forms.TextBox();
            this.tbSavedYaxis = new System.Windows.Forms.TextBox();
            this.tbSavedZaxis = new System.Windows.Forms.TextBox();
            this.tbManualXaxis = new System.Windows.Forms.TextBox();
            this.tbManualYaxis = new System.Windows.Forms.TextBox();
            this.tbManualZaxis = new System.Windows.Forms.TextBox();
            this.btnManualSave_X = new System.Windows.Forms.Button();
            this.btnManualSave_Y = new System.Windows.Forms.Button();
            this.btnManualSave_Z = new System.Windows.Forms.Button();
            this.btnMoveStep = new System.Windows.Forms.Button();
            this.btnMovePosition = new System.Windows.Forms.Button();
            this.btnMovePos_Apply = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.cbJogXSpeed = new System.Windows.Forms.ComboBox();
            this.cbJogYSpeed = new System.Windows.Forms.ComboBox();
            this.cbJogZSpeed = new System.Windows.Forms.ComboBox();
            this.btnJogRZ_minus = new System.Windows.Forms.Button();
            this.btnJogRZ_plus = new System.Windows.Forms.Button();
            this.tbCurrentRZaxis = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tbSavedRZaxis = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.btnManualSave_RZ = new System.Windows.Forms.Button();
            this.tbManualRZaxis = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cbJogRZSpeed = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btnForceJog = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picSample)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1000, 40);
            this.label1.TabIndex = 1;
            this.label1.Text = "XYZ CONTROLS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Position";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(245, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Step no.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(523, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Saved position";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Current position";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(74, 247);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "X axis :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(74, 274);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Y axis :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(256, 244);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 17);
            this.label8.TabIndex = 8;
            this.label8.Text = "Z axis :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(800, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 17);
            this.label9.TabIndex = 11;
            this.label9.Text = "Z axis :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(634, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 17);
            this.label10.TabIndex = 10;
            this.label10.Text = "Y axis :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(634, 64);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 17);
            this.label11.TabIndex = 9;
            this.label11.Text = "X axis :";
            // 
            // btnJogY_plus
            // 
            this.btnJogY_plus.BackColor = System.Drawing.Color.LightGray;
            this.btnJogY_plus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJogY_plus.Location = new System.Drawing.Point(86, 423);
            this.btnJogY_plus.Name = "btnJogY_plus";
            this.btnJogY_plus.Size = new System.Drawing.Size(63, 57);
            this.btnJogY_plus.TabIndex = 12;
            this.btnJogY_plus.Text = "Y+";
            this.btnJogY_plus.UseVisualStyleBackColor = false;
            // 
            // btnJogX_minus
            // 
            this.btnJogX_minus.BackColor = System.Drawing.Color.LightGray;
            this.btnJogX_minus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJogX_minus.Location = new System.Drawing.Point(22, 368);
            this.btnJogX_minus.Name = "btnJogX_minus";
            this.btnJogX_minus.Size = new System.Drawing.Size(63, 57);
            this.btnJogX_minus.TabIndex = 13;
            this.btnJogX_minus.Text = "X-";
            this.btnJogX_minus.UseVisualStyleBackColor = false;
            // 
            // btnJogX_plus
            // 
            this.btnJogX_plus.BackColor = System.Drawing.Color.LightGray;
            this.btnJogX_plus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJogX_plus.Location = new System.Drawing.Point(150, 368);
            this.btnJogX_plus.Name = "btnJogX_plus";
            this.btnJogX_plus.Size = new System.Drawing.Size(63, 57);
            this.btnJogX_plus.TabIndex = 14;
            this.btnJogX_plus.Text = "X+";
            this.btnJogX_plus.UseVisualStyleBackColor = false;
            // 
            // btnJogY_minus
            // 
            this.btnJogY_minus.BackColor = System.Drawing.Color.LightGray;
            this.btnJogY_minus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJogY_minus.Location = new System.Drawing.Point(86, 313);
            this.btnJogY_minus.Name = "btnJogY_minus";
            this.btnJogY_minus.Size = new System.Drawing.Size(63, 57);
            this.btnJogY_minus.TabIndex = 15;
            this.btnJogY_minus.Text = "Y-";
            this.btnJogY_minus.UseVisualStyleBackColor = false;
            // 
            // btnJogZ_plus
            // 
            this.btnJogZ_plus.BackColor = System.Drawing.Color.LightGray;
            this.btnJogZ_plus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJogZ_plus.Location = new System.Drawing.Point(220, 313);
            this.btnJogZ_plus.Name = "btnJogZ_plus";
            this.btnJogZ_plus.Size = new System.Drawing.Size(63, 57);
            this.btnJogZ_plus.TabIndex = 16;
            this.btnJogZ_plus.Text = "Z+";
            this.btnJogZ_plus.UseVisualStyleBackColor = false;
            // 
            // btnJogZ_minus
            // 
            this.btnJogZ_minus.BackColor = System.Drawing.Color.LightGray;
            this.btnJogZ_minus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJogZ_minus.Location = new System.Drawing.Point(220, 423);
            this.btnJogZ_minus.Name = "btnJogZ_minus";
            this.btnJogZ_minus.Size = new System.Drawing.Size(63, 57);
            this.btnJogZ_minus.TabIndex = 17;
            this.btnJogZ_minus.Text = "Z-";
            this.btnJogZ_minus.UseVisualStyleBackColor = false;
            // 
            // btnSaveAll
            // 
            this.btnSaveAll.BackColor = System.Drawing.Color.LightGray;
            this.btnSaveAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveAll.Location = new System.Drawing.Point(385, 423);
            this.btnSaveAll.Name = "btnSaveAll";
            this.btnSaveAll.Size = new System.Drawing.Size(63, 57);
            this.btnSaveAll.TabIndex = 18;
            this.btnSaveAll.Text = "SAVE";
            this.btnSaveAll.UseVisualStyleBackColor = false;
            this.btnSaveAll.Click += new System.EventHandler(this.btnSaveAll_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(32, 496);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 17);
            this.label12.TabIndex = 19;
            this.label12.Text = "Manual position save";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(489, 533);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 17);
            this.label13.TabIndex = 22;
            this.label13.Text = "Z axis :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(260, 533);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 17);
            this.label14.TabIndex = 21;
            this.label14.Text = "Y axis :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(32, 532);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 17);
            this.label15.TabIndex = 20;
            this.label15.Text = "X axis :";
            // 
            // picSample
            // 
            this.picSample.BackgroundImage = global::UI_Common.Properties.Resources._22_333;
            this.picSample.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSample.Location = new System.Drawing.Point(493, 176);
            this.picSample.Name = "picSample";
            this.picSample.Size = new System.Drawing.Size(487, 325);
            this.picSample.TabIndex = 23;
            this.picSample.TabStop = false;
            // 
            // cbPosition
            // 
            this.cbPosition.FormattingEnabled = true;
            this.cbPosition.Location = new System.Drawing.Point(96, 63);
            this.cbPosition.Name = "cbPosition";
            this.cbPosition.Size = new System.Drawing.Size(124, 24);
            this.cbPosition.TabIndex = 24;
            this.cbPosition.SelectedIndexChanged += new System.EventHandler(this.cbPosition_SelectedIndexChanged);
            this.cbPosition.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbPosition_KeyPress);
            // 
            // cbStep
            // 
            this.cbStep.FormattingEnabled = true;
            this.cbStep.Location = new System.Drawing.Point(310, 63);
            this.cbStep.Name = "cbStep";
            this.cbStep.Size = new System.Drawing.Size(63, 24);
            this.cbStep.TabIndex = 25;
            this.cbStep.SelectedIndexChanged += new System.EventHandler(this.cbStep_SelectedIndexChanged);
            this.cbStep.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbStep_KeyPress);
            // 
            // tbCurrentXaxis
            // 
            this.tbCurrentXaxis.Enabled = false;
            this.tbCurrentXaxis.Location = new System.Drawing.Point(130, 244);
            this.tbCurrentXaxis.Name = "tbCurrentXaxis";
            this.tbCurrentXaxis.ReadOnly = true;
            this.tbCurrentXaxis.Size = new System.Drawing.Size(77, 22);
            this.tbCurrentXaxis.TabIndex = 26;
            // 
            // tbCurrentYaxis
            // 
            this.tbCurrentYaxis.Enabled = false;
            this.tbCurrentYaxis.Location = new System.Drawing.Point(130, 271);
            this.tbCurrentYaxis.Name = "tbCurrentYaxis";
            this.tbCurrentYaxis.ReadOnly = true;
            this.tbCurrentYaxis.Size = new System.Drawing.Size(77, 22);
            this.tbCurrentYaxis.TabIndex = 27;
            // 
            // tbCurrentZaxis
            // 
            this.tbCurrentZaxis.Enabled = false;
            this.tbCurrentZaxis.Location = new System.Drawing.Point(315, 241);
            this.tbCurrentZaxis.Name = "tbCurrentZaxis";
            this.tbCurrentZaxis.ReadOnly = true;
            this.tbCurrentZaxis.Size = new System.Drawing.Size(77, 22);
            this.tbCurrentZaxis.TabIndex = 28;
            // 
            // tbSavedXaxis
            // 
            this.tbSavedXaxis.Enabled = false;
            this.tbSavedXaxis.Location = new System.Drawing.Point(689, 61);
            this.tbSavedXaxis.Name = "tbSavedXaxis";
            this.tbSavedXaxis.ReadOnly = true;
            this.tbSavedXaxis.Size = new System.Drawing.Size(77, 22);
            this.tbSavedXaxis.TabIndex = 29;
            // 
            // tbSavedYaxis
            // 
            this.tbSavedYaxis.Enabled = false;
            this.tbSavedYaxis.Location = new System.Drawing.Point(689, 90);
            this.tbSavedYaxis.Name = "tbSavedYaxis";
            this.tbSavedYaxis.ReadOnly = true;
            this.tbSavedYaxis.Size = new System.Drawing.Size(77, 22);
            this.tbSavedYaxis.TabIndex = 30;
            // 
            // tbSavedZaxis
            // 
            this.tbSavedZaxis.Enabled = false;
            this.tbSavedZaxis.Location = new System.Drawing.Point(855, 58);
            this.tbSavedZaxis.Name = "tbSavedZaxis";
            this.tbSavedZaxis.ReadOnly = true;
            this.tbSavedZaxis.Size = new System.Drawing.Size(77, 22);
            this.tbSavedZaxis.TabIndex = 31;
            // 
            // tbManualXaxis
            // 
            this.tbManualXaxis.Location = new System.Drawing.Point(91, 530);
            this.tbManualXaxis.MaxLength = 8;
            this.tbManualXaxis.Name = "tbManualXaxis";
            this.tbManualXaxis.Size = new System.Drawing.Size(77, 22);
            this.tbManualXaxis.TabIndex = 32;
            this.tbManualXaxis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbManualXaxis_KeyPress);
            // 
            // tbManualYaxis
            // 
            this.tbManualYaxis.Location = new System.Drawing.Point(319, 530);
            this.tbManualYaxis.MaxLength = 8;
            this.tbManualYaxis.Name = "tbManualYaxis";
            this.tbManualYaxis.Size = new System.Drawing.Size(77, 22);
            this.tbManualYaxis.TabIndex = 33;
            this.tbManualYaxis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbManualYaxis_KeyPress);
            // 
            // tbManualZaxis
            // 
            this.tbManualZaxis.Location = new System.Drawing.Point(547, 530);
            this.tbManualZaxis.MaxLength = 8;
            this.tbManualZaxis.Name = "tbManualZaxis";
            this.tbManualZaxis.Size = new System.Drawing.Size(77, 22);
            this.tbManualZaxis.TabIndex = 34;
            this.tbManualZaxis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbManualZaxis_KeyPress);
            // 
            // btnManualSave_X
            // 
            this.btnManualSave_X.BackColor = System.Drawing.Color.LightGray;
            this.btnManualSave_X.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManualSave_X.Location = new System.Drawing.Point(174, 520);
            this.btnManualSave_X.Name = "btnManualSave_X";
            this.btnManualSave_X.Size = new System.Drawing.Size(63, 37);
            this.btnManualSave_X.TabIndex = 35;
            this.btnManualSave_X.Text = "SAVE";
            this.btnManualSave_X.UseVisualStyleBackColor = false;
            this.btnManualSave_X.Click += new System.EventHandler(this.btnManualSave_X_Click);
            // 
            // btnManualSave_Y
            // 
            this.btnManualSave_Y.BackColor = System.Drawing.Color.LightGray;
            this.btnManualSave_Y.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManualSave_Y.Location = new System.Drawing.Point(402, 520);
            this.btnManualSave_Y.Name = "btnManualSave_Y";
            this.btnManualSave_Y.Size = new System.Drawing.Size(63, 37);
            this.btnManualSave_Y.TabIndex = 36;
            this.btnManualSave_Y.Text = "SAVE";
            this.btnManualSave_Y.UseVisualStyleBackColor = false;
            this.btnManualSave_Y.Click += new System.EventHandler(this.btnManualSave_Y_Click);
            // 
            // btnManualSave_Z
            // 
            this.btnManualSave_Z.BackColor = System.Drawing.Color.LightGray;
            this.btnManualSave_Z.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManualSave_Z.Location = new System.Drawing.Point(630, 520);
            this.btnManualSave_Z.Name = "btnManualSave_Z";
            this.btnManualSave_Z.Size = new System.Drawing.Size(63, 37);
            this.btnManualSave_Z.TabIndex = 37;
            this.btnManualSave_Z.Text = "SAVE";
            this.btnManualSave_Z.UseVisualStyleBackColor = false;
            this.btnManualSave_Z.Click += new System.EventHandler(this.btnManualSave_Z_Click);
            // 
            // btnMoveStep
            // 
            this.btnMoveStep.BackColor = System.Drawing.Color.LightGray;
            this.btnMoveStep.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMoveStep.Location = new System.Drawing.Point(491, 128);
            this.btnMoveStep.Name = "btnMoveStep";
            this.btnMoveStep.Size = new System.Drawing.Size(109, 37);
            this.btnMoveStep.TabIndex = 38;
            this.btnMoveStep.Text = "MOVE STEP";
            this.btnMoveStep.UseVisualStyleBackColor = false;
            this.btnMoveStep.Click += new System.EventHandler(this.btnMoveStep_Click);
            // 
            // btnMovePosition
            // 
            this.btnMovePosition.BackColor = System.Drawing.Color.LightGray;
            this.btnMovePosition.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMovePosition.Location = new System.Drawing.Point(606, 128);
            this.btnMovePosition.Name = "btnMovePosition";
            this.btnMovePosition.Size = new System.Drawing.Size(134, 37);
            this.btnMovePosition.TabIndex = 39;
            this.btnMovePosition.Text = "MOVE POSITION";
            this.btnMovePosition.UseVisualStyleBackColor = false;
            this.btnMovePosition.Click += new System.EventHandler(this.btnMovePosition_Click);
            // 
            // btnMovePos_Apply
            // 
            this.btnMovePos_Apply.BackColor = System.Drawing.Color.LightGray;
            this.btnMovePos_Apply.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMovePos_Apply.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovePos_Apply.Location = new System.Drawing.Point(746, 128);
            this.btnMovePos_Apply.Name = "btnMovePos_Apply";
            this.btnMovePos_Apply.Size = new System.Drawing.Size(234, 37);
            this.btnMovePos_Apply.TabIndex = 40;
            this.btnMovePos_Apply.Text = "MOVE POSITION+APPLY GLUE";
            this.btnMovePos_Apply.UseVisualStyleBackColor = false;
            this.btnMovePos_Apply.Click += new System.EventHandler(this.btnMovePos_Apply_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 131);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 17);
            this.label16.TabIndex = 41;
            this.label16.Text = "JOG Speed ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(83, 131);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 17);
            this.label17.TabIndex = 43;
            this.label17.Text = "X axis :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(83, 161);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 17);
            this.label18.TabIndex = 44;
            this.label18.Text = "Y axis :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(266, 129);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 17);
            this.label19.TabIndex = 46;
            this.label19.Text = "Z axis :";
            // 
            // cbJogXSpeed
            // 
            this.cbJogXSpeed.FormattingEnabled = true;
            this.cbJogXSpeed.Location = new System.Drawing.Point(140, 129);
            this.cbJogXSpeed.Name = "cbJogXSpeed";
            this.cbJogXSpeed.Size = new System.Drawing.Size(98, 24);
            this.cbJogXSpeed.TabIndex = 48;
            this.cbJogXSpeed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbJogXSpeed_KeyPress);
            // 
            // cbJogYSpeed
            // 
            this.cbJogYSpeed.FormattingEnabled = true;
            this.cbJogYSpeed.Location = new System.Drawing.Point(140, 158);
            this.cbJogYSpeed.Name = "cbJogYSpeed";
            this.cbJogYSpeed.Size = new System.Drawing.Size(98, 24);
            this.cbJogYSpeed.TabIndex = 49;
            this.cbJogYSpeed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbJogYSpeed_KeyPress);
            // 
            // cbJogZSpeed
            // 
            this.cbJogZSpeed.FormattingEnabled = true;
            this.cbJogZSpeed.Location = new System.Drawing.Point(323, 127);
            this.cbJogZSpeed.Name = "cbJogZSpeed";
            this.cbJogZSpeed.Size = new System.Drawing.Size(98, 24);
            this.cbJogZSpeed.TabIndex = 50;
            this.cbJogZSpeed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbJogZSpeed_KeyPress);
            // 
            // btnJogRZ_minus
            // 
            this.btnJogRZ_minus.BackColor = System.Drawing.Color.LightGray;
            this.btnJogRZ_minus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJogRZ_minus.Location = new System.Drawing.Point(289, 313);
            this.btnJogRZ_minus.Name = "btnJogRZ_minus";
            this.btnJogRZ_minus.Size = new System.Drawing.Size(63, 57);
            this.btnJogRZ_minus.TabIndex = 52;
            this.btnJogRZ_minus.Text = "RZ-";
            this.btnJogRZ_minus.UseVisualStyleBackColor = false;
            // 
            // btnJogRZ_plus
            // 
            this.btnJogRZ_plus.BackColor = System.Drawing.Color.LightGray;
            this.btnJogRZ_plus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJogRZ_plus.Location = new System.Drawing.Point(289, 423);
            this.btnJogRZ_plus.Name = "btnJogRZ_plus";
            this.btnJogRZ_plus.Size = new System.Drawing.Size(63, 57);
            this.btnJogRZ_plus.TabIndex = 51;
            this.btnJogRZ_plus.Text = "RZ+";
            this.btnJogRZ_plus.UseVisualStyleBackColor = false;
            // 
            // tbCurrentRZaxis
            // 
            this.tbCurrentRZaxis.Enabled = false;
            this.tbCurrentRZaxis.Location = new System.Drawing.Point(315, 268);
            this.tbCurrentRZaxis.Name = "tbCurrentRZaxis";
            this.tbCurrentRZaxis.ReadOnly = true;
            this.tbCurrentRZaxis.Size = new System.Drawing.Size(77, 22);
            this.tbCurrentRZaxis.TabIndex = 54;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(256, 271);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(63, 17);
            this.label20.TabIndex = 53;
            this.label20.Text = "RZ axis :";
            // 
            // tbSavedRZaxis
            // 
            this.tbSavedRZaxis.Enabled = false;
            this.tbSavedRZaxis.Location = new System.Drawing.Point(855, 90);
            this.tbSavedRZaxis.Name = "tbSavedRZaxis";
            this.tbSavedRZaxis.ReadOnly = true;
            this.tbSavedRZaxis.Size = new System.Drawing.Size(77, 22);
            this.tbSavedRZaxis.TabIndex = 56;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(790, 93);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 17);
            this.label21.TabIndex = 55;
            this.label21.Text = "RZ axis :";
            // 
            // btnManualSave_RZ
            // 
            this.btnManualSave_RZ.BackColor = System.Drawing.Color.LightGray;
            this.btnManualSave_RZ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManualSave_RZ.Location = new System.Drawing.Point(876, 517);
            this.btnManualSave_RZ.Name = "btnManualSave_RZ";
            this.btnManualSave_RZ.Size = new System.Drawing.Size(63, 37);
            this.btnManualSave_RZ.TabIndex = 59;
            this.btnManualSave_RZ.Text = "SAVE";
            this.btnManualSave_RZ.UseVisualStyleBackColor = false;
            this.btnManualSave_RZ.Click += new System.EventHandler(this.btnManualSave_RZ_Click);
            // 
            // tbManualRZaxis
            // 
            this.tbManualRZaxis.Location = new System.Drawing.Point(793, 527);
            this.tbManualRZaxis.MaxLength = 8;
            this.tbManualRZaxis.Name = "tbManualRZaxis";
            this.tbManualRZaxis.Size = new System.Drawing.Size(77, 22);
            this.tbManualRZaxis.TabIndex = 58;
            this.tbManualRZaxis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbManualRZaxis_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(726, 530);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(63, 17);
            this.label22.TabIndex = 57;
            this.label22.Text = "RZ axis :";
            // 
            // cbJogRZSpeed
            // 
            this.cbJogRZSpeed.FormattingEnabled = true;
            this.cbJogRZSpeed.Location = new System.Drawing.Point(323, 159);
            this.cbJogRZSpeed.Name = "cbJogRZSpeed";
            this.cbJogRZSpeed.Size = new System.Drawing.Size(98, 24);
            this.cbJogRZSpeed.TabIndex = 61;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(256, 161);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(63, 17);
            this.label23.TabIndex = 60;
            this.label23.Text = "RZ axis :";
            // 
            // btnForceJog
            // 
            this.btnForceJog.BackColor = System.Drawing.Color.LightGray;
            this.btnForceJog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnForceJog.Location = new System.Drawing.Point(865, 558);
            this.btnForceJog.Name = "btnForceJog";
            this.btnForceJog.Size = new System.Drawing.Size(135, 42);
            this.btnForceJog.TabIndex = 63;
            this.btnForceJog.Text = "Force Jog OFF";
            this.btnForceJog.UseVisualStyleBackColor = false;
            this.btnForceJog.Click += new System.EventHandler(this.btnForceJog_Click);
            // 
            // ucXYZControls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnForceJog);
            this.Controls.Add(this.cbJogRZSpeed);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.btnManualSave_RZ);
            this.Controls.Add(this.tbManualRZaxis);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.tbSavedRZaxis);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.tbCurrentRZaxis);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.btnJogRZ_minus);
            this.Controls.Add(this.btnJogRZ_plus);
            this.Controls.Add(this.cbJogZSpeed);
            this.Controls.Add(this.cbJogYSpeed);
            this.Controls.Add(this.cbJogXSpeed);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.btnMovePos_Apply);
            this.Controls.Add(this.btnMovePosition);
            this.Controls.Add(this.btnMoveStep);
            this.Controls.Add(this.btnManualSave_Z);
            this.Controls.Add(this.btnManualSave_Y);
            this.Controls.Add(this.btnManualSave_X);
            this.Controls.Add(this.tbManualZaxis);
            this.Controls.Add(this.tbManualYaxis);
            this.Controls.Add(this.tbManualXaxis);
            this.Controls.Add(this.tbSavedZaxis);
            this.Controls.Add(this.tbSavedYaxis);
            this.Controls.Add(this.tbSavedXaxis);
            this.Controls.Add(this.tbCurrentZaxis);
            this.Controls.Add(this.tbCurrentYaxis);
            this.Controls.Add(this.tbCurrentXaxis);
            this.Controls.Add(this.cbStep);
            this.Controls.Add(this.cbPosition);
            this.Controls.Add(this.picSample);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btnSaveAll);
            this.Controls.Add(this.btnJogZ_minus);
            this.Controls.Add(this.btnJogZ_plus);
            this.Controls.Add(this.btnJogY_minus);
            this.Controls.Add(this.btnJogX_plus);
            this.Controls.Add(this.btnJogX_minus);
            this.Controls.Add(this.btnJogY_plus);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ucXYZControls";
            this.Size = new System.Drawing.Size(1000, 600);
            ((System.ComponentModel.ISupportInitialize)(this.picSample)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnJogY_plus;
        private System.Windows.Forms.Button btnJogX_minus;
        private System.Windows.Forms.Button btnJogX_plus;
        private System.Windows.Forms.Button btnJogY_minus;
        private System.Windows.Forms.Button btnJogZ_plus;
        private System.Windows.Forms.Button btnJogZ_minus;
        private System.Windows.Forms.Button btnSaveAll;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox picSample;
        private System.Windows.Forms.ComboBox cbStep;
        private System.Windows.Forms.TextBox tbCurrentXaxis;
        private System.Windows.Forms.TextBox tbCurrentYaxis;
        private System.Windows.Forms.TextBox tbCurrentZaxis;
        private System.Windows.Forms.TextBox tbSavedXaxis;
        private System.Windows.Forms.TextBox tbSavedYaxis;
        private System.Windows.Forms.TextBox tbSavedZaxis;
        private System.Windows.Forms.TextBox tbManualXaxis;
        private System.Windows.Forms.TextBox tbManualYaxis;
        private System.Windows.Forms.TextBox tbManualZaxis;
        private System.Windows.Forms.Button btnManualSave_X;
        private System.Windows.Forms.Button btnManualSave_Y;
        private System.Windows.Forms.Button btnManualSave_Z;
        private System.Windows.Forms.Button btnMoveStep;
        private System.Windows.Forms.Button btnMovePosition;
        private System.Windows.Forms.Button btnMovePos_Apply;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cbJogXSpeed;
        private System.Windows.Forms.ComboBox cbJogYSpeed;
        private System.Windows.Forms.ComboBox cbJogZSpeed;
        private System.Windows.Forms.ComboBox cbPosition;
        private System.Windows.Forms.Button btnJogRZ_minus;
        private System.Windows.Forms.Button btnJogRZ_plus;
        private System.Windows.Forms.TextBox tbCurrentRZaxis;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbSavedRZaxis;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnManualSave_RZ;
        private System.Windows.Forms.TextBox tbManualRZaxis;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cbJogRZSpeed;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnForceJog;
    }
}
