﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucMain : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        List<Label> labInputList = new List<Label>();
        List<Label> labOutputList = new List<Label>();

        //Glue 2
        SqlConnection Conn = new SqlConnection(@"Data Source=DESKTOP-4AGMG63\SQLEXPRESS;Initial Catalog=GlueMC;integrated security=true;");
        
        bool bChkShowErr;
        
        public ucMain(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;

            # region INPUT Ui AddList
            labInputList.Add(lbUpStopR1_IN);//I:100
            labInputList.Add(lbUpStopR1_OUT);//I:101
            labInputList.Add(lbUpStopR2_IN);//I:102
            labInputList.Add(lbUpStopR2_OUT);//I:103
            labInputList.Add(lbUpChkPart_L);//I:104
            labInputList.Add(lbUpChkPart_M);//I:105
            labInputList.Add(lbUpChkPart_R);//I:106
            labInputList.Add(lbDownStopL1_IN);//I:107
            labInputList.Add(lbDownStopL1_OUT);//I:108
            labInputList.Add(lbDownStopL2_IN);//I:109
            labInputList.Add(lbDownStopL2_OUT);//I:110
            labInputList.Add(lbDownChkPart_L);//I:111
            labInputList.Add(lbDownChkPart_M);//I:112
            labInputList.Add(lbDownChkPart_R);//I:113
            labInputList.Add(lbUpper_UnLock);//I:114
            labInputList.Add(lbUpper_Lock);//I:115
            labInputList.Add(lbRFID_L_IN);//I:200
            labInputList.Add(lbRFID_L_OUT);//I:201
            labInputList.Add(lbRFID_R_IN);//I:202
            labInputList.Add(lbRFID_R_OUT);//I:203
            labInputList.Add(lbSigUp_L_req);//I:208
            labInputList.Add(lbSigUp_R_acc);//I:212
            #endregion
            /////////////////////////////////////////
            # region OUTPUT Ui AddList
            labOutputList.Add(lbSigUp_L_acc);//O:208
            labOutputList.Add(lbSigUp_R_req);//O:212
            #endregion

        }

        public void UpdateUI()
        {
            if (Visible)
            {
                #region update input
                labInputList[0].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)0].State ? Color.LawnGreen : Color.LightGray;
                labInputList[1].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)1].State ? Color.LawnGreen : Color.LightGray;
                labInputList[2].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)2].State ? Color.LawnGreen : Color.LightGray;
                labInputList[3].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)3].State ? Color.LawnGreen : Color.LightGray;
                labInputList[4].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)4].State ? Color.LawnGreen : Color.LightGray;
                labInputList[5].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)5].State ? Color.LawnGreen : Color.LightGray;
                labInputList[6].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)6].State ? Color.LawnGreen : Color.LightGray;
                labInputList[7].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)7].State ? Color.LawnGreen : Color.LightGray;
                labInputList[8].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)8].State ? Color.LawnGreen : Color.LightGray;
                labInputList[9].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)9].State ? Color.LawnGreen : Color.LightGray;
                labInputList[10].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)10].State ? Color.LawnGreen : Color.LightGray;
                labInputList[11].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)11].State ? Color.LawnGreen : Color.LightGray;
                labInputList[12].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)12].State ? Color.LawnGreen : Color.LightGray;
                labInputList[13].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)13].State ? Color.LawnGreen : Color.LightGray;
                labInputList[14].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)14].State ? Color.LawnGreen : Color.LightGray;
                labInputList[15].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)15].State ? Color.LawnGreen : Color.LightGray;
                labInputList[16].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)0].State ? Color.LawnGreen : Color.LightGray;
                labInputList[17].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)1].State ? Color.LawnGreen : Color.LightGray;
                labInputList[18].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)2].State ? Color.LawnGreen : Color.LightGray;
                labInputList[19].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)3].State ? Color.LawnGreen : Color.LightGray;
                labInputList[20].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)8].State ? Color.LawnGreen : Color.LightGray;
                labInputList[21].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)12].State ? Color.LawnGreen : Color.LightGray;
                #endregion
                # region update output
                labOutputList[0].BackColor = _mainGUI.Common.IOTable.DO[(ushort)2, (ushort)8].State ? Color.LawnGreen : Color.LightGray;
                labOutputList[1].BackColor = _mainGUI.Common.IOTable.DO[(ushort)2, (ushort)12].State ? Color.LawnGreen : Color.LightGray;
                #endregion

            }

            if (_mainGUI.Common.bChkAlarm)
            {
                if (!bChkShowErr)
                {
                    Conn.Open();
                    SqlDataAdapter SqlDa = new SqlDataAdapter("SELECT * FROM ERROR_View", Conn);
                    DataTable dtbl = new DataTable();
                    SqlDa.Fill(dtbl);
                    dataGridView1.DataSource = dtbl;

                    int nRowIndex = dataGridView1.Rows.Count - 2;
                    dataGridView1.CurrentCell = dataGridView1.Rows[nRowIndex].Cells[0];
                    dataGridView1.Rows[nRowIndex].DefaultCellStyle.BackColor = Color.Red;
                    Conn.Close();

                    bChkShowErr = true;
                }
            }
            else
            {
                if (bChkShowErr)
                {
                    dataGridView1.DataSource = null;
                    bChkShowErr = false;
                }
            }
        }
    }
}
