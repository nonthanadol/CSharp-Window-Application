﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucEquipmentControls : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        List<Label> labInputList = new List<Label>();

        public ucEquipmentControls(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;

            tbPurgeTime.Text = _mainGUI.Common.dbSetPurgeTime.ToString();
            tbTimetoPurge.Text = _mainGUI.Common.iTimetoAutoPurge.ToString();

            #region First set
            _mainGUI.Common.bChkAutoPurge = Convert.ToBoolean(_mainGUI.Common.Config.ReadValue("OptionSelect", "AutoPurgeGlue").ToString());
            if (_mainGUI.Common.bChkAutoPurge)
            {
                lbAutoPurge_status.BackColor = Color.PaleGreen;
                lbAutoPurge_status.Text = "Auto Purge ON";
            }
            else
            {
                lbAutoPurge_status.BackColor = Color.Crimson;
                lbAutoPurge_status.Text = "Auto Purge OFF";
            }

            lbManualPurge_status.BackColor = Color.Crimson;
            lbManualPurge_status.Text = "OFF";
            _mainGUI.Common.bChkManualPurge = false;
            #endregion
            #region INPUT Ui AddList
            labInputList.Add(lbIN100);//I:100
            labInputList.Add(lbIN101);//I:101
            labInputList.Add(lbIN102);//I:102
            labInputList.Add(lbIN103);//I:103
            labInputList.Add(lbIN107);//I:107
            labInputList.Add(lbIN108);//I:108
            labInputList.Add(lbIN109);//I:109
            labInputList.Add(lbIN110);//I:110
            labInputList.Add(lbIN114);//I:114
            labInputList.Add(lbIN115);//I:115
            labInputList.Add(lbIN200);//I:200
            labInputList.Add(lbIN201);//I:201
            labInputList.Add(lbIN202);//I:202
            labInputList.Add(lbIN203);//I:203
            labInputList.Add(lbIN300);//I:300
            labInputList.Add(lbIN301);//I:301
            labInputList.Add(lbIN302);//I:302
            labInputList.Add(lbIN303);//I:303
            labInputList.Add(lbIN305);//I:305
            labInputList.Add(lbIN306);//I:306
            labInputList.Add(lbIN307);//I:307
            labInputList.Add(lbIN308);//I:308
            #endregion

        }

        public void UpdateUI()
        {
            if(Visible)
            {
                #region update input
                labInputList[0].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)0].State ? Color.LawnGreen : Color.LightGray;
                labInputList[1].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)1].State ? Color.LawnGreen : Color.LightGray;
                labInputList[2].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)2].State ? Color.LawnGreen : Color.LightGray;
                labInputList[3].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)3].State ? Color.LawnGreen : Color.LightGray;
                labInputList[4].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)7].State ? Color.LawnGreen : Color.LightGray;
                labInputList[5].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)8].State ? Color.LawnGreen : Color.LightGray;
                labInputList[6].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)9].State ? Color.LawnGreen : Color.LightGray;
                labInputList[7].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)10].State ? Color.LawnGreen : Color.LightGray;
                labInputList[8].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)14].State ? Color.LawnGreen : Color.LightGray;
                labInputList[9].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)15].State ? Color.LawnGreen : Color.LightGray;
                labInputList[10].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)0].State ? Color.LawnGreen : Color.LightGray;
                labInputList[11].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)1].State ? Color.LawnGreen : Color.LightGray;
                labInputList[12].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)2].State ? Color.LawnGreen : Color.LightGray;
                labInputList[13].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)3].State ? Color.LawnGreen : Color.LightGray;
                labInputList[14].BackColor = _mainGUI.Common.IOTable.DI[(ushort)3, (ushort)0].State ? Color.LawnGreen : Color.LightGray;
                labInputList[15].BackColor = _mainGUI.Common.IOTable.DI[(ushort)3, (ushort)1].State ? Color.LawnGreen : Color.LightGray;
                labInputList[16].BackColor = _mainGUI.Common.IOTable.DI[(ushort)3, (ushort)2].State ? Color.LawnGreen : Color.LightGray;
                labInputList[17].BackColor = _mainGUI.Common.IOTable.DI[(ushort)3, (ushort)3].State ? Color.LawnGreen : Color.LightGray;
                labInputList[18].BackColor = _mainGUI.Common.IOTable.DI[(ushort)3, (ushort)5].State ? Color.LawnGreen : Color.LightGray;
                labInputList[19].BackColor = _mainGUI.Common.IOTable.DI[(ushort)3, (ushort)6].State ? Color.LawnGreen : Color.LightGray;
                labInputList[20].BackColor = _mainGUI.Common.IOTable.DI[(ushort)3, (ushort)7].State ? Color.LawnGreen : Color.LightGray;
                labInputList[21].BackColor = _mainGUI.Common.IOTable.DI[(ushort)3, (ushort)8].State ? Color.LawnGreen : Color.LightGray;
                #endregion
                tbTimeCountToPurge.Text = _mainGUI.Common.iPurgeTimeCount.ToString();

                #region RFID L
                if (!_mainGUI.Common.IOTable.DO[2, 0].State)
                {
                    btnRFID_L.BackColor = Color.LightGray;
                    _mainGUI.Common.bChkRFID_L = false;
                }
                else
                {
                    btnRFID_L.BackColor = Color.YellowGreen;
                    _mainGUI.Common.bChkRFID_L = true;
                }
                #endregion
                #region RFID R
                if (!_mainGUI.Common.IOTable.DO[2, 2].State)
                {
                    btnRFID_R.BackColor = Color.LightGray;
                    _mainGUI.Common.bChkRFID_R = false;
                }
                else
                {
                    btnRFID_R.BackColor = Color.YellowGreen;
                    _mainGUI.Common.bChkRFID_R = true;
                }
                #endregion
                #region Stopper upper
                if (!_mainGUI.Common.IOTable.DO[1, 0].State)
                {
                    btnStopper_Upper.BackColor = Color.LightGray;
                    _mainGUI.Common.bChkStopperUP = false;
                }
                else
                {
                    btnStopper_Upper.BackColor = Color.YellowGreen;
                    _mainGUI.Common.bChkStopperUP = true;
                }
                #endregion
                #region Pallet Lock-UnLock
                if (!_mainGUI.Common.IOTable.DO[1, 14].State)
                {
                    btnPalletLock.BackColor = Color.LightGray;
                    _mainGUI.Common.bChkPallet_Lock = false;
                }
                else
                {
                    btnPalletLock.BackColor = Color.YellowGreen;
                    _mainGUI.Common.bChkPallet_Lock = true;
                }
                #endregion
                #region Stopper under
                if (!_mainGUI.Common.IOTable.DO[1, 7].State)
                {
                    btnStopper_Under.BackColor = Color.LightGray;
                    _mainGUI.Common.bChkStopperDown = false;
                }
                else
                {
                    btnStopper_Under.BackColor = Color.YellowGreen;
                    _mainGUI.Common.bChkStopperDown = true;
                }
                #endregion
                #region ToolsClamp
                if (_mainGUI.Common.bToolsClamp)
                {
                    btnToolsClamp.BackColor = Color.YellowGreen;
                    btnToolsUnClamp.BackColor = Color.LightGray;
                }
                else
                {
                    btnToolsClamp.BackColor = Color.LightGray;
                    btnToolsUnClamp.BackColor = Color.YellowGreen;
                }
                #endregion

                //Disable button if initial not finish.
                if (!_mainGUI.Common.bFlgInitial_Finished || _mainGUI.Common.bManualPickPlaceOnWork) 
                { 
                    btnTool1_Pick.Enabled = false; 
                    btnTool1_Place.Enabled = false; 
                    btnTool2_Pick.Enabled = false; 
                    btnTool2_Place.Enabled = false; 
                }
                else
                {
                    if (_mainGUI.Common.iToolsPick == 0)
                    {
                        btnTool1_Pick.Enabled = true;
                        btnTool1_Place.Enabled = false;
                        btnTool2_Pick.Enabled = true;
                        btnTool2_Place.Enabled = false;
                    }
                    else if (_mainGUI.Common.iToolsPick == 1)
                    {
                        btnTool1_Pick.Enabled = false;
                        btnTool1_Place.Enabled = true;
                        btnTool2_Pick.Enabled = false;
                        btnTool2_Place.Enabled = false;
                    }
                    else if (_mainGUI.Common.iToolsPick == 2)
                    {
                        btnTool1_Pick.Enabled = false;
                        btnTool1_Place.Enabled = false;
                        btnTool2_Pick.Enabled = false;
                        btnTool2_Place.Enabled = true;
                    }
                }


            }
        }



        #region KEY PRESS EVENT
        private void tbPurgeTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        private void tbTimetoPurge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        #endregion
        #region MOUSE UP/DOWN EVENT
        private void btnAutoPurge_ON_MouseDown(object sender, MouseEventArgs e)
        {
            btnAutoPurge_ON.BackColor = Color.LightCoral;
        }

        private void btnAutoPurge_ON_MouseUp(object sender, MouseEventArgs e)
        {
            btnAutoPurge_ON.BackColor = Color.LightGray;
        }

        private void btnAutoPurge_OFF_MouseDown(object sender, MouseEventArgs e)
        {
            btnAutoPurge_OFF.BackColor = Color.LightCoral;
        }

        private void btnAutoPurge_OFF_MouseUp(object sender, MouseEventArgs e)
        {
            btnAutoPurge_OFF.BackColor = Color.LightGray;
        }

        private void btnManualPurge_ON_MouseDown(object sender, MouseEventArgs e)
        {
            btnManualPurge_ON.BackColor = Color.LightCoral;
        }

        private void btnManualPurge_ON_MouseUp(object sender, MouseEventArgs e)
        {
            btnManualPurge_ON.BackColor = Color.LightGray;
        }

        private void btnManualPurge_OFF_MouseDown(object sender, MouseEventArgs e)
        {
            btnManualPurge_OFF.BackColor = Color.LightCoral;
        }

        private void btnManualPurge_OFF_MouseUp(object sender, MouseEventArgs e)
        {
            btnManualPurge_OFF.BackColor = Color.LightGray;
        }
        #endregion
        #region BUTTON CLICK EVENT
        private void btnAutoPurge_ON_Click(object sender, EventArgs e)
        {
            lbAutoPurge_status.BackColor = Color.PaleGreen;
            lbAutoPurge_status.Text = "Auto Purge ON";
            _mainGUI.Common.bChkAutoPurge = true;
            _mainGUI.Common.Config.WriteValue("OptionSelect", "AutoPurgeGlue", _mainGUI.Common.bChkAutoPurge.ToString());
        }
        private void btnAutoPurge_OFF_Click(object sender, EventArgs e)
        {
            lbAutoPurge_status.BackColor = Color.Crimson;
            lbAutoPurge_status.Text = "Auto Purge OFF";
            _mainGUI.Common.bChkAutoPurge = false;
            _mainGUI.Common.Config.WriteValue("OptionSelect", "AutoPurgeGlue", _mainGUI.Common.bChkAutoPurge.ToString());
        }
        private void btnManualPurge_ON_Click(object sender, EventArgs e)
        {
            lbManualPurge_status.BackColor = Color.PaleGreen;
            lbManualPurge_status.Text = "ON";
            _mainGUI.Common.bChkManualPurge = true;
            _mainGUI.Common.IOTable.DO[0, 4].Set();
        }
        private void btnManualPurge2_ON_Click(object sender, EventArgs e)
        {
            lbManualPurge2_status.BackColor = Color.PaleGreen;
            lbManualPurge2_status.Text = "ON";
            _mainGUI.Common.bChkManualPurge = true;
            _mainGUI.Common.IOTable.DO[0, 5].Set();
        }
        private void btnManualPurge2_OFF_Click(object sender, EventArgs e)
        {
            lbManualPurge2_status.BackColor = Color.Crimson;
            lbManualPurge2_status.Text = "OFF";
            _mainGUI.Common.bChkManualPurge = false;
            _mainGUI.Common.IOTable.DO[0, 5].Reset();
        }
        private void btnManualPurge_OFF_Click(object sender, EventArgs e)
        {
            lbManualPurge_status.BackColor = Color.Crimson;
            lbManualPurge_status.Text = "OFF";
            _mainGUI.Common.bChkManualPurge = false;
            _mainGUI.Common.IOTable.DO[0, 4].Reset();
        }
        private void btnUpCVMove_L_Click(object sender, EventArgs e)
        {
            if (!_mainGUI.Common.bChkCVUP_MOVE_R) 
            { 
                if (_mainGUI.Common.bChkCVUP_MOVE_L)
                {
                    btnUpCVMove_L.BackColor = Color.LightGray;
                    _mainGUI.Common.bChkCVUP_MOVE_L = false;
                    _mainGUI.Common.IOTable.DO[1, 4].Reset();//CConveyer Upper CCW OFF
                }
                else
                {
                    btnUpCVMove_L.BackColor = Color.YellowGreen;
                    _mainGUI.Common.bChkCVUP_MOVE_L = true;
                    _mainGUI.Common.IOTable.DO[1, 4].Set();//CConveyer Upper CCW ON
                }
            }
        }
        private void btnUpCVMove_R_Click(object sender, EventArgs e)
        {
            if (!_mainGUI.Common.bChkCVUP_MOVE_L)
            {
                if (_mainGUI.Common.bChkCVUP_MOVE_R)
                {
                    btnUpCVMove_R.BackColor = Color.LightGray;
                    _mainGUI.Common.bChkCVUP_MOVE_R = false;
                    _mainGUI.Common.IOTable.DO[1, 5].Reset();//CConveyer Upper CW OFF
                }
                else
                {
                    btnUpCVMove_R.BackColor = Color.YellowGreen;
                    _mainGUI.Common.bChkCVUP_MOVE_R = true;
                    _mainGUI.Common.IOTable.DO[1, 5].Set();//CConveyer Upper CW ON
                }
            }

        }
        private void btnRFID_L_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkRFID_L)
            {
                _mainGUI.Common.IOTable.DO[2, 0].Reset();
            }
            else
            {
                _mainGUI.Common.IOTable.DO[2, 0].Set();
            }
        }
        private void btnRFID_R_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkRFID_R)
            {
                _mainGUI.Common.IOTable.DO[2, 2].Reset();
            }
            else
            {
                _mainGUI.Common.IOTable.DO[2, 2].Set();
            }
        }
        private void btnStopper_Upper_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkStopperUP)
            {
                _mainGUI.Common.IOTable.DO[1, 0].Reset();
            }
            else
            {
                _mainGUI.Common.IOTable.DO[1, 0].Set();
            }
        }
        private void btnPalletLock_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkPallet_Lock)
            {
                _mainGUI.Common.IOTable.DO[1, 14].Reset();
            }
            else
            {
                _mainGUI.Common.IOTable.DO[1, 14].Set();
            }
        }
        private void btnDownCVMove_L_Click(object sender, EventArgs e)
        {
            if (!_mainGUI.Common.bChkCVDown_MOVE_R)
            {
                if (_mainGUI.Common.bChkCVDown_MOVE_L)
                {
                    btnDownCVMove_L.BackColor = Color.LightGray;
                    _mainGUI.Common.bChkCVDown_MOVE_L = false;
                    _mainGUI.Common.IOTable.DO[1, 12].Reset();//CConveyer Under CCW OFF
                }
                else
                {
                    btnDownCVMove_L.BackColor = Color.YellowGreen;
                    _mainGUI.Common.bChkCVDown_MOVE_L = true;
                    _mainGUI.Common.IOTable.DO[1, 12].Set();//CConveyer Under CCW ON
                }
            }
        }
        private void btnDownCVMove_R_Click(object sender, EventArgs e)
        {
            if (!_mainGUI.Common.bChkCVDown_MOVE_L)
            {
                if (_mainGUI.Common.bChkCVDown_MOVE_R)
                {
                    btnDownCVMove_R.BackColor = Color.LightGray;
                    _mainGUI.Common.bChkCVDown_MOVE_R = false;
                    _mainGUI.Common.IOTable.DO[1, 11].Reset();//CConveyer Under CCW OFF
                }
                else
                {
                    btnDownCVMove_R.BackColor = Color.YellowGreen;
                    _mainGUI.Common.bChkCVDown_MOVE_R = true;
                    _mainGUI.Common.IOTable.DO[1, 11].Set();//CConveyer Under CCW ON
                }
            }
        }
        private void btnStopper_Under_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkStopperDown)
            {
                _mainGUI.Common.IOTable.DO[1, 7].Reset();
            }
            else
            {
                _mainGUI.Common.IOTable.DO[1, 7].Set();
            }
        }
        private void btnResetTimeCount_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Reset Time count?", "Reset confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.iPurgeTimeCount = 0;                
            }
        }

        private void btnTool1_Pick_Click(object sender, EventArgs e)
        {
            if (!_mainGUI.Common.bManualPickPlaceOnWork)
            {
                DialogResult re = MessageBox.Show("Confirm to pick tool 1?", "Pick tools confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                if (re == DialogResult.Yes)
                {
                    _mainGUI.Common.bTool_1_Pick_Trig = true;
                }
            }            
        }

        private void btnTool1_Place_Click(object sender, EventArgs e)
        {
            if (!_mainGUI.Common.bManualPickPlaceOnWork)
            {
                DialogResult re = MessageBox.Show("Confirm to place tool 1?", "Place tools confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                if (re == DialogResult.Yes)
                {
                    _mainGUI.Common.bTool_1_Place_Trig = true;
                }
            }
        }

        private void btnTool2_Pick_Click(object sender, EventArgs e)
        {
            if (!_mainGUI.Common.bManualPickPlaceOnWork)
            {
                DialogResult re = MessageBox.Show("Confirm to pick tool 2?", "Pick tools confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                if (re == DialogResult.Yes)
                {
                    _mainGUI.Common.bTool_2_Pick_Trig = true;
                }
            }
        }

        private void btnTool2_Place_Click(object sender, EventArgs e)
        {
            if (!_mainGUI.Common.bManualPickPlaceOnWork)
            {
                DialogResult re = MessageBox.Show("Confirm to place tool 1?", "Place tools confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                if (re == DialogResult.Yes)
                {
                    _mainGUI.Common.bTool_2_Place_Trig = true;
                }
            }
        }

        private void btnTool1_LockUnLock_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkTool_1_Lock)
            {
                btnTool1_LockUnLock.BackColor = Color.LightGray;
                _mainGUI.Common.bChkTool_1_Lock = false;
                _mainGUI.Common.IOTable.DO[3, 2].Reset();
            }
            else
            {
                btnTool1_LockUnLock.BackColor = Color.YellowGreen;
                _mainGUI.Common.bChkTool_1_Lock = true;
                _mainGUI.Common.IOTable.DO[3, 2].Set();
            }
        }

        private void btnTool1_INOUT_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkTool_1_INOUT)
            {
                btnTool1_INOUT.BackColor = Color.LightGray;
                _mainGUI.Common.bChkTool_1_INOUT = false;
                _mainGUI.Common.IOTable.DO[3, 0].Reset();
            }
            else
            {
                btnTool1_INOUT.BackColor = Color.YellowGreen;
                _mainGUI.Common.bChkTool_1_INOUT = true;
                _mainGUI.Common.IOTable.DO[3, 0].Set();
            }
        }

        private void btnTool2_LockUnLock_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkTool_2_Lock)
            {
                btnTool2_LockUnLock.BackColor = Color.LightGray;
                _mainGUI.Common.bChkTool_2_Lock = false;
                _mainGUI.Common.IOTable.DO[3, 7].Reset();
            }
            else
            {
                btnTool2_LockUnLock.BackColor = Color.YellowGreen;
                _mainGUI.Common.bChkTool_2_Lock = true;
                _mainGUI.Common.IOTable.DO[3, 7].Set();
            }
        }

        private void btnTool2_INOUT_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkTool_2_INOUT)
            {
                btnTool2_INOUT.BackColor = Color.LightGray;
                _mainGUI.Common.bChkTool_2_INOUT = false;
                _mainGUI.Common.IOTable.DO[3, 5].Reset();
            }
            else
            {
                btnTool2_INOUT.BackColor = Color.YellowGreen;
                _mainGUI.Common.bChkTool_2_INOUT = true;
                _mainGUI.Common.IOTable.DO[3, 5].Set();
            }
        }

        private void btnToolsClamp_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm Tools Clamp?", "Tools Clamp confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                btnToolsClamp.BackColor = Color.YellowGreen;
                btnToolsUnClamp.BackColor = Color.LightGray;
                _mainGUI.Common.bToolsClamp = true;
                _mainGUI.Common.IOTable.DO[3, 10].Set();
                _mainGUI.Common.IOTable.DO[3, 11].Reset();
            }
        }

        private void btnToolsUnClamp_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm Tools Un-Clamp?", "Tools Un-Clamp confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                btnToolsClamp.BackColor = Color.LightGray;
                btnToolsUnClamp.BackColor = Color.YellowGreen;
                _mainGUI.Common.bToolsClamp = false;
                _mainGUI.Common.IOTable.DO[3, 10].Reset();
                _mainGUI.Common.IOTable.DO[3, 11].Set();
            }
        }

        private void btnCameraLight_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkCameraLight)
            {
                btnCameraLight.BackColor = Color.LightGray;
                _mainGUI.Common.bChkCameraLight = false;
                _mainGUI.Common.IOTable.DO[2, 6].Reset(); //Light source off
            }
            else
            {
                btnCameraLight.BackColor = Color.YellowGreen;
                _mainGUI.Common.bChkCameraLight = true;
                _mainGUI.Common.IOTable.DO[2, 6].Set(); //Light source on
            }
        }


        #endregion

        
    }
}
