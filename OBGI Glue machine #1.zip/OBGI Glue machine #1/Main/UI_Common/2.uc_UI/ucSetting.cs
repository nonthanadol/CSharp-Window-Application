﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucSetting : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        public ucSetting(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;
        }

        public void UpdateUI()
        {
            if (Visible)
            {
                if (_mainGUI.Common.bPassLogin)
                {
                    _mainGUI.Common.bPassLogin = false;
                    foreach (Control item in Parent.Controls)
                    {
                        if (item is ucCalibration)
                        {
                            item.Visible = true;
                        }
                        else
                        {
                            item.Visible = false;
                        }
                    }
                }
            }
        }

        private void btnModelSelect_Click(object sender, EventArgs e)
        {
            foreach (Control item in Parent.Controls)
            {
                if (item is ucModelSelect)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }

        private void btnXYZControls_Click(object sender, EventArgs e)
        {
            foreach (Control item in Parent.Controls)
            {
                if (item is ucXYZControls)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }

        private void btnEquipControl_Click(object sender, EventArgs e)
        {
            foreach (Control item in Parent.Controls)
            {
                if (item is ucEquipmentControls)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }

        private void btnSigSafe_Click(object sender, EventArgs e)
        {
            foreach (Control item in Parent.Controls)
            {
                if (item is ucSignalSafety)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }

        private void btnPQM_Click(object sender, EventArgs e)
        {
            foreach (Control item in Parent.Controls)
            {
                if (item is ucPQM)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }

        private void btnRFID_MES_Click(object sender, EventArgs e)
        {
            foreach (Control item in Parent.Controls)
            {
                if (item is ucRFIDMes)
                {
                    item.Visible = true;

                }
                else
                {
                    item.Visible = false;
                }
            }
        }

        private void btnCalibration_Click(object sender, EventArgs e)
        {
            using (Form_Password PassInput = new Form_Password(_mainGUI))
            {
                PassInput.ShowDialog();
            }
        }

        private void btnSpdDT_Click(object sender, EventArgs e)
        {
            foreach (Control item in Parent.Controls)
            {
                if (item is ucSpeedDelay_M1)
                {
                    item.Visible = true;

                }
                else
                {
                    item.Visible = false;
                }
            }
        }
    }
}
