﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Equipment_Control.ASD_A2_E;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucCalibration : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        XYZ_Motion _ApplyGlue;


        private float fX1current_pos;
        private float fY1current_pos;
        private float fZ1current_pos;


        public ucCalibration(MainGUI mainGUI, XYZ_Motion applyGlue)
        {
            this._mainGUI = mainGUI;
            this._ApplyGlue = applyGlue;

            

            InitializeComponent();

            #region First Load & Set
            _mainGUI.Common.bChkCemeraOffset = Convert.ToBoolean(_mainGUI.Common.Config.ReadValue("OptionSelect", "CameraOffset").ToString());
            if (_mainGUI.Common.bChkCemeraOffset)
            {
                lbCameraOffset.Text = "Use camera for offset";
                lbCameraOffset.BackColor = Color.LawnGreen;
            }
            else
            {
                lbCameraOffset.Text = "Not use camera for offset";
                lbCameraOffset.BackColor = Color.Red;
            }

            //Add tools
            cbToolsCalSelectNo.Items.Add("1");
            //cbToolsCalSelectNo.Items.Add("2");

            cbToolsCalSelectNo.SelectedItem = "1";

            //First Load
            _mainGUI.Common.dbNozzle1_First_Set_X = _mainGUI.Common.Para.ReadValue("Nozzle_1", "X_First_Set").ToDouble();
            _mainGUI.Common.dbNozzle1_First_Set_Y = _mainGUI.Common.Para.ReadValue("Nozzle_1", "Y_First_Set").ToDouble();
            _mainGUI.Common.dbNozzle1_First_Set_Z = _mainGUI.Common.Para.ReadValue("Nozzle_1", "Z_First_Set").ToDouble();
            _mainGUI.Common.dbNozzle1_Now_X = _mainGUI.Common.Para.ReadValue("Nozzle_1", "X_Now").ToDouble();
            _mainGUI.Common.dbNozzle1_Now_Y = _mainGUI.Common.Para.ReadValue("Nozzle_1", "Y_Now").ToDouble();
            _mainGUI.Common.dbNozzle1_Now_Z = _mainGUI.Common.Para.ReadValue("Nozzle_1", "Z_Now").ToDouble();

            _mainGUI.Common.dbNozzle2_First_Set_X = _mainGUI.Common.Para.ReadValue("Nozzle_2", "X_First_Set").ToDouble();
            _mainGUI.Common.dbNozzle2_First_Set_Y = _mainGUI.Common.Para.ReadValue("Nozzle_2", "Y_First_Set").ToDouble();
            _mainGUI.Common.dbNozzle2_First_Set_Z = _mainGUI.Common.Para.ReadValue("Nozzle_2", "Z_First_Set").ToDouble();
            _mainGUI.Common.dbNozzle2_Now_X = _mainGUI.Common.Para.ReadValue("Nozzle_2", "X_Now").ToDouble();
            _mainGUI.Common.dbNozzle2_Now_Y = _mainGUI.Common.Para.ReadValue("Nozzle_2", "Y_Now").ToDouble();
            _mainGUI.Common.dbNozzle2_Now_Z = _mainGUI.Common.Para.ReadValue("Nozzle_2", "Z_Now").ToDouble();

            _mainGUI.Common.dbCamera_X1 = _mainGUI.Common.Para.ReadValue("Camera", "X1_Cam_3Point").ToDouble();
            _mainGUI.Common.dbCamera_X2 = _mainGUI.Common.Para.ReadValue("Camera", "X2_Cam_3Point").ToDouble();
            _mainGUI.Common.dbCamera_Y1 = _mainGUI.Common.Para.ReadValue("Camera", "Y1_Cam_3Point").ToDouble();
            _mainGUI.Common.dbCamera_Y2 = _mainGUI.Common.Para.ReadValue("Camera", "Y2_Cam_3Point").ToDouble();
            _mainGUI.Common.dbServo_X1 = _mainGUI.Common.Para.ReadValue("Camera", "X1_Servo_3Point").ToDouble();
            _mainGUI.Common.dbServo_X2 = _mainGUI.Common.Para.ReadValue("Camera", "X2_Servo_3Point").ToDouble();
            _mainGUI.Common.dbServo_Y1 = _mainGUI.Common.Para.ReadValue("Camera", "Y1_Servo_3Point").ToDouble();
            _mainGUI.Common.dbServo_Y2 = _mainGUI.Common.Para.ReadValue("Camera", "Y2_Servo_3Point").ToDouble();


            tbCamera_X1.Text = _mainGUI.Common.dbCamera_X1.ToString();
            tbCamera_X2.Text = _mainGUI.Common.dbCamera_X2.ToString();
            tbCamera_Y1.Text = _mainGUI.Common.dbCamera_Y1.ToString();
            tbCamera_Y2.Text = _mainGUI.Common.dbCamera_Y2.ToString();
            tbServo_X1.Text = _mainGUI.Common.dbServo_X1.ToString();
            tbServo_X2.Text = _mainGUI.Common.dbServo_X2.ToString();
            tbServo_Y1.Text = _mainGUI.Common.dbServo_Y1.ToString();
            tbServo_Y2.Text = _mainGUI.Common.dbServo_Y2.ToString();

            tbXMaster.Text = _mainGUI.Common.Para.ReadValue("Camera", "X_Master").ToString();
            tbYMaster.Text = _mainGUI.Common.Para.ReadValue("Camera", "Y_Master").ToString();

            #endregion

        }

        public void UpdateUI()
        {
            _mainGUI.Common.iNozzle_Cal_Select = Convert.ToInt32(cbToolsCalSelectNo.Text);

            _mainGUI.Common.dbNozzle1_First_Set_X = _mainGUI.Common.Para.ReadValue("Nozzle_1", "X_First_Set").ToInt();
            _mainGUI.Common.dbNozzle1_First_Set_Y = _mainGUI.Common.Para.ReadValue("Nozzle_1", "Y_First_Set").ToInt();
            _mainGUI.Common.dbNozzle1_First_Set_Z = _mainGUI.Common.Para.ReadValue("Nozzle_1", "Z_First_Set").ToInt();
            _mainGUI.Common.dbNozzle1_Now_X = _mainGUI.Common.Para.ReadValue("Nozzle_1", "X_Now").ToInt();
            _mainGUI.Common.dbNozzle1_Now_Y = _mainGUI.Common.Para.ReadValue("Nozzle_1", "Y_Now").ToInt();
            _mainGUI.Common.dbNozzle1_Now_Z = _mainGUI.Common.Para.ReadValue("Nozzle_1", "Z_Now").ToInt();

            _mainGUI.Common.dbNozzle2_First_Set_X = _mainGUI.Common.Para.ReadValue("Nozzle_2", "X_First_Set").ToInt();
            _mainGUI.Common.dbNozzle2_First_Set_Y = _mainGUI.Common.Para.ReadValue("Nozzle_2", "Y_First_Set").ToInt();
            _mainGUI.Common.dbNozzle2_First_Set_Z = _mainGUI.Common.Para.ReadValue("Nozzle_2", "Z_First_Set").ToInt();
            _mainGUI.Common.dbNozzle2_Now_X = _mainGUI.Common.Para.ReadValue("Nozzle_2", "X_Now").ToInt();
            _mainGUI.Common.dbNozzle2_Now_Y = _mainGUI.Common.Para.ReadValue("Nozzle_2", "Y_Now").ToInt();
            _mainGUI.Common.dbNozzle2_Now_Z = _mainGUI.Common.Para.ReadValue("Nozzle_2", "Z_Now").ToInt();

            _mainGUI.Common.dbNozzle_X_Diff = _mainGUI.Common.dbNozzle1_First_Set_X - _mainGUI.Common.dbNozzle1_Now_X;
            _mainGUI.Common.dbNozzle_Y_Diff = _mainGUI.Common.dbNozzle1_First_Set_Y - _mainGUI.Common.dbNozzle1_Now_Y;
            _mainGUI.Common.dbNozzle_Z_Diff = _mainGUI.Common.dbNozzle1_First_Set_Z - _mainGUI.Common.dbNozzle1_Now_Z;

            _mainGUI.Common.dbNozzle_2_X_Diff = _mainGUI.Common.dbNozzle2_First_Set_X - _mainGUI.Common.dbNozzle2_Now_X;
            _mainGUI.Common.dbNozzle_2_Y_Diff = _mainGUI.Common.dbNozzle2_First_Set_Y - _mainGUI.Common.dbNozzle2_Now_Y;
            _mainGUI.Common.dbNozzle_2_Z_Diff = _mainGUI.Common.dbNozzle2_First_Set_Z - _mainGUI.Common.dbNozzle2_Now_Z;

            if (_mainGUI.Common.iNozzle_Cal_Select == 1)
            {
                tbNozzle_X_Diff.Text = _mainGUI.Common.dbNozzle_X_Diff.ToString();
                tbNozzle_Y_Diff.Text = _mainGUI.Common.dbNozzle_Y_Diff.ToString();
                tbNozzle_Z_Diff.Text = _mainGUI.Common.dbNozzle_Z_Diff.ToString();
            }
            else
            {
                tbNozzle_X_Diff.Text = _mainGUI.Common.dbNozzle_2_X_Diff.ToString();
                tbNozzle_Y_Diff.Text = _mainGUI.Common.dbNozzle_2_Y_Diff.ToString();
                tbNozzle_Z_Diff.Text = _mainGUI.Common.dbNozzle_2_Z_Diff.ToString();
            }

            _mainGUI.Common.dbCamera_X_Result = (_mainGUI.Common.dbServo_X2 - _mainGUI.Common.dbServo_X1) / (_mainGUI.Common.dbCamera_X2 - _mainGUI.Common.dbCamera_X1);
            _mainGUI.Common.dbCamera_Y_Result = (_mainGUI.Common.dbServo_Y2 - _mainGUI.Common.dbServo_Y1) / (_mainGUI.Common.dbCamera_Y2 - _mainGUI.Common.dbCamera_Y1);

            tbCamera_X_Result.Text = _mainGUI.Common.dbCamera_X_Result.ToString();
            tbCamera_Y_Result.Text = _mainGUI.Common.dbCamera_Y_Result.ToString();

            _mainGUI.Common.dbMas_X_position = Convert.ToDouble(tbXMaster.Text);
            _mainGUI.Common.dbMas_Y_position = Convert.ToDouble(tbYMaster.Text);

            updateUIXYZPos();


        }

        #region Key press
        private void tbNozzleFirstSet_X_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbNozzleFirstSet_Y_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbNozzleFirstSet_Z_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbNozzleNow_X_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbNozzleNow_Y_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbNozzleNow_Z_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbCamera_X1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbCamera_X2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbCamera_Y1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbCamera_Y2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbServo_X1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbServo_X2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbServo_Y1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbServo_Y2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
        #endregion

        #region Save/Load
        private void btnNozzleFirstSet_Save_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Save Nozzle First Set?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Para.WriteValue("Nozzle_" + cbToolsCalSelectNo.Text, "X_First_Set", " " + Convert.ToDouble(tbXCurrentPos_1.Text));
                _mainGUI.Common.Para.WriteValue("Nozzle_" + cbToolsCalSelectNo.Text, "Y_First_Set", " " + Convert.ToDouble(tbYCurrentPos_1.Text));
                _mainGUI.Common.Para.WriteValue("Nozzle_" + cbToolsCalSelectNo.Text, "Z_First_Set", " " + Convert.ToDouble(tbZCurrentPos_1.Text));
            }
        }

        private void btnNozzleNow_Save_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Save Nozzle Now Set?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Para.WriteValue("Nozzle_" + cbToolsCalSelectNo.Text, "X_Now", " " + Convert.ToDouble(tbXCurrentPos_2.Text));
                _mainGUI.Common.Para.WriteValue("Nozzle_" + cbToolsCalSelectNo.Text, "Y_Now", " " + Convert.ToDouble(tbYCurrentPos_2.Text));
                _mainGUI.Common.Para.WriteValue("Nozzle_" + cbToolsCalSelectNo.Text, "Z_Now", " " + Convert.ToDouble(tbZCurrentPos_2.Text));
            }
        }

        private void btnCameraCal_Save_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to Save Camera Calibration data?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.dbCamera_X1 = Convert.ToDouble(tbCamera_X1.Text);
                _mainGUI.Common.dbCamera_X2 = Convert.ToDouble(tbCamera_X2.Text);
                _mainGUI.Common.dbCamera_Y1 = Convert.ToDouble(tbCamera_Y1.Text);
                _mainGUI.Common.dbCamera_Y2 = Convert.ToDouble(tbCamera_Y2.Text);
                _mainGUI.Common.dbServo_X1 = Convert.ToDouble(tbServo_X1.Text);
                _mainGUI.Common.dbServo_X2 = Convert.ToDouble(tbServo_X2.Text);
                _mainGUI.Common.dbServo_Y1 = Convert.ToDouble(tbServo_Y1.Text);
                _mainGUI.Common.dbServo_Y2 = Convert.ToDouble(tbServo_Y2.Text);

                _mainGUI.Common.Para.WriteValue("Camera", "X1_Cam_3Point", " " + _mainGUI.Common.dbCamera_X1);
                _mainGUI.Common.Para.WriteValue("Camera", "X2_Cam_3Point", " " + _mainGUI.Common.dbCamera_X2);
                _mainGUI.Common.Para.WriteValue("Camera", "Y1_Cam_3Point", " " + _mainGUI.Common.dbCamera_Y1);
                _mainGUI.Common.Para.WriteValue("Camera", "Y2_Cam_3Point", " " + _mainGUI.Common.dbCamera_Y2);
                _mainGUI.Common.Para.WriteValue("Camera", "X1_Servo_3Point", " " + _mainGUI.Common.dbServo_X1);
                _mainGUI.Common.Para.WriteValue("Camera", "X2_Servo_3Point", " " + _mainGUI.Common.dbServo_X2);
                _mainGUI.Common.Para.WriteValue("Camera", "Y1_Servo_3Point", " " + _mainGUI.Common.dbServo_Y1);
                _mainGUI.Common.Para.WriteValue("Camera", "Y2_Servo_3Point", " " + _mainGUI.Common.dbServo_Y2);

                _mainGUI.Common.Para.WriteValue("Camera", "X_Master", " " + Convert.ToDouble(tbXMaster.Text));
                _mainGUI.Common.Para.WriteValue("Camera", "Y_Master", " " + Convert.ToDouble(tbYMaster.Text));
            }
        }

        private void btnNozzle_Load_Click(object sender, EventArgs e)
        {
            if(cbToolsCalSelectNo.Text == "1")
            {
                tbNozzleFirstSet_X.Text = _mainGUI.Common.dbNozzle1_First_Set_X.ToString();
                tbNozzleFirstSet_Y.Text = _mainGUI.Common.dbNozzle1_First_Set_Y.ToString();
                tbNozzleFirstSet_Z.Text = _mainGUI.Common.dbNozzle1_First_Set_Z.ToString();

                tbNozzleNow_X.Text = _mainGUI.Common.dbNozzle1_Now_X.ToString();
                tbNozzleNow_Y.Text = _mainGUI.Common.dbNozzle1_Now_Y.ToString();
                tbNozzleNow_Z.Text = _mainGUI.Common.dbNozzle1_Now_Z.ToString();
            }
            else if(cbToolsCalSelectNo.Text == "2")
            {
                tbNozzleFirstSet_X.Text = _mainGUI.Common.dbNozzle2_First_Set_X.ToString();
                tbNozzleFirstSet_Y.Text = _mainGUI.Common.dbNozzle2_First_Set_Y.ToString();
                tbNozzleFirstSet_Z.Text = _mainGUI.Common.dbNozzle2_First_Set_Z.ToString();

                tbNozzleNow_X.Text = _mainGUI.Common.dbNozzle2_Now_X.ToString();
                tbNozzleNow_Y.Text = _mainGUI.Common.dbNozzle2_Now_Y.ToString();
                tbNozzleNow_Z.Text = _mainGUI.Common.dbNozzle2_Now_Z.ToString();
            }
        }

        private void btnCameraCal_Load_Click(object sender, EventArgs e)
        {
            _mainGUI.Common.dbCamera_X1 = _mainGUI.Common.Para.ReadValue("Camera", "X1_Cam_3Point").ToDouble();
            _mainGUI.Common.dbCamera_X2 = _mainGUI.Common.Para.ReadValue("Camera", "X2_Cam_3Point").ToDouble();
            _mainGUI.Common.dbCamera_Y1 = _mainGUI.Common.Para.ReadValue("Camera", "Y1_Cam_3Point").ToDouble();
            _mainGUI.Common.dbCamera_Y2 = _mainGUI.Common.Para.ReadValue("Camera", "Y2_Cam_3Point").ToDouble();
            _mainGUI.Common.dbServo_X1 = _mainGUI.Common.Para.ReadValue("Camera", "X1_Servo_3Point").ToDouble();
            _mainGUI.Common.dbServo_X2 = _mainGUI.Common.Para.ReadValue("Camera", "X2_Servo_3Point").ToDouble();
            _mainGUI.Common.dbServo_Y1 = _mainGUI.Common.Para.ReadValue("Camera", "Y1_Servo_3Point").ToDouble();
            _mainGUI.Common.dbServo_Y2 = _mainGUI.Common.Para.ReadValue("Camera", "Y2_Servo_3Point").ToDouble();

            tbCamera_X1.Text = _mainGUI.Common.dbCamera_X1.ToString();
            tbCamera_X2.Text = _mainGUI.Common.dbCamera_X2.ToString();
            tbCamera_Y1.Text = _mainGUI.Common.dbCamera_Y1.ToString();
            tbCamera_Y2.Text = _mainGUI.Common.dbCamera_Y2.ToString();
            tbServo_X1.Text = _mainGUI.Common.dbServo_X1.ToString();
            tbServo_X2.Text = _mainGUI.Common.dbServo_X2.ToString();
            tbServo_Y1.Text = _mainGUI.Common.dbServo_Y1.ToString();
            tbServo_Y2.Text = _mainGUI.Common.dbServo_Y2.ToString();

            tbXMaster.Text = _mainGUI.Common.Para.ReadValue("Camera", "X_Master").ToString();
            tbYMaster.Text = _mainGUI.Common.Para.ReadValue("Camera", "Y_Master").ToString();

        }
        #endregion

        private void btnCalibrationNozzle_Trig_Click(object sender, EventArgs e)
        {
            //Wait input code for calibration nozzle.
            DialogResult re = MessageBox.Show("Confirm to save XYZ position?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.bCalibrationToolsTrig = true;
            }
        }

        private void updateUIXYZPos()
        {
            fX1current_pos = (float)_ApplyGlue.X1_AXIS.Position;
            tbXCurrentPos_1.Text = fX1current_pos.ToString();
            tbXCurrentPos_2.Text = fX1current_pos.ToString();

            fY1current_pos = (float)_ApplyGlue.Y1_AXIS.Position;
            tbYCurrentPos_1.Text = fY1current_pos.ToString();
            tbYCurrentPos_2.Text = fY1current_pos.ToString();

            fZ1current_pos = (float)_ApplyGlue.Z1_AXIS.Position;
            tbZCurrentPos_1.Text = fZ1current_pos.ToString();
            tbZCurrentPos_2.Text = fZ1current_pos.ToString();
        }

        private void btnCemeraOffset_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkCemeraOffset)
            {
                lbCameraOffset.Text = "Not use camera for offset";
                lbCameraOffset.BackColor = Color.Red;
                _mainGUI.Common.bChkCemeraOffset = false;
                _mainGUI.Common.Config.WriteValue("OptionSelect", "CameraOffset", _mainGUI.Common.bChkCemeraOffset.ToString());
            }
            else
            {
                lbCameraOffset.Text = "Use camera for offset";
                lbCameraOffset.BackColor = Color.LawnGreen;
                _mainGUI.Common.bChkCemeraOffset = true;
                _mainGUI.Common.Config.WriteValue("OptionSelect", "CameraOffset", _mainGUI.Common.bChkCemeraOffset.ToString());
            }
        }

        private void tbXMaster_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void tbYMaster_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }
    }
}
