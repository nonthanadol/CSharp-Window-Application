﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;
using Equipment_Control.RFID;

namespace UI_Common
{
    public partial class ucRFIDMes : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        RFID_Control _RFID;

        byte[] RFID_DATA;
        string RFID_1st_Char;
        string RFID_2nd_Char;
        string RFID_3rd_Char;
        string RFID_4th_Char;
        string RFID_5th_Char;
        string RFID_6th_Char;
        string RFID_7th_Char;
        string RFID_8th_Char;
        string RFID_9th_Char;
        string RFID_10th_Char;
        string RFID_11th_Char;
        string RFID_12th_Char;
        string RFID_13th_Char;
        string RFID_14th_Char;
        string RFID_15th_Char;
        string RFID_16th_Char;
        string RFID_17th_Char;
        string RFID_18th_Char;

        public ucRFIDMes(MainGUI mainGUI, RFID_Control RFID)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;
            this._RFID = RFID;

            #region First set
            _RFID.RFIDConnect();
            _mainGUI.Common.bChkRFID_BYPASS = Convert.ToBoolean(_mainGUI.Common.Config.ReadValue("OptionSelect", "RFID_bypass").ToString());
            _mainGUI.Common.bChkMES_BYPASS = Convert.ToBoolean(_mainGUI.Common.Config.ReadValue("OptionSelect", "MES_bypass").ToString());
            LoadMESParameter();
            if (_mainGUI.Common.bChkRFID_BYPASS)
            {
                lbRFIDBypass_Status.BackColor = Color.Crimson;
                lbRFIDBypass_Status.Text = "BYPASS";
            }
            else
            {
                lbRFIDBypass_Status.BackColor = Color.PaleGreen;
                lbRFIDBypass_Status.Text = "NOT BYPASS";
            }
            if (_mainGUI.Common.bChkMES_BYPASS)
            {
                lbMESBypass_Status.BackColor = Color.Crimson;
                lbMESBypass_Status.Text = "BYPASS";
            }
            else
            {
                lbMESBypass_Status.BackColor = Color.PaleGreen;
                lbMESBypass_Status.Text = "NOT BYPASS";
            }
            #endregion

        }

        public void UpdateUI()
        {
            if (Visible)
            {
                tbRFID_R_SerialNO.Text = _mainGUI.Common.RFID_Read_Data;
            }
        }

        #region MOUSE CLICK EVENT
        private void btnRFID_READ_Click(object sender, EventArgs e)
        {
            try
            {
                _mainGUI.Common.RFID_MANUAL = true;
                _RFID.RFIDConnect();
                RFID_DATA = _RFID.ReadUserdata(0, 0, 18);
                RFID_1st_Char = Char.ConvertFromUtf32(RFID_DATA[0]);
                RFID_2nd_Char = Char.ConvertFromUtf32(RFID_DATA[1]);
                RFID_3rd_Char = Char.ConvertFromUtf32(RFID_DATA[2]);
                RFID_4th_Char = Char.ConvertFromUtf32(RFID_DATA[3]);
                RFID_5th_Char = Char.ConvertFromUtf32(RFID_DATA[4]);
                RFID_6th_Char = Char.ConvertFromUtf32(RFID_DATA[5]);
                RFID_7th_Char = Char.ConvertFromUtf32(RFID_DATA[6]);
                RFID_8th_Char = Char.ConvertFromUtf32(RFID_DATA[7]);
                RFID_9th_Char = Char.ConvertFromUtf32(RFID_DATA[8]);
                RFID_10th_Char = Char.ConvertFromUtf32(RFID_DATA[9]);
                RFID_11th_Char = Char.ConvertFromUtf32(RFID_DATA[10]);
                RFID_12th_Char = Char.ConvertFromUtf32(RFID_DATA[11]);
                RFID_13th_Char = Char.ConvertFromUtf32(RFID_DATA[12]);
                RFID_14th_Char = Char.ConvertFromUtf32(RFID_DATA[13]);
                RFID_15th_Char = Char.ConvertFromUtf32(RFID_DATA[14]);
                RFID_16th_Char = Char.ConvertFromUtf32(RFID_DATA[15]);
                RFID_17th_Char = Char.ConvertFromUtf32(RFID_DATA[16]);
                RFID_18th_Char = Char.ConvertFromUtf32(RFID_DATA[17]);

                _mainGUI.Common.RFID_Read_Data = RFID_2nd_Char + RFID_1st_Char + RFID_4th_Char + RFID_3rd_Char + RFID_6th_Char + RFID_5th_Char
                    + RFID_8th_Char + RFID_7th_Char + RFID_10th_Char + RFID_9th_Char + RFID_12th_Char + RFID_11th_Char + RFID_14th_Char
                    + RFID_13th_Char + RFID_16th_Char + RFID_15th_Char + RFID_18th_Char + RFID_17th_Char;
            }
            catch { MessageBox.Show("RFID Read Error!!!"); }
        }


        private void btnRFID_BYPASS_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkRFID_BYPASS)
            {
                lbRFIDBypass_Status.BackColor = Color.PaleGreen;
                lbRFIDBypass_Status.Text = "NOT BYPASS";
                _mainGUI.Common.bChkRFID_BYPASS = false;
                _mainGUI.Common.Config.WriteValue("OptionSelect", "RFID_bypass", _mainGUI.Common.bChkRFID_BYPASS.ToString());
            }
            else
            {
                lbRFIDBypass_Status.BackColor = Color.Crimson;
                lbRFIDBypass_Status.Text = "BYPASS";
                _mainGUI.Common.bChkRFID_BYPASS = true;
                lbMESBypass_Status.BackColor = Color.Crimson;
                lbMESBypass_Status.Text = "BYPASS";
                _mainGUI.Common.bChkMES_BYPASS = true;
                _mainGUI.Common.Config.WriteValue("OptionSelect", "RFID_bypass", _mainGUI.Common.bChkRFID_BYPASS.ToString());
                _mainGUI.Common.Config.WriteValue("OptionSelect", "MES_bypass", _mainGUI.Common.bChkMES_BYPASS.ToString());
            }
        }

        private void btnMES_BYPASS_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkMES_BYPASS)
            {
                if (!_mainGUI.Common.bChkRFID_BYPASS)
                {
                    lbMESBypass_Status.BackColor = Color.PaleGreen;
                    lbMESBypass_Status.Text = "NOT BYPASS";
                    _mainGUI.Common.bChkMES_BYPASS = false;
                    _mainGUI.Common.Config.WriteValue("OptionSelect", "MES_bypass", _mainGUI.Common.bChkMES_BYPASS.ToString());
                }                
            }
            else
            {
                lbMESBypass_Status.BackColor = Color.Crimson;
                lbMESBypass_Status.Text = "BYPASS";
                _mainGUI.Common.bChkMES_BYPASS = true;
                _mainGUI.Common.Config.WriteValue("OptionSelect", "MES_bypass", _mainGUI.Common.bChkMES_BYPASS.ToString());
            }
        }
        #endregion
        #region MOUSE UP/DOWN EVENT
        private void btnRFID_READ_MouseDown(object sender, MouseEventArgs e)
        {
            btnRFID_READ.BackColor = Color.LightCoral;
        }

        private void btnRFID_READ_MouseUp(object sender, MouseEventArgs e)
        {
            btnRFID_READ.BackColor = Color.LightGray;
        }

        private void btnRFID_BYPASS_MouseDown(object sender, MouseEventArgs e)
        {
            btnRFID_BYPASS.BackColor = Color.LightCoral;
        }

        private void btnRFID_BYPASS_MouseUp(object sender, MouseEventArgs e)
        {
            btnRFID_BYPASS.BackColor = Color.LightGray;
        }

        private void btnMES_BYPASS_MouseDown(object sender, MouseEventArgs e)
        {
            btnMES_BYPASS.BackColor = Color.LightCoral;
        }

        private void btnMES_BYPASS_MouseUp(object sender, MouseEventArgs e)
        {
            btnMES_BYPASS.BackColor = Color.LightGray;
        }
        #endregion

        private void btnLoadMESPara_Click(object sender, EventArgs e)
        {
            LoadMESParameter();
        }

        void LoadMESParameter()
        {
            tbLocalIP.Text = _mainGUI.Common.Para.ReadValue("MES", "LocalIp").ToString();
            tbLocalPort.Text = _mainGUI.Common.Para.ReadValue("MES", "LocalPort").ToString();
            tbInterfaceID.Text = _mainGUI.Common.Para.ReadValue("MES", "InterfaceID").ToString();
            tbUrl.Text = _mainGUI.Common.Para.ReadValue("MES", "Url").ToString();
            tbMESUrl.Text = _mainGUI.Common.Para.ReadValue("MES", "MESUrl").ToString();
            tbKEY.Text = _mainGUI.Common.Para.ReadValue("MES", "KEY").ToString();
            tbTokenID.Text = _mainGUI.Common.Para.ReadValue("MES", "TokenID").ToString();
            tbFactory.Text = _mainGUI.Common.Para.ReadValue("MES", "Factory").ToString();
            tbMO_Num.Text = _mainGUI.Common.Para.ReadValue("MES", "MO_Num").ToString();
            tbModel.Text = _mainGUI.Common.Para.ReadValue("MES", "Model").ToString();
            tbLineName.Text = _mainGUI.Common.Para.ReadValue("MES", "LineName").ToString();
            tbSection.Text = _mainGUI.Common.Para.ReadValue("MES", "Section").ToString();
            tbGroup.Text = _mainGUI.Common.Para.ReadValue("MES", "Group").ToString();
            tbStation.Text = _mainGUI.Common.Para.ReadValue("MES", "Station").ToString();
        }

        private void btnSaveMESPara_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm Save MES parameter?", "MES save parameter confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Para.WriteValue("MES", "LocalIp", tbLocalIP.Text);
                _mainGUI.Common.Para.WriteValue("MES", "LocalPort", tbLocalPort.Text);
                _mainGUI.Common.Para.WriteValue("MES", "InterfaceID", tbInterfaceID.Text);
                _mainGUI.Common.Para.WriteValue("MES", "Url", tbUrl.Text);
                _mainGUI.Common.Para.WriteValue("MES", "MESUrl", tbMESUrl.Text);
                _mainGUI.Common.Para.WriteValue("MES", "KEY", tbKEY.Text);
                _mainGUI.Common.Para.WriteValue("MES", "TokenID", tbTokenID.Text);
                _mainGUI.Common.Para.WriteValue("MES", "Factory", tbFactory.Text);
                _mainGUI.Common.Para.WriteValue("MES", "MO_Num", tbMO_Num.Text);
                _mainGUI.Common.Para.WriteValue("MES", "Model", tbModel.Text);
                _mainGUI.Common.Para.WriteValue("MES", "LineName", tbLineName.Text);
                _mainGUI.Common.Para.WriteValue("MES", "Section", tbSection.Text);
                _mainGUI.Common.Para.WriteValue("MES", "Group", tbGroup.Text);
                _mainGUI.Common.Para.WriteValue("MES", "Station", tbStation.Text);
            }
        }
    }
}
