﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;


namespace UI_Common
{

    public partial class ucIOmonitor : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        List<Label> labInputList = new List<Label>();
        List<Label> labOutputList = new List<Label>();
        //List<Button> btnOutputList = new List<Button>();
        public ucIOmonitor(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;
            # region INPUT Ui AddList
            labInputList.Add(lbIN000);
            labInputList.Add(lbIN001);
            labInputList.Add(lbIN002);
            labInputList.Add(lbIN003);
            labInputList.Add(lbIN004);
            labInputList.Add(lbIN005);
            labInputList.Add(lbIN006);
            labInputList.Add(lbIN007);
            labInputList.Add(lbIN008);
            labInputList.Add(lbIN009);
            labInputList.Add(lbIN010);
            labInputList.Add(lbIN011);
            labInputList.Add(lbIN012);
            labInputList.Add(lbIN013);
            labInputList.Add(lbIN014);
            labInputList.Add(lbIN015);
            labInputList.Add(lbIN100);
            labInputList.Add(lbIN101);
            labInputList.Add(lbIN102);
            labInputList.Add(lbIN103);
            labInputList.Add(lbIN104);
            labInputList.Add(lbIN105);
            labInputList.Add(lbIN106);
            labInputList.Add(lbIN107);
            labInputList.Add(lbIN108);
            labInputList.Add(lbIN109);
            labInputList.Add(lbIN110);
            labInputList.Add(lbIN111);
            labInputList.Add(lbIN112);
            labInputList.Add(lbIN113);
            labInputList.Add(lbIN114);
            labInputList.Add(lbIN115);
            #endregion
            #region OUTPUT Ui AddList
            labOutputList.Add(lbOUT000);
            labOutputList.Add(lbOUT001);
            labOutputList.Add(lbOUT002);
            labOutputList.Add(lbOUT003);
            labOutputList.Add(lbOUT004);
            labOutputList.Add(lbOUT005);
            labOutputList.Add(lbOUT006);
            labOutputList.Add(lbOUT007);
            labOutputList.Add(lbOUT008);
            labOutputList.Add(lbOUT009);
            labOutputList.Add(lbOUT010);
            labOutputList.Add(lbOUT011);
            labOutputList.Add(lbOUT012);
            labOutputList.Add(lbOUT013);
            labOutputList.Add(lbOUT014);
            labOutputList.Add(lbOUT015);
            labOutputList.Add(lbOUT100);
            labOutputList.Add(lbOUT101);
            labOutputList.Add(lbOUT102);
            labOutputList.Add(lbOUT103);
            labOutputList.Add(lbOUT104);
            labOutputList.Add(lbOUT105);
            labOutputList.Add(lbOUT106);
            labOutputList.Add(lbOUT107);
            labOutputList.Add(lbOUT108);
            labOutputList.Add(lbOUT109);
            labOutputList.Add(lbOUT110);
            labOutputList.Add(lbOUT111);
            labOutputList.Add(lbOUT112);
            labOutputList.Add(lbOUT113);
            labOutputList.Add(lbOUT114);
            labOutputList.Add(lbOUT115);
            #endregion

        }
        public void UpdateUI()
        {
            if (Visible)
            {
                for (int i = 0, j = 0; i < 16; i++, j++)
                {
                    labInputList[i].BackColor = _mainGUI.Common.IOTable.DI[(ushort)0, (ushort)j].State ? Color.LawnGreen : Color.LightGray;
                    labOutputList[i].BackColor = _mainGUI.Common.IOTable.DO[(ushort)0, (ushort)j].State ? Color.LawnGreen : Color.LightGray;
                }
                for (int i = 16, j = 0; i < 32; i++, j++)
                {
                    labInputList[i].BackColor = _mainGUI.Common.IOTable.DI[(ushort)1, (ushort)j].State ? Color.LawnGreen : Color.LightGray;
                    labOutputList[i].BackColor = _mainGUI.Common.IOTable.DO[(ushort)1, (ushort)j].State ? Color.LawnGreen : Color.LightGray;
                }
            }
        }
        private void btnIO_P2_Click(object sender, EventArgs e)
        {
            foreach (Control item in Parent.Controls)
            {
                if (item is ucIOmonitor_2)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }

    }
}
