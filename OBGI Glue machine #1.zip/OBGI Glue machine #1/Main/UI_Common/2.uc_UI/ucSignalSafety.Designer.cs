﻿
namespace UI_Common
{
    partial class ucSignalSafety
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbSigUp_R_acc = new System.Windows.Forms.Label();
            this.lbSigUp_L_acc = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.lbSigDown_R_acc = new System.Windows.Forms.Label();
            this.lbSigDown_L_acc = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnUpLeft_acc = new System.Windows.Forms.Button();
            this.btnDownRight_acc = new System.Windows.Forms.Button();
            this.lbSafetyDoor_status = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btnSafetyDoor_OFF = new System.Windows.Forms.Button();
            this.btnSafetyDoor_ON = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbAreaSensor_status = new System.Windows.Forms.Label();
            this.btnAreaSensor_ON = new System.Windows.Forms.Button();
            this.btnAreaSensor_OFF = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1000, 40);
            this.label1.TabIndex = 3;
            this.label1.Text = "SIGNAL | SAFETY";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSigUp_R_acc
            // 
            this.lbSigUp_R_acc.AutoSize = true;
            this.lbSigUp_R_acc.BackColor = System.Drawing.Color.LightGray;
            this.lbSigUp_R_acc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSigUp_R_acc.Location = new System.Drawing.Point(63, 101);
            this.lbSigUp_R_acc.Name = "lbSigUp_R_acc";
            this.lbSigUp_R_acc.Size = new System.Drawing.Size(64, 29);
            this.lbSigUp_R_acc.TabIndex = 80;
            this.lbSigUp_R_acc.Text = "I:212";
            // 
            // lbSigUp_L_acc
            // 
            this.lbSigUp_L_acc.AutoSize = true;
            this.lbSigUp_L_acc.BackColor = System.Drawing.Color.LightGray;
            this.lbSigUp_L_acc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSigUp_L_acc.Location = new System.Drawing.Point(858, 103);
            this.lbSigUp_L_acc.Name = "lbSigUp_L_acc";
            this.lbSigUp_L_acc.Size = new System.Drawing.Size(77, 29);
            this.lbSigUp_L_acc.TabIndex = 81;
            this.lbSigUp_L_acc.Text = "O:208";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(247, 103);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(202, 29);
            this.label6.TabIndex = 76;
            this.label6.Text = "Upper Left accept";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(531, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 29);
            this.label2.TabIndex = 79;
            this.label2.Text = "Upper Right request";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Black;
            this.pictureBox7.Location = new System.Drawing.Point(494, 68);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(10, 102);
            this.pictureBox7.TabIndex = 73;
            this.pictureBox7.TabStop = false;
            // 
            // lbSigDown_R_acc
            // 
            this.lbSigDown_R_acc.AutoSize = true;
            this.lbSigDown_R_acc.BackColor = System.Drawing.Color.LightGray;
            this.lbSigDown_R_acc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSigDown_R_acc.Location = new System.Drawing.Point(63, 303);
            this.lbSigDown_R_acc.Name = "lbSigDown_R_acc";
            this.lbSigDown_R_acc.Size = new System.Drawing.Size(77, 29);
            this.lbSigDown_R_acc.TabIndex = 89;
            this.lbSigDown_R_acc.Text = "O:212";
            // 
            // lbSigDown_L_acc
            // 
            this.lbSigDown_L_acc.AutoSize = true;
            this.lbSigDown_L_acc.BackColor = System.Drawing.Color.LightGray;
            this.lbSigDown_L_acc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSigDown_L_acc.Location = new System.Drawing.Point(858, 303);
            this.lbSigDown_L_acc.Name = "lbSigDown_L_acc";
            this.lbSigDown_L_acc.Size = new System.Drawing.Size(64, 29);
            this.lbSigDown_L_acc.TabIndex = 90;
            this.lbSigDown_L_acc.Text = "I:208";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(531, 303);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(218, 29);
            this.label9.TabIndex = 86;
            this.label9.Text = "Under Right accept";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(238, 303);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(211, 29);
            this.label8.TabIndex = 87;
            this.label8.Text = "Under Left request";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Black;
            this.pictureBox6.Location = new System.Drawing.Point(494, 267);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(10, 102);
            this.pictureBox6.TabIndex = 82;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.Location = new System.Drawing.Point(95, 217);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(834, 10);
            this.pictureBox1.TabIndex = 91;
            this.pictureBox1.TabStop = false;
            // 
            // btnUpLeft_acc
            // 
            this.btnUpLeft_acc.BackColor = System.Drawing.Color.LightGray;
            this.btnUpLeft_acc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpLeft_acc.Location = new System.Drawing.Point(766, 103);
            this.btnUpLeft_acc.Name = "btnUpLeft_acc";
            this.btnUpLeft_acc.Size = new System.Drawing.Size(86, 32);
            this.btnUpLeft_acc.TabIndex = 92;
            this.btnUpLeft_acc.Text = "Send";
            this.btnUpLeft_acc.UseVisualStyleBackColor = false;
            this.btnUpLeft_acc.Click += new System.EventHandler(this.btnUpLeft_acc_Click);
            // 
            // btnDownRight_acc
            // 
            this.btnDownRight_acc.BackColor = System.Drawing.Color.LightGray;
            this.btnDownRight_acc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDownRight_acc.Location = new System.Drawing.Point(146, 302);
            this.btnDownRight_acc.Name = "btnDownRight_acc";
            this.btnDownRight_acc.Size = new System.Drawing.Size(86, 32);
            this.btnDownRight_acc.TabIndex = 92;
            this.btnDownRight_acc.Text = "Send";
            this.btnDownRight_acc.UseVisualStyleBackColor = false;
            this.btnDownRight_acc.Click += new System.EventHandler(this.btnDownRight_acc_Click);
            // 
            // lbSafetyDoor_status
            // 
            this.lbSafetyDoor_status.AutoSize = true;
            this.lbSafetyDoor_status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbSafetyDoor_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSafetyDoor_status.Location = new System.Drawing.Point(329, 474);
            this.lbSafetyDoor_status.Name = "lbSafetyDoor_status";
            this.lbSafetyDoor_status.Size = new System.Drawing.Size(128, 20);
            this.lbSafetyDoor_status.TabIndex = 96;
            this.lbSafetyDoor_status.Text = "Safety Door ON";
            this.lbSafetyDoor_status.Visible = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(117, 474);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(194, 20);
            this.label22.TabIndex = 95;
            this.label22.Text = "Safety Door function :";
            this.label22.Visible = false;
            // 
            // btnSafetyDoor_OFF
            // 
            this.btnSafetyDoor_OFF.BackColor = System.Drawing.Color.LightGray;
            this.btnSafetyDoor_OFF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSafetyDoor_OFF.Location = new System.Drawing.Point(281, 502);
            this.btnSafetyDoor_OFF.Name = "btnSafetyDoor_OFF";
            this.btnSafetyDoor_OFF.Size = new System.Drawing.Size(94, 42);
            this.btnSafetyDoor_OFF.TabIndex = 93;
            this.btnSafetyDoor_OFF.Text = "Safety Door OFF";
            this.btnSafetyDoor_OFF.UseVisualStyleBackColor = false;
            this.btnSafetyDoor_OFF.Visible = false;
            this.btnSafetyDoor_OFF.Click += new System.EventHandler(this.btnSafetyDoor_OFF_Click);
            this.btnSafetyDoor_OFF.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnSafetyDoor_OFF_MouseDown);
            this.btnSafetyDoor_OFF.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnSafetyDoor_OFF_MouseUp);
            // 
            // btnSafetyDoor_ON
            // 
            this.btnSafetyDoor_ON.BackColor = System.Drawing.Color.LightGray;
            this.btnSafetyDoor_ON.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSafetyDoor_ON.Location = new System.Drawing.Point(181, 502);
            this.btnSafetyDoor_ON.Name = "btnSafetyDoor_ON";
            this.btnSafetyDoor_ON.Size = new System.Drawing.Size(94, 42);
            this.btnSafetyDoor_ON.TabIndex = 94;
            this.btnSafetyDoor_ON.Text = "Safety Door ON";
            this.btnSafetyDoor_ON.UseVisualStyleBackColor = false;
            this.btnSafetyDoor_ON.Visible = false;
            this.btnSafetyDoor_ON.Click += new System.EventHandler(this.btnSafetyDoor_ON_Click);
            this.btnSafetyDoor_ON.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnSafetyDoor_ON_MouseDown);
            this.btnSafetyDoor_ON.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnSafetyDoor_ON_MouseUp);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.Location = new System.Drawing.Point(95, 411);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(834, 10);
            this.pictureBox2.TabIndex = 97;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(519, 474);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(196, 20);
            this.label3.TabIndex = 95;
            this.label3.Text = "Area sensor function :";
            // 
            // lbAreaSensor_status
            // 
            this.lbAreaSensor_status.AutoSize = true;
            this.lbAreaSensor_status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbAreaSensor_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAreaSensor_status.Location = new System.Drawing.Point(733, 474);
            this.lbAreaSensor_status.Name = "lbAreaSensor_status";
            this.lbAreaSensor_status.Size = new System.Drawing.Size(132, 20);
            this.lbAreaSensor_status.TabIndex = 96;
            this.lbAreaSensor_status.Text = "Area Sensor ON";
            // 
            // btnAreaSensor_ON
            // 
            this.btnAreaSensor_ON.BackColor = System.Drawing.Color.LightGray;
            this.btnAreaSensor_ON.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAreaSensor_ON.Location = new System.Drawing.Point(592, 502);
            this.btnAreaSensor_ON.Name = "btnAreaSensor_ON";
            this.btnAreaSensor_ON.Size = new System.Drawing.Size(94, 42);
            this.btnAreaSensor_ON.TabIndex = 94;
            this.btnAreaSensor_ON.Text = "Area sensor ON";
            this.btnAreaSensor_ON.UseVisualStyleBackColor = false;
            this.btnAreaSensor_ON.Click += new System.EventHandler(this.btnAreaSensor_ON_Click);
            this.btnAreaSensor_ON.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnAreaSensor_ON_MouseDown);
            this.btnAreaSensor_ON.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnAreaSensor_ON_MouseUp);
            // 
            // btnAreaSensor_OFF
            // 
            this.btnAreaSensor_OFF.BackColor = System.Drawing.Color.LightGray;
            this.btnAreaSensor_OFF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAreaSensor_OFF.Location = new System.Drawing.Point(692, 502);
            this.btnAreaSensor_OFF.Name = "btnAreaSensor_OFF";
            this.btnAreaSensor_OFF.Size = new System.Drawing.Size(94, 42);
            this.btnAreaSensor_OFF.TabIndex = 93;
            this.btnAreaSensor_OFF.Text = "Area sensor OFF";
            this.btnAreaSensor_OFF.UseVisualStyleBackColor = false;
            this.btnAreaSensor_OFF.Click += new System.EventHandler(this.btnAreaSensor_OFF_Click);
            this.btnAreaSensor_OFF.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnAreaSensor_OFF_MouseDown);
            this.btnAreaSensor_OFF.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnAreaSensor_OFF_MouseUp);
            // 
            // ucSignalSafety
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lbAreaSensor_status);
            this.Controls.Add(this.lbSafetyDoor_status);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.btnAreaSensor_OFF);
            this.Controls.Add(this.btnSafetyDoor_OFF);
            this.Controls.Add(this.btnAreaSensor_ON);
            this.Controls.Add(this.btnSafetyDoor_ON);
            this.Controls.Add(this.btnDownRight_acc);
            this.Controls.Add(this.btnUpLeft_acc);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbSigDown_R_acc);
            this.Controls.Add(this.lbSigDown_L_acc);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.lbSigUp_R_acc);
            this.Controls.Add(this.lbSigUp_L_acc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label1);
            this.Name = "ucSignalSafety";
            this.Size = new System.Drawing.Size(1000, 600);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbSigUp_R_acc;
        private System.Windows.Forms.Label lbSigUp_L_acc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label lbSigDown_R_acc;
        private System.Windows.Forms.Label lbSigDown_L_acc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnUpLeft_acc;
        private System.Windows.Forms.Button btnDownRight_acc;
        private System.Windows.Forms.Label lbSafetyDoor_status;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btnSafetyDoor_OFF;
        private System.Windows.Forms.Button btnSafetyDoor_ON;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbAreaSensor_status;
        private System.Windows.Forms.Button btnAreaSensor_ON;
        private System.Windows.Forms.Button btnAreaSensor_OFF;
    }
}
