﻿
namespace UI_Common
{
    partial class ucIOmonitor_2
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbIOMonitor_2 = new System.Windows.Forms.Label();
            this.lbIO_2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnIO_P1 = new System.Windows.Forms.Button();
            this.lbIN200 = new System.Windows.Forms.Label();
            this.lbIN201 = new System.Windows.Forms.Label();
            this.lbIN203 = new System.Windows.Forms.Label();
            this.lbIN202 = new System.Windows.Forms.Label();
            this.lbIN207 = new System.Windows.Forms.Label();
            this.lbIN206 = new System.Windows.Forms.Label();
            this.lbIN205 = new System.Windows.Forms.Label();
            this.lbIN204 = new System.Windows.Forms.Label();
            this.lbIN215 = new System.Windows.Forms.Label();
            this.lbIN214 = new System.Windows.Forms.Label();
            this.lbIN213 = new System.Windows.Forms.Label();
            this.lbIN212 = new System.Windows.Forms.Label();
            this.lbIN211 = new System.Windows.Forms.Label();
            this.lbIN210 = new System.Windows.Forms.Label();
            this.lbIN209 = new System.Windows.Forms.Label();
            this.lbIN208 = new System.Windows.Forms.Label();
            this.lbIN315 = new System.Windows.Forms.Label();
            this.lbIN314 = new System.Windows.Forms.Label();
            this.lbIN313 = new System.Windows.Forms.Label();
            this.lbIN312 = new System.Windows.Forms.Label();
            this.lbIN311 = new System.Windows.Forms.Label();
            this.lbIN310 = new System.Windows.Forms.Label();
            this.lbIN309 = new System.Windows.Forms.Label();
            this.lbIN308 = new System.Windows.Forms.Label();
            this.lbIN307 = new System.Windows.Forms.Label();
            this.lbIN306 = new System.Windows.Forms.Label();
            this.lbIN305 = new System.Windows.Forms.Label();
            this.lbIN304 = new System.Windows.Forms.Label();
            this.lbIN303 = new System.Windows.Forms.Label();
            this.lbIN302 = new System.Windows.Forms.Label();
            this.lbIN301 = new System.Windows.Forms.Label();
            this.lbIN300 = new System.Windows.Forms.Label();
            this.lbOUT315 = new System.Windows.Forms.Label();
            this.lbOUT314 = new System.Windows.Forms.Label();
            this.lbOUT313 = new System.Windows.Forms.Label();
            this.lbOUT312 = new System.Windows.Forms.Label();
            this.lbOUT311 = new System.Windows.Forms.Label();
            this.lbOUT310 = new System.Windows.Forms.Label();
            this.lbOUT309 = new System.Windows.Forms.Label();
            this.lbOUT308 = new System.Windows.Forms.Label();
            this.lbOUT307 = new System.Windows.Forms.Label();
            this.lbOUT306 = new System.Windows.Forms.Label();
            this.lbOUT305 = new System.Windows.Forms.Label();
            this.lbOUT304 = new System.Windows.Forms.Label();
            this.lbOUT303 = new System.Windows.Forms.Label();
            this.lbOUT302 = new System.Windows.Forms.Label();
            this.lbOUT301 = new System.Windows.Forms.Label();
            this.lbOUT300 = new System.Windows.Forms.Label();
            this.lbOUT215 = new System.Windows.Forms.Label();
            this.lbOUT214 = new System.Windows.Forms.Label();
            this.lbOUT213 = new System.Windows.Forms.Label();
            this.lbOUT212 = new System.Windows.Forms.Label();
            this.lbOUT211 = new System.Windows.Forms.Label();
            this.lbOUT210 = new System.Windows.Forms.Label();
            this.lbOUT209 = new System.Windows.Forms.Label();
            this.lbOUT208 = new System.Windows.Forms.Label();
            this.lbOUT207 = new System.Windows.Forms.Label();
            this.lbOUT206 = new System.Windows.Forms.Label();
            this.lbOUT205 = new System.Windows.Forms.Label();
            this.lbOUT204 = new System.Windows.Forms.Label();
            this.lbOUT203 = new System.Windows.Forms.Label();
            this.lbOUT202 = new System.Windows.Forms.Label();
            this.lbOUT201 = new System.Windows.Forms.Label();
            this.lbOUT200 = new System.Windows.Forms.Label();
            this.tbIN_2 = new System.Windows.Forms.TextBox();
            this.tbOUT_2 = new System.Windows.Forms.TextBox();
            this.tbIN200 = new System.Windows.Forms.TextBox();
            this.tbIN201 = new System.Windows.Forms.TextBox();
            this.tbIN202 = new System.Windows.Forms.TextBox();
            this.tbIN203 = new System.Windows.Forms.TextBox();
            this.tbIN204 = new System.Windows.Forms.TextBox();
            this.tbIN206 = new System.Windows.Forms.TextBox();
            this.tbIN205 = new System.Windows.Forms.TextBox();
            this.tbIN207 = new System.Windows.Forms.TextBox();
            this.tbIN208 = new System.Windows.Forms.TextBox();
            this.tbIN212 = new System.Windows.Forms.TextBox();
            this.tbIN210 = new System.Windows.Forms.TextBox();
            this.tbIN214 = new System.Windows.Forms.TextBox();
            this.tbIN209 = new System.Windows.Forms.TextBox();
            this.tbIN213 = new System.Windows.Forms.TextBox();
            this.tbIN211 = new System.Windows.Forms.TextBox();
            this.tbIN215 = new System.Windows.Forms.TextBox();
            this.tbIN300 = new System.Windows.Forms.TextBox();
            this.tbIN308 = new System.Windows.Forms.TextBox();
            this.tbIN304 = new System.Windows.Forms.TextBox();
            this.tbIN312 = new System.Windows.Forms.TextBox();
            this.tbIN302 = new System.Windows.Forms.TextBox();
            this.tbIN310 = new System.Windows.Forms.TextBox();
            this.tbIN306 = new System.Windows.Forms.TextBox();
            this.tbIN314 = new System.Windows.Forms.TextBox();
            this.tbIN301 = new System.Windows.Forms.TextBox();
            this.tbIN309 = new System.Windows.Forms.TextBox();
            this.tbIN305 = new System.Windows.Forms.TextBox();
            this.tbIN313 = new System.Windows.Forms.TextBox();
            this.tbIN303 = new System.Windows.Forms.TextBox();
            this.tbIN311 = new System.Windows.Forms.TextBox();
            this.tbIN307 = new System.Windows.Forms.TextBox();
            this.tbIN315 = new System.Windows.Forms.TextBox();
            this.tbOUT200 = new System.Windows.Forms.TextBox();
            this.tbOUT208 = new System.Windows.Forms.TextBox();
            this.tbOUT204 = new System.Windows.Forms.TextBox();
            this.tbOUT212 = new System.Windows.Forms.TextBox();
            this.tbOUT202 = new System.Windows.Forms.TextBox();
            this.tbOUT210 = new System.Windows.Forms.TextBox();
            this.tbOUT206 = new System.Windows.Forms.TextBox();
            this.tbOUT214 = new System.Windows.Forms.TextBox();
            this.tbOUT201 = new System.Windows.Forms.TextBox();
            this.tbOUT209 = new System.Windows.Forms.TextBox();
            this.tbOUT205 = new System.Windows.Forms.TextBox();
            this.tbOUT213 = new System.Windows.Forms.TextBox();
            this.tbOUT203 = new System.Windows.Forms.TextBox();
            this.tbOUT211 = new System.Windows.Forms.TextBox();
            this.tbOUT207 = new System.Windows.Forms.TextBox();
            this.tbOUT215 = new System.Windows.Forms.TextBox();
            this.tbOUT300 = new System.Windows.Forms.TextBox();
            this.tbOUT308 = new System.Windows.Forms.TextBox();
            this.tbOUT304 = new System.Windows.Forms.TextBox();
            this.tbOUT312 = new System.Windows.Forms.TextBox();
            this.tbOUT302 = new System.Windows.Forms.TextBox();
            this.tbOUT310 = new System.Windows.Forms.TextBox();
            this.tbOUT306 = new System.Windows.Forms.TextBox();
            this.tbOUT314 = new System.Windows.Forms.TextBox();
            this.tbOUT301 = new System.Windows.Forms.TextBox();
            this.tbOUT309 = new System.Windows.Forms.TextBox();
            this.tbOUT305 = new System.Windows.Forms.TextBox();
            this.tbOUT313 = new System.Windows.Forms.TextBox();
            this.tbOUT303 = new System.Windows.Forms.TextBox();
            this.tbOUT311 = new System.Windows.Forms.TextBox();
            this.tbOUT307 = new System.Windows.Forms.TextBox();
            this.tbOUT315 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbIOMonitor_2
            // 
            this.lbIOMonitor_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbIOMonitor_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbIOMonitor_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIOMonitor_2.Location = new System.Drawing.Point(0, 0);
            this.lbIOMonitor_2.Name = "lbIOMonitor_2";
            this.lbIOMonitor_2.Size = new System.Drawing.Size(1000, 40);
            this.lbIOMonitor_2.TabIndex = 0;
            this.lbIOMonitor_2.Text = "I/O MONITOR";
            this.lbIOMonitor_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIO_2
            // 
            this.lbIO_2.BackColor = System.Drawing.Color.DarkGray;
            this.lbIO_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIO_2.Location = new System.Drawing.Point(399, 51);
            this.lbIO_2.Name = "lbIO_2";
            this.lbIO_2.Size = new System.Drawing.Size(153, 41);
            this.lbIO_2.TabIndex = 1;
            this.lbIO_2.Text = "I/O200 - I/O315";
            this.lbIO_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(101, 136);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(0, 22);
            this.textBox1.TabIndex = 2;
            // 
            // btnIO_P1
            // 
            this.btnIO_P1.BackColor = System.Drawing.Color.LightGray;
            this.btnIO_P1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIO_P1.Location = new System.Drawing.Point(313, 51);
            this.btnIO_P1.Name = "btnIO_P1";
            this.btnIO_P1.Size = new System.Drawing.Size(80, 41);
            this.btnIO_P1.TabIndex = 3;
            this.btnIO_P1.Text = "<=";
            this.btnIO_P1.UseVisualStyleBackColor = false;
            this.btnIO_P1.Click += new System.EventHandler(this.btnIO_P1_Click);
            // 
            // lbIN200
            // 
            this.lbIN200.BackColor = System.Drawing.Color.LightGray;
            this.lbIN200.Location = new System.Drawing.Point(45, 136);
            this.lbIN200.Name = "lbIN200";
            this.lbIN200.Size = new System.Drawing.Size(50, 22);
            this.lbIN200.TabIndex = 5;
            this.lbIN200.Text = "I:200";
            this.lbIN200.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN201
            // 
            this.lbIN201.BackColor = System.Drawing.Color.LightGray;
            this.lbIN201.Location = new System.Drawing.Point(45, 164);
            this.lbIN201.Name = "lbIN201";
            this.lbIN201.Size = new System.Drawing.Size(50, 22);
            this.lbIN201.TabIndex = 7;
            this.lbIN201.Text = "I:201";
            this.lbIN201.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN203
            // 
            this.lbIN203.BackColor = System.Drawing.Color.LightGray;
            this.lbIN203.Location = new System.Drawing.Point(45, 220);
            this.lbIN203.Name = "lbIN203";
            this.lbIN203.Size = new System.Drawing.Size(50, 22);
            this.lbIN203.TabIndex = 11;
            this.lbIN203.Text = "I:203";
            this.lbIN203.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN202
            // 
            this.lbIN202.BackColor = System.Drawing.Color.LightGray;
            this.lbIN202.Location = new System.Drawing.Point(45, 192);
            this.lbIN202.Name = "lbIN202";
            this.lbIN202.Size = new System.Drawing.Size(50, 22);
            this.lbIN202.TabIndex = 9;
            this.lbIN202.Text = "I:202";
            this.lbIN202.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN207
            // 
            this.lbIN207.BackColor = System.Drawing.Color.LightGray;
            this.lbIN207.Location = new System.Drawing.Point(45, 332);
            this.lbIN207.Name = "lbIN207";
            this.lbIN207.Size = new System.Drawing.Size(50, 22);
            this.lbIN207.TabIndex = 19;
            this.lbIN207.Text = "I:207";
            this.lbIN207.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN206
            // 
            this.lbIN206.BackColor = System.Drawing.Color.LightGray;
            this.lbIN206.Location = new System.Drawing.Point(45, 304);
            this.lbIN206.Name = "lbIN206";
            this.lbIN206.Size = new System.Drawing.Size(50, 22);
            this.lbIN206.TabIndex = 17;
            this.lbIN206.Text = "I:206";
            this.lbIN206.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN205
            // 
            this.lbIN205.BackColor = System.Drawing.Color.LightGray;
            this.lbIN205.Location = new System.Drawing.Point(45, 276);
            this.lbIN205.Name = "lbIN205";
            this.lbIN205.Size = new System.Drawing.Size(50, 22);
            this.lbIN205.TabIndex = 15;
            this.lbIN205.Text = "I:205";
            this.lbIN205.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN204
            // 
            this.lbIN204.BackColor = System.Drawing.Color.LightGray;
            this.lbIN204.Location = new System.Drawing.Point(45, 248);
            this.lbIN204.Name = "lbIN204";
            this.lbIN204.Size = new System.Drawing.Size(50, 22);
            this.lbIN204.TabIndex = 13;
            this.lbIN204.Text = "I:204";
            this.lbIN204.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN215
            // 
            this.lbIN215.BackColor = System.Drawing.Color.LightGray;
            this.lbIN215.Location = new System.Drawing.Point(45, 556);
            this.lbIN215.Name = "lbIN215";
            this.lbIN215.Size = new System.Drawing.Size(50, 22);
            this.lbIN215.TabIndex = 35;
            this.lbIN215.Text = "I:215";
            this.lbIN215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN214
            // 
            this.lbIN214.BackColor = System.Drawing.Color.LightGray;
            this.lbIN214.Location = new System.Drawing.Point(45, 528);
            this.lbIN214.Name = "lbIN214";
            this.lbIN214.Size = new System.Drawing.Size(50, 22);
            this.lbIN214.TabIndex = 33;
            this.lbIN214.Text = "I:214";
            this.lbIN214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN213
            // 
            this.lbIN213.BackColor = System.Drawing.Color.LightGray;
            this.lbIN213.Location = new System.Drawing.Point(45, 500);
            this.lbIN213.Name = "lbIN213";
            this.lbIN213.Size = new System.Drawing.Size(50, 22);
            this.lbIN213.TabIndex = 31;
            this.lbIN213.Text = "I:213";
            this.lbIN213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN212
            // 
            this.lbIN212.BackColor = System.Drawing.Color.LightGray;
            this.lbIN212.Location = new System.Drawing.Point(45, 472);
            this.lbIN212.Name = "lbIN212";
            this.lbIN212.Size = new System.Drawing.Size(50, 22);
            this.lbIN212.TabIndex = 29;
            this.lbIN212.Text = "I:212";
            this.lbIN212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN211
            // 
            this.lbIN211.BackColor = System.Drawing.Color.LightGray;
            this.lbIN211.Location = new System.Drawing.Point(45, 444);
            this.lbIN211.Name = "lbIN211";
            this.lbIN211.Size = new System.Drawing.Size(50, 22);
            this.lbIN211.TabIndex = 27;
            this.lbIN211.Text = "I:211";
            this.lbIN211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN210
            // 
            this.lbIN210.BackColor = System.Drawing.Color.LightGray;
            this.lbIN210.Location = new System.Drawing.Point(45, 416);
            this.lbIN210.Name = "lbIN210";
            this.lbIN210.Size = new System.Drawing.Size(50, 22);
            this.lbIN210.TabIndex = 25;
            this.lbIN210.Text = "I:210";
            this.lbIN210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN209
            // 
            this.lbIN209.BackColor = System.Drawing.Color.LightGray;
            this.lbIN209.Location = new System.Drawing.Point(45, 388);
            this.lbIN209.Name = "lbIN209";
            this.lbIN209.Size = new System.Drawing.Size(50, 22);
            this.lbIN209.TabIndex = 23;
            this.lbIN209.Text = "I:209";
            this.lbIN209.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN208
            // 
            this.lbIN208.BackColor = System.Drawing.Color.LightGray;
            this.lbIN208.Location = new System.Drawing.Point(45, 360);
            this.lbIN208.Name = "lbIN208";
            this.lbIN208.Size = new System.Drawing.Size(50, 22);
            this.lbIN208.TabIndex = 21;
            this.lbIN208.Text = "I:208";
            this.lbIN208.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN315
            // 
            this.lbIN315.BackColor = System.Drawing.Color.LightGray;
            this.lbIN315.Location = new System.Drawing.Point(279, 556);
            this.lbIN315.Name = "lbIN315";
            this.lbIN315.Size = new System.Drawing.Size(50, 22);
            this.lbIN315.TabIndex = 67;
            this.lbIN315.Text = "I:315";
            this.lbIN315.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN314
            // 
            this.lbIN314.BackColor = System.Drawing.Color.LightGray;
            this.lbIN314.Location = new System.Drawing.Point(279, 528);
            this.lbIN314.Name = "lbIN314";
            this.lbIN314.Size = new System.Drawing.Size(50, 22);
            this.lbIN314.TabIndex = 65;
            this.lbIN314.Text = "I:314";
            this.lbIN314.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN313
            // 
            this.lbIN313.BackColor = System.Drawing.Color.LightGray;
            this.lbIN313.Location = new System.Drawing.Point(279, 500);
            this.lbIN313.Name = "lbIN313";
            this.lbIN313.Size = new System.Drawing.Size(50, 22);
            this.lbIN313.TabIndex = 63;
            this.lbIN313.Text = "I:313";
            this.lbIN313.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN312
            // 
            this.lbIN312.BackColor = System.Drawing.Color.LightGray;
            this.lbIN312.Location = new System.Drawing.Point(279, 472);
            this.lbIN312.Name = "lbIN312";
            this.lbIN312.Size = new System.Drawing.Size(50, 22);
            this.lbIN312.TabIndex = 61;
            this.lbIN312.Text = "I:312";
            this.lbIN312.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN311
            // 
            this.lbIN311.BackColor = System.Drawing.Color.LightGray;
            this.lbIN311.Location = new System.Drawing.Point(279, 444);
            this.lbIN311.Name = "lbIN311";
            this.lbIN311.Size = new System.Drawing.Size(50, 22);
            this.lbIN311.TabIndex = 59;
            this.lbIN311.Text = "I:311";
            this.lbIN311.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN310
            // 
            this.lbIN310.BackColor = System.Drawing.Color.LightGray;
            this.lbIN310.Location = new System.Drawing.Point(279, 416);
            this.lbIN310.Name = "lbIN310";
            this.lbIN310.Size = new System.Drawing.Size(50, 22);
            this.lbIN310.TabIndex = 57;
            this.lbIN310.Text = "I:310";
            this.lbIN310.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN309
            // 
            this.lbIN309.BackColor = System.Drawing.Color.LightGray;
            this.lbIN309.Location = new System.Drawing.Point(279, 388);
            this.lbIN309.Name = "lbIN309";
            this.lbIN309.Size = new System.Drawing.Size(50, 22);
            this.lbIN309.TabIndex = 55;
            this.lbIN309.Text = "I:309";
            this.lbIN309.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN308
            // 
            this.lbIN308.BackColor = System.Drawing.Color.LightGray;
            this.lbIN308.Location = new System.Drawing.Point(279, 360);
            this.lbIN308.Name = "lbIN308";
            this.lbIN308.Size = new System.Drawing.Size(50, 22);
            this.lbIN308.TabIndex = 53;
            this.lbIN308.Text = "I:308";
            this.lbIN308.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN307
            // 
            this.lbIN307.BackColor = System.Drawing.Color.LightGray;
            this.lbIN307.Location = new System.Drawing.Point(279, 332);
            this.lbIN307.Name = "lbIN307";
            this.lbIN307.Size = new System.Drawing.Size(50, 22);
            this.lbIN307.TabIndex = 51;
            this.lbIN307.Text = "I:307";
            this.lbIN307.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN306
            // 
            this.lbIN306.BackColor = System.Drawing.Color.LightGray;
            this.lbIN306.Location = new System.Drawing.Point(279, 304);
            this.lbIN306.Name = "lbIN306";
            this.lbIN306.Size = new System.Drawing.Size(50, 22);
            this.lbIN306.TabIndex = 49;
            this.lbIN306.Text = "I:306";
            this.lbIN306.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN305
            // 
            this.lbIN305.BackColor = System.Drawing.Color.LightGray;
            this.lbIN305.Location = new System.Drawing.Point(279, 276);
            this.lbIN305.Name = "lbIN305";
            this.lbIN305.Size = new System.Drawing.Size(50, 22);
            this.lbIN305.TabIndex = 47;
            this.lbIN305.Text = "I:305";
            this.lbIN305.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN304
            // 
            this.lbIN304.BackColor = System.Drawing.Color.LightGray;
            this.lbIN304.Location = new System.Drawing.Point(279, 248);
            this.lbIN304.Name = "lbIN304";
            this.lbIN304.Size = new System.Drawing.Size(50, 22);
            this.lbIN304.TabIndex = 45;
            this.lbIN304.Text = "I:304";
            this.lbIN304.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN303
            // 
            this.lbIN303.BackColor = System.Drawing.Color.LightGray;
            this.lbIN303.Location = new System.Drawing.Point(279, 220);
            this.lbIN303.Name = "lbIN303";
            this.lbIN303.Size = new System.Drawing.Size(50, 22);
            this.lbIN303.TabIndex = 43;
            this.lbIN303.Text = "I:303";
            this.lbIN303.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN302
            // 
            this.lbIN302.BackColor = System.Drawing.Color.LightGray;
            this.lbIN302.Location = new System.Drawing.Point(279, 192);
            this.lbIN302.Name = "lbIN302";
            this.lbIN302.Size = new System.Drawing.Size(50, 22);
            this.lbIN302.TabIndex = 41;
            this.lbIN302.Text = "I:302";
            this.lbIN302.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN301
            // 
            this.lbIN301.BackColor = System.Drawing.Color.LightGray;
            this.lbIN301.Location = new System.Drawing.Point(279, 164);
            this.lbIN301.Name = "lbIN301";
            this.lbIN301.Size = new System.Drawing.Size(50, 22);
            this.lbIN301.TabIndex = 39;
            this.lbIN301.Text = "I:301";
            this.lbIN301.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN300
            // 
            this.lbIN300.BackColor = System.Drawing.Color.LightGray;
            this.lbIN300.Location = new System.Drawing.Point(279, 136);
            this.lbIN300.Name = "lbIN300";
            this.lbIN300.Size = new System.Drawing.Size(50, 22);
            this.lbIN300.TabIndex = 37;
            this.lbIN300.Text = "I:300";
            this.lbIN300.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT315
            // 
            this.lbOUT315.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT315.Location = new System.Drawing.Point(751, 556);
            this.lbOUT315.Name = "lbOUT315";
            this.lbOUT315.Size = new System.Drawing.Size(50, 22);
            this.lbOUT315.TabIndex = 131;
            this.lbOUT315.Text = "O:315";
            this.lbOUT315.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT314
            // 
            this.lbOUT314.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT314.Location = new System.Drawing.Point(751, 528);
            this.lbOUT314.Name = "lbOUT314";
            this.lbOUT314.Size = new System.Drawing.Size(50, 22);
            this.lbOUT314.TabIndex = 129;
            this.lbOUT314.Text = "O:314";
            this.lbOUT314.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT313
            // 
            this.lbOUT313.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT313.Location = new System.Drawing.Point(751, 500);
            this.lbOUT313.Name = "lbOUT313";
            this.lbOUT313.Size = new System.Drawing.Size(50, 22);
            this.lbOUT313.TabIndex = 127;
            this.lbOUT313.Text = "O:313";
            this.lbOUT313.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT312
            // 
            this.lbOUT312.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT312.Location = new System.Drawing.Point(751, 472);
            this.lbOUT312.Name = "lbOUT312";
            this.lbOUT312.Size = new System.Drawing.Size(50, 22);
            this.lbOUT312.TabIndex = 125;
            this.lbOUT312.Text = "O:312";
            this.lbOUT312.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT311
            // 
            this.lbOUT311.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT311.Location = new System.Drawing.Point(751, 444);
            this.lbOUT311.Name = "lbOUT311";
            this.lbOUT311.Size = new System.Drawing.Size(50, 22);
            this.lbOUT311.TabIndex = 123;
            this.lbOUT311.Text = "O:311";
            this.lbOUT311.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT310
            // 
            this.lbOUT310.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT310.Location = new System.Drawing.Point(751, 416);
            this.lbOUT310.Name = "lbOUT310";
            this.lbOUT310.Size = new System.Drawing.Size(50, 22);
            this.lbOUT310.TabIndex = 121;
            this.lbOUT310.Text = "O:310";
            this.lbOUT310.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT309
            // 
            this.lbOUT309.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT309.Location = new System.Drawing.Point(751, 388);
            this.lbOUT309.Name = "lbOUT309";
            this.lbOUT309.Size = new System.Drawing.Size(50, 22);
            this.lbOUT309.TabIndex = 119;
            this.lbOUT309.Text = "O:309";
            this.lbOUT309.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT308
            // 
            this.lbOUT308.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT308.Location = new System.Drawing.Point(751, 360);
            this.lbOUT308.Name = "lbOUT308";
            this.lbOUT308.Size = new System.Drawing.Size(50, 22);
            this.lbOUT308.TabIndex = 117;
            this.lbOUT308.Text = "O:308";
            this.lbOUT308.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT307
            // 
            this.lbOUT307.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT307.Location = new System.Drawing.Point(751, 332);
            this.lbOUT307.Name = "lbOUT307";
            this.lbOUT307.Size = new System.Drawing.Size(50, 22);
            this.lbOUT307.TabIndex = 115;
            this.lbOUT307.Text = "O:307";
            this.lbOUT307.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT306
            // 
            this.lbOUT306.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT306.Location = new System.Drawing.Point(751, 304);
            this.lbOUT306.Name = "lbOUT306";
            this.lbOUT306.Size = new System.Drawing.Size(50, 22);
            this.lbOUT306.TabIndex = 113;
            this.lbOUT306.Text = "O:306";
            this.lbOUT306.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT305
            // 
            this.lbOUT305.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT305.Location = new System.Drawing.Point(751, 276);
            this.lbOUT305.Name = "lbOUT305";
            this.lbOUT305.Size = new System.Drawing.Size(50, 22);
            this.lbOUT305.TabIndex = 111;
            this.lbOUT305.Text = "O:305";
            this.lbOUT305.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT304
            // 
            this.lbOUT304.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT304.Location = new System.Drawing.Point(751, 248);
            this.lbOUT304.Name = "lbOUT304";
            this.lbOUT304.Size = new System.Drawing.Size(50, 22);
            this.lbOUT304.TabIndex = 109;
            this.lbOUT304.Text = "O:304";
            this.lbOUT304.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT303
            // 
            this.lbOUT303.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT303.Location = new System.Drawing.Point(751, 220);
            this.lbOUT303.Name = "lbOUT303";
            this.lbOUT303.Size = new System.Drawing.Size(50, 22);
            this.lbOUT303.TabIndex = 107;
            this.lbOUT303.Text = "O:303";
            this.lbOUT303.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT302
            // 
            this.lbOUT302.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT302.Location = new System.Drawing.Point(751, 192);
            this.lbOUT302.Name = "lbOUT302";
            this.lbOUT302.Size = new System.Drawing.Size(50, 22);
            this.lbOUT302.TabIndex = 105;
            this.lbOUT302.Text = "O:302";
            this.lbOUT302.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT301
            // 
            this.lbOUT301.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT301.Location = new System.Drawing.Point(751, 164);
            this.lbOUT301.Name = "lbOUT301";
            this.lbOUT301.Size = new System.Drawing.Size(50, 22);
            this.lbOUT301.TabIndex = 103;
            this.lbOUT301.Text = "O:301";
            this.lbOUT301.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT300
            // 
            this.lbOUT300.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT300.Location = new System.Drawing.Point(751, 136);
            this.lbOUT300.Name = "lbOUT300";
            this.lbOUT300.Size = new System.Drawing.Size(50, 22);
            this.lbOUT300.TabIndex = 101;
            this.lbOUT300.Text = "O:300";
            this.lbOUT300.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT215
            // 
            this.lbOUT215.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT215.Location = new System.Drawing.Point(517, 556);
            this.lbOUT215.Name = "lbOUT215";
            this.lbOUT215.Size = new System.Drawing.Size(50, 22);
            this.lbOUT215.TabIndex = 99;
            this.lbOUT215.Text = "O:215";
            this.lbOUT215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT214
            // 
            this.lbOUT214.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT214.Location = new System.Drawing.Point(517, 528);
            this.lbOUT214.Name = "lbOUT214";
            this.lbOUT214.Size = new System.Drawing.Size(50, 22);
            this.lbOUT214.TabIndex = 97;
            this.lbOUT214.Text = "O:214";
            this.lbOUT214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT213
            // 
            this.lbOUT213.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT213.Location = new System.Drawing.Point(517, 500);
            this.lbOUT213.Name = "lbOUT213";
            this.lbOUT213.Size = new System.Drawing.Size(50, 22);
            this.lbOUT213.TabIndex = 95;
            this.lbOUT213.Text = "O:213";
            this.lbOUT213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT212
            // 
            this.lbOUT212.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT212.Location = new System.Drawing.Point(517, 472);
            this.lbOUT212.Name = "lbOUT212";
            this.lbOUT212.Size = new System.Drawing.Size(50, 22);
            this.lbOUT212.TabIndex = 93;
            this.lbOUT212.Text = "O:212";
            this.lbOUT212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT211
            // 
            this.lbOUT211.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT211.Location = new System.Drawing.Point(517, 444);
            this.lbOUT211.Name = "lbOUT211";
            this.lbOUT211.Size = new System.Drawing.Size(50, 22);
            this.lbOUT211.TabIndex = 91;
            this.lbOUT211.Text = "O:211";
            this.lbOUT211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT210
            // 
            this.lbOUT210.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT210.Location = new System.Drawing.Point(517, 416);
            this.lbOUT210.Name = "lbOUT210";
            this.lbOUT210.Size = new System.Drawing.Size(50, 22);
            this.lbOUT210.TabIndex = 89;
            this.lbOUT210.Text = "O:210";
            this.lbOUT210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT209
            // 
            this.lbOUT209.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT209.Location = new System.Drawing.Point(517, 388);
            this.lbOUT209.Name = "lbOUT209";
            this.lbOUT209.Size = new System.Drawing.Size(50, 22);
            this.lbOUT209.TabIndex = 87;
            this.lbOUT209.Text = "O:209";
            this.lbOUT209.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT208
            // 
            this.lbOUT208.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT208.Location = new System.Drawing.Point(517, 360);
            this.lbOUT208.Name = "lbOUT208";
            this.lbOUT208.Size = new System.Drawing.Size(50, 22);
            this.lbOUT208.TabIndex = 85;
            this.lbOUT208.Text = "O:208";
            this.lbOUT208.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT207
            // 
            this.lbOUT207.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT207.Location = new System.Drawing.Point(517, 332);
            this.lbOUT207.Name = "lbOUT207";
            this.lbOUT207.Size = new System.Drawing.Size(50, 22);
            this.lbOUT207.TabIndex = 83;
            this.lbOUT207.Text = "O:207";
            this.lbOUT207.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT206
            // 
            this.lbOUT206.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT206.Location = new System.Drawing.Point(517, 304);
            this.lbOUT206.Name = "lbOUT206";
            this.lbOUT206.Size = new System.Drawing.Size(50, 22);
            this.lbOUT206.TabIndex = 81;
            this.lbOUT206.Text = "O:206";
            this.lbOUT206.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT205
            // 
            this.lbOUT205.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT205.Location = new System.Drawing.Point(517, 276);
            this.lbOUT205.Name = "lbOUT205";
            this.lbOUT205.Size = new System.Drawing.Size(50, 22);
            this.lbOUT205.TabIndex = 79;
            this.lbOUT205.Text = "O:205";
            this.lbOUT205.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT204
            // 
            this.lbOUT204.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT204.Location = new System.Drawing.Point(517, 248);
            this.lbOUT204.Name = "lbOUT204";
            this.lbOUT204.Size = new System.Drawing.Size(50, 22);
            this.lbOUT204.TabIndex = 77;
            this.lbOUT204.Text = "O:204";
            this.lbOUT204.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT203
            // 
            this.lbOUT203.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT203.Location = new System.Drawing.Point(517, 220);
            this.lbOUT203.Name = "lbOUT203";
            this.lbOUT203.Size = new System.Drawing.Size(50, 22);
            this.lbOUT203.TabIndex = 75;
            this.lbOUT203.Text = "O:203";
            this.lbOUT203.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT202
            // 
            this.lbOUT202.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT202.Location = new System.Drawing.Point(517, 192);
            this.lbOUT202.Name = "lbOUT202";
            this.lbOUT202.Size = new System.Drawing.Size(50, 22);
            this.lbOUT202.TabIndex = 73;
            this.lbOUT202.Text = "O:202";
            this.lbOUT202.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT201
            // 
            this.lbOUT201.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT201.Location = new System.Drawing.Point(517, 164);
            this.lbOUT201.Name = "lbOUT201";
            this.lbOUT201.Size = new System.Drawing.Size(50, 22);
            this.lbOUT201.TabIndex = 71;
            this.lbOUT201.Text = "O:201";
            this.lbOUT201.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT200
            // 
            this.lbOUT200.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT200.Location = new System.Drawing.Point(517, 136);
            this.lbOUT200.Name = "lbOUT200";
            this.lbOUT200.Size = new System.Drawing.Size(50, 22);
            this.lbOUT200.TabIndex = 69;
            this.lbOUT200.Text = "O:200";
            this.lbOUT200.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbIN_2
            // 
            this.tbIN_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN_2.Location = new System.Drawing.Point(193, 108);
            this.tbIN_2.Name = "tbIN_2";
            this.tbIN_2.ReadOnly = true;
            this.tbIN_2.Size = new System.Drawing.Size(150, 22);
            this.tbIN_2.TabIndex = 132;
            this.tbIN_2.Text = "INPUT";
            this.tbIN_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbOUT_2
            // 
            this.tbOUT_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT_2.Location = new System.Drawing.Point(665, 108);
            this.tbOUT_2.Name = "tbOUT_2";
            this.tbOUT_2.ReadOnly = true;
            this.tbOUT_2.Size = new System.Drawing.Size(150, 22);
            this.tbOUT_2.TabIndex = 133;
            this.tbOUT_2.Text = "OUTPUT";
            this.tbOUT_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIN200
            // 
            this.tbIN200.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN200.Location = new System.Drawing.Point(101, 136);
            this.tbIN200.Name = "tbIN200";
            this.tbIN200.ReadOnly = true;
            this.tbIN200.Size = new System.Drawing.Size(150, 21);
            this.tbIN200.TabIndex = 134;
            this.tbIN200.Text = "RFID Left IN";
            // 
            // tbIN201
            // 
            this.tbIN201.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN201.Location = new System.Drawing.Point(101, 164);
            this.tbIN201.Name = "tbIN201";
            this.tbIN201.ReadOnly = true;
            this.tbIN201.Size = new System.Drawing.Size(150, 21);
            this.tbIN201.TabIndex = 134;
            this.tbIN201.Text = "RFID Left OUT";
            // 
            // tbIN202
            // 
            this.tbIN202.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN202.Location = new System.Drawing.Point(101, 192);
            this.tbIN202.Name = "tbIN202";
            this.tbIN202.ReadOnly = true;
            this.tbIN202.Size = new System.Drawing.Size(150, 21);
            this.tbIN202.TabIndex = 134;
            this.tbIN202.Text = "RFID Right IN";
            // 
            // tbIN203
            // 
            this.tbIN203.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN203.Location = new System.Drawing.Point(101, 220);
            this.tbIN203.Name = "tbIN203";
            this.tbIN203.ReadOnly = true;
            this.tbIN203.Size = new System.Drawing.Size(150, 21);
            this.tbIN203.TabIndex = 134;
            this.tbIN203.Text = "RFID Right OUT";
            // 
            // tbIN204
            // 
            this.tbIN204.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN204.Location = new System.Drawing.Point(101, 248);
            this.tbIN204.Name = "tbIN204";
            this.tbIN204.ReadOnly = true;
            this.tbIN204.Size = new System.Drawing.Size(150, 21);
            this.tbIN204.TabIndex = 134;
            this.tbIN204.Text = "Cal sig Y axis";
            // 
            // tbIN206
            // 
            this.tbIN206.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN206.Location = new System.Drawing.Point(101, 304);
            this.tbIN206.Name = "tbIN206";
            this.tbIN206.ReadOnly = true;
            this.tbIN206.Size = new System.Drawing.Size(150, 21);
            this.tbIN206.TabIndex = 134;
            this.tbIN206.Text = "Cal sig Z axis";
            // 
            // tbIN205
            // 
            this.tbIN205.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN205.Location = new System.Drawing.Point(101, 276);
            this.tbIN205.Name = "tbIN205";
            this.tbIN205.ReadOnly = true;
            this.tbIN205.Size = new System.Drawing.Size(150, 21);
            this.tbIN205.TabIndex = 134;
            this.tbIN205.Text = "Cal sig X axis";
            // 
            // tbIN207
            // 
            this.tbIN207.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN207.Location = new System.Drawing.Point(101, 332);
            this.tbIN207.Name = "tbIN207";
            this.tbIN207.ReadOnly = true;
            this.tbIN207.Size = new System.Drawing.Size(150, 21);
            this.tbIN207.TabIndex = 134;
            // 
            // tbIN208
            // 
            this.tbIN208.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN208.Location = new System.Drawing.Point(101, 360);
            this.tbIN208.Name = "tbIN208";
            this.tbIN208.ReadOnly = true;
            this.tbIN208.Size = new System.Drawing.Size(150, 21);
            this.tbIN208.TabIndex = 134;
            this.tbIN208.Text = "Commu before in - 1";
            // 
            // tbIN212
            // 
            this.tbIN212.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN212.Location = new System.Drawing.Point(101, 472);
            this.tbIN212.Name = "tbIN212";
            this.tbIN212.ReadOnly = true;
            this.tbIN212.Size = new System.Drawing.Size(150, 21);
            this.tbIN212.TabIndex = 134;
            this.tbIN212.Text = "Commu after in - 1";
            // 
            // tbIN210
            // 
            this.tbIN210.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN210.Location = new System.Drawing.Point(101, 416);
            this.tbIN210.Name = "tbIN210";
            this.tbIN210.ReadOnly = true;
            this.tbIN210.Size = new System.Drawing.Size(150, 21);
            this.tbIN210.TabIndex = 134;
            this.tbIN210.Text = "Commu before in - 3";
            // 
            // tbIN214
            // 
            this.tbIN214.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN214.Location = new System.Drawing.Point(101, 528);
            this.tbIN214.Name = "tbIN214";
            this.tbIN214.ReadOnly = true;
            this.tbIN214.Size = new System.Drawing.Size(150, 21);
            this.tbIN214.TabIndex = 134;
            this.tbIN214.Text = "Commu after in - 3";
            // 
            // tbIN209
            // 
            this.tbIN209.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN209.Location = new System.Drawing.Point(101, 388);
            this.tbIN209.Name = "tbIN209";
            this.tbIN209.ReadOnly = true;
            this.tbIN209.Size = new System.Drawing.Size(150, 21);
            this.tbIN209.TabIndex = 134;
            this.tbIN209.Text = "Commu before in - 2";
            // 
            // tbIN213
            // 
            this.tbIN213.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN213.Location = new System.Drawing.Point(101, 500);
            this.tbIN213.Name = "tbIN213";
            this.tbIN213.ReadOnly = true;
            this.tbIN213.Size = new System.Drawing.Size(150, 21);
            this.tbIN213.TabIndex = 134;
            this.tbIN213.Text = "Commu after in - 2";
            // 
            // tbIN211
            // 
            this.tbIN211.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN211.Location = new System.Drawing.Point(101, 444);
            this.tbIN211.Name = "tbIN211";
            this.tbIN211.ReadOnly = true;
            this.tbIN211.Size = new System.Drawing.Size(150, 21);
            this.tbIN211.TabIndex = 134;
            this.tbIN211.Text = "Commu before in - 4";
            // 
            // tbIN215
            // 
            this.tbIN215.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN215.Location = new System.Drawing.Point(101, 556);
            this.tbIN215.Name = "tbIN215";
            this.tbIN215.ReadOnly = true;
            this.tbIN215.Size = new System.Drawing.Size(150, 21);
            this.tbIN215.TabIndex = 134;
            this.tbIN215.Text = "Commu after in - 4";
            // 
            // tbIN300
            // 
            this.tbIN300.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN300.Location = new System.Drawing.Point(335, 136);
            this.tbIN300.Name = "tbIN300";
            this.tbIN300.ReadOnly = true;
            this.tbIN300.Size = new System.Drawing.Size(150, 21);
            this.tbIN300.TabIndex = 134;
            this.tbIN300.Text = "Tools-1 move In";
            // 
            // tbIN308
            // 
            this.tbIN308.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN308.Location = new System.Drawing.Point(335, 360);
            this.tbIN308.Name = "tbIN308";
            this.tbIN308.ReadOnly = true;
            this.tbIN308.Size = new System.Drawing.Size(150, 21);
            this.tbIN308.TabIndex = 134;
            this.tbIN308.Text = "Tools-2 Un-Lock";
            // 
            // tbIN304
            // 
            this.tbIN304.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN304.Location = new System.Drawing.Point(335, 248);
            this.tbIN304.Name = "tbIN304";
            this.tbIN304.ReadOnly = true;
            this.tbIN304.Size = new System.Drawing.Size(150, 21);
            this.tbIN304.TabIndex = 134;
            this.tbIN304.Text = "Sensor check Tools-1";
            // 
            // tbIN312
            // 
            this.tbIN312.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN312.Location = new System.Drawing.Point(335, 472);
            this.tbIN312.Name = "tbIN312";
            this.tbIN312.ReadOnly = true;
            this.tbIN312.Size = new System.Drawing.Size(150, 21);
            this.tbIN312.TabIndex = 134;
            // 
            // tbIN302
            // 
            this.tbIN302.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN302.Location = new System.Drawing.Point(335, 192);
            this.tbIN302.Name = "tbIN302";
            this.tbIN302.ReadOnly = true;
            this.tbIN302.Size = new System.Drawing.Size(150, 21);
            this.tbIN302.TabIndex = 134;
            this.tbIN302.Text = "Tools-1 Lock";
            // 
            // tbIN310
            // 
            this.tbIN310.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN310.Location = new System.Drawing.Point(335, 416);
            this.tbIN310.Name = "tbIN310";
            this.tbIN310.ReadOnly = true;
            this.tbIN310.Size = new System.Drawing.Size(150, 21);
            this.tbIN310.TabIndex = 134;
            // 
            // tbIN306
            // 
            this.tbIN306.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN306.Location = new System.Drawing.Point(335, 304);
            this.tbIN306.Name = "tbIN306";
            this.tbIN306.ReadOnly = true;
            this.tbIN306.Size = new System.Drawing.Size(150, 21);
            this.tbIN306.TabIndex = 134;
            this.tbIN306.Text = "Tools-2 move Out";
            // 
            // tbIN314
            // 
            this.tbIN314.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN314.Location = new System.Drawing.Point(335, 528);
            this.tbIN314.Name = "tbIN314";
            this.tbIN314.ReadOnly = true;
            this.tbIN314.Size = new System.Drawing.Size(150, 21);
            this.tbIN314.TabIndex = 134;
            // 
            // tbIN301
            // 
            this.tbIN301.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN301.Location = new System.Drawing.Point(335, 164);
            this.tbIN301.Name = "tbIN301";
            this.tbIN301.ReadOnly = true;
            this.tbIN301.Size = new System.Drawing.Size(150, 21);
            this.tbIN301.TabIndex = 134;
            this.tbIN301.Text = "Tools-1 move Out";
            // 
            // tbIN309
            // 
            this.tbIN309.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN309.Location = new System.Drawing.Point(335, 388);
            this.tbIN309.Name = "tbIN309";
            this.tbIN309.ReadOnly = true;
            this.tbIN309.Size = new System.Drawing.Size(150, 21);
            this.tbIN309.TabIndex = 134;
            this.tbIN309.Text = "Sensor check Tools-2";
            // 
            // tbIN305
            // 
            this.tbIN305.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN305.Location = new System.Drawing.Point(335, 276);
            this.tbIN305.Name = "tbIN305";
            this.tbIN305.ReadOnly = true;
            this.tbIN305.Size = new System.Drawing.Size(150, 21);
            this.tbIN305.TabIndex = 134;
            this.tbIN305.Text = "Tools-2 move In";
            // 
            // tbIN313
            // 
            this.tbIN313.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN313.Location = new System.Drawing.Point(335, 500);
            this.tbIN313.Name = "tbIN313";
            this.tbIN313.ReadOnly = true;
            this.tbIN313.Size = new System.Drawing.Size(150, 21);
            this.tbIN313.TabIndex = 134;
            // 
            // tbIN303
            // 
            this.tbIN303.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN303.Location = new System.Drawing.Point(335, 220);
            this.tbIN303.Name = "tbIN303";
            this.tbIN303.ReadOnly = true;
            this.tbIN303.Size = new System.Drawing.Size(150, 21);
            this.tbIN303.TabIndex = 134;
            this.tbIN303.Text = "Tools-1 Un-Lock";
            // 
            // tbIN311
            // 
            this.tbIN311.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN311.Location = new System.Drawing.Point(335, 444);
            this.tbIN311.Name = "tbIN311";
            this.tbIN311.ReadOnly = true;
            this.tbIN311.Size = new System.Drawing.Size(150, 21);
            this.tbIN311.TabIndex = 134;
            // 
            // tbIN307
            // 
            this.tbIN307.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN307.Location = new System.Drawing.Point(335, 332);
            this.tbIN307.Name = "tbIN307";
            this.tbIN307.ReadOnly = true;
            this.tbIN307.Size = new System.Drawing.Size(150, 21);
            this.tbIN307.TabIndex = 134;
            this.tbIN307.Text = "Tools-2 Lock";
            // 
            // tbIN315
            // 
            this.tbIN315.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN315.Location = new System.Drawing.Point(335, 556);
            this.tbIN315.Name = "tbIN315";
            this.tbIN315.ReadOnly = true;
            this.tbIN315.Size = new System.Drawing.Size(150, 21);
            this.tbIN315.TabIndex = 134;
            // 
            // tbOUT200
            // 
            this.tbOUT200.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT200.Location = new System.Drawing.Point(573, 136);
            this.tbOUT200.Name = "tbOUT200";
            this.tbOUT200.ReadOnly = true;
            this.tbOUT200.Size = new System.Drawing.Size(150, 21);
            this.tbOUT200.TabIndex = 134;
            this.tbOUT200.Text = "SOL RFID Left";
            // 
            // tbOUT208
            // 
            this.tbOUT208.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT208.Location = new System.Drawing.Point(573, 360);
            this.tbOUT208.Name = "tbOUT208";
            this.tbOUT208.ReadOnly = true;
            this.tbOUT208.Size = new System.Drawing.Size(150, 21);
            this.tbOUT208.TabIndex = 134;
            this.tbOUT208.Text = "Commu before out - 1";
            // 
            // tbOUT204
            // 
            this.tbOUT204.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT204.Location = new System.Drawing.Point(573, 248);
            this.tbOUT204.Name = "tbOUT204";
            this.tbOUT204.ReadOnly = true;
            this.tbOUT204.Size = new System.Drawing.Size(150, 21);
            this.tbOUT204.TabIndex = 134;
            // 
            // tbOUT212
            // 
            this.tbOUT212.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT212.Location = new System.Drawing.Point(573, 472);
            this.tbOUT212.Name = "tbOUT212";
            this.tbOUT212.ReadOnly = true;
            this.tbOUT212.Size = new System.Drawing.Size(150, 21);
            this.tbOUT212.TabIndex = 134;
            this.tbOUT212.Text = "Commu after out - 1";
            // 
            // tbOUT202
            // 
            this.tbOUT202.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT202.Location = new System.Drawing.Point(573, 192);
            this.tbOUT202.Name = "tbOUT202";
            this.tbOUT202.ReadOnly = true;
            this.tbOUT202.Size = new System.Drawing.Size(150, 21);
            this.tbOUT202.TabIndex = 134;
            this.tbOUT202.Text = "SOL RFID Right";
            // 
            // tbOUT210
            // 
            this.tbOUT210.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT210.Location = new System.Drawing.Point(573, 416);
            this.tbOUT210.Name = "tbOUT210";
            this.tbOUT210.ReadOnly = true;
            this.tbOUT210.Size = new System.Drawing.Size(150, 21);
            this.tbOUT210.TabIndex = 134;
            this.tbOUT210.Text = "Commu before out - 3";
            // 
            // tbOUT206
            // 
            this.tbOUT206.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT206.Location = new System.Drawing.Point(573, 304);
            this.tbOUT206.Name = "tbOUT206";
            this.tbOUT206.ReadOnly = true;
            this.tbOUT206.Size = new System.Drawing.Size(150, 21);
            this.tbOUT206.TabIndex = 134;
            this.tbOUT206.Text = "Light Control - 1";
            // 
            // tbOUT214
            // 
            this.tbOUT214.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT214.Location = new System.Drawing.Point(573, 528);
            this.tbOUT214.Name = "tbOUT214";
            this.tbOUT214.ReadOnly = true;
            this.tbOUT214.Size = new System.Drawing.Size(150, 21);
            this.tbOUT214.TabIndex = 134;
            this.tbOUT214.Text = "Commu after out - 3";
            // 
            // tbOUT201
            // 
            this.tbOUT201.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT201.Location = new System.Drawing.Point(573, 164);
            this.tbOUT201.Name = "tbOUT201";
            this.tbOUT201.ReadOnly = true;
            this.tbOUT201.Size = new System.Drawing.Size(150, 21);
            this.tbOUT201.TabIndex = 134;
            // 
            // tbOUT209
            // 
            this.tbOUT209.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT209.Location = new System.Drawing.Point(573, 388);
            this.tbOUT209.Name = "tbOUT209";
            this.tbOUT209.ReadOnly = true;
            this.tbOUT209.Size = new System.Drawing.Size(150, 21);
            this.tbOUT209.TabIndex = 134;
            this.tbOUT209.Text = "Commu before out - 2";
            // 
            // tbOUT205
            // 
            this.tbOUT205.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT205.Location = new System.Drawing.Point(573, 276);
            this.tbOUT205.Name = "tbOUT205";
            this.tbOUT205.ReadOnly = true;
            this.tbOUT205.Size = new System.Drawing.Size(150, 21);
            this.tbOUT205.TabIndex = 134;
            // 
            // tbOUT213
            // 
            this.tbOUT213.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT213.Location = new System.Drawing.Point(573, 500);
            this.tbOUT213.Name = "tbOUT213";
            this.tbOUT213.ReadOnly = true;
            this.tbOUT213.Size = new System.Drawing.Size(150, 21);
            this.tbOUT213.TabIndex = 134;
            this.tbOUT213.Text = "Commu after out - 2";
            // 
            // tbOUT203
            // 
            this.tbOUT203.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT203.Location = new System.Drawing.Point(573, 220);
            this.tbOUT203.Name = "tbOUT203";
            this.tbOUT203.ReadOnly = true;
            this.tbOUT203.Size = new System.Drawing.Size(150, 21);
            this.tbOUT203.TabIndex = 134;
            // 
            // tbOUT211
            // 
            this.tbOUT211.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT211.Location = new System.Drawing.Point(573, 444);
            this.tbOUT211.Name = "tbOUT211";
            this.tbOUT211.ReadOnly = true;
            this.tbOUT211.Size = new System.Drawing.Size(150, 21);
            this.tbOUT211.TabIndex = 134;
            this.tbOUT211.Text = "Commu before out - 4";
            // 
            // tbOUT207
            // 
            this.tbOUT207.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT207.Location = new System.Drawing.Point(573, 332);
            this.tbOUT207.Name = "tbOUT207";
            this.tbOUT207.ReadOnly = true;
            this.tbOUT207.Size = new System.Drawing.Size(150, 21);
            this.tbOUT207.TabIndex = 134;
            this.tbOUT207.Text = "Light Control - 2";
            // 
            // tbOUT215
            // 
            this.tbOUT215.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT215.Location = new System.Drawing.Point(573, 556);
            this.tbOUT215.Name = "tbOUT215";
            this.tbOUT215.ReadOnly = true;
            this.tbOUT215.Size = new System.Drawing.Size(150, 21);
            this.tbOUT215.TabIndex = 134;
            this.tbOUT215.Text = "Commu after out - 4";
            // 
            // tbOUT300
            // 
            this.tbOUT300.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT300.Location = new System.Drawing.Point(807, 136);
            this.tbOUT300.Name = "tbOUT300";
            this.tbOUT300.ReadOnly = true;
            this.tbOUT300.Size = new System.Drawing.Size(150, 21);
            this.tbOUT300.TabIndex = 134;
            this.tbOUT300.Text = "SOL Tools-1 move In/Out";
            // 
            // tbOUT308
            // 
            this.tbOUT308.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT308.Location = new System.Drawing.Point(807, 360);
            this.tbOUT308.Name = "tbOUT308";
            this.tbOUT308.ReadOnly = true;
            this.tbOUT308.Size = new System.Drawing.Size(150, 21);
            this.tbOUT308.TabIndex = 134;
            // 
            // tbOUT304
            // 
            this.tbOUT304.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT304.Location = new System.Drawing.Point(807, 248);
            this.tbOUT304.Name = "tbOUT304";
            this.tbOUT304.ReadOnly = true;
            this.tbOUT304.Size = new System.Drawing.Size(150, 21);
            this.tbOUT304.TabIndex = 134;
            // 
            // tbOUT312
            // 
            this.tbOUT312.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT312.Location = new System.Drawing.Point(807, 472);
            this.tbOUT312.Name = "tbOUT312";
            this.tbOUT312.ReadOnly = true;
            this.tbOUT312.Size = new System.Drawing.Size(150, 21);
            this.tbOUT312.TabIndex = 134;
            // 
            // tbOUT302
            // 
            this.tbOUT302.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT302.Location = new System.Drawing.Point(807, 192);
            this.tbOUT302.Name = "tbOUT302";
            this.tbOUT302.ReadOnly = true;
            this.tbOUT302.Size = new System.Drawing.Size(150, 21);
            this.tbOUT302.TabIndex = 134;
            this.tbOUT302.Text = "SOL Tools-1 Lock/UnLock";
            // 
            // tbOUT310
            // 
            this.tbOUT310.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT310.Location = new System.Drawing.Point(807, 416);
            this.tbOUT310.Name = "tbOUT310";
            this.tbOUT310.ReadOnly = true;
            this.tbOUT310.Size = new System.Drawing.Size(150, 21);
            this.tbOUT310.TabIndex = 134;
            this.tbOUT310.Text = "SOL Lock/UnLock Tools";
            // 
            // tbOUT306
            // 
            this.tbOUT306.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT306.Location = new System.Drawing.Point(807, 304);
            this.tbOUT306.Name = "tbOUT306";
            this.tbOUT306.ReadOnly = true;
            this.tbOUT306.Size = new System.Drawing.Size(150, 21);
            this.tbOUT306.TabIndex = 134;
            // 
            // tbOUT314
            // 
            this.tbOUT314.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT314.Location = new System.Drawing.Point(807, 528);
            this.tbOUT314.Name = "tbOUT314";
            this.tbOUT314.ReadOnly = true;
            this.tbOUT314.Size = new System.Drawing.Size(150, 21);
            this.tbOUT314.TabIndex = 134;
            // 
            // tbOUT301
            // 
            this.tbOUT301.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT301.Location = new System.Drawing.Point(807, 164);
            this.tbOUT301.Name = "tbOUT301";
            this.tbOUT301.ReadOnly = true;
            this.tbOUT301.Size = new System.Drawing.Size(150, 21);
            this.tbOUT301.TabIndex = 134;
            // 
            // tbOUT309
            // 
            this.tbOUT309.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT309.Location = new System.Drawing.Point(807, 388);
            this.tbOUT309.Name = "tbOUT309";
            this.tbOUT309.ReadOnly = true;
            this.tbOUT309.Size = new System.Drawing.Size(150, 21);
            this.tbOUT309.TabIndex = 134;
            // 
            // tbOUT305
            // 
            this.tbOUT305.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT305.Location = new System.Drawing.Point(807, 276);
            this.tbOUT305.Name = "tbOUT305";
            this.tbOUT305.ReadOnly = true;
            this.tbOUT305.Size = new System.Drawing.Size(150, 21);
            this.tbOUT305.TabIndex = 134;
            this.tbOUT305.Text = "SOL Tools-2 move In/Out";
            // 
            // tbOUT313
            // 
            this.tbOUT313.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT313.Location = new System.Drawing.Point(807, 500);
            this.tbOUT313.Name = "tbOUT313";
            this.tbOUT313.ReadOnly = true;
            this.tbOUT313.Size = new System.Drawing.Size(150, 21);
            this.tbOUT313.TabIndex = 134;
            // 
            // tbOUT303
            // 
            this.tbOUT303.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT303.Location = new System.Drawing.Point(807, 220);
            this.tbOUT303.Name = "tbOUT303";
            this.tbOUT303.ReadOnly = true;
            this.tbOUT303.Size = new System.Drawing.Size(150, 21);
            this.tbOUT303.TabIndex = 134;
            // 
            // tbOUT311
            // 
            this.tbOUT311.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT311.Location = new System.Drawing.Point(807, 444);
            this.tbOUT311.Name = "tbOUT311";
            this.tbOUT311.ReadOnly = true;
            this.tbOUT311.Size = new System.Drawing.Size(150, 21);
            this.tbOUT311.TabIndex = 134;
            // 
            // tbOUT307
            // 
            this.tbOUT307.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT307.Location = new System.Drawing.Point(807, 332);
            this.tbOUT307.Name = "tbOUT307";
            this.tbOUT307.ReadOnly = true;
            this.tbOUT307.Size = new System.Drawing.Size(150, 21);
            this.tbOUT307.TabIndex = 134;
            this.tbOUT307.Text = "SOL Tools-2 Lock/UnLock";
            // 
            // tbOUT315
            // 
            this.tbOUT315.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT315.Location = new System.Drawing.Point(807, 556);
            this.tbOUT315.Name = "tbOUT315";
            this.tbOUT315.ReadOnly = true;
            this.tbOUT315.Size = new System.Drawing.Size(150, 21);
            this.tbOUT315.TabIndex = 134;
            // 
            // ucIOmonitor_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.tbOUT315);
            this.Controls.Add(this.tbOUT215);
            this.Controls.Add(this.tbIN315);
            this.Controls.Add(this.tbIN215);
            this.Controls.Add(this.tbOUT307);
            this.Controls.Add(this.tbOUT207);
            this.Controls.Add(this.tbIN307);
            this.Controls.Add(this.tbIN207);
            this.Controls.Add(this.tbOUT311);
            this.Controls.Add(this.tbOUT211);
            this.Controls.Add(this.tbIN311);
            this.Controls.Add(this.tbIN211);
            this.Controls.Add(this.tbOUT303);
            this.Controls.Add(this.tbOUT203);
            this.Controls.Add(this.tbIN303);
            this.Controls.Add(this.tbIN203);
            this.Controls.Add(this.tbOUT313);
            this.Controls.Add(this.tbOUT213);
            this.Controls.Add(this.tbIN313);
            this.Controls.Add(this.tbIN213);
            this.Controls.Add(this.tbOUT305);
            this.Controls.Add(this.tbOUT205);
            this.Controls.Add(this.tbIN305);
            this.Controls.Add(this.tbIN205);
            this.Controls.Add(this.tbOUT309);
            this.Controls.Add(this.tbOUT209);
            this.Controls.Add(this.tbIN309);
            this.Controls.Add(this.tbIN209);
            this.Controls.Add(this.tbOUT301);
            this.Controls.Add(this.tbOUT201);
            this.Controls.Add(this.tbIN301);
            this.Controls.Add(this.tbIN201);
            this.Controls.Add(this.tbOUT314);
            this.Controls.Add(this.tbOUT214);
            this.Controls.Add(this.tbIN314);
            this.Controls.Add(this.tbIN214);
            this.Controls.Add(this.tbOUT306);
            this.Controls.Add(this.tbOUT206);
            this.Controls.Add(this.tbIN306);
            this.Controls.Add(this.tbIN206);
            this.Controls.Add(this.tbOUT310);
            this.Controls.Add(this.tbOUT210);
            this.Controls.Add(this.tbIN310);
            this.Controls.Add(this.tbIN210);
            this.Controls.Add(this.tbOUT302);
            this.Controls.Add(this.tbOUT202);
            this.Controls.Add(this.tbIN302);
            this.Controls.Add(this.tbIN202);
            this.Controls.Add(this.tbOUT312);
            this.Controls.Add(this.tbOUT212);
            this.Controls.Add(this.tbIN312);
            this.Controls.Add(this.tbIN212);
            this.Controls.Add(this.tbOUT304);
            this.Controls.Add(this.tbOUT204);
            this.Controls.Add(this.tbIN304);
            this.Controls.Add(this.tbIN204);
            this.Controls.Add(this.tbOUT308);
            this.Controls.Add(this.tbOUT208);
            this.Controls.Add(this.tbIN308);
            this.Controls.Add(this.tbIN208);
            this.Controls.Add(this.tbOUT300);
            this.Controls.Add(this.tbOUT200);
            this.Controls.Add(this.tbIN300);
            this.Controls.Add(this.tbIN200);
            this.Controls.Add(this.tbOUT_2);
            this.Controls.Add(this.tbIN_2);
            this.Controls.Add(this.lbOUT315);
            this.Controls.Add(this.lbOUT314);
            this.Controls.Add(this.lbOUT313);
            this.Controls.Add(this.lbOUT312);
            this.Controls.Add(this.lbOUT311);
            this.Controls.Add(this.lbOUT310);
            this.Controls.Add(this.lbOUT309);
            this.Controls.Add(this.lbOUT308);
            this.Controls.Add(this.lbOUT307);
            this.Controls.Add(this.lbOUT306);
            this.Controls.Add(this.lbOUT305);
            this.Controls.Add(this.lbOUT304);
            this.Controls.Add(this.lbOUT303);
            this.Controls.Add(this.lbOUT302);
            this.Controls.Add(this.lbOUT301);
            this.Controls.Add(this.lbOUT300);
            this.Controls.Add(this.lbOUT215);
            this.Controls.Add(this.lbOUT214);
            this.Controls.Add(this.lbOUT213);
            this.Controls.Add(this.lbOUT212);
            this.Controls.Add(this.lbOUT211);
            this.Controls.Add(this.lbOUT210);
            this.Controls.Add(this.lbOUT209);
            this.Controls.Add(this.lbOUT208);
            this.Controls.Add(this.lbOUT207);
            this.Controls.Add(this.lbOUT206);
            this.Controls.Add(this.lbOUT205);
            this.Controls.Add(this.lbOUT204);
            this.Controls.Add(this.lbOUT203);
            this.Controls.Add(this.lbOUT202);
            this.Controls.Add(this.lbOUT201);
            this.Controls.Add(this.lbOUT200);
            this.Controls.Add(this.lbIN315);
            this.Controls.Add(this.lbIN314);
            this.Controls.Add(this.lbIN313);
            this.Controls.Add(this.lbIN312);
            this.Controls.Add(this.lbIN311);
            this.Controls.Add(this.lbIN310);
            this.Controls.Add(this.lbIN309);
            this.Controls.Add(this.lbIN308);
            this.Controls.Add(this.lbIN307);
            this.Controls.Add(this.lbIN306);
            this.Controls.Add(this.lbIN305);
            this.Controls.Add(this.lbIN304);
            this.Controls.Add(this.lbIN303);
            this.Controls.Add(this.lbIN302);
            this.Controls.Add(this.lbIN301);
            this.Controls.Add(this.lbIN300);
            this.Controls.Add(this.lbIN215);
            this.Controls.Add(this.lbIN214);
            this.Controls.Add(this.lbIN213);
            this.Controls.Add(this.lbIN212);
            this.Controls.Add(this.lbIN211);
            this.Controls.Add(this.lbIN210);
            this.Controls.Add(this.lbIN209);
            this.Controls.Add(this.lbIN208);
            this.Controls.Add(this.lbIN207);
            this.Controls.Add(this.lbIN206);
            this.Controls.Add(this.lbIN205);
            this.Controls.Add(this.lbIN204);
            this.Controls.Add(this.lbIN203);
            this.Controls.Add(this.lbIN202);
            this.Controls.Add(this.lbIN201);
            this.Controls.Add(this.lbIN200);
            this.Controls.Add(this.btnIO_P1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbIO_2);
            this.Controls.Add(this.lbIOMonitor_2);
            this.Name = "ucIOmonitor_2";
            this.Size = new System.Drawing.Size(1000, 600);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbIOMonitor_2;
        private System.Windows.Forms.Label lbIO_2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnIO_P1;
        private System.Windows.Forms.Label lbIN200;
        private System.Windows.Forms.Label lbIN201;
        private System.Windows.Forms.Label lbIN203;
        private System.Windows.Forms.Label lbIN202;
        private System.Windows.Forms.Label lbIN207;
        private System.Windows.Forms.Label lbIN206;
        private System.Windows.Forms.Label lbIN205;
        private System.Windows.Forms.Label lbIN204;
        private System.Windows.Forms.Label lbIN215;
        private System.Windows.Forms.Label lbIN214;
        private System.Windows.Forms.Label lbIN213;
        private System.Windows.Forms.Label lbIN212;
        private System.Windows.Forms.Label lbIN211;
        private System.Windows.Forms.Label lbIN210;
        private System.Windows.Forms.Label lbIN209;
        private System.Windows.Forms.Label lbIN208;
        private System.Windows.Forms.Label lbIN315;
        private System.Windows.Forms.Label lbIN314;
        private System.Windows.Forms.Label lbIN313;
        private System.Windows.Forms.Label lbIN312;
        private System.Windows.Forms.Label lbIN311;
        private System.Windows.Forms.Label lbIN310;
        private System.Windows.Forms.Label lbIN309;
        private System.Windows.Forms.Label lbIN308;
        private System.Windows.Forms.Label lbIN307;
        private System.Windows.Forms.Label lbIN306;
        private System.Windows.Forms.Label lbIN305;
        private System.Windows.Forms.Label lbIN304;
        private System.Windows.Forms.Label lbIN303;
        private System.Windows.Forms.Label lbIN302;
        private System.Windows.Forms.Label lbIN301;
        private System.Windows.Forms.Label lbIN300;
        private System.Windows.Forms.Label lbOUT315;
        private System.Windows.Forms.Label lbOUT314;
        private System.Windows.Forms.Label lbOUT313;
        private System.Windows.Forms.Label lbOUT312;
        private System.Windows.Forms.Label lbOUT311;
        private System.Windows.Forms.Label lbOUT310;
        private System.Windows.Forms.Label lbOUT309;
        private System.Windows.Forms.Label lbOUT308;
        private System.Windows.Forms.Label lbOUT307;
        private System.Windows.Forms.Label lbOUT306;
        private System.Windows.Forms.Label lbOUT305;
        private System.Windows.Forms.Label lbOUT304;
        private System.Windows.Forms.Label lbOUT303;
        private System.Windows.Forms.Label lbOUT302;
        private System.Windows.Forms.Label lbOUT301;
        private System.Windows.Forms.Label lbOUT300;
        private System.Windows.Forms.Label lbOUT215;
        private System.Windows.Forms.Label lbOUT214;
        private System.Windows.Forms.Label lbOUT213;
        private System.Windows.Forms.Label lbOUT212;
        private System.Windows.Forms.Label lbOUT211;
        private System.Windows.Forms.Label lbOUT210;
        private System.Windows.Forms.Label lbOUT209;
        private System.Windows.Forms.Label lbOUT208;
        private System.Windows.Forms.Label lbOUT207;
        private System.Windows.Forms.Label lbOUT206;
        private System.Windows.Forms.Label lbOUT205;
        private System.Windows.Forms.Label lbOUT204;
        private System.Windows.Forms.Label lbOUT203;
        private System.Windows.Forms.Label lbOUT202;
        private System.Windows.Forms.Label lbOUT201;
        private System.Windows.Forms.Label lbOUT200;
        private System.Windows.Forms.TextBox tbIN_2;
        private System.Windows.Forms.TextBox tbOUT_2;
        private System.Windows.Forms.TextBox tbIN200;
        private System.Windows.Forms.TextBox tbIN201;
        private System.Windows.Forms.TextBox tbIN202;
        private System.Windows.Forms.TextBox tbIN203;
        private System.Windows.Forms.TextBox tbIN204;
        private System.Windows.Forms.TextBox tbIN206;
        private System.Windows.Forms.TextBox tbIN205;
        private System.Windows.Forms.TextBox tbIN207;
        private System.Windows.Forms.TextBox tbIN208;
        private System.Windows.Forms.TextBox tbIN212;
        private System.Windows.Forms.TextBox tbIN210;
        private System.Windows.Forms.TextBox tbIN214;
        private System.Windows.Forms.TextBox tbIN209;
        private System.Windows.Forms.TextBox tbIN213;
        private System.Windows.Forms.TextBox tbIN211;
        private System.Windows.Forms.TextBox tbIN215;
        private System.Windows.Forms.TextBox tbIN300;
        private System.Windows.Forms.TextBox tbIN308;
        private System.Windows.Forms.TextBox tbIN304;
        private System.Windows.Forms.TextBox tbIN312;
        private System.Windows.Forms.TextBox tbIN302;
        private System.Windows.Forms.TextBox tbIN310;
        private System.Windows.Forms.TextBox tbIN306;
        private System.Windows.Forms.TextBox tbIN314;
        private System.Windows.Forms.TextBox tbIN301;
        private System.Windows.Forms.TextBox tbIN309;
        private System.Windows.Forms.TextBox tbIN305;
        private System.Windows.Forms.TextBox tbIN313;
        private System.Windows.Forms.TextBox tbIN303;
        private System.Windows.Forms.TextBox tbIN311;
        private System.Windows.Forms.TextBox tbIN307;
        private System.Windows.Forms.TextBox tbIN315;
        private System.Windows.Forms.TextBox tbOUT200;
        private System.Windows.Forms.TextBox tbOUT208;
        private System.Windows.Forms.TextBox tbOUT204;
        private System.Windows.Forms.TextBox tbOUT212;
        private System.Windows.Forms.TextBox tbOUT202;
        private System.Windows.Forms.TextBox tbOUT210;
        private System.Windows.Forms.TextBox tbOUT206;
        private System.Windows.Forms.TextBox tbOUT214;
        private System.Windows.Forms.TextBox tbOUT201;
        private System.Windows.Forms.TextBox tbOUT209;
        private System.Windows.Forms.TextBox tbOUT205;
        private System.Windows.Forms.TextBox tbOUT213;
        private System.Windows.Forms.TextBox tbOUT203;
        private System.Windows.Forms.TextBox tbOUT211;
        private System.Windows.Forms.TextBox tbOUT207;
        private System.Windows.Forms.TextBox tbOUT215;
        private System.Windows.Forms.TextBox tbOUT300;
        private System.Windows.Forms.TextBox tbOUT308;
        private System.Windows.Forms.TextBox tbOUT304;
        private System.Windows.Forms.TextBox tbOUT312;
        private System.Windows.Forms.TextBox tbOUT302;
        private System.Windows.Forms.TextBox tbOUT310;
        private System.Windows.Forms.TextBox tbOUT306;
        private System.Windows.Forms.TextBox tbOUT314;
        private System.Windows.Forms.TextBox tbOUT301;
        private System.Windows.Forms.TextBox tbOUT309;
        private System.Windows.Forms.TextBox tbOUT305;
        private System.Windows.Forms.TextBox tbOUT313;
        private System.Windows.Forms.TextBox tbOUT303;
        private System.Windows.Forms.TextBox tbOUT311;
        private System.Windows.Forms.TextBox tbOUT307;
        private System.Windows.Forms.TextBox tbOUT315;
    }
}
