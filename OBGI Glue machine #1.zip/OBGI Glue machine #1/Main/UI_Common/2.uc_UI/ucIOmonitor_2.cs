﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;


namespace UI_Common
{

    public partial class ucIOmonitor_2 : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        List<Label> labInputList2 = new List<Label>();
        List<Label> labOutputList2 = new List<Label>();
        public ucIOmonitor_2(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;
            # region INPUT Ui AddList
            labInputList2.Add(lbIN200);
            labInputList2.Add(lbIN201);
            labInputList2.Add(lbIN202);
            labInputList2.Add(lbIN203);
            labInputList2.Add(lbIN204);
            labInputList2.Add(lbIN205);
            labInputList2.Add(lbIN206);
            labInputList2.Add(lbIN207);
            labInputList2.Add(lbIN208);
            labInputList2.Add(lbIN209);
            labInputList2.Add(lbIN210);
            labInputList2.Add(lbIN211);
            labInputList2.Add(lbIN212);
            labInputList2.Add(lbIN213);
            labInputList2.Add(lbIN214);
            labInputList2.Add(lbIN215);
            labInputList2.Add(lbIN300);
            labInputList2.Add(lbIN301);
            labInputList2.Add(lbIN302);
            labInputList2.Add(lbIN303);
            labInputList2.Add(lbIN304);
            labInputList2.Add(lbIN305);
            labInputList2.Add(lbIN306);
            labInputList2.Add(lbIN307);
            labInputList2.Add(lbIN308);
            labInputList2.Add(lbIN309);
            labInputList2.Add(lbIN310);
            labInputList2.Add(lbIN311);
            labInputList2.Add(lbIN312);
            labInputList2.Add(lbIN313);
            labInputList2.Add(lbIN314);
            labInputList2.Add(lbIN315);
            #endregion
            #region OUTPUT Ui AddList
            labOutputList2.Add(lbOUT200);
            labOutputList2.Add(lbOUT201);
            labOutputList2.Add(lbOUT202);
            labOutputList2.Add(lbOUT203);
            labOutputList2.Add(lbOUT204);
            labOutputList2.Add(lbOUT205);
            labOutputList2.Add(lbOUT206);
            labOutputList2.Add(lbOUT207);
            labOutputList2.Add(lbOUT208);
            labOutputList2.Add(lbOUT209);
            labOutputList2.Add(lbOUT210);
            labOutputList2.Add(lbOUT211);
            labOutputList2.Add(lbOUT212);
            labOutputList2.Add(lbOUT213);
            labOutputList2.Add(lbOUT214);
            labOutputList2.Add(lbOUT215);
            labOutputList2.Add(lbOUT300);
            labOutputList2.Add(lbOUT301);
            labOutputList2.Add(lbOUT302);
            labOutputList2.Add(lbOUT303);
            labOutputList2.Add(lbOUT304);
            labOutputList2.Add(lbOUT305);
            labOutputList2.Add(lbOUT306);
            labOutputList2.Add(lbOUT307);
            labOutputList2.Add(lbOUT308);
            labOutputList2.Add(lbOUT309);
            labOutputList2.Add(lbOUT310);
            labOutputList2.Add(lbOUT311);
            labOutputList2.Add(lbOUT312);
            labOutputList2.Add(lbOUT313);
            labOutputList2.Add(lbOUT314);
            labOutputList2.Add(lbOUT315);
            #endregion
        }
        public void UpdateUI()
        {
            if (Visible)
            {
                for (int i = 0, j = 0; i < 16; i++, j++)
                {
                    labInputList2[i].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)j].State ? Color.LawnGreen : Color.LightGray;
                    labOutputList2[i].BackColor = _mainGUI.Common.IOTable.DO[(ushort)2, (ushort)j].State ? Color.LawnGreen : Color.LightGray;
                }
                for (int i = 16, j = 0; i < 32; i++, j++)
                {
                    labInputList2[i].BackColor = _mainGUI.Common.IOTable.DI[(ushort)3, (ushort)j].State ? Color.LawnGreen : Color.LightGray;
                    labOutputList2[i].BackColor = _mainGUI.Common.IOTable.DO[(ushort)3, (ushort)j].State ? Color.LawnGreen : Color.LightGray;
                }
            }
        }

        private void btnIO_P1_Click(object sender, EventArgs e)
        {
            foreach (Control item in Parent.Controls)
            {
                if (item is ucIOmonitor)
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }

    }
}
