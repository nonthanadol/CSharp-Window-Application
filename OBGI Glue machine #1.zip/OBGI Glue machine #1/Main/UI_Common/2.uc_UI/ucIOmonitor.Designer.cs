﻿
namespace UI_Common
{
    partial class ucIOmonitor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbIOMonitor = new System.Windows.Forms.Label();
            this.lbIO_1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnIO_P2 = new System.Windows.Forms.Button();
            this.lbIN000 = new System.Windows.Forms.Label();
            this.lbIN001 = new System.Windows.Forms.Label();
            this.lbIN003 = new System.Windows.Forms.Label();
            this.lbIN002 = new System.Windows.Forms.Label();
            this.lbIN007 = new System.Windows.Forms.Label();
            this.lbIN006 = new System.Windows.Forms.Label();
            this.lbIN005 = new System.Windows.Forms.Label();
            this.lbIN004 = new System.Windows.Forms.Label();
            this.lbIN015 = new System.Windows.Forms.Label();
            this.lbIN014 = new System.Windows.Forms.Label();
            this.lbIN013 = new System.Windows.Forms.Label();
            this.lbIN012 = new System.Windows.Forms.Label();
            this.lbIN011 = new System.Windows.Forms.Label();
            this.lbIN010 = new System.Windows.Forms.Label();
            this.lbIN009 = new System.Windows.Forms.Label();
            this.lbIN008 = new System.Windows.Forms.Label();
            this.lbIN115 = new System.Windows.Forms.Label();
            this.lbIN114 = new System.Windows.Forms.Label();
            this.lbIN113 = new System.Windows.Forms.Label();
            this.lbIN112 = new System.Windows.Forms.Label();
            this.lbIN111 = new System.Windows.Forms.Label();
            this.lbIN110 = new System.Windows.Forms.Label();
            this.lbIN109 = new System.Windows.Forms.Label();
            this.lbIN108 = new System.Windows.Forms.Label();
            this.lbIN107 = new System.Windows.Forms.Label();
            this.lbIN106 = new System.Windows.Forms.Label();
            this.lbIN105 = new System.Windows.Forms.Label();
            this.lbIN104 = new System.Windows.Forms.Label();
            this.lbIN103 = new System.Windows.Forms.Label();
            this.lbIN102 = new System.Windows.Forms.Label();
            this.lbIN101 = new System.Windows.Forms.Label();
            this.lbIN100 = new System.Windows.Forms.Label();
            this.lbOUT115 = new System.Windows.Forms.Label();
            this.lbOUT114 = new System.Windows.Forms.Label();
            this.lbOUT113 = new System.Windows.Forms.Label();
            this.lbOUT112 = new System.Windows.Forms.Label();
            this.lbOUT111 = new System.Windows.Forms.Label();
            this.lbOUT110 = new System.Windows.Forms.Label();
            this.lbOUT109 = new System.Windows.Forms.Label();
            this.lbOUT108 = new System.Windows.Forms.Label();
            this.lbOUT107 = new System.Windows.Forms.Label();
            this.lbOUT106 = new System.Windows.Forms.Label();
            this.lbOUT105 = new System.Windows.Forms.Label();
            this.lbOUT104 = new System.Windows.Forms.Label();
            this.lbOUT103 = new System.Windows.Forms.Label();
            this.lbOUT102 = new System.Windows.Forms.Label();
            this.lbOUT101 = new System.Windows.Forms.Label();
            this.lbOUT100 = new System.Windows.Forms.Label();
            this.lbOUT015 = new System.Windows.Forms.Label();
            this.lbOUT014 = new System.Windows.Forms.Label();
            this.lbOUT013 = new System.Windows.Forms.Label();
            this.lbOUT012 = new System.Windows.Forms.Label();
            this.lbOUT011 = new System.Windows.Forms.Label();
            this.lbOUT010 = new System.Windows.Forms.Label();
            this.lbOUT009 = new System.Windows.Forms.Label();
            this.lbOUT008 = new System.Windows.Forms.Label();
            this.lbOUT007 = new System.Windows.Forms.Label();
            this.lbOUT006 = new System.Windows.Forms.Label();
            this.lbOUT005 = new System.Windows.Forms.Label();
            this.lbOUT004 = new System.Windows.Forms.Label();
            this.lbOUT003 = new System.Windows.Forms.Label();
            this.lbOUT002 = new System.Windows.Forms.Label();
            this.lbOUT001 = new System.Windows.Forms.Label();
            this.lbOUT000 = new System.Windows.Forms.Label();
            this.tbIN_1 = new System.Windows.Forms.TextBox();
            this.tbOUT_1 = new System.Windows.Forms.TextBox();
            this.tbIN000 = new System.Windows.Forms.TextBox();
            this.tbIN001 = new System.Windows.Forms.TextBox();
            this.tbIN002 = new System.Windows.Forms.TextBox();
            this.tbIN003 = new System.Windows.Forms.TextBox();
            this.tbIN004 = new System.Windows.Forms.TextBox();
            this.tbIN006 = new System.Windows.Forms.TextBox();
            this.tbIN005 = new System.Windows.Forms.TextBox();
            this.tbIN007 = new System.Windows.Forms.TextBox();
            this.tbIN008 = new System.Windows.Forms.TextBox();
            this.tbIN012 = new System.Windows.Forms.TextBox();
            this.tbIN010 = new System.Windows.Forms.TextBox();
            this.tbIN014 = new System.Windows.Forms.TextBox();
            this.tbIN009 = new System.Windows.Forms.TextBox();
            this.tbIN013 = new System.Windows.Forms.TextBox();
            this.tbIN011 = new System.Windows.Forms.TextBox();
            this.tbIN015 = new System.Windows.Forms.TextBox();
            this.tbIN100 = new System.Windows.Forms.TextBox();
            this.tbIN108 = new System.Windows.Forms.TextBox();
            this.tbIN104 = new System.Windows.Forms.TextBox();
            this.tbIN112 = new System.Windows.Forms.TextBox();
            this.tbIN102 = new System.Windows.Forms.TextBox();
            this.tbIN110 = new System.Windows.Forms.TextBox();
            this.tbIN106 = new System.Windows.Forms.TextBox();
            this.tbIN114 = new System.Windows.Forms.TextBox();
            this.tbIN101 = new System.Windows.Forms.TextBox();
            this.tbIN109 = new System.Windows.Forms.TextBox();
            this.tbIN105 = new System.Windows.Forms.TextBox();
            this.tbIN113 = new System.Windows.Forms.TextBox();
            this.tbIN103 = new System.Windows.Forms.TextBox();
            this.tbIN111 = new System.Windows.Forms.TextBox();
            this.tbIN107 = new System.Windows.Forms.TextBox();
            this.tbIN115 = new System.Windows.Forms.TextBox();
            this.tbOUT000 = new System.Windows.Forms.TextBox();
            this.tbOUT008 = new System.Windows.Forms.TextBox();
            this.tbOUT004 = new System.Windows.Forms.TextBox();
            this.tbOUT012 = new System.Windows.Forms.TextBox();
            this.tbOUT002 = new System.Windows.Forms.TextBox();
            this.tbOUT010 = new System.Windows.Forms.TextBox();
            this.tbOUT006 = new System.Windows.Forms.TextBox();
            this.tbOUT014 = new System.Windows.Forms.TextBox();
            this.tbOUT001 = new System.Windows.Forms.TextBox();
            this.tbOUT009 = new System.Windows.Forms.TextBox();
            this.tbOUT005 = new System.Windows.Forms.TextBox();
            this.tbOUT013 = new System.Windows.Forms.TextBox();
            this.tbOUT003 = new System.Windows.Forms.TextBox();
            this.tbOUT011 = new System.Windows.Forms.TextBox();
            this.tbOUT007 = new System.Windows.Forms.TextBox();
            this.tbOUT015 = new System.Windows.Forms.TextBox();
            this.tbOUT100 = new System.Windows.Forms.TextBox();
            this.tbOUT108 = new System.Windows.Forms.TextBox();
            this.tbOUT104 = new System.Windows.Forms.TextBox();
            this.tbOUT112 = new System.Windows.Forms.TextBox();
            this.tbOUT102 = new System.Windows.Forms.TextBox();
            this.tbOUT110 = new System.Windows.Forms.TextBox();
            this.tbOUT106 = new System.Windows.Forms.TextBox();
            this.tbOUT114 = new System.Windows.Forms.TextBox();
            this.tbOUT101 = new System.Windows.Forms.TextBox();
            this.tbOUT109 = new System.Windows.Forms.TextBox();
            this.tbOUT105 = new System.Windows.Forms.TextBox();
            this.tbOUT113 = new System.Windows.Forms.TextBox();
            this.tbOUT103 = new System.Windows.Forms.TextBox();
            this.tbOUT111 = new System.Windows.Forms.TextBox();
            this.tbOUT107 = new System.Windows.Forms.TextBox();
            this.tbOUT115 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbIOMonitor
            // 
            this.lbIOMonitor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbIOMonitor.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbIOMonitor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIOMonitor.Location = new System.Drawing.Point(0, 0);
            this.lbIOMonitor.Name = "lbIOMonitor";
            this.lbIOMonitor.Size = new System.Drawing.Size(1000, 40);
            this.lbIOMonitor.TabIndex = 0;
            this.lbIOMonitor.Text = "I/O MONITOR";
            this.lbIOMonitor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIO_1
            // 
            this.lbIO_1.BackColor = System.Drawing.Color.DarkGray;
            this.lbIO_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIO_1.Location = new System.Drawing.Point(399, 51);
            this.lbIO_1.Name = "lbIO_1";
            this.lbIO_1.Size = new System.Drawing.Size(153, 41);
            this.lbIO_1.TabIndex = 1;
            this.lbIO_1.Text = "I/O000 - I/O115";
            this.lbIO_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(101, 136);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(0, 22);
            this.textBox1.TabIndex = 2;
            // 
            // btnIO_P2
            // 
            this.btnIO_P2.BackColor = System.Drawing.Color.LightGray;
            this.btnIO_P2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIO_P2.Location = new System.Drawing.Point(558, 51);
            this.btnIO_P2.Name = "btnIO_P2";
            this.btnIO_P2.Size = new System.Drawing.Size(80, 41);
            this.btnIO_P2.TabIndex = 4;
            this.btnIO_P2.Text = "=>";
            this.btnIO_P2.UseVisualStyleBackColor = false;
            this.btnIO_P2.Click += new System.EventHandler(this.btnIO_P2_Click);
            // 
            // lbIN000
            // 
            this.lbIN000.BackColor = System.Drawing.Color.LightGray;
            this.lbIN000.Location = new System.Drawing.Point(45, 136);
            this.lbIN000.Name = "lbIN000";
            this.lbIN000.Size = new System.Drawing.Size(50, 22);
            this.lbIN000.TabIndex = 5;
            this.lbIN000.Text = "I:000";
            this.lbIN000.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN001
            // 
            this.lbIN001.BackColor = System.Drawing.Color.LightGray;
            this.lbIN001.Location = new System.Drawing.Point(45, 164);
            this.lbIN001.Name = "lbIN001";
            this.lbIN001.Size = new System.Drawing.Size(50, 22);
            this.lbIN001.TabIndex = 7;
            this.lbIN001.Text = "I:001";
            this.lbIN001.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN003
            // 
            this.lbIN003.BackColor = System.Drawing.Color.LightGray;
            this.lbIN003.Location = new System.Drawing.Point(45, 220);
            this.lbIN003.Name = "lbIN003";
            this.lbIN003.Size = new System.Drawing.Size(50, 22);
            this.lbIN003.TabIndex = 11;
            this.lbIN003.Text = "I:003";
            this.lbIN003.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN002
            // 
            this.lbIN002.BackColor = System.Drawing.Color.LightGray;
            this.lbIN002.Location = new System.Drawing.Point(45, 192);
            this.lbIN002.Name = "lbIN002";
            this.lbIN002.Size = new System.Drawing.Size(50, 22);
            this.lbIN002.TabIndex = 9;
            this.lbIN002.Text = "I:002";
            this.lbIN002.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN007
            // 
            this.lbIN007.BackColor = System.Drawing.Color.LightGray;
            this.lbIN007.Location = new System.Drawing.Point(45, 332);
            this.lbIN007.Name = "lbIN007";
            this.lbIN007.Size = new System.Drawing.Size(50, 22);
            this.lbIN007.TabIndex = 19;
            this.lbIN007.Text = "I:007";
            this.lbIN007.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN006
            // 
            this.lbIN006.BackColor = System.Drawing.Color.LightGray;
            this.lbIN006.Location = new System.Drawing.Point(45, 304);
            this.lbIN006.Name = "lbIN006";
            this.lbIN006.Size = new System.Drawing.Size(50, 22);
            this.lbIN006.TabIndex = 17;
            this.lbIN006.Text = "I:006";
            this.lbIN006.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN005
            // 
            this.lbIN005.BackColor = System.Drawing.Color.LightGray;
            this.lbIN005.Location = new System.Drawing.Point(45, 276);
            this.lbIN005.Name = "lbIN005";
            this.lbIN005.Size = new System.Drawing.Size(50, 22);
            this.lbIN005.TabIndex = 15;
            this.lbIN005.Text = "I:005";
            this.lbIN005.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN004
            // 
            this.lbIN004.BackColor = System.Drawing.Color.LightGray;
            this.lbIN004.Location = new System.Drawing.Point(45, 248);
            this.lbIN004.Name = "lbIN004";
            this.lbIN004.Size = new System.Drawing.Size(50, 22);
            this.lbIN004.TabIndex = 13;
            this.lbIN004.Text = "I:004";
            this.lbIN004.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN015
            // 
            this.lbIN015.BackColor = System.Drawing.Color.LightGray;
            this.lbIN015.Location = new System.Drawing.Point(45, 556);
            this.lbIN015.Name = "lbIN015";
            this.lbIN015.Size = new System.Drawing.Size(50, 22);
            this.lbIN015.TabIndex = 35;
            this.lbIN015.Text = "I:015";
            this.lbIN015.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN014
            // 
            this.lbIN014.BackColor = System.Drawing.Color.LightGray;
            this.lbIN014.Location = new System.Drawing.Point(45, 528);
            this.lbIN014.Name = "lbIN014";
            this.lbIN014.Size = new System.Drawing.Size(50, 22);
            this.lbIN014.TabIndex = 33;
            this.lbIN014.Text = "I:014";
            this.lbIN014.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN013
            // 
            this.lbIN013.BackColor = System.Drawing.Color.LightGray;
            this.lbIN013.Location = new System.Drawing.Point(45, 500);
            this.lbIN013.Name = "lbIN013";
            this.lbIN013.Size = new System.Drawing.Size(50, 22);
            this.lbIN013.TabIndex = 31;
            this.lbIN013.Text = "I:013";
            this.lbIN013.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN012
            // 
            this.lbIN012.BackColor = System.Drawing.Color.LightGray;
            this.lbIN012.Location = new System.Drawing.Point(45, 472);
            this.lbIN012.Name = "lbIN012";
            this.lbIN012.Size = new System.Drawing.Size(50, 22);
            this.lbIN012.TabIndex = 29;
            this.lbIN012.Text = "I:012";
            this.lbIN012.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN011
            // 
            this.lbIN011.BackColor = System.Drawing.Color.LightGray;
            this.lbIN011.Location = new System.Drawing.Point(45, 444);
            this.lbIN011.Name = "lbIN011";
            this.lbIN011.Size = new System.Drawing.Size(50, 22);
            this.lbIN011.TabIndex = 27;
            this.lbIN011.Text = "I:011";
            this.lbIN011.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN010
            // 
            this.lbIN010.BackColor = System.Drawing.Color.LightGray;
            this.lbIN010.Location = new System.Drawing.Point(45, 416);
            this.lbIN010.Name = "lbIN010";
            this.lbIN010.Size = new System.Drawing.Size(50, 22);
            this.lbIN010.TabIndex = 25;
            this.lbIN010.Text = "I:010";
            this.lbIN010.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN009
            // 
            this.lbIN009.BackColor = System.Drawing.Color.LightGray;
            this.lbIN009.Location = new System.Drawing.Point(45, 388);
            this.lbIN009.Name = "lbIN009";
            this.lbIN009.Size = new System.Drawing.Size(50, 22);
            this.lbIN009.TabIndex = 23;
            this.lbIN009.Text = "I:009";
            this.lbIN009.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN008
            // 
            this.lbIN008.BackColor = System.Drawing.Color.LightGray;
            this.lbIN008.Location = new System.Drawing.Point(45, 360);
            this.lbIN008.Name = "lbIN008";
            this.lbIN008.Size = new System.Drawing.Size(50, 22);
            this.lbIN008.TabIndex = 21;
            this.lbIN008.Text = "I:008";
            this.lbIN008.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN115
            // 
            this.lbIN115.BackColor = System.Drawing.Color.LightGray;
            this.lbIN115.Location = new System.Drawing.Point(279, 556);
            this.lbIN115.Name = "lbIN115";
            this.lbIN115.Size = new System.Drawing.Size(50, 22);
            this.lbIN115.TabIndex = 67;
            this.lbIN115.Text = "I:115";
            this.lbIN115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN114
            // 
            this.lbIN114.BackColor = System.Drawing.Color.LightGray;
            this.lbIN114.Location = new System.Drawing.Point(279, 528);
            this.lbIN114.Name = "lbIN114";
            this.lbIN114.Size = new System.Drawing.Size(50, 22);
            this.lbIN114.TabIndex = 65;
            this.lbIN114.Text = "I:114";
            this.lbIN114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN113
            // 
            this.lbIN113.BackColor = System.Drawing.Color.LightGray;
            this.lbIN113.Location = new System.Drawing.Point(279, 500);
            this.lbIN113.Name = "lbIN113";
            this.lbIN113.Size = new System.Drawing.Size(50, 22);
            this.lbIN113.TabIndex = 63;
            this.lbIN113.Text = "I:113";
            this.lbIN113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN112
            // 
            this.lbIN112.BackColor = System.Drawing.Color.LightGray;
            this.lbIN112.Location = new System.Drawing.Point(279, 472);
            this.lbIN112.Name = "lbIN112";
            this.lbIN112.Size = new System.Drawing.Size(50, 22);
            this.lbIN112.TabIndex = 61;
            this.lbIN112.Text = "I:112";
            this.lbIN112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN111
            // 
            this.lbIN111.BackColor = System.Drawing.Color.LightGray;
            this.lbIN111.Location = new System.Drawing.Point(279, 444);
            this.lbIN111.Name = "lbIN111";
            this.lbIN111.Size = new System.Drawing.Size(50, 22);
            this.lbIN111.TabIndex = 59;
            this.lbIN111.Text = "I:111";
            this.lbIN111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN110
            // 
            this.lbIN110.BackColor = System.Drawing.Color.LightGray;
            this.lbIN110.Location = new System.Drawing.Point(279, 416);
            this.lbIN110.Name = "lbIN110";
            this.lbIN110.Size = new System.Drawing.Size(50, 22);
            this.lbIN110.TabIndex = 57;
            this.lbIN110.Text = "I:110";
            this.lbIN110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN109
            // 
            this.lbIN109.BackColor = System.Drawing.Color.LightGray;
            this.lbIN109.Location = new System.Drawing.Point(279, 388);
            this.lbIN109.Name = "lbIN109";
            this.lbIN109.Size = new System.Drawing.Size(50, 22);
            this.lbIN109.TabIndex = 55;
            this.lbIN109.Text = "I:109";
            this.lbIN109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN108
            // 
            this.lbIN108.BackColor = System.Drawing.Color.LightGray;
            this.lbIN108.Location = new System.Drawing.Point(279, 360);
            this.lbIN108.Name = "lbIN108";
            this.lbIN108.Size = new System.Drawing.Size(50, 22);
            this.lbIN108.TabIndex = 53;
            this.lbIN108.Text = "I:108";
            this.lbIN108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN107
            // 
            this.lbIN107.BackColor = System.Drawing.Color.LightGray;
            this.lbIN107.Location = new System.Drawing.Point(279, 332);
            this.lbIN107.Name = "lbIN107";
            this.lbIN107.Size = new System.Drawing.Size(50, 22);
            this.lbIN107.TabIndex = 51;
            this.lbIN107.Text = "I:107";
            this.lbIN107.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN106
            // 
            this.lbIN106.BackColor = System.Drawing.Color.LightGray;
            this.lbIN106.Location = new System.Drawing.Point(279, 304);
            this.lbIN106.Name = "lbIN106";
            this.lbIN106.Size = new System.Drawing.Size(50, 22);
            this.lbIN106.TabIndex = 49;
            this.lbIN106.Text = "I:106";
            this.lbIN106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN105
            // 
            this.lbIN105.BackColor = System.Drawing.Color.LightGray;
            this.lbIN105.Location = new System.Drawing.Point(279, 276);
            this.lbIN105.Name = "lbIN105";
            this.lbIN105.Size = new System.Drawing.Size(50, 22);
            this.lbIN105.TabIndex = 47;
            this.lbIN105.Text = "I:105";
            this.lbIN105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN104
            // 
            this.lbIN104.BackColor = System.Drawing.Color.LightGray;
            this.lbIN104.Location = new System.Drawing.Point(279, 248);
            this.lbIN104.Name = "lbIN104";
            this.lbIN104.Size = new System.Drawing.Size(50, 22);
            this.lbIN104.TabIndex = 45;
            this.lbIN104.Text = "I:104";
            this.lbIN104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN103
            // 
            this.lbIN103.BackColor = System.Drawing.Color.LightGray;
            this.lbIN103.Location = new System.Drawing.Point(279, 220);
            this.lbIN103.Name = "lbIN103";
            this.lbIN103.Size = new System.Drawing.Size(50, 22);
            this.lbIN103.TabIndex = 43;
            this.lbIN103.Text = "I:103";
            this.lbIN103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN102
            // 
            this.lbIN102.BackColor = System.Drawing.Color.LightGray;
            this.lbIN102.Location = new System.Drawing.Point(279, 192);
            this.lbIN102.Name = "lbIN102";
            this.lbIN102.Size = new System.Drawing.Size(50, 22);
            this.lbIN102.TabIndex = 41;
            this.lbIN102.Text = "I:102";
            this.lbIN102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN101
            // 
            this.lbIN101.BackColor = System.Drawing.Color.LightGray;
            this.lbIN101.Location = new System.Drawing.Point(279, 164);
            this.lbIN101.Name = "lbIN101";
            this.lbIN101.Size = new System.Drawing.Size(50, 22);
            this.lbIN101.TabIndex = 39;
            this.lbIN101.Text = "I:101";
            this.lbIN101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbIN100
            // 
            this.lbIN100.BackColor = System.Drawing.Color.LightGray;
            this.lbIN100.Location = new System.Drawing.Point(279, 136);
            this.lbIN100.Name = "lbIN100";
            this.lbIN100.Size = new System.Drawing.Size(50, 22);
            this.lbIN100.TabIndex = 37;
            this.lbIN100.Text = "I:100";
            this.lbIN100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT115
            // 
            this.lbOUT115.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT115.Location = new System.Drawing.Point(751, 556);
            this.lbOUT115.Name = "lbOUT115";
            this.lbOUT115.Size = new System.Drawing.Size(50, 22);
            this.lbOUT115.TabIndex = 131;
            this.lbOUT115.Text = "O:115";
            this.lbOUT115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT114
            // 
            this.lbOUT114.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT114.Location = new System.Drawing.Point(751, 528);
            this.lbOUT114.Name = "lbOUT114";
            this.lbOUT114.Size = new System.Drawing.Size(50, 22);
            this.lbOUT114.TabIndex = 129;
            this.lbOUT114.Text = "O:114";
            this.lbOUT114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT113
            // 
            this.lbOUT113.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT113.Location = new System.Drawing.Point(751, 500);
            this.lbOUT113.Name = "lbOUT113";
            this.lbOUT113.Size = new System.Drawing.Size(50, 22);
            this.lbOUT113.TabIndex = 127;
            this.lbOUT113.Text = "O:113";
            this.lbOUT113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT112
            // 
            this.lbOUT112.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT112.Location = new System.Drawing.Point(751, 472);
            this.lbOUT112.Name = "lbOUT112";
            this.lbOUT112.Size = new System.Drawing.Size(50, 22);
            this.lbOUT112.TabIndex = 125;
            this.lbOUT112.Text = "O:112";
            this.lbOUT112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT111
            // 
            this.lbOUT111.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT111.Location = new System.Drawing.Point(751, 444);
            this.lbOUT111.Name = "lbOUT111";
            this.lbOUT111.Size = new System.Drawing.Size(50, 22);
            this.lbOUT111.TabIndex = 123;
            this.lbOUT111.Text = "O:111";
            this.lbOUT111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT110
            // 
            this.lbOUT110.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT110.Location = new System.Drawing.Point(751, 416);
            this.lbOUT110.Name = "lbOUT110";
            this.lbOUT110.Size = new System.Drawing.Size(50, 22);
            this.lbOUT110.TabIndex = 121;
            this.lbOUT110.Text = "O:110";
            this.lbOUT110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT109
            // 
            this.lbOUT109.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT109.Location = new System.Drawing.Point(751, 388);
            this.lbOUT109.Name = "lbOUT109";
            this.lbOUT109.Size = new System.Drawing.Size(50, 22);
            this.lbOUT109.TabIndex = 119;
            this.lbOUT109.Text = "O:109";
            this.lbOUT109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT108
            // 
            this.lbOUT108.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT108.Location = new System.Drawing.Point(751, 360);
            this.lbOUT108.Name = "lbOUT108";
            this.lbOUT108.Size = new System.Drawing.Size(50, 22);
            this.lbOUT108.TabIndex = 117;
            this.lbOUT108.Text = "O:108";
            this.lbOUT108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT107
            // 
            this.lbOUT107.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT107.Location = new System.Drawing.Point(751, 332);
            this.lbOUT107.Name = "lbOUT107";
            this.lbOUT107.Size = new System.Drawing.Size(50, 22);
            this.lbOUT107.TabIndex = 115;
            this.lbOUT107.Text = "O:107";
            this.lbOUT107.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT106
            // 
            this.lbOUT106.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT106.Location = new System.Drawing.Point(751, 304);
            this.lbOUT106.Name = "lbOUT106";
            this.lbOUT106.Size = new System.Drawing.Size(50, 22);
            this.lbOUT106.TabIndex = 113;
            this.lbOUT106.Text = "O:106";
            this.lbOUT106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT105
            // 
            this.lbOUT105.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT105.Location = new System.Drawing.Point(751, 276);
            this.lbOUT105.Name = "lbOUT105";
            this.lbOUT105.Size = new System.Drawing.Size(50, 22);
            this.lbOUT105.TabIndex = 111;
            this.lbOUT105.Text = "O:105";
            this.lbOUT105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT104
            // 
            this.lbOUT104.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT104.Location = new System.Drawing.Point(751, 248);
            this.lbOUT104.Name = "lbOUT104";
            this.lbOUT104.Size = new System.Drawing.Size(50, 22);
            this.lbOUT104.TabIndex = 109;
            this.lbOUT104.Text = "O:104";
            this.lbOUT104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT103
            // 
            this.lbOUT103.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT103.Location = new System.Drawing.Point(751, 220);
            this.lbOUT103.Name = "lbOUT103";
            this.lbOUT103.Size = new System.Drawing.Size(50, 22);
            this.lbOUT103.TabIndex = 107;
            this.lbOUT103.Text = "O:103";
            this.lbOUT103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT102
            // 
            this.lbOUT102.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT102.Location = new System.Drawing.Point(751, 192);
            this.lbOUT102.Name = "lbOUT102";
            this.lbOUT102.Size = new System.Drawing.Size(50, 22);
            this.lbOUT102.TabIndex = 105;
            this.lbOUT102.Text = "O:102";
            this.lbOUT102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT101
            // 
            this.lbOUT101.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT101.Location = new System.Drawing.Point(751, 164);
            this.lbOUT101.Name = "lbOUT101";
            this.lbOUT101.Size = new System.Drawing.Size(50, 22);
            this.lbOUT101.TabIndex = 103;
            this.lbOUT101.Text = "O:101";
            this.lbOUT101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT100
            // 
            this.lbOUT100.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT100.Location = new System.Drawing.Point(751, 136);
            this.lbOUT100.Name = "lbOUT100";
            this.lbOUT100.Size = new System.Drawing.Size(50, 22);
            this.lbOUT100.TabIndex = 101;
            this.lbOUT100.Text = "O:100";
            this.lbOUT100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT015
            // 
            this.lbOUT015.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT015.Location = new System.Drawing.Point(517, 556);
            this.lbOUT015.Name = "lbOUT015";
            this.lbOUT015.Size = new System.Drawing.Size(50, 22);
            this.lbOUT015.TabIndex = 99;
            this.lbOUT015.Text = "O:015";
            this.lbOUT015.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT014
            // 
            this.lbOUT014.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT014.Location = new System.Drawing.Point(517, 528);
            this.lbOUT014.Name = "lbOUT014";
            this.lbOUT014.Size = new System.Drawing.Size(50, 22);
            this.lbOUT014.TabIndex = 97;
            this.lbOUT014.Text = "O:014";
            this.lbOUT014.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT013
            // 
            this.lbOUT013.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT013.Location = new System.Drawing.Point(517, 500);
            this.lbOUT013.Name = "lbOUT013";
            this.lbOUT013.Size = new System.Drawing.Size(50, 22);
            this.lbOUT013.TabIndex = 95;
            this.lbOUT013.Text = "O:013";
            this.lbOUT013.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT012
            // 
            this.lbOUT012.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT012.Location = new System.Drawing.Point(517, 472);
            this.lbOUT012.Name = "lbOUT012";
            this.lbOUT012.Size = new System.Drawing.Size(50, 22);
            this.lbOUT012.TabIndex = 93;
            this.lbOUT012.Text = "O:012";
            this.lbOUT012.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT011
            // 
            this.lbOUT011.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT011.Location = new System.Drawing.Point(517, 444);
            this.lbOUT011.Name = "lbOUT011";
            this.lbOUT011.Size = new System.Drawing.Size(50, 22);
            this.lbOUT011.TabIndex = 91;
            this.lbOUT011.Text = "O:011";
            this.lbOUT011.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT010
            // 
            this.lbOUT010.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT010.Location = new System.Drawing.Point(517, 416);
            this.lbOUT010.Name = "lbOUT010";
            this.lbOUT010.Size = new System.Drawing.Size(50, 22);
            this.lbOUT010.TabIndex = 89;
            this.lbOUT010.Text = "O:010";
            this.lbOUT010.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT009
            // 
            this.lbOUT009.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT009.Location = new System.Drawing.Point(517, 388);
            this.lbOUT009.Name = "lbOUT009";
            this.lbOUT009.Size = new System.Drawing.Size(50, 22);
            this.lbOUT009.TabIndex = 87;
            this.lbOUT009.Text = "O:009";
            this.lbOUT009.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT008
            // 
            this.lbOUT008.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT008.Location = new System.Drawing.Point(517, 360);
            this.lbOUT008.Name = "lbOUT008";
            this.lbOUT008.Size = new System.Drawing.Size(50, 22);
            this.lbOUT008.TabIndex = 85;
            this.lbOUT008.Text = "O:008";
            this.lbOUT008.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT007
            // 
            this.lbOUT007.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT007.Location = new System.Drawing.Point(517, 332);
            this.lbOUT007.Name = "lbOUT007";
            this.lbOUT007.Size = new System.Drawing.Size(50, 22);
            this.lbOUT007.TabIndex = 83;
            this.lbOUT007.Text = "O:007";
            this.lbOUT007.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT006
            // 
            this.lbOUT006.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT006.Location = new System.Drawing.Point(517, 304);
            this.lbOUT006.Name = "lbOUT006";
            this.lbOUT006.Size = new System.Drawing.Size(50, 22);
            this.lbOUT006.TabIndex = 81;
            this.lbOUT006.Text = "O:006";
            this.lbOUT006.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT005
            // 
            this.lbOUT005.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT005.Location = new System.Drawing.Point(517, 276);
            this.lbOUT005.Name = "lbOUT005";
            this.lbOUT005.Size = new System.Drawing.Size(50, 22);
            this.lbOUT005.TabIndex = 79;
            this.lbOUT005.Text = "O:005";
            this.lbOUT005.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT004
            // 
            this.lbOUT004.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT004.Location = new System.Drawing.Point(517, 248);
            this.lbOUT004.Name = "lbOUT004";
            this.lbOUT004.Size = new System.Drawing.Size(50, 22);
            this.lbOUT004.TabIndex = 77;
            this.lbOUT004.Text = "O:004";
            this.lbOUT004.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT003
            // 
            this.lbOUT003.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT003.Location = new System.Drawing.Point(517, 220);
            this.lbOUT003.Name = "lbOUT003";
            this.lbOUT003.Size = new System.Drawing.Size(50, 22);
            this.lbOUT003.TabIndex = 75;
            this.lbOUT003.Text = "O:003";
            this.lbOUT003.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT002
            // 
            this.lbOUT002.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT002.Location = new System.Drawing.Point(517, 192);
            this.lbOUT002.Name = "lbOUT002";
            this.lbOUT002.Size = new System.Drawing.Size(50, 22);
            this.lbOUT002.TabIndex = 73;
            this.lbOUT002.Text = "O:002";
            this.lbOUT002.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT001
            // 
            this.lbOUT001.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT001.Location = new System.Drawing.Point(517, 164);
            this.lbOUT001.Name = "lbOUT001";
            this.lbOUT001.Size = new System.Drawing.Size(50, 22);
            this.lbOUT001.TabIndex = 71;
            this.lbOUT001.Text = "O:001";
            this.lbOUT001.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbOUT000
            // 
            this.lbOUT000.BackColor = System.Drawing.Color.LightGray;
            this.lbOUT000.Location = new System.Drawing.Point(517, 136);
            this.lbOUT000.Name = "lbOUT000";
            this.lbOUT000.Size = new System.Drawing.Size(50, 22);
            this.lbOUT000.TabIndex = 69;
            this.lbOUT000.Text = "O:000";
            this.lbOUT000.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbIN_1
            // 
            this.tbIN_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN_1.Location = new System.Drawing.Point(193, 108);
            this.tbIN_1.Name = "tbIN_1";
            this.tbIN_1.ReadOnly = true;
            this.tbIN_1.Size = new System.Drawing.Size(150, 22);
            this.tbIN_1.TabIndex = 132;
            this.tbIN_1.Text = "INPUT";
            this.tbIN_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbOUT_1
            // 
            this.tbOUT_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT_1.Location = new System.Drawing.Point(665, 108);
            this.tbOUT_1.Name = "tbOUT_1";
            this.tbOUT_1.ReadOnly = true;
            this.tbOUT_1.Size = new System.Drawing.Size(150, 22);
            this.tbOUT_1.TabIndex = 133;
            this.tbOUT_1.Text = "OUTPUT";
            this.tbOUT_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIN000
            // 
            this.tbIN000.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN000.Location = new System.Drawing.Point(101, 136);
            this.tbIN000.Name = "tbIN000";
            this.tbIN000.ReadOnly = true;
            this.tbIN000.Size = new System.Drawing.Size(150, 21);
            this.tbIN000.TabIndex = 134;
            this.tbIN000.Text = "Front Area Sensor";
            // 
            // tbIN001
            // 
            this.tbIN001.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN001.Location = new System.Drawing.Point(101, 164);
            this.tbIN001.Name = "tbIN001";
            this.tbIN001.ReadOnly = true;
            this.tbIN001.Size = new System.Drawing.Size(150, 21);
            this.tbIN001.TabIndex = 134;
            // 
            // tbIN002
            // 
            this.tbIN002.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN002.Location = new System.Drawing.Point(101, 192);
            this.tbIN002.Name = "tbIN002";
            this.tbIN002.ReadOnly = true;
            this.tbIN002.Size = new System.Drawing.Size(150, 21);
            this.tbIN002.TabIndex = 134;
            // 
            // tbIN003
            // 
            this.tbIN003.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN003.Location = new System.Drawing.Point(101, 220);
            this.tbIN003.Name = "tbIN003";
            this.tbIN003.ReadOnly = true;
            this.tbIN003.Size = new System.Drawing.Size(150, 21);
            this.tbIN003.TabIndex = 134;
            this.tbIN003.Text = "Rear Area Sensor";
            // 
            // tbIN004
            // 
            this.tbIN004.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN004.Location = new System.Drawing.Point(101, 248);
            this.tbIN004.Name = "tbIN004";
            this.tbIN004.ReadOnly = true;
            this.tbIN004.Size = new System.Drawing.Size(150, 21);
            this.tbIN004.TabIndex = 134;
            // 
            // tbIN006
            // 
            this.tbIN006.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN006.Location = new System.Drawing.Point(101, 304);
            this.tbIN006.Name = "tbIN006";
            this.tbIN006.ReadOnly = true;
            this.tbIN006.Size = new System.Drawing.Size(150, 21);
            this.tbIN006.TabIndex = 134;
            // 
            // tbIN005
            // 
            this.tbIN005.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN005.Location = new System.Drawing.Point(101, 276);
            this.tbIN005.Name = "tbIN005";
            this.tbIN005.ReadOnly = true;
            this.tbIN005.Size = new System.Drawing.Size(150, 21);
            this.tbIN005.TabIndex = 134;
            // 
            // tbIN007
            // 
            this.tbIN007.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN007.Location = new System.Drawing.Point(101, 332);
            this.tbIN007.Name = "tbIN007";
            this.tbIN007.ReadOnly = true;
            this.tbIN007.Size = new System.Drawing.Size(150, 21);
            this.tbIN007.TabIndex = 134;
            // 
            // tbIN008
            // 
            this.tbIN008.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN008.Location = new System.Drawing.Point(101, 360);
            this.tbIN008.Name = "tbIN008";
            this.tbIN008.ReadOnly = true;
            this.tbIN008.Size = new System.Drawing.Size(150, 21);
            this.tbIN008.TabIndex = 134;
            // 
            // tbIN012
            // 
            this.tbIN012.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN012.Location = new System.Drawing.Point(101, 472);
            this.tbIN012.Name = "tbIN012";
            this.tbIN012.ReadOnly = true;
            this.tbIN012.Size = new System.Drawing.Size(150, 21);
            this.tbIN012.TabIndex = 134;
            // 
            // tbIN010
            // 
            this.tbIN010.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN010.Location = new System.Drawing.Point(101, 416);
            this.tbIN010.Name = "tbIN010";
            this.tbIN010.ReadOnly = true;
            this.tbIN010.Size = new System.Drawing.Size(150, 21);
            this.tbIN010.TabIndex = 134;
            // 
            // tbIN014
            // 
            this.tbIN014.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN014.Location = new System.Drawing.Point(101, 528);
            this.tbIN014.Name = "tbIN014";
            this.tbIN014.ReadOnly = true;
            this.tbIN014.Size = new System.Drawing.Size(150, 21);
            this.tbIN014.TabIndex = 134;
            this.tbIN014.Text = "Start Button";
            // 
            // tbIN009
            // 
            this.tbIN009.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN009.Location = new System.Drawing.Point(101, 388);
            this.tbIN009.Name = "tbIN009";
            this.tbIN009.ReadOnly = true;
            this.tbIN009.Size = new System.Drawing.Size(150, 21);
            this.tbIN009.TabIndex = 134;
            // 
            // tbIN013
            // 
            this.tbIN013.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN013.Location = new System.Drawing.Point(101, 500);
            this.tbIN013.Name = "tbIN013";
            this.tbIN013.ReadOnly = true;
            this.tbIN013.Size = new System.Drawing.Size(150, 21);
            this.tbIN013.TabIndex = 134;
            this.tbIN013.Text = "Air pressure sensor";
            // 
            // tbIN011
            // 
            this.tbIN011.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN011.Location = new System.Drawing.Point(101, 444);
            this.tbIN011.Name = "tbIN011";
            this.tbIN011.ReadOnly = true;
            this.tbIN011.Size = new System.Drawing.Size(150, 21);
            this.tbIN011.TabIndex = 134;
            // 
            // tbIN015
            // 
            this.tbIN015.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN015.Location = new System.Drawing.Point(101, 556);
            this.tbIN015.Name = "tbIN015";
            this.tbIN015.ReadOnly = true;
            this.tbIN015.Size = new System.Drawing.Size(150, 21);
            this.tbIN015.TabIndex = 134;
            this.tbIN015.Text = "Pause Button";
            // 
            // tbIN100
            // 
            this.tbIN100.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN100.Location = new System.Drawing.Point(335, 136);
            this.tbIN100.Name = "tbIN100";
            this.tbIN100.ReadOnly = true;
            this.tbIN100.Size = new System.Drawing.Size(150, 21);
            this.tbIN100.TabIndex = 134;
            this.tbIN100.Text = "Upper Stopper IN 1";
            // 
            // tbIN108
            // 
            this.tbIN108.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN108.Location = new System.Drawing.Point(335, 360);
            this.tbIN108.Name = "tbIN108";
            this.tbIN108.ReadOnly = true;
            this.tbIN108.Size = new System.Drawing.Size(150, 21);
            this.tbIN108.TabIndex = 134;
            this.tbIN108.Text = "Under Stopper OUT 1";
            // 
            // tbIN104
            // 
            this.tbIN104.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN104.Location = new System.Drawing.Point(335, 248);
            this.tbIN104.Name = "tbIN104";
            this.tbIN104.ReadOnly = true;
            this.tbIN104.Size = new System.Drawing.Size(150, 21);
            this.tbIN104.TabIndex = 134;
            this.tbIN104.Text = "Upper SEN Chk Part L";
            // 
            // tbIN112
            // 
            this.tbIN112.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN112.Location = new System.Drawing.Point(335, 472);
            this.tbIN112.Name = "tbIN112";
            this.tbIN112.ReadOnly = true;
            this.tbIN112.Size = new System.Drawing.Size(150, 21);
            this.tbIN112.TabIndex = 134;
            this.tbIN112.Text = "Under SEN Chk Part M";
            // 
            // tbIN102
            // 
            this.tbIN102.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN102.Location = new System.Drawing.Point(335, 192);
            this.tbIN102.Name = "tbIN102";
            this.tbIN102.ReadOnly = true;
            this.tbIN102.Size = new System.Drawing.Size(150, 21);
            this.tbIN102.TabIndex = 134;
            this.tbIN102.Text = "Upper Stopper IN 2";
            // 
            // tbIN110
            // 
            this.tbIN110.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN110.Location = new System.Drawing.Point(335, 416);
            this.tbIN110.Name = "tbIN110";
            this.tbIN110.ReadOnly = true;
            this.tbIN110.Size = new System.Drawing.Size(150, 21);
            this.tbIN110.TabIndex = 134;
            this.tbIN110.Text = "Under Stopper OUT 2";
            // 
            // tbIN106
            // 
            this.tbIN106.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN106.Location = new System.Drawing.Point(335, 304);
            this.tbIN106.Name = "tbIN106";
            this.tbIN106.ReadOnly = true;
            this.tbIN106.Size = new System.Drawing.Size(150, 21);
            this.tbIN106.TabIndex = 134;
            this.tbIN106.Text = "Upper SEN Chk Part R";
            // 
            // tbIN114
            // 
            this.tbIN114.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN114.Location = new System.Drawing.Point(335, 528);
            this.tbIN114.Name = "tbIN114";
            this.tbIN114.ReadOnly = true;
            this.tbIN114.Size = new System.Drawing.Size(150, 21);
            this.tbIN114.TabIndex = 134;
            this.tbIN114.Text = "Part un-Lock";
            // 
            // tbIN101
            // 
            this.tbIN101.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN101.Location = new System.Drawing.Point(335, 164);
            this.tbIN101.Name = "tbIN101";
            this.tbIN101.ReadOnly = true;
            this.tbIN101.Size = new System.Drawing.Size(150, 21);
            this.tbIN101.TabIndex = 134;
            this.tbIN101.Text = "Upper Stopper OUT 1";
            // 
            // tbIN109
            // 
            this.tbIN109.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN109.Location = new System.Drawing.Point(335, 388);
            this.tbIN109.Name = "tbIN109";
            this.tbIN109.ReadOnly = true;
            this.tbIN109.Size = new System.Drawing.Size(150, 21);
            this.tbIN109.TabIndex = 134;
            this.tbIN109.Text = "Under Stopper IN 2";
            // 
            // tbIN105
            // 
            this.tbIN105.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN105.Location = new System.Drawing.Point(335, 276);
            this.tbIN105.Name = "tbIN105";
            this.tbIN105.ReadOnly = true;
            this.tbIN105.Size = new System.Drawing.Size(150, 21);
            this.tbIN105.TabIndex = 134;
            this.tbIN105.Text = "Upper SEN Chk Part M";
            // 
            // tbIN113
            // 
            this.tbIN113.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN113.Location = new System.Drawing.Point(335, 500);
            this.tbIN113.Name = "tbIN113";
            this.tbIN113.ReadOnly = true;
            this.tbIN113.Size = new System.Drawing.Size(150, 21);
            this.tbIN113.TabIndex = 134;
            this.tbIN113.Text = "Under SEN Chk Part L";
            // 
            // tbIN103
            // 
            this.tbIN103.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN103.Location = new System.Drawing.Point(335, 220);
            this.tbIN103.Name = "tbIN103";
            this.tbIN103.ReadOnly = true;
            this.tbIN103.Size = new System.Drawing.Size(150, 21);
            this.tbIN103.TabIndex = 134;
            this.tbIN103.Text = "Upper Stopper OUT 2";
            // 
            // tbIN111
            // 
            this.tbIN111.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN111.Location = new System.Drawing.Point(335, 444);
            this.tbIN111.Name = "tbIN111";
            this.tbIN111.ReadOnly = true;
            this.tbIN111.Size = new System.Drawing.Size(150, 21);
            this.tbIN111.TabIndex = 134;
            this.tbIN111.Text = "Under SEN Chk Part R";
            // 
            // tbIN107
            // 
            this.tbIN107.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN107.Location = new System.Drawing.Point(335, 332);
            this.tbIN107.Name = "tbIN107";
            this.tbIN107.ReadOnly = true;
            this.tbIN107.Size = new System.Drawing.Size(150, 21);
            this.tbIN107.TabIndex = 134;
            this.tbIN107.Text = "Under Stopper IN 1";
            // 
            // tbIN115
            // 
            this.tbIN115.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIN115.Location = new System.Drawing.Point(335, 556);
            this.tbIN115.Name = "tbIN115";
            this.tbIN115.ReadOnly = true;
            this.tbIN115.Size = new System.Drawing.Size(150, 21);
            this.tbIN115.TabIndex = 134;
            this.tbIN115.Text = "Part Lock";
            // 
            // tbOUT000
            // 
            this.tbOUT000.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT000.Location = new System.Drawing.Point(573, 136);
            this.tbOUT000.Name = "tbOUT000";
            this.tbOUT000.ReadOnly = true;
            this.tbOUT000.Size = new System.Drawing.Size(150, 21);
            this.tbOUT000.TabIndex = 134;
            // 
            // tbOUT008
            // 
            this.tbOUT008.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT008.Location = new System.Drawing.Point(573, 360);
            this.tbOUT008.Name = "tbOUT008";
            this.tbOUT008.ReadOnly = true;
            this.tbOUT008.Size = new System.Drawing.Size(150, 21);
            this.tbOUT008.TabIndex = 134;
            // 
            // tbOUT004
            // 
            this.tbOUT004.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT004.Location = new System.Drawing.Point(573, 248);
            this.tbOUT004.Name = "tbOUT004";
            this.tbOUT004.ReadOnly = true;
            this.tbOUT004.Size = new System.Drawing.Size(150, 21);
            this.tbOUT004.TabIndex = 134;
            this.tbOUT004.Text = "Glue Dispensing tools 1";
            // 
            // tbOUT012
            // 
            this.tbOUT012.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT012.Location = new System.Drawing.Point(573, 472);
            this.tbOUT012.Name = "tbOUT012";
            this.tbOUT012.ReadOnly = true;
            this.tbOUT012.Size = new System.Drawing.Size(150, 21);
            this.tbOUT012.TabIndex = 134;
            this.tbOUT012.Text = "Tower light - Green";
            // 
            // tbOUT002
            // 
            this.tbOUT002.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT002.Location = new System.Drawing.Point(573, 192);
            this.tbOUT002.Name = "tbOUT002";
            this.tbOUT002.ReadOnly = true;
            this.tbOUT002.Size = new System.Drawing.Size(150, 21);
            this.tbOUT002.TabIndex = 134;
            // 
            // tbOUT010
            // 
            this.tbOUT010.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT010.Location = new System.Drawing.Point(573, 416);
            this.tbOUT010.Name = "tbOUT010";
            this.tbOUT010.ReadOnly = true;
            this.tbOUT010.Size = new System.Drawing.Size(150, 21);
            this.tbOUT010.TabIndex = 134;
            this.tbOUT010.Text = "Tower light - Red";
            // 
            // tbOUT006
            // 
            this.tbOUT006.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT006.Location = new System.Drawing.Point(573, 304);
            this.tbOUT006.Name = "tbOUT006";
            this.tbOUT006.ReadOnly = true;
            this.tbOUT006.Size = new System.Drawing.Size(150, 21);
            this.tbOUT006.TabIndex = 134;
            // 
            // tbOUT014
            // 
            this.tbOUT014.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT014.Location = new System.Drawing.Point(573, 528);
            this.tbOUT014.Name = "tbOUT014";
            this.tbOUT014.ReadOnly = true;
            this.tbOUT014.Size = new System.Drawing.Size(150, 21);
            this.tbOUT014.TabIndex = 134;
            this.tbOUT014.Text = "Start Button light";
            // 
            // tbOUT001
            // 
            this.tbOUT001.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT001.Location = new System.Drawing.Point(573, 164);
            this.tbOUT001.Name = "tbOUT001";
            this.tbOUT001.ReadOnly = true;
            this.tbOUT001.Size = new System.Drawing.Size(150, 21);
            this.tbOUT001.TabIndex = 134;
            // 
            // tbOUT009
            // 
            this.tbOUT009.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT009.Location = new System.Drawing.Point(573, 388);
            this.tbOUT009.Name = "tbOUT009";
            this.tbOUT009.ReadOnly = true;
            this.tbOUT009.Size = new System.Drawing.Size(150, 21);
            this.tbOUT009.TabIndex = 134;
            // 
            // tbOUT005
            // 
            this.tbOUT005.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT005.Location = new System.Drawing.Point(573, 276);
            this.tbOUT005.Name = "tbOUT005";
            this.tbOUT005.ReadOnly = true;
            this.tbOUT005.Size = new System.Drawing.Size(150, 21);
            this.tbOUT005.TabIndex = 134;
            this.tbOUT005.Text = "Glue Dispensing tools 2";
            // 
            // tbOUT013
            // 
            this.tbOUT013.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT013.Location = new System.Drawing.Point(573, 500);
            this.tbOUT013.Name = "tbOUT013";
            this.tbOUT013.ReadOnly = true;
            this.tbOUT013.Size = new System.Drawing.Size(150, 21);
            this.tbOUT013.TabIndex = 134;
            this.tbOUT013.Text = "Tower light - Buzzer";
            // 
            // tbOUT003
            // 
            this.tbOUT003.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT003.Location = new System.Drawing.Point(573, 220);
            this.tbOUT003.Name = "tbOUT003";
            this.tbOUT003.ReadOnly = true;
            this.tbOUT003.Size = new System.Drawing.Size(150, 21);
            this.tbOUT003.TabIndex = 134;
            // 
            // tbOUT011
            // 
            this.tbOUT011.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT011.Location = new System.Drawing.Point(573, 444);
            this.tbOUT011.Name = "tbOUT011";
            this.tbOUT011.ReadOnly = true;
            this.tbOUT011.Size = new System.Drawing.Size(150, 21);
            this.tbOUT011.TabIndex = 134;
            this.tbOUT011.Text = "Tower light - Yellow";
            // 
            // tbOUT007
            // 
            this.tbOUT007.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT007.Location = new System.Drawing.Point(573, 332);
            this.tbOUT007.Name = "tbOUT007";
            this.tbOUT007.ReadOnly = true;
            this.tbOUT007.Size = new System.Drawing.Size(150, 21);
            this.tbOUT007.TabIndex = 134;
            // 
            // tbOUT015
            // 
            this.tbOUT015.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT015.Location = new System.Drawing.Point(573, 556);
            this.tbOUT015.Name = "tbOUT015";
            this.tbOUT015.ReadOnly = true;
            this.tbOUT015.Size = new System.Drawing.Size(150, 21);
            this.tbOUT015.TabIndex = 134;
            this.tbOUT015.Text = "Pause Button light";
            // 
            // tbOUT100
            // 
            this.tbOUT100.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT100.Location = new System.Drawing.Point(807, 136);
            this.tbOUT100.Name = "tbOUT100";
            this.tbOUT100.ReadOnly = true;
            this.tbOUT100.Size = new System.Drawing.Size(150, 21);
            this.tbOUT100.TabIndex = 134;
            this.tbOUT100.Text = "SOL Upper Stopper";
            // 
            // tbOUT108
            // 
            this.tbOUT108.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT108.Location = new System.Drawing.Point(807, 360);
            this.tbOUT108.Name = "tbOUT108";
            this.tbOUT108.ReadOnly = true;
            this.tbOUT108.Size = new System.Drawing.Size(150, 21);
            this.tbOUT108.TabIndex = 134;
            // 
            // tbOUT104
            // 
            this.tbOUT104.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT104.Location = new System.Drawing.Point(807, 248);
            this.tbOUT104.Name = "tbOUT104";
            this.tbOUT104.ReadOnly = true;
            this.tbOUT104.Size = new System.Drawing.Size(150, 21);
            this.tbOUT104.TabIndex = 134;
            this.tbOUT104.Text = "CW/CCW Upper CV";
            // 
            // tbOUT112
            // 
            this.tbOUT112.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT112.Location = new System.Drawing.Point(807, 472);
            this.tbOUT112.Name = "tbOUT112";
            this.tbOUT112.ReadOnly = true;
            this.tbOUT112.Size = new System.Drawing.Size(150, 21);
            this.tbOUT112.TabIndex = 134;
            this.tbOUT112.Text = "RUN Under CV";
            // 
            // tbOUT102
            // 
            this.tbOUT102.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT102.Location = new System.Drawing.Point(807, 192);
            this.tbOUT102.Name = "tbOUT102";
            this.tbOUT102.ReadOnly = true;
            this.tbOUT102.Size = new System.Drawing.Size(150, 21);
            this.tbOUT102.TabIndex = 134;
            // 
            // tbOUT110
            // 
            this.tbOUT110.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT110.Location = new System.Drawing.Point(807, 416);
            this.tbOUT110.Name = "tbOUT110";
            this.tbOUT110.ReadOnly = true;
            this.tbOUT110.Size = new System.Drawing.Size(150, 21);
            this.tbOUT110.TabIndex = 134;
            // 
            // tbOUT106
            // 
            this.tbOUT106.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT106.Location = new System.Drawing.Point(807, 304);
            this.tbOUT106.Name = "tbOUT106";
            this.tbOUT106.ReadOnly = true;
            this.tbOUT106.Size = new System.Drawing.Size(150, 21);
            this.tbOUT106.TabIndex = 134;
            // 
            // tbOUT114
            // 
            this.tbOUT114.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT114.Location = new System.Drawing.Point(807, 528);
            this.tbOUT114.Name = "tbOUT114";
            this.tbOUT114.ReadOnly = true;
            this.tbOUT114.Size = new System.Drawing.Size(150, 21);
            this.tbOUT114.TabIndex = 134;
            this.tbOUT114.Text = "SOL Lock/un-Lock part";
            // 
            // tbOUT101
            // 
            this.tbOUT101.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT101.Location = new System.Drawing.Point(807, 164);
            this.tbOUT101.Name = "tbOUT101";
            this.tbOUT101.ReadOnly = true;
            this.tbOUT101.Size = new System.Drawing.Size(150, 21);
            this.tbOUT101.TabIndex = 134;
            // 
            // tbOUT109
            // 
            this.tbOUT109.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT109.Location = new System.Drawing.Point(807, 388);
            this.tbOUT109.Name = "tbOUT109";
            this.tbOUT109.ReadOnly = true;
            this.tbOUT109.Size = new System.Drawing.Size(150, 21);
            this.tbOUT109.TabIndex = 134;
            // 
            // tbOUT105
            // 
            this.tbOUT105.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT105.Location = new System.Drawing.Point(807, 276);
            this.tbOUT105.Name = "tbOUT105";
            this.tbOUT105.ReadOnly = true;
            this.tbOUT105.Size = new System.Drawing.Size(150, 21);
            this.tbOUT105.TabIndex = 134;
            this.tbOUT105.Text = "RUN Upper CV";
            // 
            // tbOUT113
            // 
            this.tbOUT113.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT113.Location = new System.Drawing.Point(807, 500);
            this.tbOUT113.Name = "tbOUT113";
            this.tbOUT113.ReadOnly = true;
            this.tbOUT113.Size = new System.Drawing.Size(150, 21);
            this.tbOUT113.TabIndex = 134;
            // 
            // tbOUT103
            // 
            this.tbOUT103.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT103.Location = new System.Drawing.Point(807, 220);
            this.tbOUT103.Name = "tbOUT103";
            this.tbOUT103.ReadOnly = true;
            this.tbOUT103.Size = new System.Drawing.Size(150, 21);
            this.tbOUT103.TabIndex = 134;
            // 
            // tbOUT111
            // 
            this.tbOUT111.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT111.Location = new System.Drawing.Point(807, 444);
            this.tbOUT111.Name = "tbOUT111";
            this.tbOUT111.ReadOnly = true;
            this.tbOUT111.Size = new System.Drawing.Size(150, 21);
            this.tbOUT111.TabIndex = 134;
            this.tbOUT111.Text = "CW/CCW Under CV";
            // 
            // tbOUT107
            // 
            this.tbOUT107.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT107.Location = new System.Drawing.Point(807, 332);
            this.tbOUT107.Name = "tbOUT107";
            this.tbOUT107.ReadOnly = true;
            this.tbOUT107.Size = new System.Drawing.Size(150, 21);
            this.tbOUT107.TabIndex = 134;
            this.tbOUT107.Text = "SOL Under Stopper";
            // 
            // tbOUT115
            // 
            this.tbOUT115.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOUT115.Location = new System.Drawing.Point(807, 556);
            this.tbOUT115.Name = "tbOUT115";
            this.tbOUT115.ReadOnly = true;
            this.tbOUT115.Size = new System.Drawing.Size(150, 21);
            this.tbOUT115.TabIndex = 134;
            // 
            // ucIOmonitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.tbOUT115);
            this.Controls.Add(this.tbOUT015);
            this.Controls.Add(this.tbIN115);
            this.Controls.Add(this.tbIN015);
            this.Controls.Add(this.tbOUT107);
            this.Controls.Add(this.tbOUT007);
            this.Controls.Add(this.tbIN107);
            this.Controls.Add(this.tbIN007);
            this.Controls.Add(this.tbOUT111);
            this.Controls.Add(this.tbOUT011);
            this.Controls.Add(this.tbIN111);
            this.Controls.Add(this.tbIN011);
            this.Controls.Add(this.tbOUT103);
            this.Controls.Add(this.tbOUT003);
            this.Controls.Add(this.tbIN103);
            this.Controls.Add(this.tbIN003);
            this.Controls.Add(this.tbOUT113);
            this.Controls.Add(this.tbOUT013);
            this.Controls.Add(this.tbIN113);
            this.Controls.Add(this.tbIN013);
            this.Controls.Add(this.tbOUT105);
            this.Controls.Add(this.tbOUT005);
            this.Controls.Add(this.tbIN105);
            this.Controls.Add(this.tbIN005);
            this.Controls.Add(this.tbOUT109);
            this.Controls.Add(this.tbOUT009);
            this.Controls.Add(this.tbIN109);
            this.Controls.Add(this.tbIN009);
            this.Controls.Add(this.tbOUT101);
            this.Controls.Add(this.tbOUT001);
            this.Controls.Add(this.tbIN101);
            this.Controls.Add(this.tbIN001);
            this.Controls.Add(this.tbOUT114);
            this.Controls.Add(this.tbOUT014);
            this.Controls.Add(this.tbIN114);
            this.Controls.Add(this.tbIN014);
            this.Controls.Add(this.tbOUT106);
            this.Controls.Add(this.tbOUT006);
            this.Controls.Add(this.tbIN106);
            this.Controls.Add(this.tbIN006);
            this.Controls.Add(this.tbOUT110);
            this.Controls.Add(this.tbOUT010);
            this.Controls.Add(this.tbIN110);
            this.Controls.Add(this.tbIN010);
            this.Controls.Add(this.tbOUT102);
            this.Controls.Add(this.tbOUT002);
            this.Controls.Add(this.tbIN102);
            this.Controls.Add(this.tbIN002);
            this.Controls.Add(this.tbOUT112);
            this.Controls.Add(this.tbOUT012);
            this.Controls.Add(this.tbIN112);
            this.Controls.Add(this.tbIN012);
            this.Controls.Add(this.tbOUT104);
            this.Controls.Add(this.tbOUT004);
            this.Controls.Add(this.tbIN104);
            this.Controls.Add(this.tbIN004);
            this.Controls.Add(this.tbOUT108);
            this.Controls.Add(this.tbOUT008);
            this.Controls.Add(this.tbIN108);
            this.Controls.Add(this.tbIN008);
            this.Controls.Add(this.tbOUT100);
            this.Controls.Add(this.tbOUT000);
            this.Controls.Add(this.tbIN100);
            this.Controls.Add(this.tbIN000);
            this.Controls.Add(this.tbOUT_1);
            this.Controls.Add(this.tbIN_1);
            this.Controls.Add(this.lbOUT115);
            this.Controls.Add(this.lbOUT114);
            this.Controls.Add(this.lbOUT113);
            this.Controls.Add(this.lbOUT112);
            this.Controls.Add(this.lbOUT111);
            this.Controls.Add(this.lbOUT110);
            this.Controls.Add(this.lbOUT109);
            this.Controls.Add(this.lbOUT108);
            this.Controls.Add(this.lbOUT107);
            this.Controls.Add(this.lbOUT106);
            this.Controls.Add(this.lbOUT105);
            this.Controls.Add(this.lbOUT104);
            this.Controls.Add(this.lbOUT103);
            this.Controls.Add(this.lbOUT102);
            this.Controls.Add(this.lbOUT101);
            this.Controls.Add(this.lbOUT100);
            this.Controls.Add(this.lbOUT015);
            this.Controls.Add(this.lbOUT014);
            this.Controls.Add(this.lbOUT013);
            this.Controls.Add(this.lbOUT012);
            this.Controls.Add(this.lbOUT011);
            this.Controls.Add(this.lbOUT010);
            this.Controls.Add(this.lbOUT009);
            this.Controls.Add(this.lbOUT008);
            this.Controls.Add(this.lbOUT007);
            this.Controls.Add(this.lbOUT006);
            this.Controls.Add(this.lbOUT005);
            this.Controls.Add(this.lbOUT004);
            this.Controls.Add(this.lbOUT003);
            this.Controls.Add(this.lbOUT002);
            this.Controls.Add(this.lbOUT001);
            this.Controls.Add(this.lbOUT000);
            this.Controls.Add(this.lbIN115);
            this.Controls.Add(this.lbIN114);
            this.Controls.Add(this.lbIN113);
            this.Controls.Add(this.lbIN112);
            this.Controls.Add(this.lbIN111);
            this.Controls.Add(this.lbIN110);
            this.Controls.Add(this.lbIN109);
            this.Controls.Add(this.lbIN108);
            this.Controls.Add(this.lbIN107);
            this.Controls.Add(this.lbIN106);
            this.Controls.Add(this.lbIN105);
            this.Controls.Add(this.lbIN104);
            this.Controls.Add(this.lbIN103);
            this.Controls.Add(this.lbIN102);
            this.Controls.Add(this.lbIN101);
            this.Controls.Add(this.lbIN100);
            this.Controls.Add(this.lbIN015);
            this.Controls.Add(this.lbIN014);
            this.Controls.Add(this.lbIN013);
            this.Controls.Add(this.lbIN012);
            this.Controls.Add(this.lbIN011);
            this.Controls.Add(this.lbIN010);
            this.Controls.Add(this.lbIN009);
            this.Controls.Add(this.lbIN008);
            this.Controls.Add(this.lbIN007);
            this.Controls.Add(this.lbIN006);
            this.Controls.Add(this.lbIN005);
            this.Controls.Add(this.lbIN004);
            this.Controls.Add(this.lbIN003);
            this.Controls.Add(this.lbIN002);
            this.Controls.Add(this.lbIN001);
            this.Controls.Add(this.lbIN000);
            this.Controls.Add(this.btnIO_P2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbIO_1);
            this.Controls.Add(this.lbIOMonitor);
            this.Name = "ucIOmonitor";
            this.Size = new System.Drawing.Size(1000, 600);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbIOMonitor;
        private System.Windows.Forms.Label lbIO_1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnIO_P2;
        private System.Windows.Forms.Label lbIN000;
        private System.Windows.Forms.Label lbIN001;
        private System.Windows.Forms.Label lbIN003;
        private System.Windows.Forms.Label lbIN002;
        private System.Windows.Forms.Label lbIN007;
        private System.Windows.Forms.Label lbIN006;
        private System.Windows.Forms.Label lbIN005;
        private System.Windows.Forms.Label lbIN004;
        private System.Windows.Forms.Label lbIN015;
        private System.Windows.Forms.Label lbIN014;
        private System.Windows.Forms.Label lbIN013;
        private System.Windows.Forms.Label lbIN012;
        private System.Windows.Forms.Label lbIN011;
        private System.Windows.Forms.Label lbIN010;
        private System.Windows.Forms.Label lbIN009;
        private System.Windows.Forms.Label lbIN008;
        private System.Windows.Forms.Label lbIN115;
        private System.Windows.Forms.Label lbIN114;
        private System.Windows.Forms.Label lbIN113;
        private System.Windows.Forms.Label lbIN112;
        private System.Windows.Forms.Label lbIN111;
        private System.Windows.Forms.Label lbIN110;
        private System.Windows.Forms.Label lbIN109;
        private System.Windows.Forms.Label lbIN108;
        private System.Windows.Forms.Label lbIN107;
        private System.Windows.Forms.Label lbIN106;
        private System.Windows.Forms.Label lbIN105;
        private System.Windows.Forms.Label lbIN104;
        private System.Windows.Forms.Label lbIN103;
        private System.Windows.Forms.Label lbIN102;
        private System.Windows.Forms.Label lbIN101;
        private System.Windows.Forms.Label lbIN100;
        private System.Windows.Forms.Label lbOUT115;
        private System.Windows.Forms.Label lbOUT114;
        private System.Windows.Forms.Label lbOUT113;
        private System.Windows.Forms.Label lbOUT112;
        private System.Windows.Forms.Label lbOUT111;
        private System.Windows.Forms.Label lbOUT110;
        private System.Windows.Forms.Label lbOUT109;
        private System.Windows.Forms.Label lbOUT108;
        private System.Windows.Forms.Label lbOUT107;
        private System.Windows.Forms.Label lbOUT106;
        private System.Windows.Forms.Label lbOUT105;
        private System.Windows.Forms.Label lbOUT104;
        private System.Windows.Forms.Label lbOUT103;
        private System.Windows.Forms.Label lbOUT102;
        private System.Windows.Forms.Label lbOUT101;
        private System.Windows.Forms.Label lbOUT100;
        private System.Windows.Forms.Label lbOUT015;
        private System.Windows.Forms.Label lbOUT014;
        private System.Windows.Forms.Label lbOUT013;
        private System.Windows.Forms.Label lbOUT012;
        private System.Windows.Forms.Label lbOUT011;
        private System.Windows.Forms.Label lbOUT010;
        private System.Windows.Forms.Label lbOUT009;
        private System.Windows.Forms.Label lbOUT008;
        private System.Windows.Forms.Label lbOUT007;
        private System.Windows.Forms.Label lbOUT006;
        private System.Windows.Forms.Label lbOUT005;
        private System.Windows.Forms.Label lbOUT004;
        private System.Windows.Forms.Label lbOUT003;
        private System.Windows.Forms.Label lbOUT002;
        private System.Windows.Forms.Label lbOUT001;
        private System.Windows.Forms.Label lbOUT000;
        private System.Windows.Forms.TextBox tbIN_1;
        private System.Windows.Forms.TextBox tbOUT_1;
        private System.Windows.Forms.TextBox tbIN000;
        private System.Windows.Forms.TextBox tbIN001;
        private System.Windows.Forms.TextBox tbIN002;
        private System.Windows.Forms.TextBox tbIN003;
        private System.Windows.Forms.TextBox tbIN004;
        private System.Windows.Forms.TextBox tbIN006;
        private System.Windows.Forms.TextBox tbIN005;
        private System.Windows.Forms.TextBox tbIN007;
        private System.Windows.Forms.TextBox tbIN008;
        private System.Windows.Forms.TextBox tbIN012;
        private System.Windows.Forms.TextBox tbIN010;
        private System.Windows.Forms.TextBox tbIN014;
        private System.Windows.Forms.TextBox tbIN009;
        private System.Windows.Forms.TextBox tbIN013;
        private System.Windows.Forms.TextBox tbIN011;
        private System.Windows.Forms.TextBox tbIN015;
        private System.Windows.Forms.TextBox tbIN100;
        private System.Windows.Forms.TextBox tbIN108;
        private System.Windows.Forms.TextBox tbIN104;
        private System.Windows.Forms.TextBox tbIN112;
        private System.Windows.Forms.TextBox tbIN102;
        private System.Windows.Forms.TextBox tbIN110;
        private System.Windows.Forms.TextBox tbIN106;
        private System.Windows.Forms.TextBox tbIN114;
        private System.Windows.Forms.TextBox tbIN101;
        private System.Windows.Forms.TextBox tbIN109;
        private System.Windows.Forms.TextBox tbIN105;
        private System.Windows.Forms.TextBox tbIN113;
        private System.Windows.Forms.TextBox tbIN103;
        private System.Windows.Forms.TextBox tbIN111;
        private System.Windows.Forms.TextBox tbIN107;
        private System.Windows.Forms.TextBox tbIN115;
        private System.Windows.Forms.TextBox tbOUT000;
        private System.Windows.Forms.TextBox tbOUT008;
        private System.Windows.Forms.TextBox tbOUT004;
        private System.Windows.Forms.TextBox tbOUT012;
        private System.Windows.Forms.TextBox tbOUT002;
        private System.Windows.Forms.TextBox tbOUT010;
        private System.Windows.Forms.TextBox tbOUT006;
        private System.Windows.Forms.TextBox tbOUT014;
        private System.Windows.Forms.TextBox tbOUT001;
        private System.Windows.Forms.TextBox tbOUT009;
        private System.Windows.Forms.TextBox tbOUT005;
        private System.Windows.Forms.TextBox tbOUT013;
        private System.Windows.Forms.TextBox tbOUT003;
        private System.Windows.Forms.TextBox tbOUT011;
        private System.Windows.Forms.TextBox tbOUT007;
        private System.Windows.Forms.TextBox tbOUT015;
        private System.Windows.Forms.TextBox tbOUT100;
        private System.Windows.Forms.TextBox tbOUT108;
        private System.Windows.Forms.TextBox tbOUT104;
        private System.Windows.Forms.TextBox tbOUT112;
        private System.Windows.Forms.TextBox tbOUT102;
        private System.Windows.Forms.TextBox tbOUT110;
        private System.Windows.Forms.TextBox tbOUT106;
        private System.Windows.Forms.TextBox tbOUT114;
        private System.Windows.Forms.TextBox tbOUT101;
        private System.Windows.Forms.TextBox tbOUT109;
        private System.Windows.Forms.TextBox tbOUT105;
        private System.Windows.Forms.TextBox tbOUT113;
        private System.Windows.Forms.TextBox tbOUT103;
        private System.Windows.Forms.TextBox tbOUT111;
        private System.Windows.Forms.TextBox tbOUT107;
        private System.Windows.Forms.TextBox tbOUT115;
    }
}
