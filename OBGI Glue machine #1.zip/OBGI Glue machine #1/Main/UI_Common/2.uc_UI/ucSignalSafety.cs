﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucSignalSafety : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        List<Label> labInputList = new List<Label>();
        List<Label> labOutputList = new List<Label>();

        public ucSignalSafety(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;

            #region First set
            _mainGUI.Common.bChkSafetyDoor = Convert.ToBoolean(_mainGUI.Common.Config.ReadValue("OptionSelect", "SafetyDoor").ToString());
            _mainGUI.Common.bChkAreaSensor = Convert.ToBoolean(_mainGUI.Common.Config.ReadValue("OptionSelect", "AreaSensor").ToString());

            if (_mainGUI.Common.bChkSafetyDoor)
            {
                lbSafetyDoor_status.BackColor = Color.PaleGreen;
                lbSafetyDoor_status.Text = "Safety Door ON";
            }
            else
            {
                lbSafetyDoor_status.BackColor = Color.Crimson;
                lbSafetyDoor_status.Text = "Safety Door OFF";
            }
            if (_mainGUI.Common.bChkAreaSensor)
            {
                lbAreaSensor_status.BackColor = Color.PaleGreen;
                lbAreaSensor_status.Text = "Area Sensor ON";
            }
            else
            {
                lbAreaSensor_status.BackColor = Color.Crimson;
                lbAreaSensor_status.Text = "Area Sensor OFF";
            }
            #endregion
            #region INPUT Ui AddList
            labInputList.Add(lbSigDown_L_acc);//I:208
            labInputList.Add(lbSigUp_R_acc);//I:212
            #endregion
            # region OUTPUT Ui AddList
            labOutputList.Add(lbSigUp_L_acc);//O:208
            labOutputList.Add(lbSigDown_R_acc);//O:212
            #endregion

        }

        public void UpdateUI()
        {
            if (Visible)
            {
                #region update input
                labInputList[0].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)8].State ? Color.LawnGreen : Color.LightGray;
                labInputList[1].BackColor = _mainGUI.Common.IOTable.DI[(ushort)2, (ushort)12].State ? Color.LawnGreen : Color.LightGray;
                #endregion
                #region update output
                labOutputList[0].BackColor = _mainGUI.Common.IOTable.DO[(ushort)2, (ushort)8].State ? Color.LawnGreen : Color.LightGray;
                labOutputList[1].BackColor = _mainGUI.Common.IOTable.DO[(ushort)2, (ushort)12].State ? Color.LawnGreen : Color.LightGray;
                #endregion
            }
        }


        #region MOUSE CLICK EVENT
        private void btnUpLeft_acc_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkO208)
            {
                btnUpLeft_acc.BackColor = Color.LightGray;
                _mainGUI.Common.bChkO208 = false;
                _mainGUI.Common.IOTable.DO[(ushort)2, (ushort)8].Reset();
            }
            else
            {
                btnUpLeft_acc.BackColor = Color.LightCoral;
                _mainGUI.Common.bChkO208 = true;
                _mainGUI.Common.IOTable.DO[(ushort)2, (ushort)8].Set();
            }
        }

        private void btnDownRight_acc_Click(object sender, EventArgs e)
        {
            if (_mainGUI.Common.bChkO212)
            {
                btnDownRight_acc.BackColor = Color.LightGray;
                _mainGUI.Common.bChkO212 = false;
                _mainGUI.Common.IOTable.DO[(ushort)2, (ushort)12].Reset();
            }
            else
            {
                btnDownRight_acc.BackColor = Color.LightCoral;
                _mainGUI.Common.bChkO212 = true;
                _mainGUI.Common.IOTable.DO[(ushort)2, (ushort)12].Set();
            }
        }

        private void btnSafetyDoor_ON_Click(object sender, EventArgs e)
        {
            lbSafetyDoor_status.BackColor = Color.PaleGreen;
            lbSafetyDoor_status.Text = "Safety Door ON";
            _mainGUI.Common.bChkSafetyDoor = true;
            _mainGUI.Common.Config.WriteValue("OptionSelect", "SafetyDoor", _mainGUI.Common.bChkSafetyDoor.ToString());
        }

        private void btnSafetyDoor_OFF_Click(object sender, EventArgs e)
        {
            lbSafetyDoor_status.BackColor = Color.Crimson;
            lbSafetyDoor_status.Text = "Safety Door OFF";
            _mainGUI.Common.bChkSafetyDoor = false;
            _mainGUI.Common.Config.WriteValue("OptionSelect", "SafetyDoor", _mainGUI.Common.bChkSafetyDoor.ToString());
        }

        private void btnAreaSensor_ON_Click(object sender, EventArgs e)
        {
            lbAreaSensor_status.BackColor = Color.PaleGreen;
            lbAreaSensor_status.Text = "Area Sensor ON";
            _mainGUI.Common.bChkAreaSensor = true;
            _mainGUI.Common.Config.WriteValue("OptionSelect", "AreaSensor", _mainGUI.Common.bChkAreaSensor.ToString());
        }

        private void btnAreaSensor_OFF_Click(object sender, EventArgs e)
        {
            lbAreaSensor_status.BackColor = Color.Crimson;
            lbAreaSensor_status.Text = "Area Sensor OFF";
            _mainGUI.Common.bChkAreaSensor = false;
            _mainGUI.Common.Config.WriteValue("OptionSelect", "AreaSensor", _mainGUI.Common.bChkAreaSensor.ToString());
        }

        #endregion
        #region MOUSE UP/DOWN EVENT
        private void btnSafetyDoor_ON_MouseDown(object sender, MouseEventArgs e)
        {
            btnSafetyDoor_ON.BackColor = Color.LightCoral;
        }

        private void btnSafetyDoor_ON_MouseUp(object sender, MouseEventArgs e)
        {
            btnSafetyDoor_ON.BackColor = Color.LightGray;
        }

        private void btnSafetyDoor_OFF_MouseDown(object sender, MouseEventArgs e)
        {
            btnSafetyDoor_OFF.BackColor = Color.LightCoral;
        }

        private void btnSafetyDoor_OFF_MouseUp(object sender, MouseEventArgs e)
        {
            btnSafetyDoor_OFF.BackColor = Color.LightGray;
        }

        private void btnAreaSensor_ON_MouseDown(object sender, MouseEventArgs e)
        {
            btnAreaSensor_ON.BackColor = Color.LightCoral;
        }

        private void btnAreaSensor_ON_MouseUp(object sender, MouseEventArgs e)
        {
            btnAreaSensor_ON.BackColor = Color.LightGray;
        }

        private void btnAreaSensor_OFF_MouseDown(object sender, MouseEventArgs e)
        {
            btnAreaSensor_OFF.BackColor = Color.LightCoral;
        }

        private void btnAreaSensor_OFF_MouseUp(object sender, MouseEventArgs e)
        {
            btnAreaSensor_OFF.BackColor = Color.LightGray;
        }

        #endregion

    }
}
