﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Equipment_Control.IO_Control;
using Equipment_Control.Interface;

namespace UI_Common
{
    public partial class ucModelSelect : UserControl, IUpdateUI
    {
        MainGUI _mainGUI;
        public ucModelSelect(MainGUI mainGUI)
        {
            InitializeComponent();
            this._mainGUI = mainGUI;

            cbModelSelect.Items.Add("1");

            cbModelSelect.Text = _mainGUI.Common.Config.ReadValue("OptionSelect", "ModelSelect").ToString();

        }

        public void UpdateUI()
        {
            if (Visible)
            {
                if(cbModelSelect.Text == "1") { lbDescription.Text = "Now Select BUSCAP"; }
                else { lbDescription.Text = ""; }
            }
            _mainGUI.Common.iModelSelect = Convert.ToInt32(cbModelSelect.Text);
        }

        private void btnSaveModel_Click(object sender, EventArgs e)
        {
            DialogResult re = MessageBox.Show("Confirm to save default running model?", "Save confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (re == DialogResult.Yes)
            {
                _mainGUI.Common.Config.WriteValue("OptionSelect", "ModelSelect", cbModelSelect.Text);
            }
        }
    }
}
