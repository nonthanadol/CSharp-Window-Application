﻿
namespace UI_Common
{
    partial class ucSetting
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnModelSelect = new System.Windows.Forms.Button();
            this.btnXYZControls = new System.Windows.Forms.Button();
            this.btnEquipControl = new System.Windows.Forms.Button();
            this.btnSigSafe = new System.Windows.Forms.Button();
            this.btnPQM = new System.Windows.Forms.Button();
            this.btnRFID_MES = new System.Windows.Forms.Button();
            this.lbSetting = new System.Windows.Forms.Label();
            this.btnCalibration = new System.Windows.Forms.Button();
            this.btnSpdDT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnModelSelect
            // 
            this.btnModelSelect.BackColor = System.Drawing.Color.LightGray;
            this.btnModelSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModelSelect.Location = new System.Drawing.Point(50, 98);
            this.btnModelSelect.Name = "btnModelSelect";
            this.btnModelSelect.Size = new System.Drawing.Size(164, 80);
            this.btnModelSelect.TabIndex = 0;
            this.btnModelSelect.Text = "MODEL SELECT";
            this.btnModelSelect.UseVisualStyleBackColor = false;
            this.btnModelSelect.Click += new System.EventHandler(this.btnModelSelect_Click);
            // 
            // btnXYZControls
            // 
            this.btnXYZControls.BackColor = System.Drawing.Color.LightGray;
            this.btnXYZControls.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXYZControls.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXYZControls.Location = new System.Drawing.Point(410, 98);
            this.btnXYZControls.Name = "btnXYZControls";
            this.btnXYZControls.Size = new System.Drawing.Size(164, 80);
            this.btnXYZControls.TabIndex = 1;
            this.btnXYZControls.Text = "XYZ CONTROLS";
            this.btnXYZControls.UseVisualStyleBackColor = false;
            this.btnXYZControls.Click += new System.EventHandler(this.btnXYZControls_Click);
            // 
            // btnEquipControl
            // 
            this.btnEquipControl.BackColor = System.Drawing.Color.LightGray;
            this.btnEquipControl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEquipControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEquipControl.Location = new System.Drawing.Point(770, 98);
            this.btnEquipControl.Name = "btnEquipControl";
            this.btnEquipControl.Size = new System.Drawing.Size(164, 80);
            this.btnEquipControl.TabIndex = 2;
            this.btnEquipControl.Text = "EQUIPMENT CONTROLS";
            this.btnEquipControl.UseVisualStyleBackColor = false;
            this.btnEquipControl.Click += new System.EventHandler(this.btnEquipControl_Click);
            // 
            // btnSigSafe
            // 
            this.btnSigSafe.BackColor = System.Drawing.Color.LightGray;
            this.btnSigSafe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSigSafe.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSigSafe.Location = new System.Drawing.Point(50, 237);
            this.btnSigSafe.Name = "btnSigSafe";
            this.btnSigSafe.Size = new System.Drawing.Size(164, 80);
            this.btnSigSafe.TabIndex = 3;
            this.btnSigSafe.Text = "SIGNAL | SAFETY";
            this.btnSigSafe.UseVisualStyleBackColor = false;
            this.btnSigSafe.Click += new System.EventHandler(this.btnSigSafe_Click);
            // 
            // btnPQM
            // 
            this.btnPQM.BackColor = System.Drawing.Color.LightGray;
            this.btnPQM.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPQM.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPQM.Location = new System.Drawing.Point(410, 236);
            this.btnPQM.Name = "btnPQM";
            this.btnPQM.Size = new System.Drawing.Size(164, 80);
            this.btnPQM.TabIndex = 4;
            this.btnPQM.Text = "PQM | LIFETIME";
            this.btnPQM.UseVisualStyleBackColor = false;
            this.btnPQM.Click += new System.EventHandler(this.btnPQM_Click);
            // 
            // btnRFID_MES
            // 
            this.btnRFID_MES.BackColor = System.Drawing.Color.LightGray;
            this.btnRFID_MES.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRFID_MES.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRFID_MES.Location = new System.Drawing.Point(771, 237);
            this.btnRFID_MES.Name = "btnRFID_MES";
            this.btnRFID_MES.Size = new System.Drawing.Size(164, 80);
            this.btnRFID_MES.TabIndex = 5;
            this.btnRFID_MES.Text = "RFID | MES";
            this.btnRFID_MES.UseVisualStyleBackColor = false;
            this.btnRFID_MES.Click += new System.EventHandler(this.btnRFID_MES_Click);
            // 
            // lbSetting
            // 
            this.lbSetting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lbSetting.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSetting.Location = new System.Drawing.Point(0, 0);
            this.lbSetting.Name = "lbSetting";
            this.lbSetting.Size = new System.Drawing.Size(1000, 40);
            this.lbSetting.TabIndex = 6;
            this.lbSetting.Text = "SETTING";
            this.lbSetting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCalibration
            // 
            this.btnCalibration.BackColor = System.Drawing.Color.LightGray;
            this.btnCalibration.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalibration.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalibration.Location = new System.Drawing.Point(50, 376);
            this.btnCalibration.Name = "btnCalibration";
            this.btnCalibration.Size = new System.Drawing.Size(164, 80);
            this.btnCalibration.TabIndex = 7;
            this.btnCalibration.Text = "TOOLS | CAMERA CALIBRATION";
            this.btnCalibration.UseVisualStyleBackColor = false;
            this.btnCalibration.Click += new System.EventHandler(this.btnCalibration_Click);
            // 
            // btnSpdDT
            // 
            this.btnSpdDT.BackColor = System.Drawing.Color.LightGray;
            this.btnSpdDT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSpdDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpdDT.Location = new System.Drawing.Point(410, 376);
            this.btnSpdDT.Name = "btnSpdDT";
            this.btnSpdDT.Size = new System.Drawing.Size(164, 80);
            this.btnSpdDT.TabIndex = 10;
            this.btnSpdDT.Text = "SPEED | DELAY TIME";
            this.btnSpdDT.UseVisualStyleBackColor = false;
            this.btnSpdDT.Click += new System.EventHandler(this.btnSpdDT_Click);
            // 
            // ucSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnSpdDT);
            this.Controls.Add(this.btnCalibration);
            this.Controls.Add(this.lbSetting);
            this.Controls.Add(this.btnRFID_MES);
            this.Controls.Add(this.btnPQM);
            this.Controls.Add(this.btnSigSafe);
            this.Controls.Add(this.btnEquipControl);
            this.Controls.Add(this.btnXYZControls);
            this.Controls.Add(this.btnModelSelect);
            this.Name = "ucSetting";
            this.Size = new System.Drawing.Size(1000, 600);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnModelSelect;
        private System.Windows.Forms.Button btnXYZControls;
        private System.Windows.Forms.Button btnEquipControl;
        private System.Windows.Forms.Button btnSigSafe;
        private System.Windows.Forms.Button btnPQM;
        private System.Windows.Forms.Button btnRFID_MES;
        private System.Windows.Forms.Label lbSetting;
        private System.Windows.Forms.Button btnCalibration;
        private System.Windows.Forms.Button btnSpdDT;
    }
}
