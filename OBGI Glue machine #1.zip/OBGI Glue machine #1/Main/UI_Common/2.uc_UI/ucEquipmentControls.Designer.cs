﻿
namespace UI_Common
{
    partial class ucEquipmentControls
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnStopper_Upper = new System.Windows.Forms.Button();
            this.btnPalletLock = new System.Windows.Forms.Button();
            this.btnRFID_L = new System.Windows.Forms.Button();
            this.btnRFID_R = new System.Windows.Forms.Button();
            this.btnStopper_Under = new System.Windows.Forms.Button();
            this.btnUpCVMove_L = new System.Windows.Forms.Button();
            this.btnUpCVMove_R = new System.Windows.Forms.Button();
            this.btnDownCVMove_R = new System.Windows.Forms.Button();
            this.btnDownCVMove_L = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lbIN200 = new System.Windows.Forms.Label();
            this.lbIN201 = new System.Windows.Forms.Label();
            this.lbIN202 = new System.Windows.Forms.Label();
            this.lbIN203 = new System.Windows.Forms.Label();
            this.lbIN100 = new System.Windows.Forms.Label();
            this.lbIN101 = new System.Windows.Forms.Label();
            this.lbIN102 = new System.Windows.Forms.Label();
            this.lbIN103 = new System.Windows.Forms.Label();
            this.lbIN114 = new System.Windows.Forms.Label();
            this.lbIN115 = new System.Windows.Forms.Label();
            this.lbIN107 = new System.Windows.Forms.Label();
            this.lbIN108 = new System.Windows.Forms.Label();
            this.lbIN109 = new System.Windows.Forms.Label();
            this.lbIN110 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label21 = new System.Windows.Forms.Label();
            this.btnManualPurge_ON = new System.Windows.Forms.Button();
            this.btnManualPurge_OFF = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.lbManualPurge_status = new System.Windows.Forms.Label();
            this.btnAutoPurge_ON = new System.Windows.Forms.Button();
            this.btnAutoPurge_OFF = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.lbAutoPurge_status = new System.Windows.Forms.Label();
            this.tbTimetoPurge = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tbPurgeTime = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbTimeCountToPurge = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnResetTimeCount = new System.Windows.Forms.Button();
            this.btnTool2_Pick = new System.Windows.Forms.Button();
            this.btnTool2_Place = new System.Windows.Forms.Button();
            this.btnTool1_Pick = new System.Windows.Forms.Button();
            this.btnTool1_Place = new System.Windows.Forms.Button();
            this.btnTool2_LockUnLock = new System.Windows.Forms.Button();
            this.btnTool2_INOUT = new System.Windows.Forms.Button();
            this.btnTool1_LockUnLock = new System.Windows.Forms.Button();
            this.btnTool1_INOUT = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.lbIN307 = new System.Windows.Forms.Label();
            this.lbIN308 = new System.Windows.Forms.Label();
            this.lbIN306 = new System.Windows.Forms.Label();
            this.lbIN305 = new System.Windows.Forms.Label();
            this.lbIN303 = new System.Windows.Forms.Label();
            this.lbIN302 = new System.Windows.Forms.Label();
            this.lbIN300 = new System.Windows.Forms.Label();
            this.lbIN301 = new System.Windows.Forms.Label();
            this.lbManualPurge2_status = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnManualPurge2_OFF = new System.Windows.Forms.Button();
            this.btnManualPurge2_ON = new System.Windows.Forms.Button();
            this.btnCameraLight = new System.Windows.Forms.Button();
            this.btnToolsUnClamp = new System.Windows.Forms.Button();
            this.btnToolsClamp = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1000, 40);
            this.label1.TabIndex = 2;
            this.label1.Text = "EQUIPMENT CONTROLS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnStopper_Upper
            // 
            this.btnStopper_Upper.BackColor = System.Drawing.Color.LightGray;
            this.btnStopper_Upper.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStopper_Upper.Location = new System.Drawing.Point(164, 265);
            this.btnStopper_Upper.Name = "btnStopper_Upper";
            this.btnStopper_Upper.Size = new System.Drawing.Size(94, 49);
            this.btnStopper_Upper.TabIndex = 4;
            this.btnStopper_Upper.Text = "STOPPER UPPER";
            this.btnStopper_Upper.UseVisualStyleBackColor = false;
            this.btnStopper_Upper.Click += new System.EventHandler(this.btnStopper_Upper_Click);
            // 
            // btnPalletLock
            // 
            this.btnPalletLock.BackColor = System.Drawing.Color.LightGray;
            this.btnPalletLock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPalletLock.Location = new System.Drawing.Point(164, 320);
            this.btnPalletLock.Name = "btnPalletLock";
            this.btnPalletLock.Size = new System.Drawing.Size(94, 49);
            this.btnPalletLock.TabIndex = 5;
            this.btnPalletLock.Text = "PALLET LOCK";
            this.btnPalletLock.UseVisualStyleBackColor = false;
            this.btnPalletLock.Click += new System.EventHandler(this.btnPalletLock_Click);
            // 
            // btnRFID_L
            // 
            this.btnRFID_L.BackColor = System.Drawing.Color.LightGray;
            this.btnRFID_L.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRFID_L.Location = new System.Drawing.Point(116, 210);
            this.btnRFID_L.Name = "btnRFID_L";
            this.btnRFID_L.Size = new System.Drawing.Size(94, 49);
            this.btnRFID_L.TabIndex = 6;
            this.btnRFID_L.Text = "RFID  LEFT";
            this.btnRFID_L.UseVisualStyleBackColor = false;
            this.btnRFID_L.Click += new System.EventHandler(this.btnRFID_L_Click);
            // 
            // btnRFID_R
            // 
            this.btnRFID_R.BackColor = System.Drawing.Color.LightGray;
            this.btnRFID_R.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRFID_R.Location = new System.Drawing.Point(216, 210);
            this.btnRFID_R.Name = "btnRFID_R";
            this.btnRFID_R.Size = new System.Drawing.Size(94, 49);
            this.btnRFID_R.TabIndex = 7;
            this.btnRFID_R.Text = "RFID RIGHT";
            this.btnRFID_R.UseVisualStyleBackColor = false;
            this.btnRFID_R.Click += new System.EventHandler(this.btnRFID_R_Click);
            // 
            // btnStopper_Under
            // 
            this.btnStopper_Under.BackColor = System.Drawing.Color.LightGray;
            this.btnStopper_Under.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStopper_Under.Location = new System.Drawing.Point(164, 446);
            this.btnStopper_Under.Name = "btnStopper_Under";
            this.btnStopper_Under.Size = new System.Drawing.Size(94, 49);
            this.btnStopper_Under.TabIndex = 13;
            this.btnStopper_Under.Text = "STOPPER UNDER";
            this.btnStopper_Under.UseVisualStyleBackColor = false;
            this.btnStopper_Under.Click += new System.EventHandler(this.btnStopper_Under_Click);
            // 
            // btnUpCVMove_L
            // 
            this.btnUpCVMove_L.BackColor = System.Drawing.Color.LightGray;
            this.btnUpCVMove_L.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpCVMove_L.Location = new System.Drawing.Point(116, 155);
            this.btnUpCVMove_L.Name = "btnUpCVMove_L";
            this.btnUpCVMove_L.Size = new System.Drawing.Size(94, 49);
            this.btnUpCVMove_L.TabIndex = 17;
            this.btnUpCVMove_L.Text = "CV MOVE <=";
            this.btnUpCVMove_L.UseVisualStyleBackColor = false;
            this.btnUpCVMove_L.Click += new System.EventHandler(this.btnUpCVMove_L_Click);
            // 
            // btnUpCVMove_R
            // 
            this.btnUpCVMove_R.BackColor = System.Drawing.Color.LightGray;
            this.btnUpCVMove_R.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpCVMove_R.Location = new System.Drawing.Point(216, 155);
            this.btnUpCVMove_R.Name = "btnUpCVMove_R";
            this.btnUpCVMove_R.Size = new System.Drawing.Size(94, 49);
            this.btnUpCVMove_R.TabIndex = 18;
            this.btnUpCVMove_R.Text = "CV MOVE =>";
            this.btnUpCVMove_R.UseVisualStyleBackColor = false;
            this.btnUpCVMove_R.Click += new System.EventHandler(this.btnUpCVMove_R_Click);
            // 
            // btnDownCVMove_R
            // 
            this.btnDownCVMove_R.BackColor = System.Drawing.Color.LightGray;
            this.btnDownCVMove_R.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDownCVMove_R.Location = new System.Drawing.Point(216, 391);
            this.btnDownCVMove_R.Name = "btnDownCVMove_R";
            this.btnDownCVMove_R.Size = new System.Drawing.Size(94, 49);
            this.btnDownCVMove_R.TabIndex = 20;
            this.btnDownCVMove_R.Text = "CV MOVE =>";
            this.btnDownCVMove_R.UseVisualStyleBackColor = false;
            this.btnDownCVMove_R.Click += new System.EventHandler(this.btnDownCVMove_R_Click);
            // 
            // btnDownCVMove_L
            // 
            this.btnDownCVMove_L.BackColor = System.Drawing.Color.LightGray;
            this.btnDownCVMove_L.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDownCVMove_L.Location = new System.Drawing.Point(116, 391);
            this.btnDownCVMove_L.Name = "btnDownCVMove_L";
            this.btnDownCVMove_L.Size = new System.Drawing.Size(94, 49);
            this.btnDownCVMove_L.TabIndex = 19;
            this.btnDownCVMove_L.Text = "CV MOVE <=";
            this.btnDownCVMove_L.UseVisualStyleBackColor = false;
            this.btnDownCVMove_L.Click += new System.EventHandler(this.btnDownCVMove_L_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Black;
            this.pictureBox5.Location = new System.Drawing.Point(74, 375);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(281, 10);
            this.pictureBox5.TabIndex = 37;
            this.pictureBox5.TabStop = false;
            // 
            // lbIN200
            // 
            this.lbIN200.AutoSize = true;
            this.lbIN200.BackColor = System.Drawing.Color.LightGray;
            this.lbIN200.Location = new System.Drawing.Point(71, 210);
            this.lbIN200.Name = "lbIN200";
            this.lbIN200.Size = new System.Drawing.Size(39, 17);
            this.lbIN200.TabIndex = 38;
            this.lbIN200.Text = "I:200";
            // 
            // lbIN201
            // 
            this.lbIN201.AutoSize = true;
            this.lbIN201.BackColor = System.Drawing.Color.LightGray;
            this.lbIN201.Location = new System.Drawing.Point(71, 242);
            this.lbIN201.Name = "lbIN201";
            this.lbIN201.Size = new System.Drawing.Size(39, 17);
            this.lbIN201.TabIndex = 39;
            this.lbIN201.Text = "I:201";
            // 
            // lbIN202
            // 
            this.lbIN202.AutoSize = true;
            this.lbIN202.BackColor = System.Drawing.Color.LightGray;
            this.lbIN202.Location = new System.Drawing.Point(316, 210);
            this.lbIN202.Name = "lbIN202";
            this.lbIN202.Size = new System.Drawing.Size(39, 17);
            this.lbIN202.TabIndex = 38;
            this.lbIN202.Text = "I:202";
            // 
            // lbIN203
            // 
            this.lbIN203.AutoSize = true;
            this.lbIN203.BackColor = System.Drawing.Color.LightGray;
            this.lbIN203.Location = new System.Drawing.Point(316, 242);
            this.lbIN203.Name = "lbIN203";
            this.lbIN203.Size = new System.Drawing.Size(39, 17);
            this.lbIN203.TabIndex = 39;
            this.lbIN203.Text = "I:203";
            // 
            // lbIN100
            // 
            this.lbIN100.AutoSize = true;
            this.lbIN100.BackColor = System.Drawing.Color.LightGray;
            this.lbIN100.Location = new System.Drawing.Point(119, 265);
            this.lbIN100.Name = "lbIN100";
            this.lbIN100.Size = new System.Drawing.Size(39, 17);
            this.lbIN100.TabIndex = 38;
            this.lbIN100.Text = "I:100";
            // 
            // lbIN101
            // 
            this.lbIN101.AutoSize = true;
            this.lbIN101.BackColor = System.Drawing.Color.LightGray;
            this.lbIN101.Location = new System.Drawing.Point(119, 297);
            this.lbIN101.Name = "lbIN101";
            this.lbIN101.Size = new System.Drawing.Size(39, 17);
            this.lbIN101.TabIndex = 38;
            this.lbIN101.Text = "I:101";
            // 
            // lbIN102
            // 
            this.lbIN102.AutoSize = true;
            this.lbIN102.BackColor = System.Drawing.Color.LightGray;
            this.lbIN102.Location = new System.Drawing.Point(264, 265);
            this.lbIN102.Name = "lbIN102";
            this.lbIN102.Size = new System.Drawing.Size(39, 17);
            this.lbIN102.TabIndex = 38;
            this.lbIN102.Text = "I:102";
            // 
            // lbIN103
            // 
            this.lbIN103.AutoSize = true;
            this.lbIN103.BackColor = System.Drawing.Color.LightGray;
            this.lbIN103.Location = new System.Drawing.Point(264, 297);
            this.lbIN103.Name = "lbIN103";
            this.lbIN103.Size = new System.Drawing.Size(39, 17);
            this.lbIN103.TabIndex = 38;
            this.lbIN103.Text = "I:103";
            // 
            // lbIN114
            // 
            this.lbIN114.AutoSize = true;
            this.lbIN114.BackColor = System.Drawing.Color.LightGray;
            this.lbIN114.Location = new System.Drawing.Point(119, 320);
            this.lbIN114.Name = "lbIN114";
            this.lbIN114.Size = new System.Drawing.Size(39, 17);
            this.lbIN114.TabIndex = 38;
            this.lbIN114.Text = "I:114";
            // 
            // lbIN115
            // 
            this.lbIN115.AutoSize = true;
            this.lbIN115.BackColor = System.Drawing.Color.LightGray;
            this.lbIN115.Location = new System.Drawing.Point(119, 352);
            this.lbIN115.Name = "lbIN115";
            this.lbIN115.Size = new System.Drawing.Size(39, 17);
            this.lbIN115.TabIndex = 38;
            this.lbIN115.Text = "I:115";
            // 
            // lbIN107
            // 
            this.lbIN107.AutoSize = true;
            this.lbIN107.BackColor = System.Drawing.Color.LightGray;
            this.lbIN107.Location = new System.Drawing.Point(119, 446);
            this.lbIN107.Name = "lbIN107";
            this.lbIN107.Size = new System.Drawing.Size(39, 17);
            this.lbIN107.TabIndex = 38;
            this.lbIN107.Text = "I:107";
            // 
            // lbIN108
            // 
            this.lbIN108.AutoSize = true;
            this.lbIN108.BackColor = System.Drawing.Color.LightGray;
            this.lbIN108.Location = new System.Drawing.Point(119, 478);
            this.lbIN108.Name = "lbIN108";
            this.lbIN108.Size = new System.Drawing.Size(39, 17);
            this.lbIN108.TabIndex = 38;
            this.lbIN108.Text = "I:108";
            // 
            // lbIN109
            // 
            this.lbIN109.AutoSize = true;
            this.lbIN109.BackColor = System.Drawing.Color.LightGray;
            this.lbIN109.Location = new System.Drawing.Point(264, 446);
            this.lbIN109.Name = "lbIN109";
            this.lbIN109.Size = new System.Drawing.Size(39, 17);
            this.lbIN109.TabIndex = 38;
            this.lbIN109.Text = "I:109";
            // 
            // lbIN110
            // 
            this.lbIN110.AutoSize = true;
            this.lbIN110.BackColor = System.Drawing.Color.LightGray;
            this.lbIN110.Location = new System.Drawing.Point(264, 478);
            this.lbIN110.Name = "lbIN110";
            this.lbIN110.Size = new System.Drawing.Size(39, 17);
            this.lbIN110.TabIndex = 38;
            this.lbIN110.Text = "I:110";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(21, 65);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(261, 25);
            this.label16.TabIndex = 40;
            this.label16.Text = "CONVEYER / SOLENOID";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(31, 349);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 20);
            this.label17.TabIndex = 41;
            this.label17.Text = "UPPER";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(31, 388);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 20);
            this.label18.TabIndex = 41;
            this.label18.Text = "UNDER";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(14, 57);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(397, 518);
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(417, 57);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(566, 268);
            this.pictureBox2.TabIndex = 43;
            this.pictureBox2.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(427, 65);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 25);
            this.label20.TabIndex = 44;
            this.label20.Text = "GLUE";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(417, 332);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(566, 243);
            this.pictureBox3.TabIndex = 45;
            this.pictureBox3.TabStop = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(427, 341);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(184, 25);
            this.label21.TabIndex = 44;
            this.label21.Text = "TOOLS CHANGE";
            this.label21.Visible = false;
            // 
            // btnManualPurge_ON
            // 
            this.btnManualPurge_ON.BackColor = System.Drawing.Color.LightGray;
            this.btnManualPurge_ON.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManualPurge_ON.Location = new System.Drawing.Point(734, 117);
            this.btnManualPurge_ON.Name = "btnManualPurge_ON";
            this.btnManualPurge_ON.Size = new System.Drawing.Size(94, 42);
            this.btnManualPurge_ON.TabIndex = 46;
            this.btnManualPurge_ON.Text = "Manual Purge ON";
            this.btnManualPurge_ON.UseVisualStyleBackColor = false;
            this.btnManualPurge_ON.Click += new System.EventHandler(this.btnManualPurge_ON_Click);
            this.btnManualPurge_ON.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnManualPurge_ON_MouseDown);
            this.btnManualPurge_ON.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnManualPurge_ON_MouseUp);
            // 
            // btnManualPurge_OFF
            // 
            this.btnManualPurge_OFF.BackColor = System.Drawing.Color.LightGray;
            this.btnManualPurge_OFF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManualPurge_OFF.Location = new System.Drawing.Point(834, 117);
            this.btnManualPurge_OFF.Name = "btnManualPurge_OFF";
            this.btnManualPurge_OFF.Size = new System.Drawing.Size(94, 42);
            this.btnManualPurge_OFF.TabIndex = 46;
            this.btnManualPurge_OFF.Text = "Manual Purge OFF";
            this.btnManualPurge_OFF.UseVisualStyleBackColor = false;
            this.btnManualPurge_OFF.Click += new System.EventHandler(this.btnManualPurge_OFF_Click);
            this.btnManualPurge_OFF.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnManualPurge_OFF_MouseDown);
            this.btnManualPurge_OFF.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnManualPurge_OFF_MouseUp);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(731, 98);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(151, 17);
            this.label19.TabIndex = 47;
            this.label19.Text = "Glue-1 Manual Purge :";
            // 
            // lbManualPurge_status
            // 
            this.lbManualPurge_status.AutoSize = true;
            this.lbManualPurge_status.BackColor = System.Drawing.Color.Crimson;
            this.lbManualPurge_status.Location = new System.Drawing.Point(882, 98);
            this.lbManualPurge_status.Name = "lbManualPurge_status";
            this.lbManualPurge_status.Size = new System.Drawing.Size(35, 17);
            this.lbManualPurge_status.TabIndex = 48;
            this.lbManualPurge_status.Text = "OFF";
            // 
            // btnAutoPurge_ON
            // 
            this.btnAutoPurge_ON.BackColor = System.Drawing.Color.LightGray;
            this.btnAutoPurge_ON.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAutoPurge_ON.Location = new System.Drawing.Point(432, 138);
            this.btnAutoPurge_ON.Name = "btnAutoPurge_ON";
            this.btnAutoPurge_ON.Size = new System.Drawing.Size(94, 42);
            this.btnAutoPurge_ON.TabIndex = 46;
            this.btnAutoPurge_ON.Text = " Auto  Purge ON";
            this.btnAutoPurge_ON.UseVisualStyleBackColor = false;
            this.btnAutoPurge_ON.Click += new System.EventHandler(this.btnAutoPurge_ON_Click);
            this.btnAutoPurge_ON.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnAutoPurge_ON_MouseDown);
            this.btnAutoPurge_ON.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnAutoPurge_ON_MouseUp);
            // 
            // btnAutoPurge_OFF
            // 
            this.btnAutoPurge_OFF.BackColor = System.Drawing.Color.LightGray;
            this.btnAutoPurge_OFF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAutoPurge_OFF.Location = new System.Drawing.Point(532, 138);
            this.btnAutoPurge_OFF.Name = "btnAutoPurge_OFF";
            this.btnAutoPurge_OFF.Size = new System.Drawing.Size(94, 42);
            this.btnAutoPurge_OFF.TabIndex = 46;
            this.btnAutoPurge_OFF.Text = " Auto  Purge OFF";
            this.btnAutoPurge_OFF.UseVisualStyleBackColor = false;
            this.btnAutoPurge_OFF.Click += new System.EventHandler(this.btnAutoPurge_OFF_Click);
            this.btnAutoPurge_OFF.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnAutoPurge_OFF_MouseDown);
            this.btnAutoPurge_OFF.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnAutoPurge_OFF_MouseUp);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(429, 110);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(141, 17);
            this.label22.TabIndex = 47;
            this.label22.Text = "Auto Purge function :";
            // 
            // lbAutoPurge_status
            // 
            this.lbAutoPurge_status.AutoSize = true;
            this.lbAutoPurge_status.BackColor = System.Drawing.Color.PaleGreen;
            this.lbAutoPurge_status.Location = new System.Drawing.Point(580, 110);
            this.lbAutoPurge_status.Name = "lbAutoPurge_status";
            this.lbAutoPurge_status.Size = new System.Drawing.Size(104, 17);
            this.lbAutoPurge_status.TabIndex = 48;
            this.lbAutoPurge_status.Text = "Auto Purge ON";
            // 
            // tbTimetoPurge
            // 
            this.tbTimetoPurge.Location = new System.Drawing.Point(607, 234);
            this.tbTimetoPurge.MaxLength = 2;
            this.tbTimetoPurge.Name = "tbTimetoPurge";
            this.tbTimetoPurge.ReadOnly = true;
            this.tbTimetoPurge.Size = new System.Drawing.Size(70, 22);
            this.tbTimetoPurge.TabIndex = 49;
            this.tbTimetoPurge.Text = "0";
            this.tbTimetoPurge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbTimetoPurge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTimetoPurge_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.White;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(429, 237);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(167, 17);
            this.label24.TabIndex = 47;
            this.label24.Text = "Time to auto purge every";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.White;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(683, 237);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(34, 17);
            this.label25.TabIndex = 47;
            this.label25.Text = "sec.";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.White;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(431, 205);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(76, 17);
            this.label26.TabIndex = 47;
            this.label26.Text = "Purge time";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.White;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(594, 205);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(34, 17);
            this.label27.TabIndex = 47;
            this.label27.Text = "sec.";
            // 
            // tbPurgeTime
            // 
            this.tbPurgeTime.Location = new System.Drawing.Point(518, 202);
            this.tbPurgeTime.MaxLength = 6;
            this.tbPurgeTime.Name = "tbPurgeTime";
            this.tbPurgeTime.ReadOnly = true;
            this.tbPurgeTime.Size = new System.Drawing.Size(70, 22);
            this.tbPurgeTime.TabIndex = 49;
            this.tbPurgeTime.Text = "0";
            this.tbPurgeTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbPurgeTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPurgeTime_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(431, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 17);
            this.label2.TabIndex = 50;
            this.label2.Text = "Time count to auto purge";
            // 
            // tbTimeCountToPurge
            // 
            this.tbTimeCountToPurge.Location = new System.Drawing.Point(604, 268);
            this.tbTimeCountToPurge.MaxLength = 2;
            this.tbTimeCountToPurge.Name = "tbTimeCountToPurge";
            this.tbTimeCountToPurge.ReadOnly = true;
            this.tbTimeCountToPurge.Size = new System.Drawing.Size(70, 22);
            this.tbTimeCountToPurge.TabIndex = 52;
            this.tbTimeCountToPurge.Text = "0";
            this.tbTimeCountToPurge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(680, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 17);
            this.label3.TabIndex = 51;
            this.label3.Text = "sec.";
            // 
            // btnResetTimeCount
            // 
            this.btnResetTimeCount.BackColor = System.Drawing.Color.LightGray;
            this.btnResetTimeCount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResetTimeCount.Location = new System.Drawing.Point(720, 263);
            this.btnResetTimeCount.Name = "btnResetTimeCount";
            this.btnResetTimeCount.Size = new System.Drawing.Size(70, 33);
            this.btnResetTimeCount.TabIndex = 53;
            this.btnResetTimeCount.Text = "RESET";
            this.btnResetTimeCount.UseVisualStyleBackColor = false;
            this.btnResetTimeCount.Click += new System.EventHandler(this.btnResetTimeCount_Click);
            // 
            // btnTool2_Pick
            // 
            this.btnTool2_Pick.BackColor = System.Drawing.Color.LightGray;
            this.btnTool2_Pick.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTool2_Pick.Location = new System.Drawing.Point(434, 390);
            this.btnTool2_Pick.Name = "btnTool2_Pick";
            this.btnTool2_Pick.Size = new System.Drawing.Size(115, 47);
            this.btnTool2_Pick.TabIndex = 54;
            this.btnTool2_Pick.Text = "Tool 2 Pick";
            this.btnTool2_Pick.UseVisualStyleBackColor = false;
            this.btnTool2_Pick.Visible = false;
            this.btnTool2_Pick.Click += new System.EventHandler(this.btnTool2_Pick_Click);
            // 
            // btnTool2_Place
            // 
            this.btnTool2_Place.BackColor = System.Drawing.Color.LightGray;
            this.btnTool2_Place.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTool2_Place.Location = new System.Drawing.Point(434, 443);
            this.btnTool2_Place.Name = "btnTool2_Place";
            this.btnTool2_Place.Size = new System.Drawing.Size(115, 47);
            this.btnTool2_Place.TabIndex = 55;
            this.btnTool2_Place.Text = "Tool 2 Place";
            this.btnTool2_Place.UseVisualStyleBackColor = false;
            this.btnTool2_Place.Visible = false;
            this.btnTool2_Place.Click += new System.EventHandler(this.btnTool2_Place_Click);
            // 
            // btnTool1_Pick
            // 
            this.btnTool1_Pick.BackColor = System.Drawing.Color.LightGray;
            this.btnTool1_Pick.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTool1_Pick.Location = new System.Drawing.Point(850, 390);
            this.btnTool1_Pick.Name = "btnTool1_Pick";
            this.btnTool1_Pick.Size = new System.Drawing.Size(115, 47);
            this.btnTool1_Pick.TabIndex = 54;
            this.btnTool1_Pick.Text = "Tool 1 Pick";
            this.btnTool1_Pick.UseVisualStyleBackColor = false;
            this.btnTool1_Pick.Visible = false;
            this.btnTool1_Pick.Click += new System.EventHandler(this.btnTool1_Pick_Click);
            // 
            // btnTool1_Place
            // 
            this.btnTool1_Place.BackColor = System.Drawing.Color.LightGray;
            this.btnTool1_Place.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTool1_Place.Location = new System.Drawing.Point(850, 443);
            this.btnTool1_Place.Name = "btnTool1_Place";
            this.btnTool1_Place.Size = new System.Drawing.Size(115, 47);
            this.btnTool1_Place.TabIndex = 55;
            this.btnTool1_Place.Text = "Tool 1 Place";
            this.btnTool1_Place.UseVisualStyleBackColor = false;
            this.btnTool1_Place.Visible = false;
            this.btnTool1_Place.Click += new System.EventHandler(this.btnTool1_Place_Click);
            // 
            // btnTool2_LockUnLock
            // 
            this.btnTool2_LockUnLock.BackColor = System.Drawing.Color.LightGray;
            this.btnTool2_LockUnLock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTool2_LockUnLock.Location = new System.Drawing.Point(555, 390);
            this.btnTool2_LockUnLock.Name = "btnTool2_LockUnLock";
            this.btnTool2_LockUnLock.Size = new System.Drawing.Size(115, 47);
            this.btnTool2_LockUnLock.TabIndex = 54;
            this.btnTool2_LockUnLock.Text = "Tool 2 Lock/Un-Lock";
            this.btnTool2_LockUnLock.UseVisualStyleBackColor = false;
            this.btnTool2_LockUnLock.Visible = false;
            this.btnTool2_LockUnLock.Click += new System.EventHandler(this.btnTool2_LockUnLock_Click);
            // 
            // btnTool2_INOUT
            // 
            this.btnTool2_INOUT.BackColor = System.Drawing.Color.LightGray;
            this.btnTool2_INOUT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTool2_INOUT.Location = new System.Drawing.Point(555, 443);
            this.btnTool2_INOUT.Name = "btnTool2_INOUT";
            this.btnTool2_INOUT.Size = new System.Drawing.Size(115, 47);
            this.btnTool2_INOUT.TabIndex = 55;
            this.btnTool2_INOUT.Text = "Tool 2 Move IN-OUT";
            this.btnTool2_INOUT.UseVisualStyleBackColor = false;
            this.btnTool2_INOUT.Visible = false;
            this.btnTool2_INOUT.Click += new System.EventHandler(this.btnTool2_INOUT_Click);
            // 
            // btnTool1_LockUnLock
            // 
            this.btnTool1_LockUnLock.BackColor = System.Drawing.Color.LightGray;
            this.btnTool1_LockUnLock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTool1_LockUnLock.Location = new System.Drawing.Point(729, 390);
            this.btnTool1_LockUnLock.Name = "btnTool1_LockUnLock";
            this.btnTool1_LockUnLock.Size = new System.Drawing.Size(115, 47);
            this.btnTool1_LockUnLock.TabIndex = 54;
            this.btnTool1_LockUnLock.Text = "Tool 1 Lock/Un-Lock";
            this.btnTool1_LockUnLock.UseVisualStyleBackColor = false;
            this.btnTool1_LockUnLock.Visible = false;
            this.btnTool1_LockUnLock.Click += new System.EventHandler(this.btnTool1_LockUnLock_Click);
            // 
            // btnTool1_INOUT
            // 
            this.btnTool1_INOUT.BackColor = System.Drawing.Color.LightGray;
            this.btnTool1_INOUT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTool1_INOUT.Location = new System.Drawing.Point(729, 443);
            this.btnTool1_INOUT.Name = "btnTool1_INOUT";
            this.btnTool1_INOUT.Size = new System.Drawing.Size(115, 47);
            this.btnTool1_INOUT.TabIndex = 55;
            this.btnTool1_INOUT.Text = "Tool 1 Move IN-OUT";
            this.btnTool1_INOUT.UseVisualStyleBackColor = false;
            this.btnTool1_INOUT.Visible = false;
            this.btnTool1_INOUT.Click += new System.EventHandler(this.btnTool1_INOUT_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Black;
            this.pictureBox4.Location = new System.Drawing.Point(695, 397);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(10, 90);
            this.pictureBox4.TabIndex = 37;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // lbIN307
            // 
            this.lbIN307.AutoSize = true;
            this.lbIN307.BackColor = System.Drawing.Color.LightGray;
            this.lbIN307.Location = new System.Drawing.Point(631, 370);
            this.lbIN307.Name = "lbIN307";
            this.lbIN307.Size = new System.Drawing.Size(39, 17);
            this.lbIN307.TabIndex = 57;
            this.lbIN307.Text = "I:307";
            this.lbIN307.Visible = false;
            // 
            // lbIN308
            // 
            this.lbIN308.AutoSize = true;
            this.lbIN308.BackColor = System.Drawing.Color.LightGray;
            this.lbIN308.Location = new System.Drawing.Point(557, 370);
            this.lbIN308.Name = "lbIN308";
            this.lbIN308.Size = new System.Drawing.Size(39, 17);
            this.lbIN308.TabIndex = 57;
            this.lbIN308.Text = "I:308";
            this.lbIN308.Visible = false;
            // 
            // lbIN306
            // 
            this.lbIN306.AutoSize = true;
            this.lbIN306.BackColor = System.Drawing.Color.LightGray;
            this.lbIN306.Location = new System.Drawing.Point(631, 493);
            this.lbIN306.Name = "lbIN306";
            this.lbIN306.Size = new System.Drawing.Size(39, 17);
            this.lbIN306.TabIndex = 57;
            this.lbIN306.Text = "I:306";
            this.lbIN306.Visible = false;
            // 
            // lbIN305
            // 
            this.lbIN305.AutoSize = true;
            this.lbIN305.BackColor = System.Drawing.Color.LightGray;
            this.lbIN305.Location = new System.Drawing.Point(557, 493);
            this.lbIN305.Name = "lbIN305";
            this.lbIN305.Size = new System.Drawing.Size(39, 17);
            this.lbIN305.TabIndex = 57;
            this.lbIN305.Text = "I:305";
            this.lbIN305.Visible = false;
            // 
            // lbIN303
            // 
            this.lbIN303.AutoSize = true;
            this.lbIN303.BackColor = System.Drawing.Color.LightGray;
            this.lbIN303.Location = new System.Drawing.Point(802, 370);
            this.lbIN303.Name = "lbIN303";
            this.lbIN303.Size = new System.Drawing.Size(39, 17);
            this.lbIN303.TabIndex = 57;
            this.lbIN303.Text = "I:303";
            this.lbIN303.Visible = false;
            // 
            // lbIN302
            // 
            this.lbIN302.AutoSize = true;
            this.lbIN302.BackColor = System.Drawing.Color.LightGray;
            this.lbIN302.Location = new System.Drawing.Point(728, 370);
            this.lbIN302.Name = "lbIN302";
            this.lbIN302.Size = new System.Drawing.Size(39, 17);
            this.lbIN302.TabIndex = 57;
            this.lbIN302.Text = "I:302";
            this.lbIN302.Visible = false;
            // 
            // lbIN300
            // 
            this.lbIN300.AutoSize = true;
            this.lbIN300.BackColor = System.Drawing.Color.LightGray;
            this.lbIN300.Location = new System.Drawing.Point(802, 493);
            this.lbIN300.Name = "lbIN300";
            this.lbIN300.Size = new System.Drawing.Size(39, 17);
            this.lbIN300.TabIndex = 57;
            this.lbIN300.Text = "I:300";
            this.lbIN300.Visible = false;
            // 
            // lbIN301
            // 
            this.lbIN301.AutoSize = true;
            this.lbIN301.BackColor = System.Drawing.Color.LightGray;
            this.lbIN301.Location = new System.Drawing.Point(728, 493);
            this.lbIN301.Name = "lbIN301";
            this.lbIN301.Size = new System.Drawing.Size(39, 17);
            this.lbIN301.TabIndex = 57;
            this.lbIN301.Text = "I:301";
            this.lbIN301.Visible = false;
            // 
            // lbManualPurge2_status
            // 
            this.lbManualPurge2_status.AutoSize = true;
            this.lbManualPurge2_status.BackColor = System.Drawing.Color.Crimson;
            this.lbManualPurge2_status.Location = new System.Drawing.Point(882, 166);
            this.lbManualPurge2_status.Name = "lbManualPurge2_status";
            this.lbManualPurge2_status.Size = new System.Drawing.Size(35, 17);
            this.lbManualPurge2_status.TabIndex = 61;
            this.lbManualPurge2_status.Text = "OFF";
            this.lbManualPurge2_status.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(731, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 17);
            this.label5.TabIndex = 60;
            this.label5.Text = "Glue-2 Manual Purge :";
            this.label5.Visible = false;
            // 
            // btnManualPurge2_OFF
            // 
            this.btnManualPurge2_OFF.BackColor = System.Drawing.Color.LightGray;
            this.btnManualPurge2_OFF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManualPurge2_OFF.Location = new System.Drawing.Point(834, 185);
            this.btnManualPurge2_OFF.Name = "btnManualPurge2_OFF";
            this.btnManualPurge2_OFF.Size = new System.Drawing.Size(94, 42);
            this.btnManualPurge2_OFF.TabIndex = 58;
            this.btnManualPurge2_OFF.Text = "Manual Purge OFF";
            this.btnManualPurge2_OFF.UseVisualStyleBackColor = false;
            this.btnManualPurge2_OFF.Visible = false;
            this.btnManualPurge2_OFF.Click += new System.EventHandler(this.btnManualPurge2_OFF_Click);
            // 
            // btnManualPurge2_ON
            // 
            this.btnManualPurge2_ON.BackColor = System.Drawing.Color.LightGray;
            this.btnManualPurge2_ON.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManualPurge2_ON.Location = new System.Drawing.Point(734, 185);
            this.btnManualPurge2_ON.Name = "btnManualPurge2_ON";
            this.btnManualPurge2_ON.Size = new System.Drawing.Size(94, 42);
            this.btnManualPurge2_ON.TabIndex = 59;
            this.btnManualPurge2_ON.Text = "Manual Purge ON";
            this.btnManualPurge2_ON.UseVisualStyleBackColor = false;
            this.btnManualPurge2_ON.Visible = false;
            this.btnManualPurge2_ON.Click += new System.EventHandler(this.btnManualPurge2_ON_Click);
            // 
            // btnCameraLight
            // 
            this.btnCameraLight.BackColor = System.Drawing.Color.LightGray;
            this.btnCameraLight.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCameraLight.Location = new System.Drawing.Point(164, 510);
            this.btnCameraLight.Name = "btnCameraLight";
            this.btnCameraLight.Size = new System.Drawing.Size(94, 49);
            this.btnCameraLight.TabIndex = 62;
            this.btnCameraLight.Text = "CAMERA LIGHT";
            this.btnCameraLight.UseVisualStyleBackColor = false;
            this.btnCameraLight.Click += new System.EventHandler(this.btnCameraLight_Click);
            // 
            // btnToolsUnClamp
            // 
            this.btnToolsUnClamp.BackColor = System.Drawing.Color.LightGray;
            this.btnToolsUnClamp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnToolsUnClamp.Location = new System.Drawing.Point(713, 518);
            this.btnToolsUnClamp.Name = "btnToolsUnClamp";
            this.btnToolsUnClamp.Size = new System.Drawing.Size(131, 47);
            this.btnToolsUnClamp.TabIndex = 65;
            this.btnToolsUnClamp.Text = "Tools Un-Clamp";
            this.btnToolsUnClamp.UseVisualStyleBackColor = false;
            this.btnToolsUnClamp.Visible = false;
            this.btnToolsUnClamp.Click += new System.EventHandler(this.btnToolsUnClamp_Click);
            // 
            // btnToolsClamp
            // 
            this.btnToolsClamp.BackColor = System.Drawing.Color.LightGray;
            this.btnToolsClamp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnToolsClamp.Location = new System.Drawing.Point(560, 518);
            this.btnToolsClamp.Name = "btnToolsClamp";
            this.btnToolsClamp.Size = new System.Drawing.Size(131, 47);
            this.btnToolsClamp.TabIndex = 64;
            this.btnToolsClamp.Text = "Tools Clamp";
            this.btnToolsClamp.UseVisualStyleBackColor = false;
            this.btnToolsClamp.Visible = false;
            this.btnToolsClamp.Click += new System.EventHandler(this.btnToolsClamp_Click);
            // 
            // ucEquipmentControls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnToolsUnClamp);
            this.Controls.Add(this.btnToolsClamp);
            this.Controls.Add(this.btnCameraLight);
            this.Controls.Add(this.lbManualPurge2_status);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnManualPurge2_OFF);
            this.Controls.Add(this.btnManualPurge2_ON);
            this.Controls.Add(this.lbIN301);
            this.Controls.Add(this.lbIN305);
            this.Controls.Add(this.lbIN300);
            this.Controls.Add(this.lbIN306);
            this.Controls.Add(this.lbIN302);
            this.Controls.Add(this.lbIN303);
            this.Controls.Add(this.lbIN308);
            this.Controls.Add(this.lbIN307);
            this.Controls.Add(this.btnTool1_INOUT);
            this.Controls.Add(this.btnTool1_Place);
            this.Controls.Add(this.btnTool2_INOUT);
            this.Controls.Add(this.btnTool2_Place);
            this.Controls.Add(this.btnTool1_LockUnLock);
            this.Controls.Add(this.btnTool2_LockUnLock);
            this.Controls.Add(this.btnTool1_Pick);
            this.Controls.Add(this.btnTool2_Pick);
            this.Controls.Add(this.btnResetTimeCount);
            this.Controls.Add(this.tbTimeCountToPurge);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbPurgeTime);
            this.Controls.Add(this.tbTimetoPurge);
            this.Controls.Add(this.lbAutoPurge_status);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.lbManualPurge_status);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.btnAutoPurge_OFF);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.btnAutoPurge_ON);
            this.Controls.Add(this.btnManualPurge_OFF);
            this.Controls.Add(this.btnManualPurge_ON);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.lbIN203);
            this.Controls.Add(this.lbIN201);
            this.Controls.Add(this.lbIN202);
            this.Controls.Add(this.lbIN110);
            this.Controls.Add(this.lbIN103);
            this.Controls.Add(this.lbIN109);
            this.Controls.Add(this.lbIN102);
            this.Controls.Add(this.lbIN108);
            this.Controls.Add(this.lbIN101);
            this.Controls.Add(this.lbIN107);
            this.Controls.Add(this.lbIN100);
            this.Controls.Add(this.lbIN115);
            this.Controls.Add(this.lbIN114);
            this.Controls.Add(this.lbIN200);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.btnDownCVMove_R);
            this.Controls.Add(this.btnDownCVMove_L);
            this.Controls.Add(this.btnUpCVMove_R);
            this.Controls.Add(this.btnUpCVMove_L);
            this.Controls.Add(this.btnStopper_Under);
            this.Controls.Add(this.btnRFID_R);
            this.Controls.Add(this.btnRFID_L);
            this.Controls.Add(this.btnPalletLock);
            this.Controls.Add(this.btnStopper_Upper);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Name = "ucEquipmentControls";
            this.Size = new System.Drawing.Size(1000, 600);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnStopper_Upper;
        private System.Windows.Forms.Button btnPalletLock;
        private System.Windows.Forms.Button btnRFID_L;
        private System.Windows.Forms.Button btnRFID_R;
        private System.Windows.Forms.Button btnStopper_Under;
        private System.Windows.Forms.Button btnUpCVMove_L;
        private System.Windows.Forms.Button btnUpCVMove_R;
        private System.Windows.Forms.Button btnDownCVMove_R;
        private System.Windows.Forms.Button btnDownCVMove_L;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lbIN200;
        private System.Windows.Forms.Label lbIN201;
        private System.Windows.Forms.Label lbIN202;
        private System.Windows.Forms.Label lbIN203;
        private System.Windows.Forms.Label lbIN100;
        private System.Windows.Forms.Label lbIN101;
        private System.Windows.Forms.Label lbIN102;
        private System.Windows.Forms.Label lbIN103;
        private System.Windows.Forms.Label lbIN114;
        private System.Windows.Forms.Label lbIN115;
        private System.Windows.Forms.Label lbIN107;
        private System.Windows.Forms.Label lbIN108;
        private System.Windows.Forms.Label lbIN109;
        private System.Windows.Forms.Label lbIN110;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnManualPurge_ON;
        private System.Windows.Forms.Button btnManualPurge_OFF;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lbManualPurge_status;
        private System.Windows.Forms.Button btnAutoPurge_ON;
        private System.Windows.Forms.Button btnAutoPurge_OFF;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbAutoPurge_status;
        private System.Windows.Forms.TextBox tbTimetoPurge;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox tbPurgeTime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbTimeCountToPurge;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnResetTimeCount;
        private System.Windows.Forms.Button btnTool2_Pick;
        private System.Windows.Forms.Button btnTool2_Place;
        private System.Windows.Forms.Button btnTool1_Pick;
        private System.Windows.Forms.Button btnTool1_Place;
        private System.Windows.Forms.Button btnTool2_LockUnLock;
        private System.Windows.Forms.Button btnTool2_INOUT;
        private System.Windows.Forms.Button btnTool1_LockUnLock;
        private System.Windows.Forms.Button btnTool1_INOUT;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label lbIN307;
        private System.Windows.Forms.Label lbIN308;
        private System.Windows.Forms.Label lbIN306;
        private System.Windows.Forms.Label lbIN305;
        private System.Windows.Forms.Label lbIN303;
        private System.Windows.Forms.Label lbIN302;
        private System.Windows.Forms.Label lbIN300;
        private System.Windows.Forms.Label lbIN301;
        private System.Windows.Forms.Label lbManualPurge2_status;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnManualPurge2_OFF;
        private System.Windows.Forms.Button btnManualPurge2_ON;
        private System.Windows.Forms.Button btnCameraLight;
        private System.Windows.Forms.Button btnToolsUnClamp;
        private System.Windows.Forms.Button btnToolsClamp;
    }
}
