﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Prototype_App
{
    class clsIAIFunc
    {
        iVariableShare _Common;
        private clsMES _clsmes;
        //private CancellationTokenSource cancellationTokenSource;

        public clsIAIFunc(iVariableShare common)
        {
            
            _Common = common;
            _clsmes = new clsMES(_Common);
         
        }
        public void IAIMain(CancellationToken cancellationToken) 
        {

            while (!cancellationToken.IsCancellationRequested)
            {
                // Do your work here
                if (_Common.ienableFunc && _Common.iProcessFinish) // ProcessFinish need 1 pluse
                {
                    //_clsmes.MES_Send_Check();

                }
                else
                {

                }
                Thread.Sleep(1000); // Simulate work 
                Console.WriteLine("IAI Main");
                Thread.Sleep(1000); // Simulate work              
            }

        }

    }
}
