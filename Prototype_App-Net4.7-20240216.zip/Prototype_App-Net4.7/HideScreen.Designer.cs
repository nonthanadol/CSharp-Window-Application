﻿namespace Prototype_App
{
    partial class HideScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HideScreen));
            this.lbValueEnableFunc = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbValueUpdateResult = new System.Windows.Forms.Label();
            this.lbUpdateResult = new System.Windows.Forms.Label();
            this.lbValueCheckResult = new System.Windows.Forms.Label();
            this.lbCheckResult = new System.Windows.Forms.Label();
            this.lbValueSN = new System.Windows.Forms.Label();
            this.lbSN = new System.Windows.Forms.Label();
            this.btnUnHide = new System.Windows.Forms.Button();
            this.UpdateUI = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // lbValueEnableFunc
            // 
            this.lbValueEnableFunc.AutoSize = true;
            this.lbValueEnableFunc.BackColor = System.Drawing.Color.White;
            this.lbValueEnableFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbValueEnableFunc.Location = new System.Drawing.Point(995, 101);
            this.lbValueEnableFunc.Name = "lbValueEnableFunc";
            this.lbValueEnableFunc.Size = new System.Drawing.Size(39, 36);
            this.lbValueEnableFunc.TabIndex = 17;
            this.lbValueEnableFunc.Text = "...";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label1.Location = new System.Drawing.Point(789, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 36);
            this.label1.TabIndex = 16;
            this.label1.Text = "EnableFunc :";
            // 
            // lbValueUpdateResult
            // 
            this.lbValueUpdateResult.AutoSize = true;
            this.lbValueUpdateResult.BackColor = System.Drawing.Color.White;
            this.lbValueUpdateResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbValueUpdateResult.Location = new System.Drawing.Point(639, 190);
            this.lbValueUpdateResult.Name = "lbValueUpdateResult";
            this.lbValueUpdateResult.Size = new System.Drawing.Size(72, 63);
            this.lbValueUpdateResult.TabIndex = 15;
            this.lbValueUpdateResult.Text = "...";
            // 
            // lbUpdateResult
            // 
            this.lbUpdateResult.AutoSize = true;
            this.lbUpdateResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbUpdateResult.Location = new System.Drawing.Point(11, 190);
            this.lbUpdateResult.Name = "lbUpdateResult";
            this.lbUpdateResult.Size = new System.Drawing.Size(613, 63);
            this.lbUpdateResult.TabIndex = 14;
            this.lbUpdateResult.Text = "Routing Update Result  :";
            // 
            // lbValueCheckResult
            // 
            this.lbValueCheckResult.AutoSize = true;
            this.lbValueCheckResult.BackColor = System.Drawing.Color.White;
            this.lbValueCheckResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbValueCheckResult.Location = new System.Drawing.Point(639, 101);
            this.lbValueCheckResult.Name = "lbValueCheckResult";
            this.lbValueCheckResult.Size = new System.Drawing.Size(72, 63);
            this.lbValueCheckResult.TabIndex = 13;
            this.lbValueCheckResult.Text = "...";
            // 
            // lbCheckResult
            // 
            this.lbCheckResult.AutoSize = true;
            this.lbCheckResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbCheckResult.Location = new System.Drawing.Point(11, 101);
            this.lbCheckResult.Name = "lbCheckResult";
            this.lbCheckResult.Size = new System.Drawing.Size(592, 63);
            this.lbCheckResult.TabIndex = 12;
            this.lbCheckResult.Text = "Routing Check Result  :";
            // 
            // lbValueSN
            // 
            this.lbValueSN.AutoSize = true;
            this.lbValueSN.BackColor = System.Drawing.Color.White;
            this.lbValueSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbValueSN.Location = new System.Drawing.Point(443, 17);
            this.lbValueSN.Name = "lbValueSN";
            this.lbValueSN.Size = new System.Drawing.Size(72, 63);
            this.lbValueSN.TabIndex = 11;
            this.lbValueSN.Text = "...";
            // 
            // lbSN
            // 
            this.lbSN.AutoSize = true;
            this.lbSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbSN.Location = new System.Drawing.Point(11, 17);
            this.lbSN.Name = "lbSN";
            this.lbSN.Size = new System.Drawing.Size(402, 63);
            this.lbSN.TabIndex = 10;
            this.lbSN.Text = "Serial Number :";
            // 
            // btnUnHide
            // 
            this.btnUnHide.Location = new System.Drawing.Point(950, 188);
            this.btnUnHide.Name = "btnUnHide";
            this.btnUnHide.Size = new System.Drawing.Size(135, 73);
            this.btnUnHide.TabIndex = 9;
            this.btnUnHide.Text = "UnHide";
            this.btnUnHide.UseVisualStyleBackColor = true;
            this.btnUnHide.Click += new System.EventHandler(this.btnUnHide_Click);
            // 
            // UpdateUI
            // 
            this.UpdateUI.Enabled = true;
            this.UpdateUI.Interval = 500;
            this.UpdateUI.Tick += new System.EventHandler(this.UpdateUI_Tick);
            // 
            // HideScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1097, 287);
            this.Controls.Add(this.lbValueEnableFunc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbValueUpdateResult);
            this.Controls.Add(this.lbUpdateResult);
            this.Controls.Add(this.lbValueCheckResult);
            this.Controls.Add(this.lbCheckResult);
            this.Controls.Add(this.lbValueSN);
            this.Controls.Add(this.lbSN);
            this.Controls.Add(this.btnUnHide);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HideScreen";
            this.Text = "PrototypeHideScreen";
            this.Load += new System.EventHandler(this.HideScreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbValueEnableFunc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbValueUpdateResult;
        private System.Windows.Forms.Label lbUpdateResult;
        private System.Windows.Forms.Label lbValueCheckResult;
        private System.Windows.Forms.Label lbCheckResult;
        private System.Windows.Forms.Label lbValueSN;
        private System.Windows.Forms.Label lbSN;
        private System.Windows.Forms.Button btnUnHide;
        private System.Windows.Forms.Timer UpdateUI;
    }
}