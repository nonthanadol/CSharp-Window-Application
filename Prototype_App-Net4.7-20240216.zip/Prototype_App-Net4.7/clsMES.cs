﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using nsShopFloor;
using Prototype_App_MES;

namespace Prototype_App
{
    class clsMES
    {
        string getSNinfo_status;
        iVariableShare _Common = new iVariableShare();
        private uc_LogFileSetting _log;
        public clsMES(iVariableShare common)
        {
            _Common = common;
            _log = new uc_LogFileSetting(_Common);
        }

        public void MES_Initialize()
        {
            if (Properties.Settings.Default.EnableMES)
            {
                _Common.MES = new clsShopfloor_Http_Client(Properties.Settings.Default.MES_URL, Properties.Settings.Default.Key, Properties.Settings.Default.Token);
            }
        }
        public void MES_Send_Check()
        {
            // GET_SN_INFO -> store Model , MO , Line to use with 'MES_Send_Update -> ROUTING_Check'
            string sn;
            string pTest_data;
            string pLog_data;

            getSNinfo_status = "";
            _Common.iMES_MO = "";
            _Common.iMES_Model = "";
            _Common.iMES_WipLine = "";

            ResMsg_1 ReceiveSNInfo = new ResMsg_1();
            ResMsg MESChkResult = new ResMsg();

            _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResult), false);
            _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResultNG), false);

            if (Properties.Settings.Default.EnableMES && _Common.iPLCconnectStatus == "Connected" && _Common.iRFID_Barcode != null)
            {

            MES_SEND_AGAIN:
                _Common.iMES_Result_Check = "";
                getSNinfo_status = "";
                try
                {           
                    sn = _Common.iRFID_Barcode.Trim('\0') + "}";
                    ReceiveSNInfo = _Common.MES.GET_SN_INFO(Properties.Settings.Default.Factory, sn, "");

                    _Common.iMES_MO = ReceiveSNInfo.description.MO;
                    _Common.iMES_Model = ReceiveSNInfo.description.Model;
                    _Common.iMES_WipLine = ReceiveSNInfo.description.WipLine;
                    getSNinfo_status = "TURE";

                }
                catch
                {
                    getSNinfo_status = "FAIL";
                    //DialogResult re = MessageBox.Show("Can't Get SN info", "", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                }
              
                if (getSNinfo_status == "TURE")
                {
                    //_Common.records.Add(new clsCSV_Column() { SerialNumber = _Common.iRFID_Barcode,Result = "GET_SN_INFO PASS", Time = DateTime.Now.ToString() });
                    _log.addDataTable(_Common.iRFID_Barcode, "GET_SN_INFO PASS");
                    pTest_data = _Common.iRFID_Barcode.Trim('\0') + "}" + _Common.iMES_MO + "}" + _Common.iMES_Model + "}" + _Common.iMES_WipLine + "}" + _Common.iMES_Section + "}" + _Common.iMES_Group + "}" + _Common.iMES_Station + "}";
                    pLog_data = "";

                    try
                    {
                        MESChkResult = _Common.MES.ROUTING_Check(Properties.Settings.Default.Factory, pTest_data, pLog_data);
                        Console.WriteLine(pTest_data);
                    }
                    catch (Exception ex)
                    {
                        DialogResult re = MessageBox.Show("Routing Check Fail", "", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                    }

                    _Common.iMES_Result_Check = MESChkResult.Result;

                    if (MESChkResult.Result == "OK")
                    {
                        //_Common.records.Add(new clsCSV_Column() { SerialNumber = _Common.iRFID_Barcode, Result = "ROUTING_Check PASS", Time = DateTime.Now.ToString() });
                        _log.addDataTable(_Common.iRFID_Barcode, "ROUTING_Check PASS");
                        _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResult), true);
                        _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResultNG), false);

                    }
                    else
                    {
                        //_Common.records.Add(new clsCSV_Column() { SerialNumber = _Common.iRFID_Barcode, Result = "ROUTING_Check FAIL", Time = DateTime.Now.ToString() });
                        _log.addDataTable(_Common.iRFID_Barcode, "ROUTING_Check FAIL");
                        _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResult), false);
                        _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResultNG), true);

                        //DialogResult re = MessageBox.Show("MES Check Fail\n | Cancel = Reject and send to next\n | Retry = try again\n | Ignore = Skip Check Routing MES", "MES Check Routing Fail", MessageBoxButtons.RetryCancel, MessageBoxIcon.Question);
                        DialogResult re = MessageBox.Show("MES Check Fail\n | Next Station is " + ReceiveSNInfo.description.NextGroup[0] + "\n | Cancel = Reject and send to next\n | Retry = try again\n ", "MES Check Routing Fail", MessageBoxButtons.RetryCancel, MessageBoxIcon.Question);
                        
                        if (re == DialogResult.Cancel)
                        {
                            //_Common.records.Add(new clsCSV_Column() { SerialNumber = _Common.iRFID_Barcode, Result = "Force Pass", Time = DateTime.Now.ToString() });
                            _log.addDataTable(_Common.iRFID_Barcode, "Force Pass");
                            _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResult), true);
                            _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResultNG), false);
                        }
                        else if (re == DialogResult.Retry) { goto MES_SEND_AGAIN; }
                        else { /*Nothing to do*/ }

                    }
                }
                else //GET_SN_INFO FAIL
                {
                    //_Common.records.Add(new clsCSV_Column() { SerialNumber = _Common.iRFID_Barcode, Result = "GET_SN_INFO FAIL", Time = DateTime.Now.ToString() });                  
                    _log.addDataTable(_Common.iRFID_Barcode, "GET_SN_INFO FAIL");
                    _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResult), false);
                    _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResultNG), true);

                    DialogResult re1 = MessageBox.Show("Get SN info Fail\n | Cancel = Reject and send to next\n | Retry = try again\n ", "MES Get SN info Fail", MessageBoxButtons.RetryCancel, MessageBoxIcon.Question);
                    if (re1 == DialogResult.Cancel)
                    {
                        //_Common.records.Add(new clsCSV_Column() { SerialNumber = _Common.iRFID_Barcode, Result = "Force Pass", Time = DateTime.Now.ToString() });
                        _log.addDataTable(_Common.iRFID_Barcode, "Force Pass");
                        _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResult), true);
                        _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResultNG), false);
                    }
                    else if (re1 == DialogResult.Retry) { goto MES_SEND_AGAIN; }
                    else { }
                }

                //MessageBox.Show(MESChkResult.Result);

            }
        }
        public void MES_Send_Update()
        {
            string pTest_data;
            string pLog_data;
            ResMsg MESChkResult = new ResMsg();

            if (Properties.Settings.Default.EnableMES && _Common.iPLCconnectStatus == "Connected" && _Common.iRFID_Barcode != "")
            {

                pTest_data = _Common.iRFID_Barcode.Trim('\0') + "}" + _Common.iMES_MO + "}" + _Common.iMES_Model + "}" + _Common.iMES_WipLine + "}" + _Common.iMES_Section + "}" + _Common.iMES_Group + "}" + _Common.iMES_Station
                        + "}0}PASS}User}" + _Common.iInterfaceID + "}1}none}";

                pLog_data = ""; //input data if have data need to send -> "data}data}" <- wait test.

                try
                {
                    MESChkResult = _Common.MES.ROUTING_Update(Properties.Settings.Default.Factory, pTest_data, pLog_data);
                }
                catch (Exception ex) { }
                MessageBox.Show(MESChkResult.Result);
            }
        }

    }
}
