﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.Windows.Forms;
using CsvHelper;
using Prototype_App_PQM;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Prototype_App
{
    public partial class MainForm : Form
    {
        //Declare class-level variable 

        private iVariableShare _Common;
        private clsPLC _clsPlc;
        private clsPQM _clsPQM;
        private clsMES _clsmes;


        private uc_Home _home;
        private uc_PLCSetting _plcSetting;
        private uc_PQMSetting _pqmSetting;
        private uc_MESSetting _mesSetting;
        private uc_LogFileSetting _logfileSetting;
        private Login _login;
        private HideScreen _hideScreen;

        private CancellationTokenSource cancellationTokenSource;

        public MainForm()
        {
            InitializeComponent();

            //Create instance and Initializ

            _Common = new iVariableShare();

            _clsmes = new clsMES(_Common); _clsmes.MES_Initialize();
            _clsPlc = new clsPLC(_Common); _clsPlc.PLC_Initialize();
            _clsPQM = new clsPQM(_Common, Properties.Settings.Default.PQM_URL);

            _home = new uc_Home(_Common);
            _home.Dock = DockStyle.Fill;
            _home.Show();
            cotainerPanel.Controls.Add(_home);

            _plcSetting = new uc_PLCSetting(_Common);
            _plcSetting.Dock = DockStyle.Fill;
            _plcSetting.Hide();
            cotainerPanel.Controls.Add(_plcSetting);

            _pqmSetting = new uc_PQMSetting(_Common);
            _pqmSetting.Dock = DockStyle.Fill;
            _pqmSetting.Hide();
            cotainerPanel.Controls.Add(_pqmSetting);

            _mesSetting = new uc_MESSetting(_Common);
            _mesSetting.Dock = DockStyle.Fill;
            _mesSetting.Hide();
            cotainerPanel.Controls.Add(_mesSetting);

            _logfileSetting = new uc_LogFileSetting(_Common);
            _logfileSetting.Dock = DockStyle.Fill;
            _logfileSetting.Hide();
            cotainerPanel.Controls.Add(_logfileSetting);

            _login = new Login();
            _login.LoginSuccess += loging_succes;

            _hideScreen = new HideScreen(_Common);
            _hideScreen.btnUnHidePress += unHideScreen;

        }
        private void MainForm_Load(object sender, EventArgs e)
        {
            if (_Common.iEnablePLC)
            {
                cancellationTokenSource = new CancellationTokenSource();
                _clsPlc.connectPLC();

                if (_Common.modbus.Connected) { _plcSetting.btnConnect.Enabled = false; }

                try
                {
                    Task.Run(() => _clsPlc.ReadStatusThread(cancellationTokenSource.Token));
                   
                }
                catch (OperationCanceledException) { }
            }

        }
        private void MainForm_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
        public void loging_succes(object sender, EventArgs e)
        {

            _plcSetting.Enable_textbox();
            _pqmSetting.Enable_textbox();
            _mesSetting.Enable_textbox();
            Console.WriteLine("Method loging_succes");

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            _pqmSetting.Hide();
            _plcSetting.Hide();
            _mesSetting.Hide();
            _logfileSetting.Hide();
            _home.Show();

        }

        private void lbMonitorStatus_Click(object sender, EventArgs e)
        {

        }

        private void btnPLCSetting_Click(object sender, EventArgs e)
        {
            _home.Hide();
            _pqmSetting.Hide();
            _mesSetting.Hide();
            _logfileSetting.Hide();
            _plcSetting.Show();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Filter records older than one week

            // Filter records older than one week
            

            _logfileSetting.writeDataTable();
            

            if (_Common.modbus.Connected) 
            {
                _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MenableFunc), false);
                _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResult), false);
                _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MflagChkResultNG), false);
            }

            _clsPlc.disconnectPLC();
            System.Diagnostics.Process.GetCurrentProcess().Kill();     
        }

        private void btnPQMSetting_Click(object sender, EventArgs e)
        {
            _home.Hide();
            _plcSetting.Hide();
            _mesSetting.Hide();
            _logfileSetting.Hide();
            _pqmSetting.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            _login.ShowDialog();
        }

        private void UpdateUI_Tick(object sender, EventArgs e)
        {
            lbValuePLCconnect.Text = _Common.iPLCconnectStatus;
            lbValuePQMconnect.Text = _Common.iPQMconnectStatus;
            _home.lbValueCheckResult.Text = _Common.iMES_Result_Check;

            if (_Common.modbus.Connected)
            {
                lbValuePLCconnect.BackColor = Color.LightGreen;

                lbValueStatus.Text = Convert.ToString(_Common.iPQM_Status);
                lbValueStatusCode.Text = Convert.ToString(_Common.iPQM_Status_Code);
                lbValuePassQty.Text = Convert.ToString(_Common.iPQM_PassQty);
                lbValueFailQty.Text = Convert.ToString(_Common.iPQM_FailQty);
                lbValueErrCnt.Text = Convert.ToString(_Common.iPQM_Error_Count);
                lbValueSelfCheck.Text = Convert.ToString(_Common.iPQM_Self_Check);
                lbValueCycleTime.Text = Convert.ToString(_Common.iPQM_Cycle_Time);
                lbValueRunningTime.Text = Convert.ToString(_Common.iPQM_Running_Time);
                lbValueWaitingTime.Text = Convert.ToString(_Common.iPQM_Waiting_Time);
                lbValueErrTime.Text = Convert.ToString(_Common.iPQM_Error_Time);
                lbValueBarcode.Text = Convert.ToString(_Common.iRFID_Barcode);
                if (Properties.Settings.Default.EnableMES) { _mesSetting.txtBoxSN.Text = Convert.ToString(_Common.iRFID_Barcode); }
                
            }
            else
            {
                lbValuePLCconnect.BackColor = Color.Red;

                lbValueStatus.Text = "Disconnect";
                lbValueStatusCode.Text = "Disconnect";
                lbValuePassQty.Text = "Disconnect";
                lbValueFailQty.Text = "Disconnect";
                lbValueErrCnt.Text = "Disconnect";
                lbValueSelfCheck.Text = "Disconnect";
                lbValueCycleTime.Text = "Disconnect";
                lbValueRunningTime.Text = "Disconnect";
                lbValueWaitingTime.Text = "Disconnect";
                lbValueErrTime.Text = "Disconnect";
                lbValueBarcode.Text = "Disconnect";
            }

            if (_Common.iPQMconnectStatus == "Connected")
            {
                lbValuePQMconnect.BackColor = Color.LightGreen;

            }
            else
            {
                lbValuePQMconnect.BackColor = Color.Red;
            }
            if (_Common.mesChkFlag) 
            {
                _logfileSetting.updateDataTable();
            
            }
        }

        private void UpdatePQM_Tick(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.EnablePQM)
            {
                _clsPQM.Send();
            }
        }

        private void btnMESSetting_Click(object sender, EventArgs e)
        {
            _home.Hide();
            _plcSetting.Hide();
            _pqmSetting.Hide();
            _logfileSetting.Hide();
            _mesSetting.Show();
        }

        private void btnLogFileSetting_Click(object sender, EventArgs e)
        {
            _home.Hide();
            _plcSetting.Hide();
            _pqmSetting.Hide();
            _mesSetting.Hide();
            _logfileSetting.Show();
        }

        private void btnHide_Click(object sender, EventArgs e)
        {
            this.Hide();
            _hideScreen.ShowDialog();
            
        }

        public void unHideScreen(object sender, EventArgs e)
        {
   
            //_hideScreen.Hide();
            this.Show();

        }
    }
}
