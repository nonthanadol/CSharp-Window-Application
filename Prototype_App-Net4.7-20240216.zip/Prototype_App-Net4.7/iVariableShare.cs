﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prototype_App_MES;
using EasyModbus;
using CsvHelper;
using System.IO;

namespace Prototype_App
{
    public class iVariableShare
    {
        public string iInterfaceID { get; set; }

        #region PLC
        public string iPLCconnectStatus { get; set; }
        public string iRFID_Barcode { get; set; }
        public bool iEnablePLC { get; set; }
        public bool iProcessFinish { get; set; }
        public bool ienableFunc { get; set; }
        public bool iFlagChkResult { get; set; }

        public ModbusClient modbus;

        #endregion

        #region PQM_Parameter
        public string iPQMconnectStatus { get; set; }
        public int iPQM_Status { get; set; }
        public string iPQM_Status_Code { get; set; }
        public int iPQM_PassQty { get; set; }
        public int iPQM_FailQty { get; set; }
        public int iPQM_Error_Count { get; set; }
        public uint iPQM_Error_Time { get; set; }
        public uint iPQM_Cycle_Time { get; set; }
        public uint iPQM_Running_Time { get; set; }
        public uint iPQM_Waiting_Time { get; set; }
        public int iPQM_Self_Check { get; set; }

        public string iPQM_InputQty = null;

        #endregion

        #region MES_Parameter
        public string iMES_MO { get; set; }
        public string iMES_Model { get; set; }
        public string iMES_WipLine { get; set; }
        public string iMES_Result_Update { get; set; }
        public string iMES_Result_Check { get; set; }
        public bool mesChkFlag { get; set; }

        public string iMES_Section = Properties.Settings.Default.MES_Section;
        public string iMES_Group = Properties.Settings.Default.MES_Group;
        public string iMES_Station = Properties.Settings.Default.MES_Station;
        public clsShopfloor_Http_Client MES;

        #endregion

        #region IAI_Parameter
        public bool iIAIfinish { get; set; }
        #endregion

        public List<clsCSV_Column> records { get; set; }
      

    }


}