﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prototype_App
{
    public partial class HideScreen : Form
    {
        private iVariableShare _Common;
        public event EventHandler btnUnHidePress;
        public HideScreen(iVariableShare common)
        {
            InitializeComponent();
            _Common = common;
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(1100, 700);
        }

        private void HideScreen_Load(object sender, EventArgs e)
        {

        }

        private void btnUnHide_Click(object sender, EventArgs e)
        {
            btnUnHidePress?.Invoke(this, EventArgs.Empty);
            this.Close();
        }

        private void UpdateUI_Tick(object sender, EventArgs e)
        {
            lbValueSN.Text = _Common.iRFID_Barcode;
            lbValueCheckResult.Text = _Common.iMES_Result_Check;
            lbValueUpdateResult.Text = _Common.iMES_Result_Update;
            lbValueEnableFunc.Text = Convert.ToString(_Common.ienableFunc);
        }
    }
}
