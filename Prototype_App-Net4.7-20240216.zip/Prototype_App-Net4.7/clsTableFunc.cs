﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Prototype_App.Interface;

namespace Prototype_App
{
    public class clsTableFunc
    {
        iVariableShare _Common;
        private clsMES _clsmes;
        private uc_LogFileSetting _logSetting;
       
        //private CancellationTokenSource cancellationTokenSource;
        public clsTableFunc(iVariableShare common)
        {

            _Common = common;
            _clsmes = new clsMES(_Common);
            _logSetting = new uc_LogFileSetting(_Common);
            

        }
        public void TableMain(CancellationToken cancellationToken)
        {
            
            while (!cancellationToken.IsCancellationRequested)
            {

                //Console.WriteLine("Table Main");
                //_Common.mesChkFlag = false;
                _Common.mesChkFlag = false;
                if (_Common.ienableFunc && _Common.iProcessFinish) // ProcessFinish need 1 pluse
                {
                    _clsmes.MES_Send_Check();
                    _Common.mesChkFlag = true;

                }
                else 
                {
                    //_logSetting.addDataTable("DSDSD","6565656");
                    //_Common.mesChkFlag = true;

                }
                Thread.Sleep(1); // Simulate work              
            }

        }






    }
}
