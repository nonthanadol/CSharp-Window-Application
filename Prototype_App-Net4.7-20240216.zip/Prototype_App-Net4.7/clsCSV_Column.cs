﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototype_App
{
    public class clsCSV_Column
    {
        public string SerialNumber { get; set; }
        public string Result { get; set; }
        public DateTime Time { get; set; }
        //public string SerialNumber { get; set; }
        

    }
}
