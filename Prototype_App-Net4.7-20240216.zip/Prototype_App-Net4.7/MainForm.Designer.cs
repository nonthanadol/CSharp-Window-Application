﻿namespace Prototype_App
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.titlePanel = new System.Windows.Forms.Panel();
            this.btnHide = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lbTitle = new System.Windows.Forms.Label();
            this.cotainerPanel = new System.Windows.Forms.Panel();
            this.controlPanel = new System.Windows.Forms.Panel();
            this.btnLogFileSetting = new System.Windows.Forms.Button();
            this.btnMESSetting = new System.Windows.Forms.Button();
            this.btnPLCSetting = new System.Windows.Forms.Button();
            this.btnPQMSetting = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.tblStatusMonitorPanel = new System.Windows.Forms.TableLayoutPanel();
            this.lbValueSelfCheck = new System.Windows.Forms.Label();
            this.lbSelfCheck = new System.Windows.Forms.Label();
            this.lbValueErrCnt = new System.Windows.Forms.Label();
            this.lbErrCnt = new System.Windows.Forms.Label();
            this.lbValueFailQty = new System.Windows.Forms.Label();
            this.lbFailQty = new System.Windows.Forms.Label();
            this.lbValuePassQty = new System.Windows.Forms.Label();
            this.lbPassQty = new System.Windows.Forms.Label();
            this.lbValueStatusCode = new System.Windows.Forms.Label();
            this.lbStatusCode = new System.Windows.Forms.Label();
            this.lbValueStatus = new System.Windows.Forms.Label();
            this.lbStatus = new System.Windows.Forms.Label();
            this.lbValuePQMconnect = new System.Windows.Forms.Label();
            this.lbValuePLCconnect = new System.Windows.Forms.Label();
            this.lbPLCconnect = new System.Windows.Forms.Label();
            this.lbPQMconnect = new System.Windows.Forms.Label();
            this.lbCycleTime = new System.Windows.Forms.Label();
            this.lbValueCycleTime = new System.Windows.Forms.Label();
            this.lbRunningTime = new System.Windows.Forms.Label();
            this.lbValueRunningTime = new System.Windows.Forms.Label();
            this.lbWaitingTime = new System.Windows.Forms.Label();
            this.lbValueWaitingTime = new System.Windows.Forms.Label();
            this.lbErrTime = new System.Windows.Forms.Label();
            this.lbValueErrTime = new System.Windows.Forms.Label();
            this.lbBarcode = new System.Windows.Forms.Label();
            this.lbValueBarcode = new System.Windows.Forms.Label();
            this.lbMonitorStatus = new System.Windows.Forms.Label();
            this.UpdateUI = new System.Windows.Forms.Timer(this.components);
            this.UpdatePQM = new System.Windows.Forms.Timer(this.components);
            this.titlePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.controlPanel.SuspendLayout();
            this.tblStatusMonitorPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // titlePanel
            // 
            this.titlePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.titlePanel.Controls.Add(this.btnHide);
            this.titlePanel.Controls.Add(this.pictureBox1);
            this.titlePanel.Controls.Add(this.btnLogin);
            this.titlePanel.Controls.Add(this.lbTitle);
            this.titlePanel.Location = new System.Drawing.Point(2, 2);
            this.titlePanel.Margin = new System.Windows.Forms.Padding(7);
            this.titlePanel.Name = "titlePanel";
            this.titlePanel.Size = new System.Drawing.Size(2406, 141);
            this.titlePanel.TabIndex = 0;
            // 
            // btnHide
            // 
            this.btnHide.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHide.Location = new System.Drawing.Point(2093, 7);
            this.btnHide.Margin = new System.Windows.Forms.Padding(7);
            this.btnHide.Name = "btnHide";
            this.btnHide.Size = new System.Drawing.Size(147, 127);
            this.btnHide.TabIndex = 4;
            this.btnHide.Text = "Hide";
            this.btnHide.UseVisualStyleBackColor = true;
            this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(425, 141);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(2252, 7);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(7);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(147, 127);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // lbTitle
            // 
            this.lbTitle.AutoSize = true;
            this.lbTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitle.Location = new System.Drawing.Point(893, 33);
            this.lbTitle.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(738, 82);
            this.lbTitle.TabIndex = 0;
            this.lbTitle.Text = "Prototype Application";
            // 
            // cotainerPanel
            // 
            this.cotainerPanel.Location = new System.Drawing.Point(499, 152);
            this.cotainerPanel.Margin = new System.Windows.Forms.Padding(7);
            this.cotainerPanel.Name = "cotainerPanel";
            this.cotainerPanel.Size = new System.Drawing.Size(1909, 1189);
            this.cotainerPanel.TabIndex = 1;
            // 
            // controlPanel
            // 
            this.controlPanel.BackColor = System.Drawing.SystemColors.ControlDark;
            this.controlPanel.Controls.Add(this.btnLogFileSetting);
            this.controlPanel.Controls.Add(this.btnMESSetting);
            this.controlPanel.Controls.Add(this.btnPLCSetting);
            this.controlPanel.Controls.Add(this.btnPQMSetting);
            this.controlPanel.Controls.Add(this.btnHome);
            this.controlPanel.Location = new System.Drawing.Point(499, 1350);
            this.controlPanel.Margin = new System.Windows.Forms.Padding(7);
            this.controlPanel.Name = "controlPanel";
            this.controlPanel.Size = new System.Drawing.Size(1909, 192);
            this.controlPanel.TabIndex = 2;
            // 
            // btnLogFileSetting
            // 
            this.btnLogFileSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogFileSetting.Location = new System.Drawing.Point(979, 50);
            this.btnLogFileSetting.Margin = new System.Windows.Forms.Padding(7);
            this.btnLogFileSetting.Name = "btnLogFileSetting";
            this.btnLogFileSetting.Size = new System.Drawing.Size(250, 94);
            this.btnLogFileSetting.TabIndex = 4;
            this.btnLogFileSetting.Text = "LogFileSetting";
            this.btnLogFileSetting.UseVisualStyleBackColor = true;
            this.btnLogFileSetting.Click += new System.EventHandler(this.btnLogFileSetting_Click);
            // 
            // btnMESSetting
            // 
            this.btnMESSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMESSetting.Location = new System.Drawing.Point(743, 50);
            this.btnMESSetting.Margin = new System.Windows.Forms.Padding(7);
            this.btnMESSetting.Name = "btnMESSetting";
            this.btnMESSetting.Size = new System.Drawing.Size(222, 94);
            this.btnMESSetting.TabIndex = 3;
            this.btnMESSetting.Text = "MESSetting";
            this.btnMESSetting.UseVisualStyleBackColor = true;
            this.btnMESSetting.Click += new System.EventHandler(this.btnMESSetting_Click);
            // 
            // btnPLCSetting
            // 
            this.btnPLCSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPLCSetting.Location = new System.Drawing.Point(273, 50);
            this.btnPLCSetting.Margin = new System.Windows.Forms.Padding(7);
            this.btnPLCSetting.Name = "btnPLCSetting";
            this.btnPLCSetting.Size = new System.Drawing.Size(222, 94);
            this.btnPLCSetting.TabIndex = 2;
            this.btnPLCSetting.Text = "PLCSetting";
            this.btnPLCSetting.UseVisualStyleBackColor = true;
            this.btnPLCSetting.Click += new System.EventHandler(this.btnPLCSetting_Click);
            // 
            // btnPQMSetting
            // 
            this.btnPQMSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPQMSetting.Location = new System.Drawing.Point(508, 50);
            this.btnPQMSetting.Margin = new System.Windows.Forms.Padding(7);
            this.btnPQMSetting.Name = "btnPQMSetting";
            this.btnPQMSetting.Size = new System.Drawing.Size(222, 94);
            this.btnPQMSetting.TabIndex = 1;
            this.btnPQMSetting.Text = "PQMSetting";
            this.btnPQMSetting.UseVisualStyleBackColor = true;
            this.btnPQMSetting.Click += new System.EventHandler(this.btnPQMSetting_Click);
            // 
            // btnHome
            // 
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Location = new System.Drawing.Point(11, 50);
            this.btnHome.Margin = new System.Windows.Forms.Padding(7);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(222, 94);
            this.btnHome.TabIndex = 0;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // tblStatusMonitorPanel
            // 
            this.tblStatusMonitorPanel.BackColor = System.Drawing.Color.White;
            this.tblStatusMonitorPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tblStatusMonitorPanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblStatusMonitorPanel.ColumnCount = 2;
            this.tblStatusMonitorPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.48544F));
            this.tblStatusMonitorPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.51456F));
            this.tblStatusMonitorPanel.Controls.Add(this.lbValueSelfCheck, 1, 7);
            this.tblStatusMonitorPanel.Controls.Add(this.lbSelfCheck, 0, 7);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValueErrCnt, 1, 6);
            this.tblStatusMonitorPanel.Controls.Add(this.lbErrCnt, 0, 6);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValueFailQty, 1, 5);
            this.tblStatusMonitorPanel.Controls.Add(this.lbFailQty, 0, 5);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValuePassQty, 1, 4);
            this.tblStatusMonitorPanel.Controls.Add(this.lbPassQty, 0, 4);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValueStatusCode, 1, 3);
            this.tblStatusMonitorPanel.Controls.Add(this.lbStatusCode, 0, 3);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValueStatus, 1, 2);
            this.tblStatusMonitorPanel.Controls.Add(this.lbStatus, 0, 2);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValuePQMconnect, 1, 1);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValuePLCconnect, 1, 0);
            this.tblStatusMonitorPanel.Controls.Add(this.lbPLCconnect, 0, 0);
            this.tblStatusMonitorPanel.Controls.Add(this.lbPQMconnect, 0, 1);
            this.tblStatusMonitorPanel.Controls.Add(this.lbCycleTime, 0, 8);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValueCycleTime, 1, 8);
            this.tblStatusMonitorPanel.Controls.Add(this.lbRunningTime, 0, 9);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValueRunningTime, 1, 9);
            this.tblStatusMonitorPanel.Controls.Add(this.lbWaitingTime, 0, 10);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValueWaitingTime, 1, 10);
            this.tblStatusMonitorPanel.Controls.Add(this.lbErrTime, 0, 11);
            this.tblStatusMonitorPanel.Controls.Add(this.lbValueErrTime, 1, 11);
            this.tblStatusMonitorPanel.Location = new System.Drawing.Point(9, 338);
            this.tblStatusMonitorPanel.Margin = new System.Windows.Forms.Padding(7);
            this.tblStatusMonitorPanel.Name = "tblStatusMonitorPanel";
            this.tblStatusMonitorPanel.RowCount = 12;
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tblStatusMonitorPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblStatusMonitorPanel.Size = new System.Drawing.Size(483, 1097);
            this.tblStatusMonitorPanel.TabIndex = 3;
            // 
            // lbValueSelfCheck
            // 
            this.lbValueSelfCheck.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValueSelfCheck.AutoSize = true;
            this.lbValueSelfCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueSelfCheck.Location = new System.Drawing.Point(343, 657);
            this.lbValueSelfCheck.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueSelfCheck.Name = "lbValueSelfCheck";
            this.lbValueSelfCheck.Size = new System.Drawing.Size(39, 36);
            this.lbValueSelfCheck.TabIndex = 15;
            this.lbValueSelfCheck.Text = "...";
            this.lbValueSelfCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbSelfCheck
            // 
            this.lbSelfCheck.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbSelfCheck.AutoSize = true;
            this.lbSelfCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSelfCheck.Location = new System.Drawing.Point(39, 657);
            this.lbSelfCheck.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbSelfCheck.Name = "lbSelfCheck";
            this.lbSelfCheck.Size = new System.Drawing.Size(166, 36);
            this.lbSelfCheck.TabIndex = 14;
            this.lbSelfCheck.Text = "SelfCheck :";
            this.lbSelfCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValueErrCnt
            // 
            this.lbValueErrCnt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValueErrCnt.AutoSize = true;
            this.lbValueErrCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueErrCnt.Location = new System.Drawing.Point(343, 567);
            this.lbValueErrCnt.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueErrCnt.Name = "lbValueErrCnt";
            this.lbValueErrCnt.Size = new System.Drawing.Size(39, 36);
            this.lbValueErrCnt.TabIndex = 13;
            this.lbValueErrCnt.Text = "...";
            this.lbValueErrCnt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbErrCnt
            // 
            this.lbErrCnt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbErrCnt.AutoSize = true;
            this.lbErrCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrCnt.Location = new System.Drawing.Point(63, 567);
            this.lbErrCnt.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbErrCnt.Name = "lbErrCnt";
            this.lbErrCnt.Size = new System.Drawing.Size(117, 36);
            this.lbErrCnt.TabIndex = 12;
            this.lbErrCnt.Text = "ErrCnt :";
            this.lbErrCnt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValueFailQty
            // 
            this.lbValueFailQty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValueFailQty.AutoSize = true;
            this.lbValueFailQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueFailQty.Location = new System.Drawing.Point(343, 477);
            this.lbValueFailQty.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueFailQty.Name = "lbValueFailQty";
            this.lbValueFailQty.Size = new System.Drawing.Size(39, 36);
            this.lbValueFailQty.TabIndex = 11;
            this.lbValueFailQty.Text = "...";
            this.lbValueFailQty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbFailQty
            // 
            this.lbFailQty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbFailQty.AutoSize = true;
            this.lbFailQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFailQty.Location = new System.Drawing.Point(60, 477);
            this.lbFailQty.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbFailQty.Name = "lbFailQty";
            this.lbFailQty.Size = new System.Drawing.Size(124, 36);
            this.lbFailQty.TabIndex = 10;
            this.lbFailQty.Text = "FailQty :";
            this.lbFailQty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValuePassQty
            // 
            this.lbValuePassQty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValuePassQty.AutoSize = true;
            this.lbValuePassQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValuePassQty.Location = new System.Drawing.Point(343, 387);
            this.lbValuePassQty.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValuePassQty.Name = "lbValuePassQty";
            this.lbValuePassQty.Size = new System.Drawing.Size(39, 36);
            this.lbValuePassQty.TabIndex = 9;
            this.lbValuePassQty.Text = "...";
            this.lbValuePassQty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPassQty
            // 
            this.lbPassQty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbPassQty.AutoSize = true;
            this.lbPassQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassQty.Location = new System.Drawing.Point(51, 387);
            this.lbPassQty.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbPassQty.Name = "lbPassQty";
            this.lbPassQty.Size = new System.Drawing.Size(142, 36);
            this.lbPassQty.TabIndex = 8;
            this.lbPassQty.Text = "PassQty :";
            this.lbPassQty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValueStatusCode
            // 
            this.lbValueStatusCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValueStatusCode.AutoSize = true;
            this.lbValueStatusCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueStatusCode.Location = new System.Drawing.Point(343, 297);
            this.lbValueStatusCode.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueStatusCode.Name = "lbValueStatusCode";
            this.lbValueStatusCode.Size = new System.Drawing.Size(39, 36);
            this.lbValueStatusCode.TabIndex = 7;
            this.lbValueStatusCode.Text = "...";
            this.lbValueStatusCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbStatusCode
            // 
            this.lbStatusCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbStatusCode.AutoSize = true;
            this.lbStatusCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbStatusCode.Location = new System.Drawing.Point(29, 297);
            this.lbStatusCode.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbStatusCode.Name = "lbStatusCode";
            this.lbStatusCode.Size = new System.Drawing.Size(186, 36);
            this.lbStatusCode.TabIndex = 6;
            this.lbStatusCode.Text = "StatusCode :";
            this.lbStatusCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValueStatus
            // 
            this.lbValueStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValueStatus.AutoSize = true;
            this.lbValueStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueStatus.Location = new System.Drawing.Point(343, 207);
            this.lbValueStatus.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueStatus.Name = "lbValueStatus";
            this.lbValueStatus.Size = new System.Drawing.Size(39, 36);
            this.lbValueStatus.TabIndex = 5;
            this.lbValueStatus.Text = "...";
            this.lbValueStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbStatus
            // 
            this.lbStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbStatus.AutoSize = true;
            this.lbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbStatus.Location = new System.Drawing.Point(64, 207);
            this.lbStatus.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(115, 36);
            this.lbStatus.TabIndex = 4;
            this.lbStatus.Text = "Status :";
            this.lbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValuePQMconnect
            // 
            this.lbValuePQMconnect.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValuePQMconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValuePQMconnect.Location = new System.Drawing.Point(251, 100);
            this.lbValuePQMconnect.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValuePQMconnect.Name = "lbValuePQMconnect";
            this.lbValuePQMconnect.Size = new System.Drawing.Size(224, 71);
            this.lbValuePQMconnect.TabIndex = 3;
            this.lbValuePQMconnect.Text = "...";
            this.lbValuePQMconnect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValuePLCconnect
            // 
            this.lbValuePLCconnect.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValuePLCconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValuePLCconnect.Location = new System.Drawing.Point(251, 10);
            this.lbValuePLCconnect.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValuePLCconnect.Name = "lbValuePLCconnect";
            this.lbValuePLCconnect.Size = new System.Drawing.Size(224, 71);
            this.lbValuePLCconnect.TabIndex = 1;
            this.lbValuePLCconnect.Text = "...";
            this.lbValuePLCconnect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPLCconnect
            // 
            this.lbPLCconnect.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbPLCconnect.AutoSize = true;
            this.lbPLCconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPLCconnect.Location = new System.Drawing.Point(25, 27);
            this.lbPLCconnect.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbPLCconnect.Name = "lbPLCconnect";
            this.lbPLCconnect.Size = new System.Drawing.Size(194, 36);
            this.lbPLCconnect.TabIndex = 0;
            this.lbPLCconnect.Text = "PLCconnect :";
            this.lbPLCconnect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPQMconnect
            // 
            this.lbPQMconnect.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbPQMconnect.AutoSize = true;
            this.lbPQMconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPQMconnect.Location = new System.Drawing.Point(20, 117);
            this.lbPQMconnect.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbPQMconnect.Name = "lbPQMconnect";
            this.lbPQMconnect.Size = new System.Drawing.Size(203, 36);
            this.lbPQMconnect.TabIndex = 2;
            this.lbPQMconnect.Text = "PQMconnect :";
            this.lbPQMconnect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbCycleTime
            // 
            this.lbCycleTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbCycleTime.AutoSize = true;
            this.lbCycleTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCycleTime.Location = new System.Drawing.Point(37, 747);
            this.lbCycleTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbCycleTime.Name = "lbCycleTime";
            this.lbCycleTime.Size = new System.Drawing.Size(169, 36);
            this.lbCycleTime.TabIndex = 16;
            this.lbCycleTime.Text = "CycleTime :";
            this.lbCycleTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValueCycleTime
            // 
            this.lbValueCycleTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValueCycleTime.AutoSize = true;
            this.lbValueCycleTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueCycleTime.Location = new System.Drawing.Point(343, 747);
            this.lbValueCycleTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueCycleTime.Name = "lbValueCycleTime";
            this.lbValueCycleTime.Size = new System.Drawing.Size(39, 36);
            this.lbValueCycleTime.TabIndex = 17;
            this.lbValueCycleTime.Text = "...";
            this.lbValueCycleTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbRunningTime
            // 
            this.lbRunningTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbRunningTime.AutoSize = true;
            this.lbRunningTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRunningTime.Location = new System.Drawing.Point(17, 837);
            this.lbRunningTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbRunningTime.Name = "lbRunningTime";
            this.lbRunningTime.Size = new System.Drawing.Size(209, 36);
            this.lbRunningTime.TabIndex = 19;
            this.lbRunningTime.Text = "RunningTime :";
            this.lbRunningTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValueRunningTime
            // 
            this.lbValueRunningTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValueRunningTime.AutoSize = true;
            this.lbValueRunningTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueRunningTime.Location = new System.Drawing.Point(343, 837);
            this.lbValueRunningTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueRunningTime.Name = "lbValueRunningTime";
            this.lbValueRunningTime.Size = new System.Drawing.Size(39, 36);
            this.lbValueRunningTime.TabIndex = 18;
            this.lbValueRunningTime.Text = "...";
            this.lbValueRunningTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbWaitingTime
            // 
            this.lbWaitingTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbWaitingTime.AutoSize = true;
            this.lbWaitingTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbWaitingTime.Location = new System.Drawing.Point(24, 927);
            this.lbWaitingTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbWaitingTime.Name = "lbWaitingTime";
            this.lbWaitingTime.Size = new System.Drawing.Size(196, 36);
            this.lbWaitingTime.TabIndex = 21;
            this.lbWaitingTime.Text = "WaitingTime :";
            this.lbWaitingTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValueWaitingTime
            // 
            this.lbValueWaitingTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValueWaitingTime.AutoSize = true;
            this.lbValueWaitingTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueWaitingTime.Location = new System.Drawing.Point(343, 927);
            this.lbValueWaitingTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueWaitingTime.Name = "lbValueWaitingTime";
            this.lbValueWaitingTime.Size = new System.Drawing.Size(39, 36);
            this.lbValueWaitingTime.TabIndex = 20;
            this.lbValueWaitingTime.Text = "...";
            this.lbValueWaitingTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbErrTime
            // 
            this.lbErrTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbErrTime.AutoSize = true;
            this.lbErrTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbErrTime.Location = new System.Drawing.Point(54, 1025);
            this.lbErrTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbErrTime.Name = "lbErrTime";
            this.lbErrTime.Size = new System.Drawing.Size(135, 36);
            this.lbErrTime.TabIndex = 23;
            this.lbErrTime.Text = "ErrTime :";
            this.lbErrTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValueErrTime
            // 
            this.lbValueErrTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbValueErrTime.AutoSize = true;
            this.lbValueErrTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueErrTime.Location = new System.Drawing.Point(343, 1025);
            this.lbValueErrTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueErrTime.Name = "lbValueErrTime";
            this.lbValueErrTime.Size = new System.Drawing.Size(39, 36);
            this.lbValueErrTime.TabIndex = 22;
            this.lbValueErrTime.Text = "...";
            this.lbValueErrTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbBarcode
            // 
            this.lbBarcode.AutoSize = true;
            this.lbBarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBarcode.Location = new System.Drawing.Point(3, 295);
            this.lbBarcode.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbBarcode.Name = "lbBarcode";
            this.lbBarcode.Size = new System.Drawing.Size(142, 36);
            this.lbBarcode.TabIndex = 25;
            this.lbBarcode.Text = "Barcode :";
            this.lbBarcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbValueBarcode
            // 
            this.lbValueBarcode.AutoSize = true;
            this.lbValueBarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbValueBarcode.Location = new System.Drawing.Point(150, 295);
            this.lbValueBarcode.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbValueBarcode.Name = "lbValueBarcode";
            this.lbValueBarcode.Size = new System.Drawing.Size(39, 36);
            this.lbValueBarcode.TabIndex = 24;
            this.lbValueBarcode.Text = "...";
            this.lbValueBarcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbMonitorStatus
            // 
            this.lbMonitorStatus.BackColor = System.Drawing.SystemColors.Info;
            this.lbMonitorStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMonitorStatus.Location = new System.Drawing.Point(9, 152);
            this.lbMonitorStatus.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbMonitorStatus.Name = "lbMonitorStatus";
            this.lbMonitorStatus.Size = new System.Drawing.Size(483, 116);
            this.lbMonitorStatus.TabIndex = 4;
            this.lbMonitorStatus.Text = "MonitorStatus";
            this.lbMonitorStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbMonitorStatus.Click += new System.EventHandler(this.lbMonitorStatus_Click);
            // 
            // UpdateUI
            // 
            this.UpdateUI.Enabled = true;
            this.UpdateUI.Interval = 1;
            this.UpdateUI.Tick += new System.EventHandler(this.UpdateUI_Tick);
            // 
            // UpdatePQM
            // 
            this.UpdatePQM.Enabled = true;
            this.UpdatePQM.Interval = 2000;
            this.UpdatePQM.Tick += new System.EventHandler(this.UpdatePQM_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(2408, 1526);
            this.Controls.Add(this.lbValueBarcode);
            this.Controls.Add(this.lbBarcode);
            this.Controls.Add(this.lbMonitorStatus);
            this.Controls.Add(this.tblStatusMonitorPanel);
            this.Controls.Add(this.controlPanel);
            this.Controls.Add(this.cotainerPanel);
            this.Controls.Add(this.titlePanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(7);
            this.Name = "MainForm";
            this.Text = "Prototype App";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MainForm_KeyPress);
            this.titlePanel.ResumeLayout(false);
            this.titlePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.controlPanel.ResumeLayout(false);
            this.tblStatusMonitorPanel.ResumeLayout(false);
            this.tblStatusMonitorPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel titlePanel;
        private System.Windows.Forms.Panel cotainerPanel;
        private System.Windows.Forms.Panel controlPanel;
        private System.Windows.Forms.TableLayoutPanel tblStatusMonitorPanel;
        private System.Windows.Forms.Button btnPQMSetting;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Label lbMonitorStatus;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.Button btnPLCSetting;
        private System.Windows.Forms.Label lbValuePLCconnect;
        private System.Windows.Forms.Label lbPLCconnect;
        private System.Windows.Forms.Label lbPQMconnect;
        private System.Windows.Forms.Label lbValueSelfCheck;
        private System.Windows.Forms.Label lbSelfCheck;
        private System.Windows.Forms.Label lbValueErrCnt;
        private System.Windows.Forms.Label lbErrCnt;
        private System.Windows.Forms.Label lbValueFailQty;
        private System.Windows.Forms.Label lbFailQty;
        private System.Windows.Forms.Label lbValuePassQty;
        private System.Windows.Forms.Label lbPassQty;
        private System.Windows.Forms.Label lbValueStatusCode;
        private System.Windows.Forms.Label lbStatusCode;
        private System.Windows.Forms.Label lbValueStatus;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.Label lbValuePQMconnect;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbCycleTime;
        private System.Windows.Forms.Label lbValueCycleTime;
        private System.Windows.Forms.Label lbRunningTime;
        private System.Windows.Forms.Label lbValueRunningTime;
        private System.Windows.Forms.Label lbWaitingTime;
        private System.Windows.Forms.Label lbValueWaitingTime;
        private System.Windows.Forms.Label lbErrTime;
        private System.Windows.Forms.Label lbValueErrTime;
        private System.Windows.Forms.Label lbBarcode;
        private System.Windows.Forms.Label lbValueBarcode;
        private System.Windows.Forms.Timer UpdateUI;
        private System.Windows.Forms.Timer UpdatePQM;
        private System.Windows.Forms.Button btnMESSetting;
        private System.Windows.Forms.Button btnLogFileSetting;
        private System.Windows.Forms.Button btnHide;
    }
}

