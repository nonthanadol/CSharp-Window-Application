﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Prototype_App_MES;


namespace Prototype_App
{
    public partial class uc_MESSetting : UserControl
    {
        iVariableShare _Common = new iVariableShare();
        public uc_MESSetting(iVariableShare common)
        {
            InitializeComponent();

            _Common = common;
        }
        private void uc_MESSetting_Load(object sender, EventArgs e)
        {
            groupMESinfo.Show();
            txtBoxURL.Text = Properties.Settings.Default.MES_URL;
            txtBoxKey.Text = Properties.Settings.Default.Key;
            txtBoxToken.Text = Properties.Settings.Default.Token;
            txtBoxFactory.Text = Properties.Settings.Default.Factory;

            txtBoxSection.Text = Properties.Settings.Default.MES_Section;
            txtBoxGroup.Text = Properties.Settings.Default.MES_Group;
            txtBoxStation.Text = Properties.Settings.Default.MES_Station;

            checkEnableMES.Checked = Properties.Settings.Default.EnableMES;

        }
        public void Enable_textbox()
        {
            txtBoxURL.Enabled = true;
            txtBoxKey.Enabled = true;
            txtBoxToken.Enabled = true;
            txtBoxFactory.Enabled = true;

            txtBoxSection.Enabled = true;
            txtBoxGroup.Enabled = true;
            txtBoxStation.Enabled = true;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.MES_URL = txtBoxURL.Text;
            Properties.Settings.Default.Key = txtBoxKey.Text;
            Properties.Settings.Default.Token = txtBoxToken.Text;
            Properties.Settings.Default.Factory = txtBoxFactory.Text;

            Properties.Settings.Default.MES_Section = txtBoxSection.Text;
            Properties.Settings.Default.MES_Group = txtBoxGroup.Text;
            Properties.Settings.Default.MES_Station = txtBoxStation.Text;

            Properties.Settings.Default.EnableMES = checkEnableMES.Checked;

            Properties.Settings.Default.Save();

        }
        private void btnLoad_Click(object sender, EventArgs e)
        {
            txtBoxURL.Text = Properties.Settings.Default.MES_URL;
            txtBoxKey.Text = Properties.Settings.Default.Key;
            txtBoxToken.Text = Properties.Settings.Default.Token;
            txtBoxFactory.Text = Properties.Settings.Default.Factory;

            txtBoxSection.Text = Properties.Settings.Default.MES_Section;
            txtBoxGroup.Text = Properties.Settings.Default.MES_Group;
            txtBoxStation.Text = Properties.Settings.Default.MES_Station;

            checkEnableMES.Checked = Properties.Settings.Default.EnableMES;
        }
        private void btnGetinfo_Click(object sender, EventArgs e)
        {

            string sn;
            ResMsg_1 ReceiveSNInfo = new ResMsg_1();

            if (Properties.Settings.Default.EnableMES && _Common.iPLCconnectStatus == "Connected")
            {
                //input SN from RFID
                try
                {
                    sn = _Common.iRFID_Barcode.Trim('\0') + "}";
                    ReceiveSNInfo = _Common.MES.GET_SN_INFO(Properties.Settings.Default.Factory, sn, "");
                    txtBoxModel.Text = ReceiveSNInfo.description.Model;
                    txtBoxMO.Text = ReceiveSNInfo.description.MO;
                    txtBoxWipLine.Text = ReceiveSNInfo.description.WipLine;
                    txtBoxWipSection.Text = ReceiveSNInfo.description.WipSection;
                    txtBoxWipGroup.Text = ReceiveSNInfo.description.WipGroup;
                    txtBoxWipStation.Text = ReceiveSNInfo.description.WipStation;
                    txtBoxNextGroup.Text = ReceiveSNInfo.description.NextGroup[0];
                }
                catch
                {
                    DialogResult re = MessageBox.Show("Can't Get SN info", "", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);

                }
            }
            else
            {
                //input SN from manual 
                try
                {
                    ReceiveSNInfo = _Common.MES.GET_SN_INFO(Properties.Settings.Default.Factory, txtBoxSN.Text, "");
                    txtBoxModel.Text = ReceiveSNInfo.description.Model;
                    txtBoxMO.Text = ReceiveSNInfo.description.MO;
                    txtBoxWipLine.Text = ReceiveSNInfo.description.WipLine;
                    txtBoxWipSection.Text = ReceiveSNInfo.description.WipSection;
                    txtBoxWipGroup.Text = ReceiveSNInfo.description.WipGroup;
                    txtBoxWipStation.Text = ReceiveSNInfo.description.WipStation;
                    txtBoxNextGroup.Text = ReceiveSNInfo.description.NextGroup[0];


                    foreach (string s in ReceiveSNInfo.description.NextGroup)
                    {
                        Console.WriteLine(s + "\n");
                    }
                    Console.WriteLine(ReceiveSNInfo.description.MACSN);
                    Console.WriteLine(ReceiveSNInfo.description.SN);
                    Console.WriteLine(ReceiveSNInfo.description.SSN);
                    Console.WriteLine(ReceiveSNInfo.description.MOVer);
                    Console.WriteLine(ReceiveSNInfo.description.CaseSN);
                    Console.WriteLine(ReceiveSNInfo.description.CustomerCode);
                    Console.WriteLine(ReceiveSNInfo.description.CustomerName);

                    MessageBox.Show(ReceiveSNInfo.description.NextGroup[0] + "\n" + ReceiveSNInfo.description.MACSN + "\n" + ReceiveSNInfo.description.SN + "\n" +
                        ReceiveSNInfo.description.SSN + "\n" + ReceiveSNInfo.description.MOVer + "\n" + ReceiveSNInfo.description.CaseSN + "\n" + ReceiveSNInfo.description.CustomerCode
                        + "\n" + ReceiveSNInfo.description.CustomerName);


                }
                catch
                {
                    DialogResult re = MessageBox.Show("Can't Get SN info", "", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                    if (re == DialogResult.Yes) { Console.WriteLine("Yes"); }
                    else { Console.WriteLine("No"); }
                }

            }

        }
        private void btnROUTING_Check_Click(object sender, EventArgs e)
        {
            string pTest_data;
            string pLog_data;
            ResMsg MESChkResult = new ResMsg();

            if (Properties.Settings.Default.EnableMES && _Common.iRFID_Barcode != "")
            {
                pTest_data = txtBoxSN.Text.Trim('\0') + "}" + txtBoxMO.Text + "}" + txtBoxModel.Text + "}" + txtBoxWipLine.Text + "}" + txtBoxSection.Text + "}" + txtBoxGroup.Text + "}" + txtBoxStation.Text + "}";
                pLog_data = "";

                try
                {
                    MESChkResult = _Common.MES.ROUTING_Check(txtBoxFactory.Text, pTest_data, pLog_data);
                }
                catch (Exception ex) { }

                MessageBox.Show("ROUTING_Check : " + MESChkResult.Result);
            }
        }
        private void btnROUTING_Update_PASS_Click(object sender, EventArgs e)
        {
            //Update Routing PASS

            ResMsg MESChkResult = new ResMsg();

            if (Properties.Settings.Default.EnableMES && _Common.iRFID_Barcode != "")
            {
                string pTest_data;
                string pLog_data;

                pTest_data = txtBoxSN.Text.Trim('\0') + "}" + txtBoxMO.Text + "}" + txtBoxModel.Text + "}" + txtBoxWipLine.Text + "}" + txtBoxSection.Text + "}" + txtBoxGroup.Text + "}" + txtBoxStation.Text
                        + "}0}PASS}User}" + _Common.iInterfaceID + "}1}none}";

                pLog_data = ""; //input data if have data need to send -> "data}data}" <- wait test.

                MESChkResult = _Common.MES.ROUTING_Update(txtBoxFactory.Text, pTest_data, pLog_data);

                MessageBox.Show(MESChkResult.Result);
            }
            //Console.WriteLine(_Common.iInterfaceID);
        }
        private void btnROUTING_Update_FAIL_Click(object sender, EventArgs e)
        {
            //Update Routing FAIL

            ResMsg MESChkResult = new ResMsg();

            if (Properties.Settings.Default.EnableMES && _Common.iRFID_Barcode != "")
            {
                string pTest_data;
                string pLog_data;

                pTest_data = txtBoxSN.Text.Trim('\0') + "}" + txtBoxMO.Text + "}" + txtBoxModel.Text + "}" + txtBoxWipLine.Text + "}" + txtBoxSection.Text + "}" + txtBoxGroup.Text + "}" + txtBoxStation.Text
                        + "}0}FAIL}User}" + _Common.iInterfaceID + "}1}none}";

                pLog_data = ""; //input data if have data need to send -> "data}data}" <- wait test.

                MESChkResult = _Common.MES.ROUTING_Update(txtBoxFactory.Text, pTest_data, pLog_data);

                MessageBox.Show(MESChkResult.Result);
            }
        }
        private void checkEnableMES_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupMESinfo_Enter(object sender, EventArgs e)
        {

        }

        private void groupMESinfo_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.Black, Color.White);
        }
        private void DrawGroupBox(GroupBox box, Graphics g, Color textColor, Color borderColor)
        {
            if (box != null)
            {
                Brush textBrush = new SolidBrush(textColor);
                Brush borderBrush = new SolidBrush(borderColor);
                Pen borderPen = new Pen(borderBrush);
                SizeF strSize = g.MeasureString(box.Text, box.Font);
                Rectangle rect = new Rectangle(box.ClientRectangle.X,
                                               box.ClientRectangle.Y + (int)(strSize.Height / 2),
                                               box.ClientRectangle.Width - 1,
                                               box.ClientRectangle.Height - (int)(strSize.Height / 2) - 1);

                // Clear text and border
                g.Clear(this.BackColor);

                // Draw text
                g.DrawString(box.Text, box.Font, textBrush, box.Padding.Left, 0);

                // Drawing Border
                //Left
                g.DrawLine(borderPen, rect.Location, new Point(rect.X, rect.Y + rect.Height));
                //Right
                g.DrawLine(borderPen, new Point(rect.X + rect.Width, rect.Y), new Point(rect.X + rect.Width, rect.Y + rect.Height));
                //Bottom
                g.DrawLine(borderPen, new Point(rect.X, rect.Y + rect.Height), new Point(rect.X + rect.Width, rect.Y + rect.Height));
                //Top1
                g.DrawLine(borderPen, new Point(rect.X, rect.Y), new Point(rect.X + box.Padding.Left, rect.Y));
                //Top2
                g.DrawLine(borderPen, new Point(rect.X + box.Padding.Left + (int)(strSize.Width), rect.Y), new Point(rect.X + rect.Width, rect.Y));
            }


        }
    

    }
}
