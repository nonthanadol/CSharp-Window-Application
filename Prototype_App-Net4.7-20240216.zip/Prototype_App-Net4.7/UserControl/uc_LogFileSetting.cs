﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using CsvHelper;
using System.Globalization;
using CsvHelper.Configuration;
using System.Xml.Linq;
using System.Reflection.Emit;
using Prototype_App.Interface;


namespace Prototype_App
{
    public partial class uc_LogFileSetting : UserControl, IUpdateUI
    {
        iVariableShare _Common = new iVariableShare();
        private string csvpath = @"D:\Prototype_App-Net4.7\log.csv";
        public uc_LogFileSetting(iVariableShare common)
        {
            InitializeComponent();
            _Common = common;
            clsCSVColumnBindingSource.DataSource = new List<clsCSV_Column>();
            readDataTable();
            updateDataTable();

        }
        private void uc_LogFileSetting_Load(object sender, EventArgs e)
        {
            txtBoxFilePath.Text = Properties.Settings.Default.Log_Path;

        }

        private void btnReadLog_Click(object sender, EventArgs e)
        {
            //string textfile = @"D:\Training\C#\DataTest\logFile.txt";
            string textfile = txtBoxFilePath.Text;
            if (File.Exists(textfile))
            {
                string textContent = File.ReadAllText(textfile);
                txtBoxAllContent.Text = textContent;

            }
        }
        public void readDataTable()
        {
            //FileStream fileStream = new FileStream(@"D:\Prototype_App-Net4.7\Book1.csv", FileMode.OpenOrCreate, FileAccess.ReadWrite);

            using (var reader = new StreamReader(csvpath))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                _Common.records = csv.GetRecords<clsCSV_Column>().ToList();

            }
           updateDataTable();

        }
        public void writeDataTable()
        {
            //FileStream fileStream = new FileStream(@"D:\Prototype_App-Net4.7\Book1.csv", FileMode.OpenOrCreate, FileAccess.ReadWrite);

            var filteredRecords = _Common.records.Where(record => (DateTime.Now - record.Time).TotalDays <= 2).ToList();

            using (var writer = new StreamWriter(csvpath))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {

                csv.WriteField("SerialNumber");
                csv.WriteField("Result");
                csv.WriteField("Time");
                csv.NextRecord();

                // Write records
                foreach (var record in filteredRecords)
                {
                    csv.WriteField(record.SerialNumber);
                    csv.WriteField(record.Result);
                    csv.WriteField(record.Time);
                    csv.NextRecord();
                }
            }

        }
        public void updateDataTable()
        {
            dataGridView1.DataSource = _Common.records;

        }
        public void addDataTable(string sn,string res) 
        {

            _Common.records.Add(new clsCSV_Column() { SerialNumber = sn, Result = res, Time = DateTime.Now});
            writeDataTable();
            readDataTable();
            updateDataTable();
            
        }
        
        private void txtBoxFilePath_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            
            dataGridView1.DataSource = _Common.records;

        }

        private void txtBoxAllContent_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbAllContent_Click(object sender, EventArgs e)
        {

        }

        private void lbPath_Click(object sender, EventArgs e)
        {

        }

        private void UpdateUI_Tick(object sender, EventArgs e)
        {
            //dataGridView1.DataSource = _Common.records;
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            addDataTable("aa","654");
        }

    }
}
