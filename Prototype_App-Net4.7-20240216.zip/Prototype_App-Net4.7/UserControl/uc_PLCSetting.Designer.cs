﻿namespace Prototype_App
{
    partial class uc_PLCSetting
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbPLCSetting = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.txtBoxIPAddress = new System.Windows.Forms.TextBox();
            this.lbIPAddress = new System.Windows.Forms.Label();
            this.lbPLCModbusAddress = new System.Windows.Forms.Label();
            this.txtBoxDstatus = new System.Windows.Forms.TextBox();
            this.lbDstatus = new System.Windows.Forms.Label();
            this.lbDstatusCode = new System.Windows.Forms.Label();
            this.txtBoxDstatusCode = new System.Windows.Forms.TextBox();
            this.lbDpassQty = new System.Windows.Forms.Label();
            this.txtBoxDpassQty = new System.Windows.Forms.TextBox();
            this.lbDfailQty = new System.Windows.Forms.Label();
            this.txtBoxDfailQty = new System.Windows.Forms.TextBox();
            this.lbDerrCnt = new System.Windows.Forms.Label();
            this.txtBoxDerrCnt = new System.Windows.Forms.TextBox();
            this.lbDselfCheck = new System.Windows.Forms.Label();
            this.txtBoxDselfCheck = new System.Windows.Forms.TextBox();
            this.lbDcycleTime = new System.Windows.Forms.Label();
            this.txtBoxDcycleTime = new System.Windows.Forms.TextBox();
            this.lbDwaitingTime = new System.Windows.Forms.Label();
            this.txtBoxDwaitingTime = new System.Windows.Forms.TextBox();
            this.lbDerrTime = new System.Windows.Forms.Label();
            this.txtBoxDerrTime = new System.Windows.Forms.TextBox();
            this.lbDrunningTime = new System.Windows.Forms.Label();
            this.txtBoxDrunningTime = new System.Windows.Forms.TextBox();
            this.lbLoad = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtBoxDbarcode = new System.Windows.Forms.TextBox();
            this.lbDbarcode = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxMprocessFinish = new System.Windows.Forms.TextBox();
            this.lbMprocessFinish = new System.Windows.Forms.Label();
            this.txtBoxDupdateResult = new System.Windows.Forms.TextBox();
            this.lbDupdateResult = new System.Windows.Forms.Label();
            this.txtBoxMenableFunc = new System.Windows.Forms.TextBox();
            this.lbMenableFunc = new System.Windows.Forms.Label();
            this.txtBoxMflagChkResult = new System.Windows.Forms.TextBox();
            this.lbMflagChkResult = new System.Windows.Forms.Label();
            this.txtBoxMflagChkResultNG = new System.Windows.Forms.TextBox();
            this.lblbMflagChkResultNG = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbPLCSetting
            // 
            this.lbPLCSetting.BackColor = System.Drawing.SystemColors.Info;
            this.lbPLCSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPLCSetting.Location = new System.Drawing.Point(0, 0);
            this.lbPLCSetting.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbPLCSetting.Name = "lbPLCSetting";
            this.lbPLCSetting.Size = new System.Drawing.Size(1909, 116);
            this.lbPLCSetting.TabIndex = 6;
            this.lbPLCSetting.Text = "PLCSetting";
            this.lbPLCSetting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnConnect
            // 
            this.btnConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.Location = new System.Drawing.Point(973, 170);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(7);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(254, 65);
            this.btnConnect.TabIndex = 7;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisconnect.Location = new System.Drawing.Point(1269, 170);
            this.btnDisconnect.Margin = new System.Windows.Forms.Padding(7);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(266, 65);
            this.btnDisconnect.TabIndex = 8;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // txtBoxIPAddress
            // 
            this.txtBoxIPAddress.Enabled = false;
            this.txtBoxIPAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxIPAddress.Location = new System.Drawing.Point(322, 172);
            this.txtBoxIPAddress.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxIPAddress.Name = "txtBoxIPAddress";
            this.txtBoxIPAddress.Size = new System.Drawing.Size(601, 56);
            this.txtBoxIPAddress.TabIndex = 9;
            // 
            // lbIPAddress
            // 
            this.lbIPAddress.AutoSize = true;
            this.lbIPAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIPAddress.Location = new System.Drawing.Point(49, 172);
            this.lbIPAddress.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbIPAddress.Name = "lbIPAddress";
            this.lbIPAddress.Size = new System.Drawing.Size(256, 51);
            this.lbIPAddress.TabIndex = 10;
            this.lbIPAddress.Text = "IPAddress : ";
            // 
            // lbPLCModbusAddress
            // 
            this.lbPLCModbusAddress.BackColor = System.Drawing.SystemColors.Info;
            this.lbPLCModbusAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPLCModbusAddress.Location = new System.Drawing.Point(0, 315);
            this.lbPLCModbusAddress.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbPLCModbusAddress.Name = "lbPLCModbusAddress";
            this.lbPLCModbusAddress.Size = new System.Drawing.Size(1909, 62);
            this.lbPLCModbusAddress.TabIndex = 11;
            this.lbPLCModbusAddress.Text = "PLC  Modbus  Address";
            this.lbPLCModbusAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtBoxDstatus
            // 
            this.txtBoxDstatus.Enabled = false;
            this.txtBoxDstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDstatus.Location = new System.Drawing.Point(291, 429);
            this.txtBoxDstatus.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDstatus.Name = "txtBoxDstatus";
            this.txtBoxDstatus.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDstatus.TabIndex = 19;
            // 
            // lbDstatus
            // 
            this.lbDstatus.AutoSize = true;
            this.lbDstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDstatus.Location = new System.Drawing.Point(97, 436);
            this.lbDstatus.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDstatus.Name = "lbDstatus";
            this.lbDstatus.Size = new System.Drawing.Size(169, 40);
            this.lbDstatus.TabIndex = 20;
            this.lbDstatus.Text = "Dstatus : ";
            // 
            // lbDstatusCode
            // 
            this.lbDstatusCode.AutoSize = true;
            this.lbDstatusCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDstatusCode.Location = new System.Drawing.Point(8, 529);
            this.lbDstatusCode.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDstatusCode.Name = "lbDstatusCode";
            this.lbDstatusCode.Size = new System.Drawing.Size(255, 40);
            this.lbDstatusCode.TabIndex = 22;
            this.lbDstatusCode.Text = "DstatusCode : ";
            // 
            // txtBoxDstatusCode
            // 
            this.txtBoxDstatusCode.Enabled = false;
            this.txtBoxDstatusCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDstatusCode.Location = new System.Drawing.Point(291, 523);
            this.txtBoxDstatusCode.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDstatusCode.Name = "txtBoxDstatusCode";
            this.txtBoxDstatusCode.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDstatusCode.TabIndex = 21;
            // 
            // lbDpassQty
            // 
            this.lbDpassQty.AutoSize = true;
            this.lbDpassQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDpassQty.Location = new System.Drawing.Point(64, 637);
            this.lbDpassQty.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDpassQty.Name = "lbDpassQty";
            this.lbDpassQty.Size = new System.Drawing.Size(205, 40);
            this.lbDpassQty.TabIndex = 24;
            this.lbDpassQty.Text = "DpassQty : ";
            // 
            // txtBoxDpassQty
            // 
            this.txtBoxDpassQty.Enabled = false;
            this.txtBoxDpassQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDpassQty.Location = new System.Drawing.Point(291, 623);
            this.txtBoxDpassQty.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDpassQty.Name = "txtBoxDpassQty";
            this.txtBoxDpassQty.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDpassQty.TabIndex = 23;
            // 
            // lbDfailQty
            // 
            this.lbDfailQty.AutoSize = true;
            this.lbDfailQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDfailQty.Location = new System.Drawing.Point(97, 735);
            this.lbDfailQty.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDfailQty.Name = "lbDfailQty";
            this.lbDfailQty.Size = new System.Drawing.Size(175, 40);
            this.lbDfailQty.TabIndex = 26;
            this.lbDfailQty.Text = "DfailQty : ";
            this.lbDfailQty.Click += new System.EventHandler(this.lbDfailQty_Click);
            // 
            // txtBoxDfailQty
            // 
            this.txtBoxDfailQty.Enabled = false;
            this.txtBoxDfailQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDfailQty.Location = new System.Drawing.Point(291, 728);
            this.txtBoxDfailQty.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDfailQty.Name = "txtBoxDfailQty";
            this.txtBoxDfailQty.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDfailQty.TabIndex = 25;
            // 
            // lbDerrCnt
            // 
            this.lbDerrCnt.AutoSize = true;
            this.lbDerrCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDerrCnt.Location = new System.Drawing.Point(97, 835);
            this.lbDerrCnt.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDerrCnt.Name = "lbDerrCnt";
            this.lbDerrCnt.Size = new System.Drawing.Size(173, 40);
            this.lbDerrCnt.TabIndex = 28;
            this.lbDerrCnt.Text = "DerrCnt : ";
            // 
            // txtBoxDerrCnt
            // 
            this.txtBoxDerrCnt.Enabled = false;
            this.txtBoxDerrCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDerrCnt.Location = new System.Drawing.Point(291, 828);
            this.txtBoxDerrCnt.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDerrCnt.Name = "txtBoxDerrCnt";
            this.txtBoxDerrCnt.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDerrCnt.TabIndex = 27;
            // 
            // lbDselfCheck
            // 
            this.lbDselfCheck.AutoSize = true;
            this.lbDselfCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDselfCheck.Location = new System.Drawing.Point(37, 917);
            this.lbDselfCheck.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDselfCheck.Name = "lbDselfCheck";
            this.lbDselfCheck.Size = new System.Drawing.Size(231, 40);
            this.lbDselfCheck.TabIndex = 30;
            this.lbDselfCheck.Text = "DselfCheck : ";
            // 
            // txtBoxDselfCheck
            // 
            this.txtBoxDselfCheck.Enabled = false;
            this.txtBoxDselfCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDselfCheck.Location = new System.Drawing.Point(291, 910);
            this.txtBoxDselfCheck.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDselfCheck.Name = "txtBoxDselfCheck";
            this.txtBoxDselfCheck.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDselfCheck.TabIndex = 29;
            this.txtBoxDselfCheck.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbDcycleTime
            // 
            this.lbDcycleTime.AutoSize = true;
            this.lbDcycleTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDcycleTime.Location = new System.Drawing.Point(591, 439);
            this.lbDcycleTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDcycleTime.Name = "lbDcycleTime";
            this.lbDcycleTime.Size = new System.Drawing.Size(235, 40);
            this.lbDcycleTime.TabIndex = 32;
            this.lbDcycleTime.Text = "DcycleTime : ";
            // 
            // txtBoxDcycleTime
            // 
            this.txtBoxDcycleTime.Enabled = false;
            this.txtBoxDcycleTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDcycleTime.Location = new System.Drawing.Point(843, 432);
            this.txtBoxDcycleTime.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDcycleTime.Name = "txtBoxDcycleTime";
            this.txtBoxDcycleTime.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDcycleTime.TabIndex = 31;
            // 
            // lbDwaitingTime
            // 
            this.lbDwaitingTime.AutoSize = true;
            this.lbDwaitingTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDwaitingTime.Location = new System.Drawing.Point(559, 631);
            this.lbDwaitingTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDwaitingTime.Name = "lbDwaitingTime";
            this.lbDwaitingTime.Size = new System.Drawing.Size(265, 40);
            this.lbDwaitingTime.TabIndex = 34;
            this.lbDwaitingTime.Text = "DwaitingTime : ";
            // 
            // txtBoxDwaitingTime
            // 
            this.txtBoxDwaitingTime.Enabled = false;
            this.txtBoxDwaitingTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDwaitingTime.Location = new System.Drawing.Point(843, 624);
            this.txtBoxDwaitingTime.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDwaitingTime.Name = "txtBoxDwaitingTime";
            this.txtBoxDwaitingTime.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDwaitingTime.TabIndex = 33;
            // 
            // lbDerrTime
            // 
            this.lbDerrTime.AutoSize = true;
            this.lbDerrTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDerrTime.Location = new System.Drawing.Point(629, 738);
            this.lbDerrTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDerrTime.Name = "lbDerrTime";
            this.lbDerrTime.Size = new System.Drawing.Size(197, 40);
            this.lbDerrTime.TabIndex = 36;
            this.lbDerrTime.Text = "DerrTime : ";
            // 
            // txtBoxDerrTime
            // 
            this.txtBoxDerrTime.Enabled = false;
            this.txtBoxDerrTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDerrTime.Location = new System.Drawing.Point(843, 725);
            this.txtBoxDerrTime.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDerrTime.Name = "txtBoxDerrTime";
            this.txtBoxDerrTime.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDerrTime.TabIndex = 35;
            // 
            // lbDrunningTime
            // 
            this.lbDrunningTime.AutoSize = true;
            this.lbDrunningTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDrunningTime.Location = new System.Drawing.Point(549, 533);
            this.lbDrunningTime.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDrunningTime.Name = "lbDrunningTime";
            this.lbDrunningTime.Size = new System.Drawing.Size(273, 40);
            this.lbDrunningTime.TabIndex = 39;
            this.lbDrunningTime.Text = "DrunningTime : ";
            // 
            // txtBoxDrunningTime
            // 
            this.txtBoxDrunningTime.Enabled = false;
            this.txtBoxDrunningTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDrunningTime.Location = new System.Drawing.Point(843, 526);
            this.txtBoxDrunningTime.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDrunningTime.Name = "txtBoxDrunningTime";
            this.txtBoxDrunningTime.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDrunningTime.TabIndex = 38;
            // 
            // lbLoad
            // 
            this.lbLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLoad.Location = new System.Drawing.Point(922, 1026);
            this.lbLoad.Margin = new System.Windows.Forms.Padding(7);
            this.lbLoad.Name = "lbLoad";
            this.lbLoad.Size = new System.Drawing.Size(189, 107);
            this.lbLoad.TabIndex = 41;
            this.lbLoad.Text = "Load";
            this.lbLoad.UseVisualStyleBackColor = true;
            this.lbLoad.Click += new System.EventHandler(this.lbLoad_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(688, 1026);
            this.btnSave.Margin = new System.Windows.Forms.Padding(7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(189, 107);
            this.btnSave.TabIndex = 40;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtBoxDbarcode
            // 
            this.txtBoxDbarcode.Enabled = false;
            this.txtBoxDbarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDbarcode.Location = new System.Drawing.Point(843, 814);
            this.txtBoxDbarcode.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDbarcode.Name = "txtBoxDbarcode";
            this.txtBoxDbarcode.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDbarcode.TabIndex = 42;
            // 
            // lbDbarcode
            // 
            this.lbDbarcode.AutoSize = true;
            this.lbDbarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDbarcode.Location = new System.Drawing.Point(617, 821);
            this.lbDbarcode.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDbarcode.Name = "lbDbarcode";
            this.lbDbarcode.Size = new System.Drawing.Size(203, 40);
            this.lbDbarcode.TabIndex = 43;
            this.lbDbarcode.Text = "Dbarcode : ";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(538, 420);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 582);
            this.label1.TabIndex = 45;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(1091, 409);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 582);
            this.label2.TabIndex = 46;
            // 
            // txtBoxMprocessFinish
            // 
            this.txtBoxMprocessFinish.Enabled = false;
            this.txtBoxMprocessFinish.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxMprocessFinish.Location = new System.Drawing.Point(1466, 576);
            this.txtBoxMprocessFinish.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxMprocessFinish.Name = "txtBoxMprocessFinish";
            this.txtBoxMprocessFinish.Size = new System.Drawing.Size(221, 48);
            this.txtBoxMprocessFinish.TabIndex = 47;
            // 
            // lbMprocessFinish
            // 
            this.lbMprocessFinish.AutoSize = true;
            this.lbMprocessFinish.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMprocessFinish.Location = new System.Drawing.Point(1165, 579);
            this.lbMprocessFinish.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbMprocessFinish.Name = "lbMprocessFinish";
            this.lbMprocessFinish.Size = new System.Drawing.Size(299, 40);
            this.lbMprocessFinish.TabIndex = 48;
            this.lbMprocessFinish.Text = "MprocessFinish : ";
            // 
            // txtBoxDupdateResult
            // 
            this.txtBoxDupdateResult.Enabled = false;
            this.txtBoxDupdateResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxDupdateResult.Location = new System.Drawing.Point(1466, 419);
            this.txtBoxDupdateResult.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxDupdateResult.Name = "txtBoxDupdateResult";
            this.txtBoxDupdateResult.Size = new System.Drawing.Size(221, 48);
            this.txtBoxDupdateResult.TabIndex = 49;
            // 
            // lbDupdateResult
            // 
            this.lbDupdateResult.AutoSize = true;
            this.lbDupdateResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDupdateResult.Location = new System.Drawing.Point(1177, 427);
            this.lbDupdateResult.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbDupdateResult.Name = "lbDupdateResult";
            this.lbDupdateResult.Size = new System.Drawing.Size(275, 40);
            this.lbDupdateResult.TabIndex = 50;
            this.lbDupdateResult.Text = "DupdateResult :";
            // 
            // txtBoxMenableFunc
            // 
            this.txtBoxMenableFunc.Enabled = false;
            this.txtBoxMenableFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxMenableFunc.Location = new System.Drawing.Point(1466, 499);
            this.txtBoxMenableFunc.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxMenableFunc.Name = "txtBoxMenableFunc";
            this.txtBoxMenableFunc.Size = new System.Drawing.Size(221, 48);
            this.txtBoxMenableFunc.TabIndex = 51;
            // 
            // lbMenableFunc
            // 
            this.lbMenableFunc.AutoSize = true;
            this.lbMenableFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMenableFunc.Location = new System.Drawing.Point(1196, 502);
            this.lbMenableFunc.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbMenableFunc.Name = "lbMenableFunc";
            this.lbMenableFunc.Size = new System.Drawing.Size(265, 40);
            this.lbMenableFunc.TabIndex = 52;
            this.lbMenableFunc.Text = "MenableFunc : ";
            // 
            // txtBoxMflagChkResult
            // 
            this.txtBoxMflagChkResult.Enabled = false;
            this.txtBoxMflagChkResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxMflagChkResult.Location = new System.Drawing.Point(1466, 651);
            this.txtBoxMflagChkResult.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxMflagChkResult.Name = "txtBoxMflagChkResult";
            this.txtBoxMflagChkResult.Size = new System.Drawing.Size(221, 48);
            this.txtBoxMflagChkResult.TabIndex = 53;
            // 
            // lbMflagChkResult
            // 
            this.lbMflagChkResult.AutoSize = true;
            this.lbMflagChkResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMflagChkResult.Location = new System.Drawing.Point(1165, 654);
            this.lbMflagChkResult.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbMflagChkResult.Name = "lbMflagChkResult";
            this.lbMflagChkResult.Size = new System.Drawing.Size(301, 40);
            this.lbMflagChkResult.TabIndex = 54;
            this.lbMflagChkResult.Text = "MflagChkResult : ";
            // 
            // txtBoxMflagChkResultNG
            // 
            this.txtBoxMflagChkResultNG.Enabled = false;
            this.txtBoxMflagChkResultNG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxMflagChkResultNG.Location = new System.Drawing.Point(1466, 725);
            this.txtBoxMflagChkResultNG.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxMflagChkResultNG.Name = "txtBoxMflagChkResultNG";
            this.txtBoxMflagChkResultNG.Size = new System.Drawing.Size(221, 48);
            this.txtBoxMflagChkResultNG.TabIndex = 55;
            // 
            // lblbMflagChkResultNG
            // 
            this.lblbMflagChkResultNG.AutoSize = true;
            this.lblbMflagChkResultNG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbMflagChkResultNG.Location = new System.Drawing.Point(1111, 728);
            this.lblbMflagChkResultNG.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lblbMflagChkResultNG.Name = "lblbMflagChkResultNG";
            this.lblbMflagChkResultNG.Size = new System.Drawing.Size(355, 40);
            this.lblbMflagChkResultNG.TabIndex = 56;
            this.lblbMflagChkResultNG.Text = "MflagChkResultNG : ";
            // 
            // uc_PLCSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.txtBoxMflagChkResultNG);
            this.Controls.Add(this.lblbMflagChkResultNG);
            this.Controls.Add(this.txtBoxMflagChkResult);
            this.Controls.Add(this.lbMflagChkResult);
            this.Controls.Add(this.txtBoxMenableFunc);
            this.Controls.Add(this.lbMenableFunc);
            this.Controls.Add(this.txtBoxDupdateResult);
            this.Controls.Add(this.lbDupdateResult);
            this.Controls.Add(this.txtBoxMprocessFinish);
            this.Controls.Add(this.lbMprocessFinish);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBoxDbarcode);
            this.Controls.Add(this.lbDbarcode);
            this.Controls.Add(this.lbLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtBoxDrunningTime);
            this.Controls.Add(this.txtBoxDstatus);
            this.Controls.Add(this.lbDrunningTime);
            this.Controls.Add(this.txtBoxDerrTime);
            this.Controls.Add(this.txtBoxDstatusCode);
            this.Controls.Add(this.lbDerrTime);
            this.Controls.Add(this.lbDstatusCode);
            this.Controls.Add(this.txtBoxDwaitingTime);
            this.Controls.Add(this.txtBoxDpassQty);
            this.Controls.Add(this.lbDwaitingTime);
            this.Controls.Add(this.lbDpassQty);
            this.Controls.Add(this.txtBoxDcycleTime);
            this.Controls.Add(this.txtBoxDfailQty);
            this.Controls.Add(this.lbDcycleTime);
            this.Controls.Add(this.lbDfailQty);
            this.Controls.Add(this.txtBoxDselfCheck);
            this.Controls.Add(this.lbDerrCnt);
            this.Controls.Add(this.lbDselfCheck);
            this.Controls.Add(this.lbDstatus);
            this.Controls.Add(this.txtBoxDerrCnt);
            this.Controls.Add(this.lbPLCModbusAddress);
            this.Controls.Add(this.lbIPAddress);
            this.Controls.Add(this.txtBoxIPAddress);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.lbPLCSetting);
            this.Margin = new System.Windows.Forms.Padding(7);
            this.Name = "uc_PLCSetting";
            this.Size = new System.Drawing.Size(1909, 1189);
            this.Load += new System.EventHandler(this.uc_PLCSetting_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbPLCSetting;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.TextBox txtBoxIPAddress;
        private System.Windows.Forms.Label lbIPAddress;
        private System.Windows.Forms.Label lbPLCModbusAddress;
        private System.Windows.Forms.TextBox txtBoxDstatus;
        private System.Windows.Forms.Label lbDstatus;
        private System.Windows.Forms.Label lbDstatusCode;
        private System.Windows.Forms.TextBox txtBoxDstatusCode;
        private System.Windows.Forms.Label lbDpassQty;
        private System.Windows.Forms.TextBox txtBoxDpassQty;
        private System.Windows.Forms.Label lbDfailQty;
        private System.Windows.Forms.TextBox txtBoxDfailQty;
        private System.Windows.Forms.Label lbDerrCnt;
        private System.Windows.Forms.TextBox txtBoxDerrCnt;
        private System.Windows.Forms.Label lbDselfCheck;
        private System.Windows.Forms.TextBox txtBoxDselfCheck;
        private System.Windows.Forms.Label lbDcycleTime;
        private System.Windows.Forms.TextBox txtBoxDcycleTime;
        private System.Windows.Forms.Label lbDwaitingTime;
        private System.Windows.Forms.TextBox txtBoxDwaitingTime;
        private System.Windows.Forms.Label lbDerrTime;
        private System.Windows.Forms.TextBox txtBoxDerrTime;
        private System.Windows.Forms.Label lbDrunningTime;
        private System.Windows.Forms.TextBox txtBoxDrunningTime;
        private System.Windows.Forms.Button lbLoad;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtBoxDbarcode;
        private System.Windows.Forms.Label lbDbarcode;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxMprocessFinish;
        private System.Windows.Forms.Label lbMprocessFinish;
        private System.Windows.Forms.TextBox txtBoxDupdateResult;
        private System.Windows.Forms.Label lbDupdateResult;
        private System.Windows.Forms.TextBox txtBoxMenableFunc;
        private System.Windows.Forms.Label lbMenableFunc;
        private System.Windows.Forms.TextBox txtBoxMflagChkResult;
        private System.Windows.Forms.Label lbMflagChkResult;
        private System.Windows.Forms.TextBox txtBoxMflagChkResultNG;
        private System.Windows.Forms.Label lblbMflagChkResultNG;
    }
}
