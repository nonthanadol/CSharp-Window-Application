﻿namespace Prototype_App
{
    partial class uc_LogFileSetting
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbLogFileSetting = new System.Windows.Forms.Label();
            this.txtBoxAllContent = new System.Windows.Forms.RichTextBox();
            this.btnReadLog = new System.Windows.Forms.Button();
            this.lbAllContent = new System.Windows.Forms.Label();
            this.txtBoxFilePath = new System.Windows.Forms.TextBox();
            this.lbPath = new System.Windows.Forms.Label();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.serialNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clsCSVColumnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clsCSVColumnBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lbLogFileSetting
            // 
            this.lbLogFileSetting.BackColor = System.Drawing.SystemColors.Info;
            this.lbLogFileSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLogFileSetting.Location = new System.Drawing.Point(0, 0);
            this.lbLogFileSetting.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbLogFileSetting.Name = "lbLogFileSetting";
            this.lbLogFileSetting.Size = new System.Drawing.Size(1909, 116);
            this.lbLogFileSetting.TabIndex = 9;
            this.lbLogFileSetting.Text = "LogFileSetting";
            this.lbLogFileSetting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtBoxAllContent
            // 
            this.txtBoxAllContent.Location = new System.Drawing.Point(235, 1067);
            this.txtBoxAllContent.Name = "txtBoxAllContent";
            this.txtBoxAllContent.Size = new System.Drawing.Size(488, 62);
            this.txtBoxAllContent.TabIndex = 10;
            this.txtBoxAllContent.Text = "";
            this.txtBoxAllContent.Visible = false;
            this.txtBoxAllContent.TextChanged += new System.EventHandler(this.txtBoxAllContent_TextChanged);
            // 
            // btnReadLog
            // 
            this.btnReadLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnReadLog.Location = new System.Drawing.Point(1118, 1100);
            this.btnReadLog.Name = "btnReadLog";
            this.btnReadLog.Size = new System.Drawing.Size(226, 67);
            this.btnReadLog.TabIndex = 11;
            this.btnReadLog.Text = "ReadLog";
            this.btnReadLog.UseVisualStyleBackColor = true;
            this.btnReadLog.Visible = false;
            this.btnReadLog.Click += new System.EventHandler(this.btnReadLog_Click);
            // 
            // lbAllContent
            // 
            this.lbAllContent.AutoSize = true;
            this.lbAllContent.Location = new System.Drawing.Point(830, 1058);
            this.lbAllContent.Name = "lbAllContent";
            this.lbAllContent.Size = new System.Drawing.Size(123, 29);
            this.lbAllContent.TabIndex = 12;
            this.lbAllContent.Text = "AllContent";
            this.lbAllContent.Visible = false;
            this.lbAllContent.Click += new System.EventHandler(this.lbAllContent_Click);
            // 
            // txtBoxFilePath
            // 
            this.txtBoxFilePath.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxFilePath.Location = new System.Drawing.Point(1223, 1046);
            this.txtBoxFilePath.Name = "txtBoxFilePath";
            this.txtBoxFilePath.Size = new System.Drawing.Size(665, 41);
            this.txtBoxFilePath.TabIndex = 13;
            this.txtBoxFilePath.Visible = false;
            this.txtBoxFilePath.TextChanged += new System.EventHandler(this.txtBoxFilePath_TextChanged);
            // 
            // lbPath
            // 
            this.lbPath.AutoSize = true;
            this.lbPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbPath.Location = new System.Drawing.Point(1112, 1046);
            this.lbPath.Name = "lbPath";
            this.lbPath.Size = new System.Drawing.Size(92, 36);
            this.lbPath.TabIndex = 14;
            this.lbPath.Text = "Path :";
            this.lbPath.Visible = false;
            this.lbPath.Click += new System.EventHandler(this.lbPath_Click);
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(817, 1105);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(136, 65);
            this.btnRead.TabIndex = 16;
            this.btnRead.Text = "btnRead";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Visible = false;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(959, 1105);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(136, 65);
            this.btnWrite.TabIndex = 17;
            this.btnWrite.Text = "btnWrite";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Visible = false;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serialNumberDataGridViewTextBoxColumn,
            this.resultDataGridViewTextBoxColumn,
            this.timeDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.clsCSVColumnBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(63, 143);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 92;
            this.dataGridView1.RowTemplate.Height = 37;
            this.dataGridView1.Size = new System.Drawing.Size(1733, 886);
            this.dataGridView1.TabIndex = 18;
            // 
            // serialNumberDataGridViewTextBoxColumn
            // 
            this.serialNumberDataGridViewTextBoxColumn.DataPropertyName = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn.HeaderText = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn.MinimumWidth = 11;
            this.serialNumberDataGridViewTextBoxColumn.Name = "serialNumberDataGridViewTextBoxColumn";
            this.serialNumberDataGridViewTextBoxColumn.Width = 200;
            // 
            // resultDataGridViewTextBoxColumn
            // 
            this.resultDataGridViewTextBoxColumn.DataPropertyName = "Result";
            this.resultDataGridViewTextBoxColumn.HeaderText = "Result";
            this.resultDataGridViewTextBoxColumn.MinimumWidth = 11;
            this.resultDataGridViewTextBoxColumn.Name = "resultDataGridViewTextBoxColumn";
            this.resultDataGridViewTextBoxColumn.Width = 225;
            // 
            // timeDataGridViewTextBoxColumn
            // 
            this.timeDataGridViewTextBoxColumn.DataPropertyName = "Time";
            this.timeDataGridViewTextBoxColumn.HeaderText = "Time";
            this.timeDataGridViewTextBoxColumn.MinimumWidth = 11;
            this.timeDataGridViewTextBoxColumn.Name = "timeDataGridViewTextBoxColumn";
            this.timeDataGridViewTextBoxColumn.Width = 225;
            // 
            // clsCSVColumnBindingSource
            // 
            this.clsCSVColumnBindingSource.DataSource = typeof(Prototype_App.clsCSV_Column);
            // 
            // uc_LogFileSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.lbPath);
            this.Controls.Add(this.txtBoxFilePath);
            this.Controls.Add(this.lbAllContent);
            this.Controls.Add(this.btnReadLog);
            this.Controls.Add(this.txtBoxAllContent);
            this.Controls.Add(this.lbLogFileSetting);
            this.Name = "uc_LogFileSetting";
            this.Size = new System.Drawing.Size(1916, 1189);
            this.Load += new System.EventHandler(this.uc_LogFileSetting_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clsCSVColumnBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbLogFileSetting;
        private System.Windows.Forms.RichTextBox txtBoxAllContent;
        private System.Windows.Forms.Button btnReadLog;
        private System.Windows.Forms.Label lbAllContent;
        private System.Windows.Forms.TextBox txtBoxFilePath;
        private System.Windows.Forms.Label lbPath;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.BindingSource clsCSVColumnBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeDataGridViewTextBoxColumn;
        public System.Windows.Forms.DataGridView dataGridView1;
    }
}
