﻿namespace Prototype_App
{
    partial class uc_Home
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbHOME = new System.Windows.Forms.Label();
            this.cbbDeviceList = new System.Windows.Forms.ComboBox();
            this.lbReadFrom = new System.Windows.Forms.Label();
            this.groupIAIFunc = new System.Windows.Forms.GroupBox();
            this.groupAutoChangeModel = new System.Windows.Forms.GroupBox();
            this.lbValueCurrentModel = new System.Windows.Forms.Label();
            this.lbCurrentModel = new System.Windows.Forms.Label();
            this.checkAutoChangeModel = new System.Windows.Forms.CheckBox();
            this.groupAutoUpRoute = new System.Windows.Forms.GroupBox();
            this.lbValueUpdateResult = new System.Windows.Forms.Label();
            this.lbUpdateResult = new System.Windows.Forms.Label();
            this.btnSTOPautoUpRoute = new System.Windows.Forms.Button();
            this.btnSTARTautoUpRoute = new System.Windows.Forms.Button();
            this.groupSerialPort = new System.Windows.Forms.GroupBox();
            this.lbPort = new System.Windows.Forms.Label();
            this.btnCloseSerialPort = new System.Windows.Forms.Button();
            this.btnOpenSerialPort = new System.Windows.Forms.Button();
            this.cbbPortList = new System.Windows.Forms.ComboBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.btnWriteBarCode = new System.Windows.Forms.Button();
            this.txtBoxWriteBarcode = new System.Windows.Forms.TextBox();
            this.groupRFID = new System.Windows.Forms.GroupBox();
            this.lbBarcode = new System.Windows.Forms.Label();
            this.groupTableFunc = new System.Windows.Forms.GroupBox();
            this.lbValueCheckResult = new System.Windows.Forms.Label();
            this.lbCheckResult = new System.Windows.Forms.Label();
            this.groupInterlockRoute = new System.Windows.Forms.GroupBox();
            this.checkInterlockRoute = new System.Windows.Forms.CheckBox();
            this.UpdateHomeUI = new System.Windows.Forms.Timer(this.components);
            this.groupIAIFunc.SuspendLayout();
            this.groupAutoChangeModel.SuspendLayout();
            this.groupAutoUpRoute.SuspendLayout();
            this.groupSerialPort.SuspendLayout();
            this.groupRFID.SuspendLayout();
            this.groupTableFunc.SuspendLayout();
            this.groupInterlockRoute.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbHOME
            // 
            this.lbHOME.BackColor = System.Drawing.SystemColors.Info;
            this.lbHOME.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHOME.Location = new System.Drawing.Point(0, 0);
            this.lbHOME.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbHOME.Name = "lbHOME";
            this.lbHOME.Size = new System.Drawing.Size(1909, 116);
            this.lbHOME.TabIndex = 5;
            this.lbHOME.Text = "HOME";
            this.lbHOME.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbbDeviceList
            // 
            this.cbbDeviceList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.cbbDeviceList.FormattingEnabled = true;
            this.cbbDeviceList.Items.AddRange(new object[] {
            "PLC(TCP/IP)",
            "Log(.txt)"});
            this.cbbDeviceList.Location = new System.Drawing.Point(344, 167);
            this.cbbDeviceList.Name = "cbbDeviceList";
            this.cbbDeviceList.Size = new System.Drawing.Size(243, 44);
            this.cbbDeviceList.TabIndex = 6;
            this.cbbDeviceList.SelectedIndexChanged += new System.EventHandler(this.cbbDeviceList_SelectedIndexChanged);
            // 
            // lbReadFrom
            // 
            this.lbReadFrom.AutoSize = true;
            this.lbReadFrom.BackColor = System.Drawing.Color.White;
            this.lbReadFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbReadFrom.Location = new System.Drawing.Point(39, 170);
            this.lbReadFrom.Name = "lbReadFrom";
            this.lbReadFrom.Size = new System.Drawing.Size(270, 36);
            this.lbReadFrom.TabIndex = 7;
            this.lbReadFrom.Text = "Read Status From :";
            // 
            // groupIAIFunc
            // 
            this.groupIAIFunc.Controls.Add(this.groupAutoChangeModel);
            this.groupIAIFunc.Controls.Add(this.groupAutoUpRoute);
            this.groupIAIFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupIAIFunc.Location = new System.Drawing.Point(45, 540);
            this.groupIAIFunc.Name = "groupIAIFunc";
            this.groupIAIFunc.Size = new System.Drawing.Size(916, 402);
            this.groupIAIFunc.TabIndex = 8;
            this.groupIAIFunc.TabStop = false;
            this.groupIAIFunc.Text = "IAI Function";
            this.groupIAIFunc.Visible = false;
            this.groupIAIFunc.Paint += new System.Windows.Forms.PaintEventHandler(this.groupIAIFunc_Paint);
            // 
            // groupAutoChangeModel
            // 
            this.groupAutoChangeModel.Controls.Add(this.lbValueCurrentModel);
            this.groupAutoChangeModel.Controls.Add(this.lbCurrentModel);
            this.groupAutoChangeModel.Controls.Add(this.checkAutoChangeModel);
            this.groupAutoChangeModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupAutoChangeModel.Location = new System.Drawing.Point(74, 240);
            this.groupAutoChangeModel.Name = "groupAutoChangeModel";
            this.groupAutoChangeModel.Size = new System.Drawing.Size(810, 139);
            this.groupAutoChangeModel.TabIndex = 1;
            this.groupAutoChangeModel.TabStop = false;
            this.groupAutoChangeModel.Text = "Auto Change Model";
            this.groupAutoChangeModel.Visible = false;
            // 
            // lbValueCurrentModel
            // 
            this.lbValueCurrentModel.AutoSize = true;
            this.lbValueCurrentModel.BackColor = System.Drawing.Color.White;
            this.lbValueCurrentModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbValueCurrentModel.Location = new System.Drawing.Point(475, 67);
            this.lbValueCurrentModel.Name = "lbValueCurrentModel";
            this.lbValueCurrentModel.Size = new System.Drawing.Size(39, 36);
            this.lbValueCurrentModel.TabIndex = 4;
            this.lbValueCurrentModel.Text = "...";
            this.lbValueCurrentModel.Visible = false;
            // 
            // lbCurrentModel
            // 
            this.lbCurrentModel.AutoSize = true;
            this.lbCurrentModel.BackColor = System.Drawing.Color.White;
            this.lbCurrentModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbCurrentModel.Location = new System.Drawing.Point(220, 70);
            this.lbCurrentModel.Name = "lbCurrentModel";
            this.lbCurrentModel.Size = new System.Drawing.Size(220, 36);
            this.lbCurrentModel.TabIndex = 4;
            this.lbCurrentModel.Text = "Current Model :";
            this.lbCurrentModel.Visible = false;
            // 
            // checkAutoChangeModel
            // 
            this.checkAutoChangeModel.AutoSize = true;
            this.checkAutoChangeModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.checkAutoChangeModel.Location = new System.Drawing.Point(51, 66);
            this.checkAutoChangeModel.Name = "checkAutoChangeModel";
            this.checkAutoChangeModel.Size = new System.Drawing.Size(140, 40);
            this.checkAutoChangeModel.TabIndex = 0;
            this.checkAutoChangeModel.Text = "Enable";
            this.checkAutoChangeModel.UseVisualStyleBackColor = true;
            this.checkAutoChangeModel.Visible = false;
            // 
            // groupAutoUpRoute
            // 
            this.groupAutoUpRoute.Controls.Add(this.lbValueUpdateResult);
            this.groupAutoUpRoute.Controls.Add(this.lbUpdateResult);
            this.groupAutoUpRoute.Controls.Add(this.btnSTOPautoUpRoute);
            this.groupAutoUpRoute.Controls.Add(this.btnSTARTautoUpRoute);
            this.groupAutoUpRoute.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupAutoUpRoute.Location = new System.Drawing.Point(74, 64);
            this.groupAutoUpRoute.Name = "groupAutoUpRoute";
            this.groupAutoUpRoute.Size = new System.Drawing.Size(729, 162);
            this.groupAutoUpRoute.TabIndex = 0;
            this.groupAutoUpRoute.TabStop = false;
            this.groupAutoUpRoute.Text = "Auto Update Route";
            this.groupAutoUpRoute.Visible = false;
            // 
            // lbValueUpdateResult
            // 
            this.lbValueUpdateResult.AutoSize = true;
            this.lbValueUpdateResult.BackColor = System.Drawing.Color.White;
            this.lbValueUpdateResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbValueUpdateResult.Location = new System.Drawing.Point(614, 79);
            this.lbValueUpdateResult.Name = "lbValueUpdateResult";
            this.lbValueUpdateResult.Size = new System.Drawing.Size(39, 36);
            this.lbValueUpdateResult.TabIndex = 3;
            this.lbValueUpdateResult.Text = "...";
            this.lbValueUpdateResult.Visible = false;
            // 
            // lbUpdateResult
            // 
            this.lbUpdateResult.AutoSize = true;
            this.lbUpdateResult.BackColor = System.Drawing.Color.White;
            this.lbUpdateResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbUpdateResult.Location = new System.Drawing.Point(378, 79);
            this.lbUpdateResult.Name = "lbUpdateResult";
            this.lbUpdateResult.Size = new System.Drawing.Size(220, 36);
            this.lbUpdateResult.TabIndex = 2;
            this.lbUpdateResult.Text = "Update Result :";
            this.lbUpdateResult.Visible = false;
            // 
            // btnSTOPautoUpRoute
            // 
            this.btnSTOPautoUpRoute.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnSTOPautoUpRoute.Location = new System.Drawing.Point(199, 64);
            this.btnSTOPautoUpRoute.Name = "btnSTOPautoUpRoute";
            this.btnSTOPautoUpRoute.Size = new System.Drawing.Size(143, 63);
            this.btnSTOPautoUpRoute.TabIndex = 1;
            this.btnSTOPautoUpRoute.Text = "STOP";
            this.btnSTOPautoUpRoute.UseVisualStyleBackColor = true;
            this.btnSTOPautoUpRoute.Visible = false;
            this.btnSTOPautoUpRoute.Click += new System.EventHandler(this.btnSTOPautoUpRoute_Click);
            // 
            // btnSTARTautoUpRoute
            // 
            this.btnSTARTautoUpRoute.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnSTARTautoUpRoute.Location = new System.Drawing.Point(32, 64);
            this.btnSTARTautoUpRoute.Name = "btnSTARTautoUpRoute";
            this.btnSTARTautoUpRoute.Size = new System.Drawing.Size(143, 63);
            this.btnSTARTautoUpRoute.TabIndex = 0;
            this.btnSTARTautoUpRoute.Text = "START";
            this.btnSTARTautoUpRoute.UseVisualStyleBackColor = true;
            this.btnSTARTautoUpRoute.Visible = false;
            this.btnSTARTautoUpRoute.Click += new System.EventHandler(this.btnSTARTautoUpRoute_Click);
            // 
            // groupSerialPort
            // 
            this.groupSerialPort.Controls.Add(this.lbPort);
            this.groupSerialPort.Controls.Add(this.btnCloseSerialPort);
            this.groupSerialPort.Controls.Add(this.btnOpenSerialPort);
            this.groupSerialPort.Controls.Add(this.cbbPortList);
            this.groupSerialPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupSerialPort.Location = new System.Drawing.Point(991, 540);
            this.groupSerialPort.Name = "groupSerialPort";
            this.groupSerialPort.Size = new System.Drawing.Size(470, 226);
            this.groupSerialPort.TabIndex = 1;
            this.groupSerialPort.TabStop = false;
            this.groupSerialPort.Text = "Serial Port";
            this.groupSerialPort.Visible = false;
            this.groupSerialPort.Paint += new System.Windows.Forms.PaintEventHandler(this.groupSerialPort_Paint);
            // 
            // lbPort
            // 
            this.lbPort.AutoSize = true;
            this.lbPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbPort.Location = new System.Drawing.Point(54, 55);
            this.lbPort.Name = "lbPort";
            this.lbPort.Size = new System.Drawing.Size(86, 36);
            this.lbPort.TabIndex = 5;
            this.lbPort.Text = "Port :";
            this.lbPort.Visible = false;
            // 
            // btnCloseSerialPort
            // 
            this.btnCloseSerialPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnCloseSerialPort.Location = new System.Drawing.Point(227, 128);
            this.btnCloseSerialPort.Name = "btnCloseSerialPort";
            this.btnCloseSerialPort.Size = new System.Drawing.Size(143, 63);
            this.btnCloseSerialPort.TabIndex = 3;
            this.btnCloseSerialPort.Text = "Close";
            this.btnCloseSerialPort.UseVisualStyleBackColor = true;
            this.btnCloseSerialPort.Visible = false;
            this.btnCloseSerialPort.Click += new System.EventHandler(this.btnCloseSerialPort_Click);
            // 
            // btnOpenSerialPort
            // 
            this.btnOpenSerialPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnOpenSerialPort.Location = new System.Drawing.Point(60, 128);
            this.btnOpenSerialPort.Name = "btnOpenSerialPort";
            this.btnOpenSerialPort.Size = new System.Drawing.Size(143, 63);
            this.btnOpenSerialPort.TabIndex = 2;
            this.btnOpenSerialPort.Text = "Open";
            this.btnOpenSerialPort.UseVisualStyleBackColor = true;
            this.btnOpenSerialPort.Visible = false;
            this.btnOpenSerialPort.Click += new System.EventHandler(this.btnOpenSerialPort_Click);
            // 
            // cbbPortList
            // 
            this.cbbPortList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.cbbPortList.FormattingEnabled = true;
            this.cbbPortList.Location = new System.Drawing.Point(155, 52);
            this.cbbPortList.Name = "cbbPortList";
            this.cbbPortList.Size = new System.Drawing.Size(134, 44);
            this.cbbPortList.TabIndex = 0;
            this.cbbPortList.Visible = false;
            this.cbbPortList.SelectedIndexChanged += new System.EventHandler(this.cbbPortList_SelectedIndexChanged);
            this.cbbPortList.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cbbPortList_MouseClick);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // btnWriteBarCode
            // 
            this.btnWriteBarCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnWriteBarCode.Location = new System.Drawing.Point(914, 51);
            this.btnWriteBarCode.Name = "btnWriteBarCode";
            this.btnWriteBarCode.Size = new System.Drawing.Size(161, 55);
            this.btnWriteBarCode.TabIndex = 4;
            this.btnWriteBarCode.Text = "Write";
            this.btnWriteBarCode.UseVisualStyleBackColor = true;
            this.btnWriteBarCode.Click += new System.EventHandler(this.btnWriteBarCode_Click);
            // 
            // txtBoxWriteBarcode
            // 
            this.txtBoxWriteBarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxWriteBarcode.Location = new System.Drawing.Point(240, 58);
            this.txtBoxWriteBarcode.Name = "txtBoxWriteBarcode";
            this.txtBoxWriteBarcode.Size = new System.Drawing.Size(655, 41);
            this.txtBoxWriteBarcode.TabIndex = 9;
            this.txtBoxWriteBarcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoxWriteBarcode.TextChanged += new System.EventHandler(this.txtBoxWriteBarcode_TextChanged);
            this.txtBoxWriteBarcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxWriteBarcode_KeyPress);
            // 
            // groupRFID
            // 
            this.groupRFID.Controls.Add(this.lbBarcode);
            this.groupRFID.Controls.Add(this.txtBoxWriteBarcode);
            this.groupRFID.Controls.Add(this.btnWriteBarCode);
            this.groupRFID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupRFID.Location = new System.Drawing.Point(751, 141);
            this.groupRFID.Name = "groupRFID";
            this.groupRFID.Size = new System.Drawing.Size(1108, 121);
            this.groupRFID.TabIndex = 10;
            this.groupRFID.TabStop = false;
            this.groupRFID.Text = "RFID";
            this.groupRFID.Visible = false;
            this.groupRFID.Paint += new System.Windows.Forms.PaintEventHandler(this.groupRFID_Paint);
            // 
            // lbBarcode
            // 
            this.lbBarcode.AutoSize = true;
            this.lbBarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbBarcode.Location = new System.Drawing.Point(59, 58);
            this.lbBarcode.Name = "lbBarcode";
            this.lbBarcode.Size = new System.Drawing.Size(150, 36);
            this.lbBarcode.TabIndex = 10;
            this.lbBarcode.Text = "Barcode ::";
            // 
            // groupTableFunc
            // 
            this.groupTableFunc.Controls.Add(this.lbValueCheckResult);
            this.groupTableFunc.Controls.Add(this.lbCheckResult);
            this.groupTableFunc.Controls.Add(this.groupInterlockRoute);
            this.groupTableFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupTableFunc.Location = new System.Drawing.Point(45, 291);
            this.groupTableFunc.Name = "groupTableFunc";
            this.groupTableFunc.Size = new System.Drawing.Size(916, 221);
            this.groupTableFunc.TabIndex = 11;
            this.groupTableFunc.TabStop = false;
            this.groupTableFunc.Text = "Table Function";
            this.groupTableFunc.Paint += new System.Windows.Forms.PaintEventHandler(this.groupTableFunc_Paint);
            // 
            // lbValueCheckResult
            // 
            this.lbValueCheckResult.AutoSize = true;
            this.lbValueCheckResult.BackColor = System.Drawing.Color.White;
            this.lbValueCheckResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbValueCheckResult.Location = new System.Drawing.Point(736, 103);
            this.lbValueCheckResult.Name = "lbValueCheckResult";
            this.lbValueCheckResult.Size = new System.Drawing.Size(59, 48);
            this.lbValueCheckResult.TabIndex = 5;
            this.lbValueCheckResult.Text = "...";
            // 
            // lbCheckResult
            // 
            this.lbCheckResult.AutoSize = true;
            this.lbCheckResult.BackColor = System.Drawing.Color.White;
            this.lbCheckResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbCheckResult.Location = new System.Drawing.Point(496, 113);
            this.lbCheckResult.Name = "lbCheckResult";
            this.lbCheckResult.Size = new System.Drawing.Size(208, 36);
            this.lbCheckResult.TabIndex = 4;
            this.lbCheckResult.Text = "Check Result :";
            // 
            // groupInterlockRoute
            // 
            this.groupInterlockRoute.Controls.Add(this.checkInterlockRoute);
            this.groupInterlockRoute.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupInterlockRoute.Location = new System.Drawing.Point(74, 57);
            this.groupInterlockRoute.Name = "groupInterlockRoute";
            this.groupInterlockRoute.Size = new System.Drawing.Size(391, 139);
            this.groupInterlockRoute.TabIndex = 5;
            this.groupInterlockRoute.TabStop = false;
            this.groupInterlockRoute.Text = "Interlock Route";
            // 
            // checkInterlockRoute
            // 
            this.checkInterlockRoute.AutoSize = true;
            this.checkInterlockRoute.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.checkInterlockRoute.Location = new System.Drawing.Point(51, 68);
            this.checkInterlockRoute.Name = "checkInterlockRoute";
            this.checkInterlockRoute.Size = new System.Drawing.Size(140, 40);
            this.checkInterlockRoute.TabIndex = 0;
            this.checkInterlockRoute.Text = "Enable";
            this.checkInterlockRoute.UseVisualStyleBackColor = true;
            this.checkInterlockRoute.CheckedChanged += new System.EventHandler(this.checkInterlockRoute_CheckedChanged);
            // 
            // UpdateHomeUI
            // 
            this.UpdateHomeUI.Tick += new System.EventHandler(this.UpdateHomeUI_Tick);
            // 
            // uc_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.groupTableFunc);
            this.Controls.Add(this.groupRFID);
            this.Controls.Add(this.groupSerialPort);
            this.Controls.Add(this.groupIAIFunc);
            this.Controls.Add(this.lbReadFrom);
            this.Controls.Add(this.cbbDeviceList);
            this.Controls.Add(this.lbHOME);
            this.Margin = new System.Windows.Forms.Padding(7);
            this.Name = "uc_Home";
            this.Size = new System.Drawing.Size(1909, 1189);
            this.Load += new System.EventHandler(this.uc_Home_Load);
            this.groupIAIFunc.ResumeLayout(false);
            this.groupAutoChangeModel.ResumeLayout(false);
            this.groupAutoChangeModel.PerformLayout();
            this.groupAutoUpRoute.ResumeLayout(false);
            this.groupAutoUpRoute.PerformLayout();
            this.groupSerialPort.ResumeLayout(false);
            this.groupSerialPort.PerformLayout();
            this.groupRFID.ResumeLayout(false);
            this.groupRFID.PerformLayout();
            this.groupTableFunc.ResumeLayout(false);
            this.groupTableFunc.PerformLayout();
            this.groupInterlockRoute.ResumeLayout(false);
            this.groupInterlockRoute.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbHOME;
        private System.Windows.Forms.ComboBox cbbDeviceList;
        private System.Windows.Forms.Label lbReadFrom;
        private System.Windows.Forms.GroupBox groupIAIFunc;
        private System.Windows.Forms.GroupBox groupAutoChangeModel;
        private System.Windows.Forms.GroupBox groupAutoUpRoute;
        private System.Windows.Forms.GroupBox groupSerialPort;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button btnSTOPautoUpRoute;
        private System.Windows.Forms.Button btnSTARTautoUpRoute;
        private System.Windows.Forms.Button btnCloseSerialPort;
        private System.Windows.Forms.Button btnOpenSerialPort;
        private System.Windows.Forms.ComboBox cbbPortList;
        private System.Windows.Forms.Label lbValueCurrentModel;
        private System.Windows.Forms.Label lbCurrentModel;
        private System.Windows.Forms.CheckBox checkAutoChangeModel;
        private System.Windows.Forms.Label lbValueUpdateResult;
        private System.Windows.Forms.Label lbUpdateResult;
        private System.Windows.Forms.Label lbPort;
        private System.Windows.Forms.Button btnWriteBarCode;
        private System.Windows.Forms.TextBox txtBoxWriteBarcode;
        private System.Windows.Forms.GroupBox groupRFID;
        private System.Windows.Forms.Label lbBarcode;
        private System.Windows.Forms.GroupBox groupTableFunc;
        private System.Windows.Forms.GroupBox groupInterlockRoute;
        public System.Windows.Forms.CheckBox checkInterlockRoute;
        private System.Windows.Forms.Label lbCheckResult;
        private System.Windows.Forms.Timer UpdateHomeUI;
        public System.Windows.Forms.Label lbValueCheckResult;
    }
}
