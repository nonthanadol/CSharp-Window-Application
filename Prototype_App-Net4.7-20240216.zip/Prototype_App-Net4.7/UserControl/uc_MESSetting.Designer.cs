﻿namespace Prototype_App
{
    partial class uc_MESSetting
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbMESSetting = new System.Windows.Forms.Label();
            this.btnGetinfo = new System.Windows.Forms.Button();
            this.lbURL = new System.Windows.Forms.Label();
            this.lbKey = new System.Windows.Forms.Label();
            this.lbToken = new System.Windows.Forms.Label();
            this.lbFactory = new System.Windows.Forms.Label();
            this.lbSN = new System.Windows.Forms.Label();
            this.checkEnableMES = new System.Windows.Forms.CheckBox();
            this.txtBoxURL = new System.Windows.Forms.TextBox();
            this.txtBoxKey = new System.Windows.Forms.TextBox();
            this.txtBoxToken = new System.Windows.Forms.TextBox();
            this.txtBoxFactory = new System.Windows.Forms.TextBox();
            this.txtBoxSN = new System.Windows.Forms.TextBox();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtBoxModel = new System.Windows.Forms.TextBox();
            this.lbModel = new System.Windows.Forms.Label();
            this.lbMO = new System.Windows.Forms.Label();
            this.lbWipLine = new System.Windows.Forms.Label();
            this.txtBoxMO = new System.Windows.Forms.TextBox();
            this.txtBoxWipLine = new System.Windows.Forms.TextBox();
            this.lbWipSection = new System.Windows.Forms.Label();
            this.lbWipGroup = new System.Windows.Forms.Label();
            this.lbWipStation = new System.Windows.Forms.Label();
            this.txtBoxWipSection = new System.Windows.Forms.TextBox();
            this.txtBoxWipGroup = new System.Windows.Forms.TextBox();
            this.txtBoxWipStation = new System.Windows.Forms.TextBox();
            this.txtBoxSection = new System.Windows.Forms.TextBox();
            this.txtBoxStation = new System.Windows.Forms.TextBox();
            this.txtBoxGroup = new System.Windows.Forms.TextBox();
            this.lbSection = new System.Windows.Forms.Label();
            this.lbStation = new System.Windows.Forms.Label();
            this.lbGroup = new System.Windows.Forms.Label();
            this.btnROUTING_Check = new System.Windows.Forms.Button();
            this.btnROUTING_Update_PASS = new System.Windows.Forms.Button();
            this.groupMESinfo = new System.Windows.Forms.GroupBox();
            this.btnROUTING_Update_FAIL = new System.Windows.Forms.Button();
            this.txtBoxNextGroup = new System.Windows.Forms.TextBox();
            this.lbNextGroup = new System.Windows.Forms.Label();
            this.groupMESinfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbMESSetting
            // 
            this.lbMESSetting.BackColor = System.Drawing.SystemColors.Info;
            this.lbMESSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMESSetting.Location = new System.Drawing.Point(0, 0);
            this.lbMESSetting.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbMESSetting.Name = "lbMESSetting";
            this.lbMESSetting.Size = new System.Drawing.Size(1909, 116);
            this.lbMESSetting.TabIndex = 8;
            this.lbMESSetting.Text = "MESSetting";
            this.lbMESSetting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGetinfo
            // 
            this.btnGetinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnGetinfo.Location = new System.Drawing.Point(311, 761);
            this.btnGetinfo.Name = "btnGetinfo";
            this.btnGetinfo.Size = new System.Drawing.Size(254, 79);
            this.btnGetinfo.TabIndex = 9;
            this.btnGetinfo.Text = "Get info";
            this.btnGetinfo.UseVisualStyleBackColor = true;
            this.btnGetinfo.Click += new System.EventHandler(this.btnGetinfo_Click);
            // 
            // lbURL
            // 
            this.lbURL.AutoSize = true;
            this.lbURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbURL.Location = new System.Drawing.Point(90, 237);
            this.lbURL.Name = "lbURL";
            this.lbURL.Size = new System.Drawing.Size(126, 48);
            this.lbURL.TabIndex = 11;
            this.lbURL.Text = "URL :";
            // 
            // lbKey
            // 
            this.lbKey.AutoSize = true;
            this.lbKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbKey.Location = new System.Drawing.Point(101, 329);
            this.lbKey.Name = "lbKey";
            this.lbKey.Size = new System.Drawing.Size(115, 48);
            this.lbKey.TabIndex = 12;
            this.lbKey.Text = "Key :";
            // 
            // lbToken
            // 
            this.lbToken.AutoSize = true;
            this.lbToken.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbToken.Location = new System.Drawing.Point(57, 419);
            this.lbToken.Name = "lbToken";
            this.lbToken.Size = new System.Drawing.Size(159, 48);
            this.lbToken.TabIndex = 13;
            this.lbToken.Text = "Token :";
            // 
            // lbFactory
            // 
            this.lbFactory.AutoSize = true;
            this.lbFactory.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbFactory.Location = new System.Drawing.Point(33, 508);
            this.lbFactory.Name = "lbFactory";
            this.lbFactory.Size = new System.Drawing.Size(183, 48);
            this.lbFactory.TabIndex = 14;
            this.lbFactory.Text = "Factory :";
            // 
            // lbSN
            // 
            this.lbSN.AutoSize = true;
            this.lbSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbSN.Location = new System.Drawing.Point(183, 68);
            this.lbSN.Name = "lbSN";
            this.lbSN.Size = new System.Drawing.Size(101, 48);
            this.lbSN.TabIndex = 15;
            this.lbSN.Text = "SN :";
            // 
            // checkEnableMES
            // 
            this.checkEnableMES.AutoSize = true;
            this.checkEnableMES.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkEnableMES.Location = new System.Drawing.Point(222, 159);
            this.checkEnableMES.Margin = new System.Windows.Forms.Padding(7);
            this.checkEnableMES.Name = "checkEnableMES";
            this.checkEnableMES.Size = new System.Drawing.Size(283, 55);
            this.checkEnableMES.TabIndex = 16;
            this.checkEnableMES.Text = "EnableMES";
            this.checkEnableMES.UseVisualStyleBackColor = true;
            this.checkEnableMES.CheckedChanged += new System.EventHandler(this.checkEnableMES_CheckedChanged);
            // 
            // txtBoxURL
            // 
            this.txtBoxURL.Enabled = false;
            this.txtBoxURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxURL.Location = new System.Drawing.Point(228, 234);
            this.txtBoxURL.Name = "txtBoxURL";
            this.txtBoxURL.Size = new System.Drawing.Size(626, 55);
            this.txtBoxURL.TabIndex = 17;
            // 
            // txtBoxKey
            // 
            this.txtBoxKey.Enabled = false;
            this.txtBoxKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxKey.Location = new System.Drawing.Point(228, 326);
            this.txtBoxKey.Name = "txtBoxKey";
            this.txtBoxKey.Size = new System.Drawing.Size(626, 55);
            this.txtBoxKey.TabIndex = 18;
            // 
            // txtBoxToken
            // 
            this.txtBoxToken.Enabled = false;
            this.txtBoxToken.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxToken.Location = new System.Drawing.Point(228, 416);
            this.txtBoxToken.Name = "txtBoxToken";
            this.txtBoxToken.Size = new System.Drawing.Size(626, 55);
            this.txtBoxToken.TabIndex = 19;
            // 
            // txtBoxFactory
            // 
            this.txtBoxFactory.Enabled = false;
            this.txtBoxFactory.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxFactory.Location = new System.Drawing.Point(228, 508);
            this.txtBoxFactory.Name = "txtBoxFactory";
            this.txtBoxFactory.Size = new System.Drawing.Size(626, 55);
            this.txtBoxFactory.TabIndex = 20;
            // 
            // txtBoxSN
            // 
            this.txtBoxSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxSN.Location = new System.Drawing.Point(310, 68);
            this.txtBoxSN.Name = "txtBoxSN";
            this.txtBoxSN.Size = new System.Drawing.Size(626, 55);
            this.txtBoxSN.TabIndex = 21;
            // 
            // btnLoad
            // 
            this.btnLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoad.Location = new System.Drawing.Point(461, 936);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(7);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(189, 107);
            this.btnLoad.TabIndex = 23;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(227, 936);
            this.btnSave.Margin = new System.Windows.Forms.Padding(7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(189, 107);
            this.btnSave.TabIndex = 22;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtBoxModel
            // 
            this.txtBoxModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxModel.Location = new System.Drawing.Point(310, 157);
            this.txtBoxModel.Name = "txtBoxModel";
            this.txtBoxModel.Size = new System.Drawing.Size(626, 55);
            this.txtBoxModel.TabIndex = 24;
            // 
            // lbModel
            // 
            this.lbModel.AutoSize = true;
            this.lbModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbModel.Location = new System.Drawing.Point(120, 160);
            this.lbModel.Name = "lbModel";
            this.lbModel.Size = new System.Drawing.Size(157, 48);
            this.lbModel.TabIndex = 25;
            this.lbModel.Text = "Model :";
            // 
            // lbMO
            // 
            this.lbMO.AutoSize = true;
            this.lbMO.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbMO.Location = new System.Drawing.Point(170, 250);
            this.lbMO.Name = "lbMO";
            this.lbMO.Size = new System.Drawing.Size(111, 48);
            this.lbMO.TabIndex = 26;
            this.lbMO.Text = "MO :";
            // 
            // lbWipLine
            // 
            this.lbWipLine.AutoSize = true;
            this.lbWipLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbWipLine.Location = new System.Drawing.Point(82, 342);
            this.lbWipLine.Name = "lbWipLine";
            this.lbWipLine.Size = new System.Drawing.Size(195, 48);
            this.lbWipLine.TabIndex = 27;
            this.lbWipLine.Text = "WipLine :";
            // 
            // txtBoxMO
            // 
            this.txtBoxMO.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxMO.Location = new System.Drawing.Point(310, 250);
            this.txtBoxMO.Name = "txtBoxMO";
            this.txtBoxMO.Size = new System.Drawing.Size(626, 55);
            this.txtBoxMO.TabIndex = 28;
            // 
            // txtBoxWipLine
            // 
            this.txtBoxWipLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxWipLine.Location = new System.Drawing.Point(310, 342);
            this.txtBoxWipLine.Name = "txtBoxWipLine";
            this.txtBoxWipLine.Size = new System.Drawing.Size(626, 55);
            this.txtBoxWipLine.TabIndex = 29;
            // 
            // lbWipSection
            // 
            this.lbWipSection.AutoSize = true;
            this.lbWipSection.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbWipSection.Location = new System.Drawing.Point(21, 434);
            this.lbWipSection.Name = "lbWipSection";
            this.lbWipSection.Size = new System.Drawing.Size(256, 48);
            this.lbWipSection.TabIndex = 30;
            this.lbWipSection.Text = "WipSection :";
            // 
            // lbWipGroup
            // 
            this.lbWipGroup.AutoSize = true;
            this.lbWipGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbWipGroup.Location = new System.Drawing.Point(45, 521);
            this.lbWipGroup.Name = "lbWipGroup";
            this.lbWipGroup.Size = new System.Drawing.Size(232, 48);
            this.lbWipGroup.TabIndex = 31;
            this.lbWipGroup.Text = "WipGroup :";
            // 
            // lbWipStation
            // 
            this.lbWipStation.AutoSize = true;
            this.lbWipStation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbWipStation.Location = new System.Drawing.Point(36, 610);
            this.lbWipStation.Name = "lbWipStation";
            this.lbWipStation.Size = new System.Drawing.Size(247, 48);
            this.lbWipStation.TabIndex = 32;
            this.lbWipStation.Text = "WipStation :";
            // 
            // txtBoxWipSection
            // 
            this.txtBoxWipSection.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxWipSection.Location = new System.Drawing.Point(310, 431);
            this.txtBoxWipSection.Name = "txtBoxWipSection";
            this.txtBoxWipSection.Size = new System.Drawing.Size(626, 55);
            this.txtBoxWipSection.TabIndex = 33;
            // 
            // txtBoxWipGroup
            // 
            this.txtBoxWipGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxWipGroup.Location = new System.Drawing.Point(310, 518);
            this.txtBoxWipGroup.Name = "txtBoxWipGroup";
            this.txtBoxWipGroup.Size = new System.Drawing.Size(626, 55);
            this.txtBoxWipGroup.TabIndex = 34;
            // 
            // txtBoxWipStation
            // 
            this.txtBoxWipStation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxWipStation.Location = new System.Drawing.Point(310, 607);
            this.txtBoxWipStation.Name = "txtBoxWipStation";
            this.txtBoxWipStation.Size = new System.Drawing.Size(626, 55);
            this.txtBoxWipStation.TabIndex = 35;
            // 
            // txtBoxSection
            // 
            this.txtBoxSection.Enabled = false;
            this.txtBoxSection.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxSection.Location = new System.Drawing.Point(228, 664);
            this.txtBoxSection.Name = "txtBoxSection";
            this.txtBoxSection.Size = new System.Drawing.Size(626, 55);
            this.txtBoxSection.TabIndex = 36;
            // 
            // txtBoxStation
            // 
            this.txtBoxStation.Enabled = false;
            this.txtBoxStation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxStation.Location = new System.Drawing.Point(228, 831);
            this.txtBoxStation.Name = "txtBoxStation";
            this.txtBoxStation.Size = new System.Drawing.Size(626, 55);
            this.txtBoxStation.TabIndex = 37;
            // 
            // txtBoxGroup
            // 
            this.txtBoxGroup.Enabled = false;
            this.txtBoxGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxGroup.Location = new System.Drawing.Point(228, 749);
            this.txtBoxGroup.Name = "txtBoxGroup";
            this.txtBoxGroup.Size = new System.Drawing.Size(626, 55);
            this.txtBoxGroup.TabIndex = 38;
            // 
            // lbSection
            // 
            this.lbSection.AutoSize = true;
            this.lbSection.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbSection.Location = new System.Drawing.Point(33, 667);
            this.lbSection.Name = "lbSection";
            this.lbSection.Size = new System.Drawing.Size(183, 48);
            this.lbSection.TabIndex = 39;
            this.lbSection.Text = "Section :";
            // 
            // lbStation
            // 
            this.lbStation.AutoSize = true;
            this.lbStation.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbStation.Location = new System.Drawing.Point(42, 831);
            this.lbStation.Name = "lbStation";
            this.lbStation.Size = new System.Drawing.Size(174, 48);
            this.lbStation.TabIndex = 40;
            this.lbStation.Text = "Station :";
            // 
            // lbGroup
            // 
            this.lbGroup.AutoSize = true;
            this.lbGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbGroup.Location = new System.Drawing.Point(57, 749);
            this.lbGroup.Name = "lbGroup";
            this.lbGroup.Size = new System.Drawing.Size(159, 48);
            this.lbGroup.TabIndex = 41;
            this.lbGroup.Text = "Group :";
            // 
            // btnROUTING_Check
            // 
            this.btnROUTING_Check.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnROUTING_Check.Location = new System.Drawing.Point(584, 761);
            this.btnROUTING_Check.Name = "btnROUTING_Check";
            this.btnROUTING_Check.Size = new System.Drawing.Size(254, 79);
            this.btnROUTING_Check.TabIndex = 42;
            this.btnROUTING_Check.Text = "ROUTING_Check";
            this.btnROUTING_Check.UseVisualStyleBackColor = true;
            this.btnROUTING_Check.Click += new System.EventHandler(this.btnROUTING_Check_Click);
            // 
            // btnROUTING_Update_PASS
            // 
            this.btnROUTING_Update_PASS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnROUTING_Update_PASS.Location = new System.Drawing.Point(226, 864);
            this.btnROUTING_Update_PASS.Name = "btnROUTING_Update_PASS";
            this.btnROUTING_Update_PASS.Size = new System.Drawing.Size(339, 79);
            this.btnROUTING_Update_PASS.TabIndex = 43;
            this.btnROUTING_Update_PASS.Text = "ROUTING_Update_PASS";
            this.btnROUTING_Update_PASS.UseVisualStyleBackColor = true;
            this.btnROUTING_Update_PASS.Click += new System.EventHandler(this.btnROUTING_Update_PASS_Click);
            // 
            // groupMESinfo
            // 
            this.groupMESinfo.Controls.Add(this.btnROUTING_Update_FAIL);
            this.groupMESinfo.Controls.Add(this.txtBoxNextGroup);
            this.groupMESinfo.Controls.Add(this.lbNextGroup);
            this.groupMESinfo.Controls.Add(this.txtBoxWipLine);
            this.groupMESinfo.Controls.Add(this.btnROUTING_Update_PASS);
            this.groupMESinfo.Controls.Add(this.btnGetinfo);
            this.groupMESinfo.Controls.Add(this.btnROUTING_Check);
            this.groupMESinfo.Controls.Add(this.lbSN);
            this.groupMESinfo.Controls.Add(this.txtBoxSN);
            this.groupMESinfo.Controls.Add(this.txtBoxModel);
            this.groupMESinfo.Controls.Add(this.lbModel);
            this.groupMESinfo.Controls.Add(this.lbMO);
            this.groupMESinfo.Controls.Add(this.lbWipLine);
            this.groupMESinfo.Controls.Add(this.txtBoxMO);
            this.groupMESinfo.Controls.Add(this.txtBoxWipStation);
            this.groupMESinfo.Controls.Add(this.lbWipSection);
            this.groupMESinfo.Controls.Add(this.txtBoxWipGroup);
            this.groupMESinfo.Controls.Add(this.lbWipGroup);
            this.groupMESinfo.Controls.Add(this.txtBoxWipSection);
            this.groupMESinfo.Controls.Add(this.lbWipStation);
            this.groupMESinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.groupMESinfo.Location = new System.Drawing.Point(891, 147);
            this.groupMESinfo.Name = "groupMESinfo";
            this.groupMESinfo.Size = new System.Drawing.Size(980, 966);
            this.groupMESinfo.TabIndex = 45;
            this.groupMESinfo.TabStop = false;
            this.groupMESinfo.Text = "MES info";
            this.groupMESinfo.Paint += new System.Windows.Forms.PaintEventHandler(this.groupMESinfo_Paint);
            this.groupMESinfo.Enter += new System.EventHandler(this.groupMESinfo_Enter);
            // 
            // btnROUTING_Update_FAIL
            // 
            this.btnROUTING_Update_FAIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.btnROUTING_Update_FAIL.Location = new System.Drawing.Point(584, 864);
            this.btnROUTING_Update_FAIL.Name = "btnROUTING_Update_FAIL";
            this.btnROUTING_Update_FAIL.Size = new System.Drawing.Size(319, 79);
            this.btnROUTING_Update_FAIL.TabIndex = 46;
            this.btnROUTING_Update_FAIL.Text = "ROUTING_Update_FAIL";
            this.btnROUTING_Update_FAIL.UseVisualStyleBackColor = true;
            this.btnROUTING_Update_FAIL.Click += new System.EventHandler(this.btnROUTING_Update_FAIL_Click);
            // 
            // txtBoxNextGroup
            // 
            this.txtBoxNextGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.txtBoxNextGroup.Location = new System.Drawing.Point(310, 684);
            this.txtBoxNextGroup.Name = "txtBoxNextGroup";
            this.txtBoxNextGroup.Size = new System.Drawing.Size(626, 55);
            this.txtBoxNextGroup.TabIndex = 45;
            // 
            // lbNextGroup
            // 
            this.lbNextGroup.AutoSize = true;
            this.lbNextGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.lbNextGroup.Location = new System.Drawing.Point(28, 691);
            this.lbNextGroup.Name = "lbNextGroup";
            this.lbNextGroup.Size = new System.Drawing.Size(256, 48);
            this.lbNextGroup.TabIndex = 44;
            this.lbNextGroup.Text = "Next Group :";
            // 
            // uc_MESSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.groupMESinfo);
            this.Controls.Add(this.lbGroup);
            this.Controls.Add(this.lbStation);
            this.Controls.Add(this.lbSection);
            this.Controls.Add(this.txtBoxGroup);
            this.Controls.Add(this.txtBoxStation);
            this.Controls.Add(this.txtBoxSection);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtBoxFactory);
            this.Controls.Add(this.txtBoxToken);
            this.Controls.Add(this.txtBoxKey);
            this.Controls.Add(this.txtBoxURL);
            this.Controls.Add(this.checkEnableMES);
            this.Controls.Add(this.lbFactory);
            this.Controls.Add(this.lbToken);
            this.Controls.Add(this.lbKey);
            this.Controls.Add(this.lbURL);
            this.Controls.Add(this.lbMESSetting);
            this.Name = "uc_MESSetting";
            this.Size = new System.Drawing.Size(1909, 1189);
            this.Load += new System.EventHandler(this.uc_MESSetting_Load);
            this.groupMESinfo.ResumeLayout(false);
            this.groupMESinfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbMESSetting;
        private System.Windows.Forms.Button btnGetinfo;
        private System.Windows.Forms.Label lbURL;
        private System.Windows.Forms.Label lbKey;
        private System.Windows.Forms.Label lbToken;
        private System.Windows.Forms.Label lbFactory;
        private System.Windows.Forms.Label lbSN;
        private System.Windows.Forms.CheckBox checkEnableMES;
        private System.Windows.Forms.TextBox txtBoxURL;
        private System.Windows.Forms.TextBox txtBoxKey;
        private System.Windows.Forms.TextBox txtBoxToken;
        private System.Windows.Forms.TextBox txtBoxFactory;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtBoxModel;
        public System.Windows.Forms.TextBox txtBoxSN;
        private System.Windows.Forms.Label lbModel;
        private System.Windows.Forms.Label lbMO;
        private System.Windows.Forms.Label lbWipLine;
        private System.Windows.Forms.TextBox txtBoxMO;
        private System.Windows.Forms.TextBox txtBoxWipLine;
        private System.Windows.Forms.Label lbWipSection;
        private System.Windows.Forms.Label lbWipGroup;
        private System.Windows.Forms.Label lbWipStation;
        private System.Windows.Forms.TextBox txtBoxWipSection;
        private System.Windows.Forms.TextBox txtBoxWipGroup;
        private System.Windows.Forms.TextBox txtBoxWipStation;
        private System.Windows.Forms.TextBox txtBoxSection;
        private System.Windows.Forms.TextBox txtBoxStation;
        private System.Windows.Forms.TextBox txtBoxGroup;
        private System.Windows.Forms.Label lbSection;
        private System.Windows.Forms.Label lbStation;
        private System.Windows.Forms.Label lbGroup;
        private System.Windows.Forms.Button btnROUTING_Check;
        private System.Windows.Forms.Button btnROUTING_Update_PASS;
        private System.Windows.Forms.GroupBox groupMESinfo;
        private System.Windows.Forms.TextBox txtBoxNextGroup;
        private System.Windows.Forms.Label lbNextGroup;
        private System.Windows.Forms.Button btnROUTING_Update_FAIL;
    }
}
