﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prototype_App
{
    public partial class uc_PQMSetting : UserControl
    {
        iVariableShare _Common = new iVariableShare();
        public uc_PQMSetting(iVariableShare common)
        {
            InitializeComponent();
            _Common = common;
            _Common.iInterfaceID = Properties.Settings.Default.InterfaceID;
        }

        private void uc_PQMSetting_Load(object sender, EventArgs e)
        {
            txtBoxURL.Text = Properties.Settings.Default.PQM_URL;
            txtBoxInterfaceID.Text = Properties.Settings.Default.InterfaceID;
            checkEnablePQM.Checked = Properties.Settings.Default.EnablePQM;

        }

        public void Enable_textbox()
        {
            txtBoxInterfaceID.Enabled = true;
            txtBoxURL.Enabled = true;

        }

        private void checkMES_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.PQM_URL = txtBoxURL.Text;
            Properties.Settings.Default.InterfaceID = txtBoxInterfaceID.Text;
            Properties.Settings.Default.EnablePQM = checkEnablePQM.Checked;
            _Common.iInterfaceID = Properties.Settings.Default.InterfaceID;

            Properties.Settings.Default.Save();
        }

        private void lbLoad_Click(object sender, EventArgs e)
        {
            txtBoxURL.Text = Properties.Settings.Default.PQM_URL;
            txtBoxInterfaceID.Text = Properties.Settings.Default.InterfaceID;
            checkEnablePQM.Checked = Properties.Settings.Default.EnablePQM;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
