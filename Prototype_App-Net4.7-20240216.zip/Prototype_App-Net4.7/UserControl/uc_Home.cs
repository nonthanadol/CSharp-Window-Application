﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prototype_App
{
    public partial class uc_Home : UserControl
    {
        iVariableShare _Common = new iVariableShare();
        private clsIAIFunc _clsIAIfunc;
        private clsTableFunc _clsTableFunc;
        private clsPLC _clsPLC;

        string DispString;
        private CancellationTokenSource cancellationTokenSource1;
        private CancellationTokenSource cancellationTokenSource2;

        public uc_Home(iVariableShare common)
        {
            InitializeComponent();
            _Common = common;
            _Common.iEnablePLC = Properties.Settings.Default.EnablePLC;
            //cancellationTokenSource1 = new CancellationTokenSource();
            //cancellationTokenSource2 = new CancellationTokenSource();

            _clsIAIfunc = new clsIAIFunc(_Common);
            _clsTableFunc = new clsTableFunc(_Common);
            _clsPLC = new clsPLC(_Common);
           
        }
        private void uc_Home_Load(object sender, EventArgs e)
        {
            //bool[] enableFuncTable;
            //groupIAIFunc.Show();
            //groupSerialPort.Show();
          
            try
            {
                cbbPortList.Items.AddRange(SerialPort.GetPortNames());
                cbbPortList.SelectedIndex = 0;
            }
            catch { }

            if (Properties.Settings.Default.EnablePLC)
            {
                cbbDeviceList.SelectedIndex = 0;
                try 
                {
                    //_clsPLC.connectPLC();
                    //enableFuncTable = _Common.modbus.ReadCoils(Convert.ToInt32(Properties.Settings.Default.MenableFunc), 1);
                    //_Common.ienableFunc = enableFuncTable[0];
                } 
                catch { }

                //checkInterlockRoute.Checked = _Common.ienableFunc;
            }
            else
            {
                cbbDeviceList.SelectedIndex = 1;
            }

        }
        private void UpdateHomeUI_Tick(object sender, EventArgs e)
        {
            //lbValueCheckResult.Text = _Common.iMES_Result_Check;
        }
        private void cbbDeviceList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbbDeviceList.SelectedIndex == 0)
            {
                Properties.Settings.Default.EnablePLC = true;
                Properties.Settings.Default.EnableLog = false;
                _Common.iEnablePLC = true;

            }
            else
            {
                Properties.Settings.Default.EnableLog = true;
                Properties.Settings.Default.EnablePLC = false;
                _Common.iEnablePLC = false;

            }

            Properties.Settings.Default.Save();
        }

        #region Serial Port
        private void cbbPortList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbbPortList_MouseClick(object sender, MouseEventArgs e)
        {
            cbbPortList.Items.Clear();
            try
            {
                cbbPortList.Items.AddRange(SerialPort.GetPortNames());
                cbbPortList.SelectedIndex = 0;
            }
            catch { }
        }
        private void btnOpenSerialPort_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName = cbbPortList.Text;
                serialPort1.BaudRate = 9600;
                serialPort1.Open();

            }
            catch
            {

            }
        }
        private void btnCloseSerialPort_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();

            }
            catch { }
        }
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            DispString = serialPort1.ReadExisting();
            this.Invoke(new EventHandler(DisplayText));

        }
        private void DisplayText(object sender, EventArgs e)
        {
            Console.WriteLine(DispString);
        }



        #endregion

        #region autoUpdateRoute
        private async void btnSTARTautoUpRoute_Click(object sender, EventArgs e)
        {
            btnSTARTautoUpRoute.Enabled = false;
            btnSTOPautoUpRoute.Enabled = true;
            cancellationTokenSource1 = new CancellationTokenSource();
            try
            {
                // Run the loop on a separate thread
                await Task.Run(() => _clsIAIfunc.IAIMain(cancellationTokenSource1.Token));
            }
            catch (OperationCanceledException)
            {
                // Task was canceled
            }
            finally
            {
                // Re-enable Button1
                btnSTARTautoUpRoute.Enabled = true;
            }
            //_clsIAIfunc.callIAIMain();
        }

        private void btnSTOPautoUpRoute_Click(object sender, EventArgs e)
        {
            cancellationTokenSource1?.Cancel();
            btnSTOPautoUpRoute.Enabled = false;
        }

        #endregion

        #region RFID
        private void btnWriteBarCode_Click(object sender, EventArgs e)
        {
            if (_Common.iPLCconnectStatus == "Connected")
            {
                _clsPLC.writeRFID(txtBoxWriteBarcode.Text);
            }
            else { MessageBox.Show("error"); }
        }
        private void txtBoxWriteBarcode_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void txtBoxWriteBarcode_KeyPress(object sender, KeyPressEventArgs e)
        {     
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (_Common.iPLCconnectStatus == "Connected")
                {
                    _clsPLC.writeRFID(txtBoxWriteBarcode.Text);
                }
                else { MessageBox.Show("error"); }
            }
        }

        #endregion

        #region Table Function
        private async void checkInterlockRoute_CheckedChanged(object sender, EventArgs e)
        {
            
            if (checkInterlockRoute.Checked == true) 
            {
                cancellationTokenSource2 = new CancellationTokenSource();
                try { _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MenableFunc), true); } catch { }
                
                try
                {
                    // Run the loop on a separate thread
                    await Task.Run(() => _clsTableFunc.TableMain(cancellationTokenSource2.Token));

                }
                catch (OperationCanceledException)
                {
                    // Task was canceled
                    _Common.mesChkFlag = false;
                    //Console.WriteLine("catch");
                }
                finally
                {
                    // Re-enable Button1
                    //btnSTARTautoUpRoute.Enabled = true;
                    //Console.WriteLine("finally");
                    _Common.mesChkFlag = false;
                }


            }
            else
            {      
                try { _Common.modbus.WriteSingleCoil(Convert.ToInt32(Properties.Settings.Default.MenableFunc), false); } catch { }
                cancellationTokenSource2?.Cancel();
                _Common.mesChkFlag = false;
            }
        }

        #endregion

        #region Appearance
        private void DrawGroupBox(GroupBox box, Graphics g, Color textColor, Color borderColor)
        {
            if (box != null)
            {
                Brush textBrush = new SolidBrush(textColor);
                Brush borderBrush = new SolidBrush(borderColor);
                Pen borderPen = new Pen(borderBrush);
                SizeF strSize = g.MeasureString(box.Text, box.Font);
                Rectangle rect = new Rectangle(box.ClientRectangle.X,
                                               box.ClientRectangle.Y + (int)(strSize.Height / 2),
                                               box.ClientRectangle.Width - 1,
                                               box.ClientRectangle.Height - (int)(strSize.Height / 2) - 1);

                // Clear text and border
                g.Clear(this.BackColor);

                // Draw text
                g.DrawString(box.Text, box.Font, textBrush, box.Padding.Left, 0);

                // Drawing Border
                //Left
                g.DrawLine(borderPen, rect.Location, new Point(rect.X, rect.Y + rect.Height));
                //Right
                g.DrawLine(borderPen, new Point(rect.X + rect.Width, rect.Y), new Point(rect.X + rect.Width, rect.Y + rect.Height));
                //Bottom
                g.DrawLine(borderPen, new Point(rect.X, rect.Y + rect.Height), new Point(rect.X + rect.Width, rect.Y + rect.Height));
                //Top1
                g.DrawLine(borderPen, new Point(rect.X, rect.Y), new Point(rect.X + box.Padding.Left, rect.Y));
                //Top2
                g.DrawLine(borderPen, new Point(rect.X + box.Padding.Left + (int)(strSize.Width), rect.Y), new Point(rect.X + rect.Width, rect.Y));
            }


        }

        
        private void groupIAIFunc_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.Black, Color.CadetBlue);
        }
        
        private void groupRFID_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.Black, Color.CadetBlue);
        }
        private void groupSerialPort_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.Black, Color.CadetBlue);
        }
        
        private void groupTableFunc_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.Black, Color.CadetBlue);
        }

        #endregion
    }
}
