﻿namespace Prototype_App
{
    partial class uc_PQMSetting
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbPQMSetting = new System.Windows.Forms.Label();
            this.lbURL = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxURL = new System.Windows.Forms.TextBox();
            this.txtBoxInterfaceID = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lbLoad = new System.Windows.Forms.Button();
            this.checkEnablePQM = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lbPQMSetting
            // 
            this.lbPQMSetting.BackColor = System.Drawing.SystemColors.Info;
            this.lbPQMSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPQMSetting.Location = new System.Drawing.Point(0, 0);
            this.lbPQMSetting.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbPQMSetting.Name = "lbPQMSetting";
            this.lbPQMSetting.Size = new System.Drawing.Size(1909, 116);
            this.lbPQMSetting.TabIndex = 7;
            this.lbPQMSetting.Text = "PQMSetting";
            this.lbPQMSetting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbURL
            // 
            this.lbURL.AutoSize = true;
            this.lbURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbURL.Location = new System.Drawing.Point(380, 225);
            this.lbURL.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbURL.Name = "lbURL";
            this.lbURL.Size = new System.Drawing.Size(131, 51);
            this.lbURL.TabIndex = 8;
            this.lbURL.Text = "URL :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(259, 328);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 51);
            this.label1.TabIndex = 9;
            this.label1.Text = "InterfaceID :";
            // 
            // txtBoxURL
            // 
            this.txtBoxURL.Enabled = false;
            this.txtBoxURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxURL.Location = new System.Drawing.Point(525, 225);
            this.txtBoxURL.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxURL.Name = "txtBoxURL";
            this.txtBoxURL.Size = new System.Drawing.Size(790, 56);
            this.txtBoxURL.TabIndex = 10;
            // 
            // txtBoxInterfaceID
            // 
            this.txtBoxInterfaceID.Enabled = false;
            this.txtBoxInterfaceID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxInterfaceID.Location = new System.Drawing.Point(525, 328);
            this.txtBoxInterfaceID.Margin = new System.Windows.Forms.Padding(7);
            this.txtBoxInterfaceID.Name = "txtBoxInterfaceID";
            this.txtBoxInterfaceID.Size = new System.Drawing.Size(790, 56);
            this.txtBoxInterfaceID.TabIndex = 11;
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(681, 582);
            this.btnSave.Margin = new System.Windows.Forms.Padding(7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(189, 107);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lbLoad
            // 
            this.lbLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLoad.Location = new System.Drawing.Point(915, 582);
            this.lbLoad.Margin = new System.Windows.Forms.Padding(7);
            this.lbLoad.Name = "lbLoad";
            this.lbLoad.Size = new System.Drawing.Size(189, 107);
            this.lbLoad.TabIndex = 13;
            this.lbLoad.Text = "Load";
            this.lbLoad.UseVisualStyleBackColor = true;
            this.lbLoad.Click += new System.EventHandler(this.lbLoad_Click);
            // 
            // checkEnablePQM
            // 
            this.checkEnablePQM.AutoSize = true;
            this.checkEnablePQM.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkEnablePQM.Location = new System.Drawing.Point(525, 142);
            this.checkEnablePQM.Margin = new System.Windows.Forms.Padding(7);
            this.checkEnablePQM.Name = "checkEnablePQM";
            this.checkEnablePQM.Size = new System.Drawing.Size(287, 55);
            this.checkEnablePQM.TabIndex = 17;
            this.checkEnablePQM.Text = "EnablePQM";
            this.checkEnablePQM.UseVisualStyleBackColor = true;
            // 
            // uc_PQMSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.checkEnablePQM);
            this.Controls.Add(this.lbLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtBoxInterfaceID);
            this.Controls.Add(this.txtBoxURL);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbURL);
            this.Controls.Add(this.lbPQMSetting);
            this.Margin = new System.Windows.Forms.Padding(7);
            this.Name = "uc_PQMSetting";
            this.Size = new System.Drawing.Size(1909, 1189);
            this.Load += new System.EventHandler(this.uc_PQMSetting_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbPQMSetting;
        private System.Windows.Forms.Label lbURL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxURL;
        private System.Windows.Forms.TextBox txtBoxInterfaceID;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button lbLoad;
        private System.Windows.Forms.CheckBox checkEnablePQM;
    }
}
