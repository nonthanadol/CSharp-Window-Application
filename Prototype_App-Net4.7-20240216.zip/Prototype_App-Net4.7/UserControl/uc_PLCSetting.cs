﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Prototype_App
{
    public partial class uc_PLCSetting : UserControl
    {
        private clsPLC _clsPlc;
        iVariableShare _Common = new iVariableShare();
        private CancellationTokenSource cancellationTokenSource;
        public uc_PLCSetting(iVariableShare common)
        {
            InitializeComponent();

            _Common = common;       
            _clsPlc = new clsPLC(_Common);
            cancellationTokenSource = new CancellationTokenSource();

        }

        private void uc_PLCSetting_Load(object sender, EventArgs e)
        {
            txtBoxIPAddress.Text = Properties.Settings.Default.IPAddress;
            txtBoxDstatus.Text = Properties.Settings.Default.Dstatus;
            txtBoxDstatusCode.Text = Properties.Settings.Default.DstatusCode;
            txtBoxDpassQty.Text = Properties.Settings.Default.DpassQty;
            txtBoxDfailQty.Text = Properties.Settings.Default.DfailQty;
            txtBoxDerrCnt.Text = Properties.Settings.Default.DerrorCnt;
            txtBoxDselfCheck.Text = Properties.Settings.Default.DselfCheck;
            txtBoxDcycleTime.Text = Properties.Settings.Default.DcycleTime;
            txtBoxDrunningTime.Text = Properties.Settings.Default.DrunningTime;
            txtBoxDwaitingTime.Text = Properties.Settings.Default.DwaitingTime;
            txtBoxDerrTime.Text = Properties.Settings.Default.DerrTime;
            txtBoxDbarcode.Text = Properties.Settings.Default.Dbarcode;
            txtBoxDupdateResult.Text = Properties.Settings.Default.DupdateResult;
            txtBoxMenableFunc.Text = Properties.Settings.Default.MenableFunc;
            txtBoxMprocessFinish.Text = Properties.Settings.Default.MprocessFinish;
            txtBoxMflagChkResult.Text = Properties.Settings.Default.MflagChkResult;
            txtBoxMflagChkResultNG.Text = Properties.Settings.Default.MflagChkResultNG;

        }
        public void Enable_textbox() 
        {
            txtBoxIPAddress.Enabled = true;
            txtBoxDstatus.Enabled = true;
            txtBoxDstatusCode.Enabled = true;
            txtBoxDpassQty.Enabled = true;
            txtBoxDfailQty.Enabled = true;
            txtBoxDerrCnt.Enabled = true;
            txtBoxDselfCheck.Enabled = true;
            txtBoxDcycleTime.Enabled = true;
            txtBoxDrunningTime.Enabled = true;
            txtBoxDwaitingTime.Enabled = true;
            txtBoxDerrTime.Enabled = true;
            txtBoxDbarcode.Enabled = true;
            txtBoxDupdateResult.Enabled = true;
            txtBoxMenableFunc.Enabled = true;
            txtBoxMprocessFinish.Enabled = true;
            txtBoxMflagChkResult.Enabled = true;
            txtBoxMflagChkResultNG.Enabled = true;
        }

        private async void btnConnect_Click(object sender, EventArgs e)
        {
            btnConnect.Enabled = false;
            btnDisconnect.Enabled = true;

            if (_Common.iEnablePLC)
            {
                _clsPlc.connectPLC();

                if (_Common.modbus.Connected) { btnConnect.Enabled = false; }
                else { btnConnect.Enabled = true; }

                try
                {
                    await Task.Run(() => _clsPlc.ReadStatusThread(cancellationTokenSource.Token));
                    
                }
                catch (OperationCanceledException) { }
                //finally{btnConnect.Enabled = true;}

            }

        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            _clsPlc.disconnectPLC();
            _clsPlc.StopReadStatusThread();

            btnDisconnect.Enabled = false;
            btnConnect.Enabled = true;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbDfailQty_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.IPAddress = txtBoxIPAddress.Text;
            Properties.Settings.Default.Dstatus = txtBoxDstatus.Text;
            Properties.Settings.Default.DstatusCode = txtBoxDstatusCode.Text;
            Properties.Settings.Default.DpassQty = txtBoxDpassQty.Text;
            Properties.Settings.Default.DfailQty = txtBoxDfailQty.Text;
            Properties.Settings.Default.DerrorCnt = txtBoxDerrCnt.Text;
            Properties.Settings.Default.DselfCheck = txtBoxDselfCheck.Text;
            Properties.Settings.Default.DcycleTime = txtBoxDcycleTime.Text;
            Properties.Settings.Default.DrunningTime = txtBoxDrunningTime.Text;
            Properties.Settings.Default.DwaitingTime = txtBoxDwaitingTime.Text;
            Properties.Settings.Default.DerrTime = txtBoxDerrTime.Text;
            Properties.Settings.Default.Dbarcode = txtBoxDbarcode.Text;
            Properties.Settings.Default.DupdateResult = txtBoxDupdateResult.Text;
            Properties.Settings.Default.MenableFunc = txtBoxMenableFunc.Text;
            Properties.Settings.Default.MprocessFinish = txtBoxMprocessFinish.Text;
            Properties.Settings.Default.MflagChkResult = txtBoxMflagChkResult.Text;
            Properties.Settings.Default.MflagChkResultNG = txtBoxMflagChkResultNG.Text;

            Properties.Settings.Default.Save();
        }

        private void lbLoad_Click(object sender, EventArgs e)
        {
            txtBoxIPAddress.Text = Properties.Settings.Default.IPAddress;
            txtBoxDstatus.Text = Properties.Settings.Default.Dstatus;
            txtBoxDstatusCode.Text = Properties.Settings.Default.DstatusCode;
            txtBoxDpassQty.Text = Properties.Settings.Default.DpassQty;
            txtBoxDfailQty.Text = Properties.Settings.Default.DfailQty;
            txtBoxDerrCnt.Text = Properties.Settings.Default.DerrorCnt;
            txtBoxDselfCheck.Text = Properties.Settings.Default.DselfCheck;
            txtBoxDcycleTime.Text = Properties.Settings.Default.DcycleTime;
            txtBoxDrunningTime.Text = Properties.Settings.Default.DrunningTime;
            txtBoxDwaitingTime.Text = Properties.Settings.Default.DwaitingTime;
            txtBoxDerrTime.Text = Properties.Settings.Default.DerrTime;
            txtBoxDbarcode.Text = Properties.Settings.Default.Dbarcode;
            txtBoxDupdateResult.Text = Properties.Settings.Default.DupdateResult;
            txtBoxMenableFunc.Text = Properties.Settings.Default.MenableFunc;
            txtBoxMprocessFinish.Text = Properties.Settings.Default.MprocessFinish;
            txtBoxMflagChkResult.Text = Properties.Settings.Default.MflagChkResult;
            txtBoxMflagChkResultNG.Text = Properties.Settings.Default.MflagChkResultNG;

        }
    }
}
