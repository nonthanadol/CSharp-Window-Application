﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EasyModbus;
using Microsoft.Win32;
using System.Threading;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Prototype_App_MES;

namespace Prototype_App
{
    public class clsPLC
    {

        iVariableShare _Common = new iVariableShare();
        clsTool _Tool = new clsTool();
        //private uc_Home _home;

        int[] status;
        int[] statusCode;
        int[] passQty;
        int[] failQty;
        int[] errorCnt;
        int[] selfCheck;
        int[] cycleTime;
        int[] RunningTime;
        int[] WaitingTime;
        int[] errTime;
        int[] raw_Barcode;
        string Barcode;

        bool[] ProcessFinish;
        bool[] enableFunc;

        private CancellationTokenSource cancellationTokenSource;

        public clsPLC(iVariableShare common)
        {
            _Common = common;
            cancellationTokenSource = new CancellationTokenSource();

        }
        public void PLC_Initialize()
        {
            _Common.modbus = new ModbusClient();
        }
        public void StopReadStatusThread()
        {
            cancellationTokenSource?.Cancel();
        }

        public void ReadStatusThread(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    if (_Common.modbus.Connected == true)
                    {
                        readRegister();
                    }
                    else
                    {
                        StopReadStatusThread();
                    }
                }
                catch (ThreadAbortException)
                {

                }
                Thread.Sleep(1);
            }
        }
        public void connectPLC()
        {

            string ip = Properties.Settings.Default.IPAddress;
            string port = "502";


            _Common.modbus.IPAddress = ip; // IP PLC
            _Common.modbus.Port = Convert.ToInt32(port);

            try
            {
                _Common.modbus.Connect();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            if (_Common.modbus.Connected == true)
            {
                _Common.iPLCconnectStatus = "Connected";

            }
            else
            {
                _Common.iPLCconnectStatus = "Connect Fail!!";

            }

        }

        public void disconnectPLC()
        {

            _Common.modbus.Disconnect();
            _Common.iPLCconnectStatus = "Disconnect!!";

        }
        public void readRegister()
        {

            try
            {
                if (_Common.modbus.Connected == true)
                {

                    //bool[] X = obj_modbus.ReadDiscreteInputs(1025, 2); // ReadCoils(1025, 2);
                    status = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.Dstatus), 1);
                    statusCode = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.DstatusCode), 1);
                    //passQty = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.DpassQty), 1);
                    //failQty = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.DfailQty), 1);
                    //errorCnt = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.DerrorCnt), 1);
                    //selfCheck = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.DselfCheck), 1);
                    //cycleTime = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.DcycleTime), 2);
                    //RunningTime = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.DrunningTime), 2);
                    //WaitingTime = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.DwaitingTime), 2);
                    //errTime = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.DerrTime), 2);

                    ProcessFinish = _Common.modbus.ReadCoils(Convert.ToInt32(Properties.Settings.Default.MprocessFinish), 1);
                    enableFunc = _Common.modbus.ReadCoils(Convert.ToInt32(Properties.Settings.Default.MenableFunc), 1);

                    if (Properties.Settings.Default.EnableMES == true)
                    {
                        try
                        {
                            raw_Barcode = _Common.modbus.ReadHoldingRegisters(Convert.ToInt32(Properties.Settings.Default.Dbarcode), 9);
                            Barcode = _Tool.ConvertArrayIntToAsciiText(raw_Barcode);
                            _Common.iRFID_Barcode = Barcode;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        //Console.WriteLine("Enable MES" + _Common.iRFID_Barcode + "##");
                    }

                    /*
                    int CycleTmr1 = cycleTime[0];
                    int CycleTmr2 = cycleTime[1];

                    uint DWcycleTime = (uint)((CycleTmr2 << 16) | CycleTmr1);
                    */

                   //uint DWcycleTime = _Tool.combineWord(cycleTime[0], cycleTime[1]);
                    //uint DWRunningTime = _Tool.combineWord(RunningTime[0], RunningTime[1]);
                    //uint DWWaitingTime = _Tool.combineWord(WaitingTime[0], WaitingTime[1]);
                    //uint DWerrTime = _Tool.combineWord(errTime[0], errTime[1]);

                    _Common.iPQM_Status = status[0];
                    _Common.iPQM_Status_Code = Convert.ToString(statusCode[0]);
                    //_Common.iPQM_PassQty = passQty[0];
                    //_Common.iPQM_FailQty = failQty[0];
                    //_Common.iPQM_Error_Count = errorCnt[0];
                    //_Common.iPQM_Self_Check = selfCheck[0];
                    //_Common.iPQM_Cycle_Time = DWcycleTime;
                    //_Common.iPQM_Running_Time = DWRunningTime;
                    //_Common.iPQM_Waiting_Time = DWWaitingTime;
                   //_Common.iPQM_Error_Time = DWerrTime;

                    _Common.iProcessFinish = ProcessFinish[0];
                    _Common.ienableFunc = enableFunc[0];
                     //Console.WriteLine("iProcessFinish" + _Common.iProcessFinish);

                }
                else
                {
                    _Common.iPLCconnectStatus = "Disconnect!!";
                    StopReadStatusThread();

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void writeRFID(string asciiText)
        {
            int[] Writebarcode;

            Writebarcode = _Tool.ConvertAsciiTextToArrayInt(asciiText);
            _Common.modbus.WriteMultipleRegisters(Convert.ToInt32(Properties.Settings.Default.Dbarcode), Writebarcode);

        }
      
    }
}